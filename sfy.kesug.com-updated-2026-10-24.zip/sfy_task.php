<?php
declare(strict_types=1);
/** Legacy path → /go/<session> (pages/task.php). */
require __DIR__ . '/pages/task.php';
