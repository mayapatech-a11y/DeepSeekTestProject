<?php
declare(strict_types=1);
/** Hub panel → Overview. */

$s       = sfy_hub_settings();
$scripts = sfy_hub_scripts_count(['status' => 'published']);
$drafts  = sfy_hub_scripts_count(['status' => 'draft']);
$games   = count(sfy_hub_games(200));
$offers  = sfy_hub_offers(false);
$active  = count(array_filter($offers, fn($o) => (int)$o['is_active'] === 1));
$ord     = sfy_hub_order_stats();
$msgs    = sfy_hub_message_stats();

/* Health: does every table and column the module declares really exist? */
$health = sfy_try(function (): array {
    $missingTables = [];
    $missingCols   = [];
    foreach (sfy_hub_tables() as $table => $ddl) {
        if (!sfy_table_exists($table)) { $missingTables[] = $table; continue; }
        foreach (sfy_schema_defined_columns($ddl) as $col => $def) {
            if (preg_match('/AUTO_INCREMENT|PRIMARY KEY/i', $def)) continue;
            if (!sfy_column_exists($table, $col)) $missingCols[] = $table . '.' . $col;
        }
    }
    return ['tables' => $missingTables, 'cols' => $missingCols];
}, ['tables' => [], 'cols' => []]);

$ok = !$health['tables'] && !$health['cols'];
?>

<div class="hub-grid-3" style="margin-bottom:var(--gap)">
  <?= sfy_kpi('Scripts live', number_format($scripts), 'g', $drafts > 0 ? number_format($drafts) . ' draft(s) waiting' : 'no drafts') ?>
  <?= sfy_kpi('Games covered', number_format($games), 'blue', 'distinct game names') ?>
  <?= sfy_kpi('Offers on sale', number_format($active) . ' / ' . count($offers), 'gold', 'active / total') ?>
  <?= sfy_kpi('Orders pending', number_format((int)$ord['pending']), 'orange', number_format((int)$ord['total']) . ' placed all time') ?>
  <?= sfy_kpi('Keys delivered', number_format((int)$ord['delivered']), 'g', sfy_hub_money($ord['value']) . ' marked as paid') ?>
  <?= sfy_kpi('Inbox unread', number_format((int)$msgs['new']), 'red', number_format((int)$msgs['total']) . ' message(s) total') ?>
</div>

<div class="hub-grid-2">
  <div class="card">
    <div class="card-head">
      <h2>&gt; HUB_TABLES</h2><span class="spacer"></span>
      <span class="badge <?= $ok ? 'g' : 'r' ?>"><?= $ok ? '✓ READY' : '✖ INCOMPLETE' ?></span>
    </div>
    <?php if ($ok): ?>
      <p class="small dim" style="margin:0">
        All four tables and every column are present. The module installs and repairs its own schema, so this
        section never needs the main Updater.
      </p>
    <?php else: ?>
      <div class="msg warn" style="margin-bottom:11px">
        ◆
        <?php if ($health['tables']): ?>Missing table(s): <?= sfy_esc(implode(', ', $health['tables'])) ?>. <?php endif; ?>
        <?php if ($health['cols']): ?>Missing column(s): <?= sfy_esc(implode(', ', array_slice($health['cols'], 0, 6))) ?><?= count($health['cols']) > 6 ? ' …' : '' ?>. <?php endif; ?>
      </div>
      <?php if (sfy_admin_can('updater')): ?>
        <form method="POST" data-hub-once>
          <?= sfy_csrf_field() ?>
          <input type="hidden" name="action" value="install">
          <button class="btn btn-primary" data-busy="INSTALLING…">⬆ CREATE / REPAIR HUB TABLES</button>
        </form>
      <?php endif; ?>
    <?php endif; ?>

    <table class="hub-table-mini" style="margin-top:14px">
      <tr><th>Table</th><th>Purpose</th><th>Rows</th></tr>
      <?php foreach (['sfy_hub_scripts' => 'Script cards', 'sfy_hub_offers' => 'Premium plans',
                      'sfy_hub_orders' => 'Buy-page requests', 'sfy_hub_messages' => 'Suggestions + support'] as $t => $what):
            $n = (int)sfy_try(fn() => (int)(sfy_db()->query("SELECT COUNT(*) AS n FROM `$t`")->fetch()['n'] ?? 0), 0); ?>
        <tr><td class="mono"><?= sfy_esc($t) ?></td><td><?= sfy_esc($what) ?></td><td class="mono"><?= number_format($n) ?></td></tr>
      <?php endforeach; ?>
    </table>
  </div>

  <div class="card">
    <div class="card-head"><h2>&gt; THEME_LINK</h2></div>
    <p class="small dim" style="margin-top:0">
      The hub has no theme of its own: it prints the install's appearance layer and its own sizing on top.
      Pick a palette in <b>Admin → Appearance</b> and the hub follows instantly — the two screens below are
      the only hub-specific controls.
    </p>
    <table class="hub-table-mini">
      <tr><th>Layer</th><th>Where</th></tr>
      <tr><td>Palette, fonts, radius, glow, motion</td>
          <td><a href="<?= sfy_esc(sfy_admin_url(['tab' => 'appearance'])) ?>">Main Admin → Appearance</a></td></tr>
      <tr><td>Hub width, columns, card + image + type size</td>
          <td><a href="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'appearance'])) ?>">Here → Appearance</a></td></tr>
      <tr><td>Homepage link in the menu / footer</td>
          <td><a href="<?= sfy_esc(sfy_admin_url(['tab' => 'appearance'])) ?>#footer">Main Admin → Footer</a></td></tr>
      <tr><td>Ads pointing at the buy page</td>
          <td><a href="<?= sfy_esc(sfy_admin_url(['tab' => 'ads'])) ?>">Main Admin → Ads</a> → target
              <span class="mono"><?= sfy_esc(sfy_hub_url('offers')) ?></span></td></tr>
    </table>
  </div>
</div>

<div class="card">
  <div class="card-head"><h2>&gt; QUICK_ACTIONS</h2></div>
  <div class="btn-row">
    <a class="btn btn-primary" href="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'import'])) ?>">📥 IMPORT FROM A LINK</a>
    <a class="btn" href="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'script'])) ?>">✎ NEW SCRIPT BY HAND</a>
    <a class="btn" href="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'offers'])) ?>">⚡ MANAGE OFFERS</a>
    <a class="btn" href="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'inbox'])) ?>">✉ OPEN THE INBOX</a>
    <a class="btn btn-ghost" href="<?= sfy_esc(sfy_hub_url()) ?>" target="_blank" rel="noopener">↗ VIEW THE HUB</a>
  </div>

  <hr class="sep">

  <div class="card-head" style="border:0;padding:0;margin-bottom:8px"><h2>&gt; MODULE_MAP</h2></div>
  <p class="small dim" style="margin-top:0">
    Everything this module owns is under <span class="mono">/hub/</span> — updating it means replacing that one
    folder, and deleting it removes the module without touching the rest of the site.
  </p>
  <table class="hub-table-mini">
    <tr><th>Path</th><th>What it is</th></tr>
    <tr><td class="mono">hub/index.php</td><td>Public front controller (?p=…)</td></tr>
    <tr><td class="mono">hub/views/</td><td>Home, scripts, script, offers, buy, contact, suggest</td></tr>
    <tr><td class="mono">hub/lib/</td><td>Settings, installer, queries, forms, importer, UI</td></tr>
    <tr><td class="mono">hub/admin/</td><td>This panel</td></tr>
    <tr><td class="mono">hub/assets/</td><td>hub.css (theme variables only) + hub.js (enhancements only)</td></tr>
    <tr><td class="mono">app/theme.php</td><td>The only file outside the folder: two links in the header and footer</td></tr>
  </table>
</div>
