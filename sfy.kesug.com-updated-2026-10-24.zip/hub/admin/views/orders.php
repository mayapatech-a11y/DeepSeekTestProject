<?php
declare(strict_types=1);
/**
 * Hub panel → Orders.
 *
 * The buy page has no payment gateway behind it, so this is where a purchase
 * actually happens: staff read the request, confirm the payment out of band,
 * mark it paid, deliver the key and mark it delivered. Marking DELIVERED is
 * also what counts the sale against the offer, so the shop's numbers come
 * from real fulfilments rather than from clicks.
 */

$status  = (string)sfy_param('status', '');
$q       = (string)sfy_param('q', '');
$page    = max(1, sfy_int('page', 1));
$filter  = ['status' => $status, 'q' => $q];
$total   = sfy_hub_orders_count($filter);
$rows    = sfy_hub_orders($filter, $page, 20);
$stats   = sfy_hub_order_stats();
$statuses = sfy_hub_order_statuses();
?>

<div class="hub-grid-3" style="margin-bottom:var(--gap)">
  <?= sfy_kpi('Pending', number_format((int)($stats['pending'] ?? 0)), 'orange', 'waiting on an admin') ?>
  <?= sfy_kpi('Marked paid', number_format((int)($stats['paid'] ?? 0)), 'gold', 'payment confirmed') ?>
  <?= sfy_kpi('Delivered', number_format((int)($stats['delivered'] ?? 0)), 'g', sfy_hub_money($stats['value'] ?? 0) . ' in sales') ?>
</div>

<div class="card">
  <div class="card-head">
    <h2>&gt; ORDER_QUEUE</h2>
    <span class="spacer"></span>
    <span class="hub-admin-badge"><?= number_format($total) ?> MATCH(ES)</span>
  </div>

  <form method="GET" action="<?= sfy_esc(sfy_url('hub/admin/')) ?>" style="display:flex;gap:9px;flex-wrap:wrap;margin-bottom:13px">
    <input type="hidden" name="tab" value="orders">
    <input type="search" name="q" class="grow" value="<?= sfy_esc($q) ?>" placeholder="Reference, name, contact or plan…"
           style="flex:1 1 240px;min-width:0">
    <select name="status" style="flex:0 0 170px">
      <option value="">Every status</option>
      <?php foreach ($statuses as $k => $label): ?>
        <option value="<?= sfy_esc($k) ?>" <?= $status === $k ? 'selected' : '' ?>><?= sfy_esc($label) ?></option>
      <?php endforeach; ?>
    </select>
    <button class="btn btn-sm">FILTER</button>
  </form>

  <?php if (!$rows): ?>
    <div class="empty">No orders match. The buy page is at
      <span class="mono"><?= sfy_esc(sfy_hub_url('offers')) ?></span>.</div>
  <?php else: ?>
    <?php foreach ($rows as $o): ?>
      <div class="secrow">
        <div class="hd">
          <span class="nm mono"><?= sfy_esc((string)$o['reference']) ?></span>
          <span class="hub-pill <?= sfy_esc((string)$o['status']) ?>">
            <?= sfy_esc((string)($statuses[(string)$o['status']] ?? $o['status'])) ?></span>
          <span class="small dim"><?= sfy_esc((string)$o['offer_title']) ?>
            · <?= sfy_esc(sfy_hub_money($o['amount'], (string)$o['currency'])) ?></span>
          <span class="spacer"></span>
          <span class="tiny mute"><?= sfy_esc(sfy_ago((string)$o['created_at'])) ?></span>
        </div>
        <div class="bd">
          <div class="grid grid-2" style="gap:12px">
            <div>
              <table class="hub-table-mini">
                <tr><th>Buyer</th><td><?= sfy_esc((string)$o['buyer_name']) ?></td></tr>
                <tr><th>Contact</th><td>
                  <span class="mono"><?= sfy_esc((string)$o['buyer_contact']) ?></span>
                  <?php if ((string)$o['contact_kind'] === 'email'): ?>
                    <a class="tiny" href="mailto:<?= sfy_esc((string)$o['buyer_contact']) ?>">➤ mail</a>
                  <?php endif; ?>
                </td></tr>
                <tr><th>Pays with</th><td><?= sfy_esc((string)$o['payment_method'] !== '' ? (string)$o['payment_method'] : '—') ?></td></tr>
                <tr><th>Plan</th><td><?= sfy_esc((string)$o['duration_label'] !== '' ? (string)$o['duration_label'] : '—') ?>
                  <span class="mono tiny"><?= sfy_esc((string)$o['offer_slug']) ?></span></td></tr>
                <tr><th>IP</th><td class="mono tiny"><?= sfy_esc(sfy_mask_ip((string)$o['ip'])) ?></td></tr>
              </table>
              <?php if (trim((string)$o['message']) !== ''): ?>
                <div class="label" style="margin-top:11px">Buyer's note</div>
                <div class="hub-import-out" style="max-height:120px"><?= sfy_esc((string)$o['message']) ?></div>
              <?php endif; ?>
            </div>
            <div>
              <form method="POST">
                <?= sfy_csrf_field() ?>
                <input type="hidden" name="action" value="order_status">
                <input type="hidden" name="id" value="<?= (int)$o['id'] ?>">
                <div class="field">
                  <label class="label">Status</label>
                  <select name="status">
                    <?php foreach ($statuses as $k => $label): ?>
                      <option value="<?= sfy_esc($k) ?>" <?= (string)$o['status'] === $k ? 'selected' : '' ?>>
                        <?= sfy_esc($label) ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <div class="field">
                  <label class="label">Internal note (visible to staff only)</label>
                  <textarea name="admin_note" style="min-height:80px"><?= sfy_esc((string)($o['admin_note'] ?? '')) ?></textarea>
                </div>
                <button class="btn btn-primary btn-block">SAVE ORDER</button>
              </form>
              <form method="POST" data-confirm="Delete order <?= sfy_esc((string)$o['reference']) ?>?" style="margin-top:9px">
                <?= sfy_csrf_field() ?>
                <input type="hidden" name="action" value="delete_order">
                <input type="hidden" name="id" value="<?= (int)$o['id'] ?>">
                <button class="btn btn-sm btn-danger btn-block">DELETE ORDER</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; ?>

    <?php $pages = max(1, (int)ceil($total / 20)); if ($pages > 1): ?>
      <div class="hub-pager">
        <?php for ($p = 1; $p <= $pages; $p++): ?>
          <a class="hub-page <?= $p === $page ? 'on' : '' ?>"
             href="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'orders', 'q' => $q, 'status' => $status, 'page' => $p])) ?>"><?= $p ?></a>
        <?php endfor; ?>
      </div>
    <?php endif; ?>
  <?php endif; ?>
</div>
