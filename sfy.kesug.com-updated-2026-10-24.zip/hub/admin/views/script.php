<?php
declare(strict_types=1);
/**
 * Hub panel → Script editor.
 *
 * One screen does three jobs, because they are the same job: creating a
 * script by hand, editing one, and reviewing whatever an import just pulled
 * off a link. The import lands *in the form*, fully editable — which is the
 * point of importing: it saves the typing, it does not take the pen away.
 */

$id     = (int)sfy_param('id', 0);
$row    = $id > 0 ? sfy_hub_script($id) : null;
$import = null;

if ((string)sfy_param('clear', '') === '1') unset($_SESSION['sfy_hub_import']);

if (sfy_int('import', 0) === 1 && !empty($_SESSION['sfy_hub_import'])) {
    $import = $_SESSION['sfy_hub_import'];
}

/* An import that failed still has something to say, so it is shown on the
   editor too — the owner pressed a button and must not be left guessing. */
$aFailed = is_array($import) && empty($import['ok']) ? $import : null;
$f       = is_array($import) && !empty($import['ok']) ? (array)$import['fields'] : [];

/* Field value: what the row has, or what the import suggested, or nothing. */
/* The editor is a plain form. Standard HTML behaviour already re-fills it
   from $_POST when the browser redisplays a rejected submit, so nothing here
   needs to remember anything: the row wins for an existing script, the
   import wins for a new draft, and $_POST wins over both. */
$posted  = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) === 'POST';
/* A hand-off from the inbox ("start a script for this game") arrives as
   ?game=…, so the suggestion is already typed into the right field. */
$prefill = ['game_name' => (string)sfy_param('game', '')];
$val = function (string $key, string $default = '') use ($row, $f, $posted, $prefill): string {
    if ($posted && array_key_exists($key, $_POST) && is_scalar($_POST[$key])) return (string)$_POST[$key];
    if ($row !== null)              return (string)($row[$key] ?? $default);
    if (array_key_exists($key, $f)) return (string)$f[$key];
    if (($prefill[$key] ?? '') !== '') return (string)$prefill[$key];
    return $default;
};
$flag = function (string $key, bool $default = false) use ($row, $f, $posted): bool {
    if ($posted)                    return !empty($_POST[$key]);   // an unticked box is absent, i.e. OFF
    if ($row !== null)              return (int)($row[$key] ?? 0) === 1;
    if (array_key_exists($key, $f)) return (int)$f[$key] === 1;
    return $default;
};
$gameOptions = sfy_hub_game_options();

/* The video as the page will read it, so the field can say what it is about to
   do instead of leaving the owner to find out by opening the script page. */
$vlinkRaw = $val('video_url');
$vlink    = sfy_hub_video_parse($vlinkRaw);
?>

<div class="hub-admin-note">
  ◆ A script is visible to visitors the moment its status is <b>published</b>. Drafts render only for
  signed-in staff, which is how an import can be reviewed calmly before anyone sees it.
</div>

<div class="hub-grid-2">
  <div>
    <form class="card" method="POST" action="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'scripts'])) ?>" data-hub-once>
      <?= sfy_csrf_field() ?>
      <input type="hidden" name="action" value="save_script">
      <input type="hidden" name="id" value="<?= (int)$id ?>">
      <?php if ($import && !empty($import['ok'])): ?>
        <input type="hidden" name="import_source" value="link-<?= sfy_esc((string)$import['source']) ?>">
        <input type="hidden" name="import_url" value="<?= sfy_esc((string)$import['url']) ?>">
        <input type="hidden" name="imported_at" value="<?= sfy_esc(date('Y-m-d H:i:s')) ?>">
      <?php endif; ?>

      <div class="card-head">
        <h2>&gt; <?= $id > 0 ? 'EDIT_SCRIPT #' . (int)$id : ($f ? 'REVIEW_IMPORT' : 'NEW_SCRIPT') ?></h2>
        <span class="spacer"></span>
        <?php if ($id > 0): ?>
          <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_hub_script_link($row)) ?>" target="_blank" rel="noopener">↗ view page</a>
        <?php endif; ?>
      </div>

      <?php if ($import && !empty($import['ok'])): ?>
        <div class="msg info">
          ◆ Imported from <b><?= sfy_esc((string)$import['source']) ?></b>.
          <?php foreach ((array)$import['notes'] as $n): ?><br>· <?= sfy_esc((string)$n) ?><?php endforeach; ?>
          <br>Review every field before you save — the importer guesses.
        </div>
      <?php endif; ?>
      <?php if ($aFailed): ?>
        <div class="msg err">✖ <?= sfy_esc((string)$aFailed['error']) ?></div>
      <?php endif; ?>

      <div class="field">
        <label class="label">Title *</label>
        <input type="text" name="title" maxlength="191" required value="<?= sfy_esc($val('title')) ?>">
      </div>

      <div class="grid grid-2" style="gap:12px">
        <div class="field">
          <label class="label">Game name</label>
          <input type="text" name="game_name" maxlength="191" list="hub-game-list" value="<?= sfy_esc($val('game_name')) ?>">
          <datalist id="hub-game-list">
            <?php foreach ($gameOptions as $g): ?>
              <option value="<?= sfy_esc((string)$g['game_name']) ?>"></option>
            <?php endforeach; ?>
          </datalist>
        </div>
        <div class="field">
          <label class="label">Roblox place / game id</label>
          <input type="text" name="game_id" maxlength="64" value="<?= sfy_esc($val('game_id')) ?>">
        </div>
      </div>

      <div class="field">
        <label class="label">Card teaser (one line)</label>
        <input type="text" name="summary" maxlength="400" value="<?= sfy_esc($val('summary')) ?>"
               placeholder="Aimbot, ESP and speed — keyless.">
      </div>

      <div class="field">
        <label class="label">Description</label>
        <textarea name="description" style="min-height:110px"><?= sfy_esc($val('description')) ?></textarea>
      </div>

      <div class="field">
        <label class="label">Features (one per line)</label>
        <textarea name="features" style="min-height:110px"><?= sfy_esc($val('features')) ?></textarea>
      </div>

      <div class="field">
        <label class="label">Script code *</label>
        <textarea name="script_code" style="min-height:180px;font-family:var(--mono);font-size:12px"
                  spellcheck="false"><?= sfy_esc($val('script_code')) ?></textarea>
        <div class="hint">Paste the Lua here. It is rendered inside a scrollable box with a copy button.</div>
      </div>

      <div class="grid grid-2" style="gap:12px">
        <div class="field">
          <label class="label">Thumbnail URL</label>
          <input type="text" name="thumbnail" maxlength="500" value="<?= sfy_esc($val('thumbnail')) ?>">
        </div>
        <div class="field">
          <label class="label">Video (YouTube or Vimeo)</label>
          <input type="text" name="video_url" maxlength="500" value="<?= sfy_esc($vlinkRaw) ?>"
                 placeholder="https://youtu.be/… or the whole embed code">
          <?php if ($vlinkRaw === ''): ?>
            <div class="hint">Blank means a picture and nothing to press. A link here turns the hero image
              into the player itself — the picture shows first, and the video loads when it is pressed.</div>
          <?php elseif ($vlink['embed'] !== ''): ?>
            <div class="hint"><b>✔ <?= sfy_esc($vlink['provider']) ?></b> · id <span class="mono"><?= sfy_esc($vlink['id']) ?></span> —
              plays inside the hero image on the script page. Saved as <span class="mono"><?= sfy_esc($vlink['watch']) ?></span>.
              A thumbnail above overrides the video's own still.</div>
          <?php else: ?>
            <div class="hint">✖ Not a link this can play in the page — it is kept as typed and offered as an ordinary
              <b>▶ WATCH VIDEO</b> button instead, which is the honest thing to do with a link from a host this does not embed.</div>
          <?php endif; ?>
          <div class="chiprow" style="margin-top:8px">
            <label class="chip"><input type="checkbox" name="video_autoplay" value="1"
              <?= $flag('video_autoplay') ? 'checked' : '' ?>> ▶ Autoplay</label>
          </div>
          <div class="hint">Autoplay starts the video by itself, <b>muted</b>: every browser refuses a video that
            begins with sound, so the player puts a sound button on it. Unticked, the video waits for a press —
            and then it plays with sound straight away. Visitors with data-saving or reduced-motion on are left
            with the picture either way.</div>
        </div>
      </div>

      <div class="grid grid-2" style="gap:12px">
        <div class="field">
          <label class="label">Game link</label>
          <input type="text" name="game_link" maxlength="500" value="<?= sfy_esc($val('game_link')) ?>">
        </div>
        <div class="field">
          <label class="label">Discord link</label>
          <input type="text" name="discord_url" maxlength="500" value="<?= sfy_esc($val('discord_url')) ?>">
        </div>
      </div>

      <div class="grid grid-3" style="gap:12px">
        <div class="field">
          <label class="label">Author</label>
          <input type="text" name="author" maxlength="96" value="<?= sfy_esc($val('author')) ?>">
        </div>
        <div class="field">
          <label class="label">Tags (comma separated)</label>
          <input type="text" name="tags" maxlength="255" value="<?= sfy_esc($val('tags')) ?>">
        </div>
        <div class="field">
          <label class="label">Slug (blank = from title)</label>
          <input type="text" name="slug" maxlength="191" value="<?= sfy_esc((string)($row['slug'] ?? '')) ?>">
        </div>
      </div>

      <div class="field">
        <label class="label">Status</label>
        <div class="chiprow">
          <label class="chip"><input type="radio" name="status" value="published"
            <?= (string)($row['status'] ?? 'published') === 'published' ? 'checked' : '' ?>> Published</label>
          <label class="chip"><input type="radio" name="status" value="draft"
            <?= (string)($row['status'] ?? '') === 'draft' ? 'checked' : '' ?>> Draft (staff only)</label>
        </div>
      </div>

      <div class="field">
        <label class="label">Flags</label>
        <div class="chiprow">
          <label class="chip"><input type="checkbox" name="is_free" value="1" <?= $flag('is_free', true) ? 'checked' : '' ?>> Free</label>
          <label class="chip"><input type="checkbox" name="is_featured" value="1" <?= $flag('is_featured') ? 'checked' : '' ?>> Featured</label>
          <label class="chip"><input type="checkbox" name="key_system" value="1" <?= $flag('key_system') ? 'checked' : '' ?>> Needs a key</label>
          <label class="chip"><input type="checkbox" name="is_universal" value="1" <?= $flag('is_universal') ? 'checked' : '' ?>> Universal</label>
        </div>
      </div>

      <div class="grid grid-2" style="gap:12px">
        <div class="field">
          <label class="label">Sort order (lower shows first)</label>
          <input type="number" name="sort_order" value="<?= (int)($row['sort_order'] ?? 0) ?>">
        </div>
        <div class="field">
          <label class="label">Provenance</label>
          <input type="text" name="source" maxlength="32" value="<?= sfy_esc($val('source', 'manual')) ?>">
          <div class="hint">manual, link-scriptblox, link-haxhell…</div>
        </div>
      </div>

      <?php if ($id > 0 && trim((string)($row['source_url'] ?? '')) !== ''): ?>
        <div class="field">
          <label class="label">Imported from</label>
          <input type="text" name="source_url" maxlength="500" value="<?= sfy_esc((string)$row['source_url']) ?>">
        </div>
      <?php else: ?>
        <input type="hidden" name="source_url" value="<?= sfy_esc($val('source_url')) ?>">
      <?php endif; ?>

      <div class="btn-row">
        <button class="btn btn-primary btn-lg" data-busy="SAVING…"><?= $id > 0 ? 'SAVE SCRIPT' : 'CREATE SCRIPT' ?></button>
        <?php if ($id > 0): ?>
          <a class="btn btn-ghost" href="<?= sfy_esc(sfy_hub_script_link($row)) ?>" target="_blank" rel="noopener">PREVIEW PAGE</a>
        <?php endif; ?>
      </div>
    </form>
  </div>

  <div>
    <div class="card">
      <div class="card-head"><h2>&gt; FILL_FROM_A_LINK</h2></div>
      <p class="hint" style="margin-top:0">
        Paste a ScriptBlox or HaxHell script page. Everything the importer finds appears in the form on the
        left, ready to edit — nothing is saved until you press the button there.
      </p>
      <form method="POST" action="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'import'])) ?>" data-hub-once>
        <?= sfy_csrf_field() ?>
        <input type="hidden" name="action" value="import_fetch">
        <div class="field">
          <label class="label">Script page URL</label>
          <input type="text" name="url" placeholder="https://scriptblox.com/script/…" value="<?= sfy_esc((string)($import['url'] ?? '')) ?>">
        </div>
        <div class="field">
          <label class="label">…or paste the page source</label>
          <textarea name="pasted" style="min-height:90px" spellcheck="false"
                    placeholder="Only needed when the site blocks servers (Ctrl+U on the page, then paste it here)"></textarea>
        </div>
        <button class="btn btn-primary btn-block" data-busy="FETCHING…">📥 IMPORT FROM LINK</button>
      </form>
      <?php if ($import && !empty($import['ok'])): ?>
        <div class="hint" style="margin-top:11px">
          Showing the imported draft. <a href="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'script', 'clear' => 1])) ?>">Start a blank one instead</a>.
        </div>
      <?php endif; ?>
    </div>

    <div class="card">
      <div class="card-head"><h2>&gt; WHAT_GETS_IMPORTED</h2></div>
      <table class="hub-table-mini">
        <?php foreach (sfy_hub_import_sources() as $key => $src): ?>
          <tr>
            <td><b><?= sfy_esc((string)$src['label']) ?></b><div class="hint" style="margin-top:3px"><?= sfy_esc((string)$src['how']) ?></div></td>
          </tr>
        <?php endforeach; ?>
      </table>
      <div class="hint">
        Import is best-effort: a site that blocks servers or renders in JavaScript cannot be read from here.
        The paste box is the way through, and every field stays editable either way.
      </div>
    </div>
  </div>
</div>
