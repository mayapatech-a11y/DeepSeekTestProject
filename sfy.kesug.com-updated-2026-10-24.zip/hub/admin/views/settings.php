<?php
declare(strict_types=1);
/** Hub panel → Settings. */

$s       = sfy_hub_settings();
$health  = sfy_try(function (): array {
    $bad = [];
    foreach (sfy_hub_tables() as $table => $ddl) {
        if (!sfy_table_exists($table)) { $bad[] = $table; continue; }
        foreach (sfy_schema_defined_columns($ddl) as $col => $def) {
            if (preg_match('/AUTO_INCREMENT|PRIMARY KEY/i', $def)) continue;
            if (!sfy_column_exists($table, $col)) $bad[] = $table . '.' . $col;
        }
    }
    return $bad;
}, []);

/* The install's own support link is what the hub falls back to, so the field
   shows the effective value rather than an empty box that looks like a bug. */
$effectiveDiscord = trim((string)$s['support_discord']) !== ''
    ? (string)$s['support_discord']
    : trim((string)sfy_config_get('set_support_discord', ''));
?>

<div class="card">
  <div class="card-head">
    <h2>&gt; HUB_SETTINGS</h2><span class="spacer"></span>
    <span class="hub-admin-badge">v<?= sfy_esc(SFY_HUB_VERSION) ?></span>
  </div>

  <form method="POST" action="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'settings'])) ?>">
    <?= sfy_csrf_field() ?>
    <input type="hidden" name="action" value="save_settings">
    <input type="hidden" name="__flags" value="1">
    <input type="hidden" name="__scope" value="settings">

    <div class="card-head" style="border:0;padding:0;margin-bottom:10px"><h2>&gt; IDENTITY</h2></div>
    <div class="grid grid-2" style="gap:12px">
      <div class="field">
        <label class="label">Hub name (used by the wordmark)</label>
        <input type="text" name="title" maxlength="60" value="<?= sfy_esc((string)$s['title']) ?>">
      </div>
      <div class="field">
        <label class="label">Tagline</label>
        <input type="text" name="tagline" maxlength="160" value="<?= sfy_esc((string)$s['tagline']) ?>">
      </div>
    </div>
    <div class="grid grid-2" style="gap:12px">
      <div class="field">
        <label class="label">Home heading</label>
        <input type="text" name="home_heading" maxlength="80" value="<?= sfy_esc((string)$s['home_heading']) ?>">
      </div>
      <div class="field">
        <label class="label">Home sub-text</label>
        <input type="text" name="home_sub" maxlength="200" value="<?= sfy_esc((string)$s['home_sub']) ?>">
      </div>
    </div>
    <div class="field">
      <label class="label">Notice strip above the grid (optional)</label>
      <input type="text" name="home_notice" maxlength="300" value="<?= sfy_esc((string)$s['home_notice']) ?>"
             placeholder="New: 7-day keys are back in stock.">
    </div>

    <hr class="sep">

    <div class="card-head" style="border:0;padding:0;margin-bottom:10px"><h2>&gt; SECTIONS</h2></div>
    <div class="field">
      <label class="label">Which sections are shown</label>
      <div class="chiprow">
        <label class="chip"><input type="checkbox" name="nav_scripts" value="1" <?= !empty($s['nav_scripts']) ? 'checked' : '' ?>> Script library</label>
        <label class="chip"><input type="checkbox" name="nav_offers" value="1" <?= !empty($s['nav_offers']) ? 'checked' : '' ?>> Premium offers</label>
        <label class="chip"><input type="checkbox" name="nav_suggest" value="1" <?= !empty($s['nav_suggest']) ? 'checked' : '' ?>> Game requests</label>
        <label class="chip"><input type="checkbox" name="nav_contact" value="1" <?= !empty($s['nav_contact']) ? 'checked' : '' ?>> Contact support</label>
      </div>
    </div>

    <div class="grid grid-2" style="gap:12px">
      <div class="field">
        <label class="label">Site entry points in the hub's bar</label>
        <div class="chiprow">
          <label class="chip"><input type="checkbox" name="nav_code" value="1" <?= !empty($s['nav_code']) ? 'checked' : '' ?>> Get code button</label>
          <label class="chip"><input type="checkbox" name="nav_home" value="1" <?= !empty($s['nav_home']) ? 'checked' : '' ?>> Link back to the site's home page</label>
        </div>
        <div class="hint">The highlighted <b>GET CODE</b> button sits next to <b>GET PREMIUM</b> and opens the
          token flow; the home link is the first item in the bar, and is what visitors use to reach the page the
          hub was put in front of.</div>
      </div>
      <div class="field">
        <label class="label">Where those two point</label>
        <input type="text" name="code_url" maxlength="300" value="<?= sfy_esc((string)$s['code_url']) ?>"
               placeholder="<?= sfy_esc(sfy_url('tutorial')) ?>" style="margin-bottom:8px">
        <input type="text" name="home_url" maxlength="300" value="<?= sfy_esc((string)$s['home_url']) ?>"
               placeholder="<?= sfy_esc(sfy_hub_site_home()) ?>">
        <div class="hint">Blank uses the address shown as a placeholder — the guide page for the code button, and
          <span class="mono">/home</span> for the home link. Set your own if you mounted the landing page
          elsewhere, and clear it here rather than removing the link if the route is not there.</div>
      </div>
    </div>
    <div class="field">
      <label class="label">Which forms accept submissions</label>
      <div class="chiprow">
        <label class="chip"><input type="checkbox" name="contact_enabled" value="1" <?= !empty($s['contact_enabled']) ? 'checked' : '' ?>> Support form</label>
        <label class="chip"><input type="checkbox" name="suggest_enabled" value="1" <?= !empty($s['suggest_enabled']) ? 'checked' : '' ?>> Game suggestion form</label>
        <label class="chip"><input type="checkbox" name="orders_enabled" value="1" <?= !empty($s['orders_enabled']) ? 'checked' : '' ?>> Buy-page orders</label>
        <label class="chip"><input type="checkbox" name="captcha_forms" value="1" <?= !empty($s['captcha_forms']) ? 'checked' : '' ?>> Human check on hub forms</label>
      </div>
      <div class="hint">
        The human check reuses the Cloudflare keys in
        <a href="<?= sfy_esc(sfy_admin_url(['tab' => 'settings'])) ?>">Main Admin → Settings</a>; if the widget cannot
        render, the gate steps aside rather than refusing honest visitors.
      </div>
    </div>

    <hr class="sep">

    <div class="card-head" style="border:0;padding:0;margin-bottom:10px"><h2>&gt; SUPPORT</h2></div>
    <div class="grid grid-2" style="gap:12px">
      <div class="field">
        <label class="label">Discord invite (blank = the install's own link)</label>
        <input type="text" name="support_discord" maxlength="300" value="<?= sfy_esc((string)$s['support_discord']) ?>"
               placeholder="<?= sfy_esc($effectiveDiscord) ?>">
      </div>
      <div class="field">
        <label class="label">Support email (optional)</label>
        <input type="text" name="support_email" maxlength="120" value="<?= sfy_esc((string)$s['support_email']) ?>">
      </div>
    </div>
    <div class="field">
      <label class="label">What to tell visitors before they write</label>
      <textarea name="support_note" style="min-height:70px"><?= sfy_esc((string)$s['support_note']) ?></textarea>
      <div class="hint">Shown under the send button on the contact page.</div>
    </div>

    <hr class="sep">

    <div class="card-head" style="border:0;padding:0;margin-bottom:10px"><h2>&gt; SHOP</h2></div>
    <div class="grid grid-2" style="gap:12px">
      <div class="field">
        <label class="label">Currency code</label>
        <input type="text" name="currency" maxlength="8" value="<?= sfy_esc((string)$s['currency']) ?>">
      </div>
      <div class="field">
        <label class="label">Payment methods (one per line)</label>
        <textarea name="pay_methods" style="min-height:80px"><?= sfy_esc((string)$s['pay_methods']) ?></textarea>
      </div>
    </div>
    <div class="field">
      <label class="label">Shop intro (offers page)</label>
      <textarea name="shop_intro" style="min-height:60px"><?= sfy_esc((string)$s['shop_intro']) ?></textarea>
    </div>
    <div class="field">
      <label class="label">What to do after ordering</label>
      <textarea name="pay_instructions" style="min-height:90px"><?= sfy_esc((string)$s['pay_instructions']) ?></textarea>
      <div class="hint">Shown on the confirmation panel next to the customer's reference code.</div>
    </div>
    <div class="field">
      <label class="label">Buy-page disclaimer</label>
      <textarea name="buy_note" style="min-height:60px"><?= sfy_esc((string)$s['buy_note']) ?></textarea>
    </div>

    <button class="btn btn-primary btn-lg">SAVE SETTINGS</button>
  </form>
</div>

<div class="card">
  <div class="card-head">
    <h2>&gt; MODULE_HEALTH</h2><span class="spacer"></span>
    <span class="badge <?= $health ? 'r' : 'g' ?>"><?= $health ? '✖ ' . count($health) . ' PROBLEM(S)' : '✓ OK' ?></span>
  </div>
  <?php if ($health): ?>
    <div class="msg warn">◆ Missing: <?= sfy_esc(implode(', ', array_slice($health, 0, 8))) ?><?= count($health) > 8 ? ' …' : '' ?></div>
  <?php else: ?>
    <p class="small dim" style="margin:0 0 12px">Every table and column the module declares exists.</p>
  <?php endif; ?>
  <?php if (sfy_admin_can('updater')): ?>
    <form method="POST" data-hub-once>
      <?= sfy_csrf_field() ?>
      <input type="hidden" name="action" value="install">
      <button class="btn btn-primary" data-busy="INSTALLING…">⬆ CREATE / REPAIR HUB TABLES</button>
    </form>
  <?php endif; ?>
  <table class="hub-table-mini" style="margin-top:14px">
    <tr><th>PHP</th><td class="mono"><?= sfy_esc(PHP_VERSION) ?></td></tr>
    <tr><th>Outbound requests</th><td class="mono"><?= function_exists('curl_init') ? 'curl' : (ini_get('allow_url_fopen') ? 'streams' : 'none — imports need the paste box') ?></td></tr>
    <tr><th>Public URL</th><td class="mono"><?= sfy_esc(sfy_hub_url()) ?></td></tr>
    <tr><th>Panel URL</th><td class="mono"><?= sfy_esc(sfy_hub_admin_url()) ?></td></tr>
    <tr><th>Buy page</th><td class="mono"><?= sfy_esc(sfy_hub_url('offers')) ?></td></tr>
    <tr><th>App fingerprint</th><td class="mono"><?= sfy_esc(function_exists('sfy_app_fingerprint') ? sfy_app_fingerprint() : '—') ?></td></tr>
  </table>
</div>
