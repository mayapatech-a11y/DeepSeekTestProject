<?php
declare(strict_types=1);
/**
 * Hub panel → Payment methods.
 *
 * Where the money actually goes: one row per method, with the address or
 * checkout link the buyer is shown, the answers the buyer has to give, and —
 * for a gateway — the credentials plus the signed callback URL that lets the
 * provider confirm an order by itself.
 *
 * The screen is honest about the state of each row rather than trusting the
 * owner to remember: a method with no address, or a gateway with no webhook
 * secret, is labelled as such in the list, because that is the difference
 * between a shop that takes money and a form that collects a promise.
 */

$id    = (int)sfy_param('id', 0);
$tpl   = (string)sfy_param('template', '');
$edit  = $id > 0 ? sfy_hub_payment($id) : null;
$tplName = '';
if (!$edit && $tpl !== '') {
    /* A template only prefills the form, so an unknown key is not an error:
       it just opens the blank one. */
    $from = sfy_hub_payment_template($tpl);
    if ($from) { $edit = $from; $tplName = (string)($from['name'] ?? ''); }
}
/* The form opens in a popup, and only when the URL asks for it: editing an id,
   starting from a template, or asking for a blank one. */
$isNew = !$edit && (string)sfy_param('new', '') !== '';
$open  = $edit !== null || $isNew;

$rows  = sfy_hub_payments(false);
$kinds = sfy_hub_payment_kinds();
$probe = $_SESSION['sfy_hub_pay_probe'] ?? null;

$v = function (string $key, string $default = '') use ($edit): string {
    if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) === 'POST' && isset($_POST[$key]) && is_scalar($_POST[$key])) {
        return (string)$_POST[$key];
    }
    return (string)($edit[$key] ?? $default);
};

$ready    = [];
$unusable = 0;
foreach ($rows as $r) {
    $ready[(int)$r['id']] = sfy_hub_payment_ready($r);
    // Only the ones actually *offered* are a problem: a half-finished row the
    // owner has switched off is a draft, not a fault.
    if (!empty($r['is_active']) && !$ready[(int)$r['id']]['ok']) $unusable++;
}
$auto = 0;
foreach ($rows as $r) if (sfy_hub_payment_auto_confirm($r)) $auto++;
?>

<div class="card">
  <div class="card-head">
    <h2>&gt; PAYMENT_METHODS</h2>
    <span class="spacer"></span>
    <span class="hub-admin-badge"><?= count($rows) ?> METHOD(S)</span>
    <span class="hub-pill <?= $auto > 0 ? 'new' : '' ?>"><?= (int)$auto ?> AUTO-CONFIRM</span>
    <?php if ($unusable > 0): ?>
      <span class="hub-pill pending"><?= (int)$unusable ?> NEEDS INPUT</span>
    <?php endif; ?>
    <?php if (sfy_admin_can('settings')): ?>
      <a class="btn btn-sm btn-primary"
         href="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'payments', 'new' => 1])) ?>">＋ ADD A METHOD</a>
    <?php endif; ?>
  </div>

  <?php if (sfy_admin_can('settings')): ?>
    <div class="hub-cats">
      <?php foreach (sfy_hub_payment_templates() as $key => $t): ?>
        <a class="hub-cat" href="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'payments', 'template' => $key])) ?>">
          <span aria-hidden="true"><?= sfy_esc((string)$t['icon']) ?></span>
          <?= sfy_esc((string)$t['name']) ?></a>
      <?php endforeach; ?>
      <a class="hub-cat" href="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'payments', 'new' => 1])) ?>">
        ＋ something else</a>
    </div>
    <p class="hint" style="margin:-6px 0 13px">Pick one to start from — it fills the popup in and nothing more:
      the name, what the buyer must provide, the wording and the shape of the API fields all stay editable, and no
      credentials ship with it.</p>
  <?php endif; ?>

  <?php if (!$rows): ?>
    <div class="empty">No payment methods yet. Pick one of the templates below to start from — a shop with no
      method listed is a shop nobody can pay.</div>
  <?php else: ?>
    <div class="tbl-wrap">
      <table class="tbl">
        <thead><tr>
          <th>Method</th><th style="width:150px">Goes to</th><th style="width:200px">State</th>
          <th style="width:230px">Actions</th>
        </tr></thead>
        <tbody>
        <?php foreach ($rows as $r): ?>
          <?php $rd = $ready[(int)$r['id']]; ?>
          <tr>
            <td>
              <b><?= sfy_esc(sfy_hub_pay_icon($r)) ?> <?= sfy_esc((string)$r['name']) ?></b>
              <span class="hub-pill"><?= sfy_esc(sfy_hub_pay_kind_label((string)$r['kind'])) ?></span>
              <?php if (!empty($r['is_featured'])): ?><span class="hub-pill pending">featured</span><?php endif; ?>
              <div class="hint mono"><?= sfy_esc((string)$r['slug']) ?>
                <?php if (trim((string)$r['network']) !== ''): ?> · <?= sfy_esc((string)$r['network']) ?><?php endif; ?></div>
            </td>
            <td class="small">
              <?php $dest = sfy_hub_payment_destination($r); ?>
              <?= $dest !== '' ? sfy_esc($dest) : '<span class="hub-pill cancelled">none yet</span>' ?>
            </td>
            <td>
              <span class="hub-pill <?= !empty($r['is_active']) ? 'new' : 'cancelled' ?>">
                <?= !empty($r['is_active']) ? 'offered' : 'hidden' ?></span>
              <?php if ($rd['ok']): ?>
                <span class="hub-pill delivered"><?= sfy_hub_payment_auto_confirm($r) ? 'auto-confirm' : 'ready' ?></span>
              <?php else: ?>
                <span class="hub-pill pending" title="Missing: <?= sfy_esc(implode(', ', $rd['missing'])) ?>">
                  needs <?= sfy_esc(implode(' + ', array_slice($rd['missing'], 0, 2))) ?></span>
              <?php endif; ?>
            </td>
            <td>
              <div class="btn-row" style="gap:6px">
                <a class="btn btn-sm" href="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'payments', 'id' => (int)$r['id']])) ?>">Edit</a>
                <form method="POST" class="inline">
                  <?= sfy_csrf_field() ?>
                  <input type="hidden" name="action" value="flag_payment">
                  <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                  <input type="hidden" name="column" value="is_active">
                  <button class="btn btn-sm btn-ghost"><?= !empty($r['is_active']) ? 'Hide' : 'Show' ?></button>
                </form>
                <form method="POST" class="inline">
                  <?= sfy_csrf_field() ?>
                  <input type="hidden" name="action" value="flag_payment">
                  <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                  <input type="hidden" name="column" value="is_featured">
                  <button class="btn btn-sm btn-ghost" title="Show this method first"><?= !empty($r['is_featured']) ? '★' : '☆' ?></button>
                </form>
                <?php if (trim((string)$r['api_endpoint']) !== '' || trim((string)$r['checkout_url']) !== ''): ?>
                  <form method="POST" class="inline">
                    <?= sfy_csrf_field() ?>
                    <input type="hidden" name="action" value="test_payment">
                    <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                    <button class="btn btn-sm btn-ghost" title="Ask the endpoint whether the host answers">Test</button>
                  </form>
                <?php endif; ?>
                <form method="POST" class="inline" data-confirm="Delete the payment method &quot;<?= sfy_esc((string)$r['name']) ?>&quot;?">
                  <?= sfy_csrf_field() ?>
                  <input type="hidden" name="action" value="delete_payment">
                  <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                  <button class="btn btn-sm btn-danger">Del</button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>

  <?php if ($probe): ?>
    <div class="hub-admin-note" style="margin-top:13px">
      <b>Last endpoint test:</b>
      <?= sfy_esc((string)($probe['name'] ?? '')) ?>
      — <?= !empty($probe['ok']) ? '✔ ' . sfy_esc((string)$probe['note']) : '✖ ' . sfy_esc((string)$probe['error']) ?>
      <div class="hint mono"><?= sfy_esc((string)($probe['url'] ?? '')) ?></div>
    </div>
  <?php endif; ?>
</div>

<?php if ($open):
  $closeUrl = sfy_hub_admin_url(['tab' => 'payments']);
  sfy_hub_modal_start([
      'title' => $id > 0 ? 'Payment method #' . $id : ($tplName !== '' ? 'New method — ' . $tplName : 'New payment method'),
      'sub'   => $id > 0 ? (string)($edit['name'] ?? '') : 'Nothing is charged until you switch it on',
      'icon'  => '💳',
      'close' => $closeUrl,
      'wide'  => true,
  ]);
?>

<form method="POST" action="<?= sfy_esc($closeUrl) ?>">
  <?= sfy_csrf_field() ?>
  <input type="hidden" name="action" value="save_payment">
  <input type="hidden" name="id" value="<?= (int)$id ?>">

  <div class="grid grid-2" style="gap:12px">
    <div class="field">
      <label class="label">Name *</label>
      <input type="text" name="name" maxlength="96" required value="<?= sfy_esc($v('name')) ?>" placeholder="GCash">
    </div>
    <div class="field">
      <label class="label">Slug (the id callbacks match on)</label>
      <input type="text" name="slug" maxlength="96" value="<?= sfy_esc($v('slug')) ?>" placeholder="gcash">
      <div class="hint">Leave blank to build it from the name.</div>
    </div>
  </div>

  <div class="grid grid-3" style="gap:12px">
    <div class="field">
      <label class="label">Collected by</label>
      <select name="kind">
        <?php foreach ($kinds as $k => $info): ?>
          <option value="<?= sfy_esc($k) ?>" <?= $v('kind', 'wallet') === $k ? 'selected' : '' ?>>
            <?= sfy_esc((string)$info['label']) ?></option>
        <?php endforeach; ?>
      </select>
      <div class="hint">wallet = an address or number you own · redirect = a hosted checkout link ·
        gateway = a link plus API keys and a callback.</div>
    </div>
    <div class="field">
      <label class="label">Icon (an emoji)</label>
      <input type="text" name="icon" maxlength="12" value="<?= sfy_esc($v('icon')) ?>" placeholder="🟡">
    </div>
    <div class="field">
      <label class="label">Network / chain</label>
      <input type="text" name="network" maxlength="96" value="<?= sfy_esc($v('network')) ?>" placeholder="USDT · TRC20">
    </div>
  </div>

  <div class="field">
    <label class="label">One-line summary (shown on the shop page)</label>
    <input type="text" name="summary" maxlength="255" value="<?= sfy_esc($v('summary')) ?>"
           placeholder="Send USDT to our wallet — low fee, confirmation in minutes.">
  </div>

  <div class="grid grid-2" style="gap:12px">
    <div class="field">
      <label class="label">What the buyer must provide (one per line)</label>
      <textarea name="requirements" style="min-height:110px"><?= sfy_esc($v('requirements')) ?></textarea>
      <div class="hint">Format: <span class="mono">Label | placeholder | required</span> — the third part is
        optional, and a line with no third part counts as required. Each one becomes a field on the buy page,
        and the answers arrive with the order.</div>
    </div>
    <div class="field">
      <label class="label">Payment instructions (shown to the buyer)</label>
      <textarea name="instructions" style="min-height:110px"><?= sfy_esc($v('instructions')) ?></textarea>
      <div class="hint">Where to send it, in the order they have to do it. Newlines are kept.</div>
    </div>
  </div>

  <div class="grid grid-3" style="gap:12px">
    <div class="field">
      <label class="label">Address / number / account</label>
      <input type="text" name="address" maxlength="255" value="<?= sfy_esc($v('address')) ?>" placeholder="0x… or 09xx xxx xxxx">
      <div class="hint">Printed on the order page with a copy button. Required for a wallet method.</div>
    </div>
    <div class="field">
      <label class="label">Currency this method settles in</label>
      <input type="text" name="currency" maxlength="8" value="<?= sfy_esc($v('currency')) ?>" placeholder="blank = the plan's">
    </div>
    <div class="field">
      <label class="label">Minimum</label>
      <input type="text" name="min_amount" value="<?= sfy_esc($v('min_amount', '0.00')) ?>">
      <div class="hint">0 means no minimum.</div>
    </div>
  </div>

  <div class="grid grid-2" style="gap:12px">
    <div class="field">
      <label class="label">Checkout link (hosted payment page)</label>
      <input type="text" name="checkout_url" maxlength="500" value="<?= sfy_esc($v('checkout_url')) ?>"
             placeholder="https://www.paypal.com/paypalme/you/{amount}">
      <div class="hint">Placeholders:
        <?php foreach (sfy_hub_payment_placeholders() as $ph => $what): ?>
          <span class="mono" title="<?= sfy_esc($what) ?>"><?= sfy_esc($ph) ?></span>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="field">
      <label class="label">What the buyer does after paying</label>
      <textarea name="confirm_note" style="min-height:70px"><?= sfy_esc($v('confirm_note')) ?></textarea>
    </div>
  </div>

  <fieldset style="border:1px solid var(--line);border-radius:var(--r);padding:13px;margin:0 0 14px">
    <legend class="label" style="padding:0 7px">Gateway API (optional — needed for auto-confirmation)</legend>

    <div class="grid grid-3" style="gap:12px">
      <div class="field">
        <label class="label">Provider</label>
        <input type="text" name="api_provider" maxlength="64" value="<?= sfy_esc($v('api_provider')) ?>" placeholder="stripe">
      </div>
      <div class="field" style="grid-column:span 2">
        <label class="label">API endpoint</label>
        <input type="text" name="api_endpoint" maxlength="500" value="<?= sfy_esc($v('api_endpoint')) ?>"
               placeholder="https://api.stripe.com/v1/checkout/sessions">
        <div class="hint">Used by the <b>Test</b> button: it checks that the host answers. A gateway refusing an
          anonymous GET with 401/405 is the expected answer.</div>
      </div>
    </div>

    <div class="grid grid-3" style="gap:12px">
      <div class="field">
        <label class="label">Public key / client id</label>
        <input type="text" name="api_key" maxlength="191" value="<?= sfy_esc($v('api_key')) ?>">
      </div>
      <div class="field">
        <label class="label">Secret key</label>
        <input type="text" name="api_secret" maxlength="255" value="<?= sfy_esc($v('api_secret')) ?>">
        <?php if (trim((string)$v('api_secret')) !== ''): ?>
          <div class="hint">Stored as typed. It is only ever sent to this screen.</div>
        <?php endif; ?>
      </div>
      <div class="field">
        <label class="label">Webhook secret</label>
        <input type="text" name="webhook_secret" maxlength="255" value="<?= sfy_esc($v('webhook_secret')) ?>">
      </div>
    </div>

    <div class="field">
      <label class="label">Extra credentials (one <span class="mono">key = value</span> per line)</label>
      <textarea name="api_extra" style="min-height:70px"><?= sfy_esc($v('api_extra')) ?></textarea>
    </div>

    <?php if ($id > 0 && trim((string)$v('webhook_secret')) !== ''): ?>
      <div class="field">
        <label class="label">Callback URL — paste this into the provider</label>
        <div class="hub-addr">
          <code id="hub-pay-hook"><?= sfy_esc(sfy_hub_payment_webhook_url($edit)) ?></code>
          <button type="button" class="hub-copy" data-hub-copy="#hub-pay-hook">COPY</button>
        </div>
        <div class="hint">It only accepts a POST whose body is signed with
          <?= sfy_esc(sfy_hub_payment_signature_note()) ?>
          A call that is not signed changes nothing.</div>
      </div>
      <?php $sample = sfy_hub_payment_link($edit, ['amount' => '4.00', 'currency' => 'USD', 'reference' => 'SFY-7K3M9Q',
                                                    'offer_slug' => '7-day', 'offer_title' => '7-Day Key']); ?>
      <?php if ($sample !== ''): ?>
        <div class="field">
          <label class="label">A real order through this link would look like</label>
          <div class="hub-import-out" style="max-height:80px"><?= sfy_esc($sample) ?></div>
        </div>
      <?php endif; ?>
    <?php endif; ?>
  </fieldset>

  <div class="grid grid-3" style="gap:12px">
    <div class="field">
      <label class="label">Sort order</label>
      <input type="number" name="sort_order" value="<?= (int)($edit['sort_order'] ?? 0) ?>">
    </div>
    <div class="field">
      <label class="label">Fee note</label>
      <input type="text" name="fee_note" maxlength="191" value="<?= sfy_esc($v('fee_note')) ?>"
             placeholder="Network fees are paid by the sender.">
    </div>
    <div class="field">
      <label class="label">State</label>
      <div class="chiprow">
        <label class="chip"><input type="checkbox" name="is_active" value="1"
          <?= !$edit || !empty($edit['is_active']) ? 'checked' : '' ?>> Offered</label>
        <label class="chip"><input type="checkbox" name="is_featured" value="1"
          <?= $edit && !empty($edit['is_featured']) ? 'checked' : '' ?>> Featured first</label>
        <label class="chip"><input type="checkbox" name="needs_review" value="1"
          <?= !$edit || !empty($edit['needs_review']) ? 'checked' : '' ?>> Admin confirms</label>
      </div>
    </div>
  </div>

  <div class="modal-actions">
    <a class="btn btn-sm btn-ghost" href="<?= sfy_esc($closeUrl) ?>">CANCEL</a>
    <button class="btn btn-primary"><?= $id > 0 ? 'SAVE METHOD' : 'CREATE METHOD' ?></button>
  </div>
</form>

<?php sfy_hub_modal_end(); ?>
<?php endif; ?>
