<?php
declare(strict_types=1);
/** Hub panel → Offers (the premium plans the buy page sells). */

$id     = (int)sfy_param('id', 0);
$edit   = $id > 0 ? sfy_hub_offer($id) : null;
$offers = sfy_hub_offers(false);
$cur    = (string)sfy_hub_setting('currency', 'USD');
$closeUrl = sfy_hub_admin_url(['tab' => 'offers']);
/* The plan form opens in a popup, and only when the URL asks for it — which
   is also what closes it again after a save. */
$open   = $edit !== null || (string)sfy_param('new', '') !== '';

$v = function (string $key, string $default = '') use ($edit): string {
    if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) === 'POST' && isset($_POST[$key]) && is_scalar($_POST[$key])) {
        return (string)$_POST[$key];
    }
    return (string)($edit[$key] ?? $default);
};
?>

<div class="card">
  <div class="card-head">
    <h2>&gt; PREMIUM_OFFERS</h2>
    <span class="spacer"></span>
    <span class="hub-admin-badge"><?= count($offers) ?> PLAN(S)</span>
    <a class="btn btn-sm" href="<?= sfy_esc(sfy_hub_url('offers')) ?>" target="_blank" rel="noopener">↗ view shop</a>
    <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_hub_url('buy')) ?>" target="_blank" rel="noopener">↗ view buy page</a>
    <?php if (sfy_admin_can('ads')): ?>
      <a class="btn btn-sm btn-primary" href="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'offers', 'new' => 1])) ?>">＋ ADD A PLAN</a>
    <?php endif; ?>
  </div>

  <?php if (!$offers): ?>
    <div class="empty">No plans yet. Add one with the button above — the shop page stays empty until you do.</div>
  <?php else: ?>
    <div class="tbl-wrap">
      <table class="tbl">
        <thead><tr>
          <th>Plan</th><th style="width:110px">Price</th><th style="width:90px">Duration</th>
          <th style="width:110px">Sold / stock</th><th style="width:130px">State</th><th style="width:190px">Actions</th>
        </tr></thead>
        <tbody>
        <?php foreach ($offers as $o): ?>
          <tr>
            <td>
              <b><?= sfy_esc((string)$o['title']) ?></b>
              <?php if (trim((string)$o['badge']) !== ''): ?><span class="hub-pill"><?= sfy_esc((string)$o['badge']) ?></span><?php endif; ?>
              <div class="hint mono"><?= sfy_esc((string)$o['slug']) ?>
                <?php if (trim((string)$o['checkout_url']) !== ''): ?> · external checkout<?php endif; ?></div>
            </td>
            <td class="mono"><?= sfy_esc(sfy_hub_money($o['price'], (string)$o['currency'])) ?>
              <?php if ((float)$o['old_price'] > 0): ?>
                <div class="tiny mute" style="text-decoration:line-through"><?= sfy_esc(sfy_hub_money($o['old_price'], (string)$o['currency'])) ?></div>
              <?php endif; ?>
            </td>
            <td class="small"><?= sfy_esc((string)($o['duration_label'] !== '' ? $o['duration_label'] : $o['duration_days'] . 'd')) ?></td>
            <td class="mono small"><?= (int)$o['sold'] ?> / <?= (int)$o['stock'] === 0 ? '∞' : (int)$o['stock'] ?></td>
            <td>
              <span class="hub-pill <?= !empty($o['is_active']) ? 'new' : 'cancelled' ?>">
                <?= !empty($o['is_active']) ? 'on sale' : 'hidden' ?></span>
              <?php if (!empty($o['is_featured'])): ?><span class="hub-pill pending">featured</span><?php endif; ?>
            </td>
            <td>
              <div class="btn-row" style="gap:6px">
                <a class="btn btn-sm" href="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'offers', 'id' => (int)$o['id']])) ?>">Edit</a>
                <form method="POST" class="inline">
                  <?= sfy_csrf_field() ?>
                  <input type="hidden" name="action" value="flag_offer">
                  <input type="hidden" name="id" value="<?= (int)$o['id'] ?>">
                  <input type="hidden" name="column" value="is_active">
                  <button class="btn btn-sm btn-ghost"><?= !empty($o['is_active']) ? 'Hide' : 'Show' ?></button>
                </form>
                <form method="POST" class="inline">
                  <?= sfy_csrf_field() ?>
                  <input type="hidden" name="action" value="flag_offer">
                  <input type="hidden" name="id" value="<?= (int)$o['id'] ?>">
                  <input type="hidden" name="column" value="is_featured">
                  <button class="btn btn-sm btn-ghost" title="Toggle featured"><?= !empty($o['is_featured']) ? '★' : '☆' ?></button>
                </form>
                <form method="POST" class="inline" data-confirm="Delete the offer &quot;<?= sfy_esc((string)$o['title']) ?>&quot;?">
                  <?= sfy_csrf_field() ?>
                  <input type="hidden" name="action" value="delete_offer">
                  <input type="hidden" name="id" value="<?= (int)$o['id'] ?>">
                  <button class="btn btn-sm btn-danger">Del</button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php if ($open):
  sfy_hub_modal_start([
      'title' => $edit ? 'Plan #' . $id : 'New plan',
      'sub'   => $edit ? (string)($edit['title'] ?? '') : 'A plan is a price, a duration and its perks',
      'icon'  => '⚡',
      'close' => $closeUrl,
      'wide'  => true,
  ]);
?>

<form method="POST" action="<?= sfy_esc($closeUrl) ?>">
  <?= sfy_csrf_field() ?>
  <input type="hidden" name="action" value="save_offer">
  <input type="hidden" name="id" value="<?= (int)$id ?>">

  <div class="grid grid-2" style="gap:12px">
    <div class="field">
      <label class="label">Title *</label>
      <input type="text" name="title" maxlength="191" required value="<?= sfy_esc($v('title')) ?>" placeholder="2-Day Key">
    </div>
    <div class="field">
      <label class="label">Subtitle</label>
      <input type="text" name="subtitle" maxlength="255" value="<?= sfy_esc($v('subtitle')) ?>" placeholder="Try it out">
    </div>
  </div>

  <div class="grid grid-3" style="gap:12px">
    <div class="field">
      <label class="label">Duration label</label>
      <input type="text" name="duration_label" maxlength="48" value="<?= sfy_esc($v('duration_label')) ?>" placeholder="2 DAYS">
    </div>
    <div class="field">
      <label class="label">Duration (days)</label>
      <input type="number" name="duration_days" min="0" max="3650" value="<?= (int)($edit['duration_days'] ?? 0) ?>">
    </div>
    <div class="field">
      <label class="label">Badge</label>
      <input type="text" name="badge" maxlength="48" value="<?= sfy_esc($v('badge')) ?>" placeholder="BEST VALUE">
    </div>
  </div>

  <div class="grid grid-3" style="gap:12px">
    <div class="field">
      <label class="label">Price</label>
      <input type="text" name="price" value="<?= sfy_esc($v('price', '0.00')) ?>">
    </div>
    <div class="field">
      <label class="label">Was (optional)</label>
      <input type="text" name="old_price" value="<?= sfy_esc($v('old_price')) ?>">
    </div>
    <div class="field">
      <label class="label">Currency</label>
      <input type="text" name="currency" maxlength="8" value="<?= sfy_esc($v('currency', $cur)) ?>">
    </div>
  </div>

  <div class="field">
    <label class="label">Perks (one per line)</label>
    <textarea name="perks" style="min-height:100px"><?= sfy_esc($v('perks')) ?></textarea>
  </div>

  <div class="field">
    <label class="label">Description</label>
    <textarea name="description" style="min-height:80px"><?= sfy_esc($v('description')) ?></textarea>
  </div>

  <div class="grid grid-2" style="gap:12px">
    <div class="field">
      <label class="label">Checkout URL (optional)</label>
      <input type="text" name="checkout_url" maxlength="500" value="<?= sfy_esc($v('checkout_url')) ?>">
      <div class="hint">Leave blank to collect an order here instead of sending the buyer elsewhere.</div>
    </div>
    <div class="field">
      <label class="label">Accent colour (optional)</label>
      <input type="text" name="accent" maxlength="7" value="<?= sfy_esc($v('accent')) ?>" placeholder="#e8b34a">
    </div>
  </div>

  <div class="grid grid-3" style="gap:12px">
    <div class="field">
      <label class="label">Stock (0 = unlimited)</label>
      <input type="number" name="stock" min="0" value="<?= (int)($edit['stock'] ?? 0) ?>">
    </div>
    <div class="field">
      <label class="label">Sort order</label>
      <input type="number" name="sort_order" value="<?= (int)($edit['sort_order'] ?? 0) ?>">
    </div>
    <div class="field">
      <label class="label">State</label>
      <div class="chiprow">
        <label class="chip"><input type="checkbox" name="is_active" value="1" <?= !$edit || !empty($edit['is_active']) ? 'checked' : '' ?>> On sale</label>
        <label class="chip"><input type="checkbox" name="is_featured" value="1" <?= $edit && !empty($edit['is_featured']) ? 'checked' : '' ?>> Featured</label>
      </div>
    </div>
  </div>

  <div class="modal-actions">
    <a class="btn btn-sm btn-ghost" href="<?= sfy_esc($closeUrl) ?>">CANCEL</a>
    <button class="btn btn-primary"><?= $edit ? 'SAVE PLAN' : 'CREATE PLAN' ?></button>
  </div>
</form>

<?php sfy_hub_modal_end(); ?>
<?php endif; ?>
