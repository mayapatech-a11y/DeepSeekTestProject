<?php
declare(strict_types=1);
/**
 * Hub panel → Appearance.
 *
 * The *palette* is not here on purpose: the hub prints the install's own
 * appearance layer, so colours, fonts, radius, glow and motion stay in one
 * place (Admin → Appearance). What this screen owns is everything the rest of
 * the site has no opinion about — how wide the hub is, how many cards fit in
 * a row, how big a thumbnail is, how large the type runs.
 *
 * Every value is a CSS custom property (see hub.css); changing one is a
 * number change, never a template edit, and the two links at the top show the
 * result immediately.
 */

$s = sfy_hub_settings();

$ranges = [
    'shell'      => ['Content width',      'px', 900,  1800, 20,  'The whole hub is centred inside this.'],
    'cols'       => ['Cards per row',      ' col', 2,   6,    1,   'On a screen wide enough for it.'],
    'gap'        => ['Space between cards','px', 0,    40,   2,   'Grid gap, and page rhythm.'],
    'card_pad'   => ['Card padding',       'px', 6,    30,   1,   'Inside every script card.'],
    'thumb_h'    => ['Image height',       'px', 90,   320,  5,   'Thumbnail height in the grid and the detail hero.'],
    'font_scale' => ['Type scale',         '%',  85,   130,  1,   'Scales the hub only, not the rest of the site.'],
    'title_size' => ['Card title size',    'px', 12,   24,   1,   'The script name on a card.'],
    'desc_lines' => ['Description lines',  '',   0,    4,    1,   'Lines of teaser kept in a card (0 = hide).'],
    'radius'     => ['Corner radius',      'px', 0,    28,   1,   '0 = follow the theme’s own radius.'],
    'logo_h'     => ['Logo bar height',    'px', 16,   90,   1,   'The logo is drawn as a bar, never a circle.'],
    'per_page'   => ['Scripts per page',   '',   4,    48,   2,   'Before the pager splits the list.'],
];

$presets = [
    'Gallery' => ['cols' => 4, 'thumb_h' => 150, 'card_pad' => 14, 'gap' => 16, 'font_scale' => 100, 'title_size' => 15, 'desc_lines' => 2, 'radius' => 0, 'shell' => 1240],
    'Dense'   => ['cols' => 5, 'thumb_h' => 118, 'card_pad' => 11, 'gap' => 11, 'font_scale' => 94,  'title_size' => 14, 'desc_lines' => 2, 'radius' => 8, 'shell' => 1440],
    'Big'     => ['cols' => 3, 'thumb_h' => 210, 'card_pad' => 18, 'gap' => 20, 'font_scale' => 108, 'title_size' => 18, 'desc_lines' => 3, 'radius' => 16, 'shell' => 1280],
    'Reader'  => ['cols' => 2, 'thumb_h' => 260, 'card_pad' => 20, 'gap' => 22, 'font_scale' => 112, 'title_size' => 19, 'desc_lines' => 4, 'radius' => 18, 'shell' => 1080],
];
?>

<div class="hub-admin-note">
  ◆ Palette, fonts, glow and motion belong to the whole install — change those in
  <a href="<?= sfy_esc(sfy_admin_url(['tab' => 'appearance'])) ?>">Main Admin → Appearance</a>
  and the hub follows. This screen is the hub-only sizing on top of it.
</div>

<div class="card">
  <div class="card-head">
    <h2>&gt; LIVE_LOOK</h2><span class="spacer"></span>
    <a class="btn btn-sm" href="<?= sfy_esc(sfy_hub_url()) ?>" target="_blank" rel="noopener">↗ hub home</a>
    <a class="btn btn-sm" href="<?= sfy_esc(sfy_hub_url('scripts')) ?>" target="_blank" rel="noopener">↗ scripts</a>
    <a class="btn btn-sm" href="<?= sfy_esc(sfy_hub_url('offers')) ?>" target="_blank" rel="noopener">↗ offers</a>
  </div>
  <div class="btn-row" id="hub-presets">
    <span class="label" style="margin:0 6px 0 0">Quick layouts:</span>
    <?php foreach ($presets as $name => $set): ?>
      <button type="button" class="btn btn-sm btn-ghost" data-hub-preset='<?= sfy_esc(json_encode($set)) ?>'>
        <?= sfy_esc($name) ?>
      </button>
    <?php endforeach; ?>
  </div>
  <div class="hint">A quick layout only fills the fields below — nothing is saved until you press SAVE.</div>
</div>

<form class="card" method="POST" action="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'appearance'])) ?>" id="hub-appearance-form">
  <?= sfy_csrf_field() ?>
  <input type="hidden" name="action" value="save_appearance">
  <input type="hidden" name="__flags" value="1">

  <div class="card-head"><h2>&gt; SIZING</h2></div>

  <div class="grid grid-2" style="gap:18px">
    <?php foreach ($ranges as $key => [$label, $suffix, $lo, $hi, $step, $hint]): ?>
      <div class="field">
        <label class="label"><?= sfy_esc($label) ?></label>
        <div class="hub-slider">
          <input type="range" name="<?= sfy_esc($key) ?>" min="<?= (int)$lo ?>" max="<?= (int)$hi ?>"
                 step="<?= (int)$step ?>" value="<?= (int)$s[$key] ?>" data-suffix="<?= sfy_esc($suffix) ?>">
          <output><?= (int)$s[$key] ?><?= sfy_esc($suffix) ?></output>
        </div>
        <div class="hint"><?= sfy_esc($hint) ?></div>
      </div>
    <?php endforeach; ?>
  </div>

  <hr class="sep">

  <div class="card-head"><h2>&gt; BLOCKS</h2></div>
  <div class="grid grid-2" style="gap:12px">
    <div class="field">
      <label class="label">Layout switches</label>
      <div class="chiprow">
        <label class="chip"><input type="checkbox" name="sidebar" value="1" <?= !empty($s['sidebar']) ? 'checked' : '' ?>> Side rail (featured + top scripts)</label>
        <label class="chip"><input type="checkbox" name="chips" value="1" <?= !empty($s['chips']) ? 'checked' : '' ?>> Game / category chips</label>
        <label class="chip"><input type="checkbox" name="search" value="1" <?= !empty($s['search']) ? 'checked' : '' ?>> Search box in the bar</label>
        <label class="chip"><input type="checkbox" name="filters" value="1" <?= !empty($s['filters']) ? 'checked' : '' ?>> Sort row above the grid</label>
      </div>
    </div>
    <div class="field">
      <label class="label">Logo</label>
      <div class="chiprow" style="margin-bottom:9px">
        <label class="chip"><input type="checkbox" name="logo_text" value="1" <?= !empty($s['logo_text']) ? 'checked' : '' ?>> Show the name next to the logo</label>
      </div>
      <input type="text" name="logo_url" maxlength="300" value="<?= sfy_esc((string)$s['logo_url']) ?>"
             placeholder="Blank = /sfyLogo.png from this install">
      <div class="hint">
        Rendered at the height above, with its own aspect ratio —
        <span class="mono">sfyLogo.png</span> is square, so it reads as a bar mark rather than an avatar.
      </div>
    </div>
  </div>

  <div class="btn-row" style="margin-top:14px">
    <button class="btn btn-primary btn-lg">SAVE THE LOOK</button>
    <button class="btn btn-ghost" type="reset">RESET THE FIELDS</button>
  </div>
</form>

<script>
(function(){
  /* Quick layouts: fill the sliders, update their readouts, save nothing. */
  var form = document.getElementById('hub-appearance-form');
  var wrap = document.getElementById('hub-presets');
  if(!form || !wrap) return;

  function sync(input){
    var out = input.parentNode.querySelector('output');
    if(out) out.textContent = input.value + (input.getAttribute('data-suffix') || '');
  }

  wrap.querySelectorAll('[data-hub-preset]').forEach(function(btn){
    btn.addEventListener('click', function(){
      var set;
      try { set = JSON.parse(btn.getAttribute('data-hub-preset')); } catch(e){ return; }
      Object.keys(set).forEach(function(k){
        var el = form.querySelector('[name="' + k + '"]');
        if(!el) return;
        el.value = set[k];
        sync(el);
      });
      wrap.querySelectorAll('button').forEach(function(b){ b.classList.remove('btn-primary'); });
      btn.classList.add('btn-primary');
    });
  });

  form.querySelectorAll('input[type=range]').forEach(function(r){
    r.addEventListener('input', function(){ sync(r); });
  });
})();
</script>
