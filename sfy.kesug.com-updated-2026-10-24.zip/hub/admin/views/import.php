<?php
declare(strict_types=1);
/** Hub panel → Import a link. */

$last = $_SESSION['sfy_hub_import'] ?? null;
$url  = is_array($last) ? (string)($last['url'] ?? '') : '';
$fail = is_array($last) && empty($last['ok']) ? (string)($last['error'] ?? '') : '';
$notes = is_array($last) ? (array)($last['notes'] ?? []) : [];
?>

<div class="hub-admin-note">
  ◆ Paste a script page link and the importer fills a script card from it — then you review and edit every
  field before saving. This is the same pipeline as the “Fill from a link” box in the editor, with room to
  explain what it does and does not manage.
</div>

<div class="hub-grid-2">
  <div class="card">
    <div class="card-head"><h2>&gt; IMPORT_FROM_LINK</h2></div>

    <?php if ($fail !== ''): ?>
      <div class="msg err">✖ <?= sfy_esc($fail) ?></div>
    <?php endif; ?>

    <form method="POST" action="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'import'])) ?>" data-hub-once>
      <?= sfy_csrf_field() ?>
      <input type="hidden" name="action" value="import_fetch">

      <div class="field">
        <label class="label">Script page URL</label>
        <input type="text" name="url" maxlength="500" value="<?= sfy_esc($url) ?>"
               placeholder="https://scriptblox.com/script/SILENT-AIMBOT-WITH-ESP-by-SFY-212341">
        <div class="hint">
          ScriptBlox is read through its public JSON API; HaxHell and everything else through the page HTML.
        </div>
      </div>

      <div class="field">
        <label class="label">…or paste the page source / the code</label>
        <textarea name="pasted" style="min-height:130px;font-family:var(--mono);font-size:12px" spellcheck="false"
                  placeholder="When a site blocks server requests, open it in your browser, press Ctrl+U (view source), copy everything and paste it here. Pasting just the Lua code works too."></textarea>
        <div class="hint">Pasting fills in for the network fetch entirely — nothing is requested from the site.</div>
      </div>

      <div class="field">
        <label class="label">Video link (optional)</label>
        <input type="text" name="video_url" maxlength="500"
               placeholder="https://youtu.be/… or the whole embed code">
        <div class="hint">
          The fetch already takes a video link off the page when there is one. Whatever you type here wins, and it
          travels into the draft with everything else. YouTube and Vimeo play inside the script page's hero image;
          any other link becomes a plain <b>▶ WATCH VIDEO</b> button.
        </div>
        <div class="chiprow" style="margin-top:8px">
          <label class="chip"><input type="checkbox" name="video_autoplay" value="1"> ▶ Autoplay it (starts muted)</label>
        </div>
      </div>

      <button class="btn btn-primary btn-lg" data-busy="FETCHING…">📥 FETCH &amp; FILL A DRAFT</button>
    </form>

    <?php if ($notes && $fail === ''): ?>
      <div class="label" style="margin-top:16px">Last fetch</div>
      <div class="hub-import-out"><?php foreach ($notes as $n): ?><?= sfy_esc((string)$n) . "\n" ?><?php endforeach; ?></div>
    <?php endif; ?>
  </div>

  <div>
    <div class="card">
      <div class="card-head"><h2>&gt; SOURCES</h2></div>
      <table class="hub-table-mini">
        <tr><th>Source</th><th>How it is read</th></tr>
        <?php foreach (sfy_hub_import_sources() as $key => $src): ?>
          <tr>
            <td><b><?= sfy_esc((string)$src['label']) ?></b><div class="hint mono"><?= sfy_esc($key) ?></div></td>
            <td class="small"><?= sfy_esc((string)$src['how']) ?></td>
          </tr>
        <?php endforeach; ?>
      </table>
    </div>

    <div class="card">
      <div class="card-head"><h2>&gt; WHEN_IT_FAILS</h2></div>
      <ol class="hub-steps">
        <li><b>“refused the request (HTTP 403/503)”</b> — the site's bot protection blocks servers. Open the
          page in your browser, view source, paste it into the box on the left.</li>
        <li><b>“nothing usable was found”</b> — the page renders in JavaScript. Looking at the script in your
          browser and copying the code by hand always works; paste it into the Script code box.</li>
        <li><b>“allows neither curl nor outbound streams”</b> — this host cannot make outbound requests at
          all. Every import has to go through the paste box.</li>
        <li><b>Partial fields</b> — normal. An import fills what the page exposes; the rest is the editor's
          job, which is exactly why nothing is saved automatically.</li>
      </ol>
    </div>

    <div class="card">
      <div class="card-head"><h2>&gt; LEGAL_NOTE</h2></div>
      <p class="small dim" style="margin:0">
        Importing copies <i>content</i> — a title, a description, a piece of Lua — from a page you pointed at.
        Whether you may republish it is a question for that page's author and your own terms, not for this
        script; the module simply records where a card came from
        (<span class="mono">source_url</span>) so the answer stays checkable.
      </p>
    </div>
  </div>
</div>
