<?php
declare(strict_types=1);
/** Hub panel → Scripts (list). */

$q      = (string)sfy_param('q', '');
$status = (string)sfy_param('status', 'any');
$page   = max(1, sfy_int('page', 1));
$per    = 25;

$filter = ['q' => $q, 'status' => in_array($status, ['published', 'draft'], true) ? $status : 'any'];
$total  = sfy_hub_scripts_count($filter);
$rows   = sfy_hub_scripts($filter, $page, $per);
$pages  = max(1, (int)ceil($total / $per));

$statusUrl = function (string $st) use ($q): string {
    return sfy_hub_admin_url(['tab' => 'scripts', 'status' => $st, 'q' => $q]);
};
?>

<div class="card">
  <div class="card-head">
    <h2>&gt; SCRIPT_LIBRARY</h2>
    <span class="spacer"></span>
    <span class="hub-admin-badge"><?= number_format($total) ?> ROW(S)</span>
    <a class="btn btn-sm btn-primary" href="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'script'])) ?>">＋ NEW</a>
    <a class="btn btn-sm" href="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'import'])) ?>">📥 IMPORT</a>
  </div>

  <div class="input-group" style="display:flex;gap:9px;flex-wrap:wrap;align-items:center;margin-bottom:13px">
    <form method="GET" action="<?= sfy_esc(sfy_url('hub/admin/')) ?>" style="display:flex;gap:9px;flex:1 1 260px;min-width:0">
      <input type="hidden" name="tab" value="scripts">
      <input type="hidden" name="status" value="<?= sfy_esc($filter['status']) ?>">
      <input class="grow" type="search" name="q" value="<?= sfy_esc($q) ?>" placeholder="Search title, game, tag, author…">
      <button class="btn btn-sm">SEARCH</button>
    </form>
    <div class="seg">
      <a class="<?= $filter['status'] === 'published' ? 'active' : '' ?>" href="<?= sfy_esc($statusUrl('published')) ?>">Published</a>
      <a class="<?= $filter['status'] === 'draft' ? 'active' : '' ?>" href="<?= sfy_esc($statusUrl('draft')) ?>">Drafts</a>
      <a class="<?= $filter['status'] === 'any' ? 'active' : '' ?>" href="<?= sfy_esc($statusUrl('any')) ?>">All</a>
    </div>
  </div>

  <?php if (!$rows): ?>
    <div class="empty">Nothing matches. <?= $q !== '' ? 'Try a different search.' : 'Add a script, or import one from a link.' ?></div>
  <?php else: ?>
    <div class="tbl-wrap">
      <table class="tbl">
        <thead>
          <tr>
            <th style="width:56px">Img</th>
            <th>Script</th>
            <th style="width:130px">Game</th>
            <th style="width:96px">Flags</th>
            <th style="width:110px">Views / copies</th>
            <th style="width:150px">Source</th>
            <th style="width:210px">Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td>
              <?php $thumb = trim((string)$r['thumbnail']); ?>
              <?php if ($thumb !== ''): ?>
                <img src="<?= sfy_esc($thumb) ?>" alt="" style="width:44px;height:34px;object-fit:cover;border-radius:6px"
                     referrerpolicy="no-referrer">
              <?php else: ?>
                <span class="hub-pill">no img</span>
              <?php endif; ?>
            </td>
            <td>
              <b><?= sfy_esc(sfy_short((string)$r['title'], 46)) ?></b>
              <div class="hint mono" style="margin-top:2px">/<?= sfy_esc((string)$r['slug']) ?></div>
            </td>
            <td class="small"><?= sfy_esc((string)$r['game_name'] !== '' ? (string)$r['game_name'] : '—') ?></td>
            <td>
              <span class="hub-pill <?= (string)$r['status'] === 'published' ? 'new' : 'pending' ?>">
                <?= (string)$r['status'] === 'published' ? 'live' : 'draft' ?></span>
              <?php if (!empty($r['is_featured'])): ?><span class="hub-pill">feat</span><?php endif; ?>
              <?php if (!empty($r['key_system'])): ?><span class="hub-pill">key</span><?php endif; ?>
            </td>
            <td class="mono small"><?= number_format((int)$r['views']) ?> / <?= number_format((int)$r['copies']) ?></td>
            <td class="small">
              <?= sfy_esc((string)$r['source']) ?>
              <?php if (trim((string)$r['source_url']) !== ''): ?>
                <div><a class="mono tiny" href="<?= sfy_esc((string)$r['source_url']) ?>" target="_blank" rel="noopener nofollow">link ↗</a></div>
              <?php endif; ?>
            </td>
            <td>
              <div class="btn-row" style="gap:6px">
                <a class="btn btn-sm" href="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'script', 'id' => (int)$r['id']])) ?>">Edit</a>
                <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_hub_script_link($r)) ?>" target="_blank" rel="noopener">View</a>

                <form method="POST" class="inline">
                  <?= sfy_csrf_field() ?>
                  <input type="hidden" name="action" value="publish_script">
                  <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                  <input type="hidden" name="status" value="<?= (string)$r['status'] === 'published' ? 'draft' : 'published' ?>">
                  <button class="btn btn-sm <?= (string)$r['status'] === 'published' ? 'btn-ghost' : 'btn-primary' ?>"
                          title="<?= (string)$r['status'] === 'published' ? 'Unpublish' : 'Publish' ?>">
                    <?= (string)$r['status'] === 'published' ? 'Unpub' : 'Publish' ?>
                  </button>
                </form>

                <form method="POST" class="inline">
                  <?= sfy_csrf_field() ?>
                  <input type="hidden" name="action" value="flag_script">
                  <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                  <input type="hidden" name="column" value="is_featured">
                  <button class="btn btn-sm btn-ghost" title="Toggle featured">
                    <?= !empty($r['is_featured']) ? '★' : '☆' ?>
                  </button>
                </form>

                <form method="POST" class="inline" data-confirm="Delete &quot;<?= sfy_esc(sfy_short((string)$r['title'], 40)) ?>&quot;? This cannot be undone.">
                  <?= sfy_csrf_field() ?>
                  <input type="hidden" name="action" value="delete_script">
                  <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                  <button class="btn btn-sm btn-danger">Del</button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <?php if ($pages > 1): ?>
      <div class="hub-pager">
        <?php for ($p = 1; $p <= $pages; $p++): ?>
          <a class="hub-page <?= $p === $page ? 'on' : '' ?>"
             href="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'scripts', 'q' => $q, 'status' => $filter['status'], 'page' => $p])) ?>"><?= $p ?></a>
        <?php endfor; ?>
      </div>
    <?php endif; ?>
  <?php endif; ?>
</div>
