<?php
declare(strict_types=1);
/**
 * Hub panel → Diagnostics.
 *
 * The screen to open *before* uploading, and the one to open when an upload
 * already went wrong. It answers, in one place and without a shell on the
 * host: is every table and column here, is there anything to show, are the
 * stored settings the ones the pages actually read, do the import sources
 * still have the shape the readers were written for, and are drafts really
 * absent from the sitemap.
 *
 * The live source probe makes outbound requests, so it is a button and never
 * part of rendering this page.
 */

$h      = sfy_hub_health();
$s      = sfy_hub_settings();
$probe  = $h['probe'];
$pill   = fn($ok): string => !empty($ok) ? 'g' : 'r';

/* The one line the owner pastes into robots.txt. It is shown rather than
   written: the module must not touch a file outside its own folder, and a
   robots.txt that exists is the site owner's, not the module's. */
$robots = "User-agent: *\nAllow: /hub/\nSitemap: " . $h['index']['url'] . "\n";
?>

<div class="hub-grid-3" style="margin-bottom:var(--gap)">
  <?= sfy_kpi('Problems', number_format($h['problems']), $h['problems'] > 0 ? 'red' : 'g',
              $h['problems'] > 0 ? 'fix these before an upload' : 'nothing blocking') ?>
  <?= sfy_kpi('Tables', number_format(count($h['tables']) - count($h['missing_tables'])) . ' / ' . count($h['tables']),
              $h['missing_tables'] ? 'red' : 'g',
              $h['missing_columns'] ? count($h['missing_columns']) . ' column(s) missing' : 'all columns present') ?>
  <?= sfy_kpi('Scripts live', number_format((int)$h['content']['published']), 'g',
              number_format((int)$h['content']['drafts']) . ' draft(s)') ?>
  <?= sfy_kpi('Indexable URLs', number_format((int)$h['index']['count']), 'blue',
              $h['index']['leaked'] ? 'DRAFTS LEAKED' : 'drafts excluded') ?>
  <?= sfy_kpi('Settings read', number_format((int)$h['settings']['saved']) . ' / ' . number_format((int)$h['settings']['total']),
              $h['settings']['odd'] ? 'orange' : 'g',
              $h['settings']['odd'] ? count($h['settings']['odd']) . ' rewritten on read' : 'as stored') ?>
  <?= sfy_kpi('Payment methods', number_format((int)$h['payments']['offered']) . ' on offer',
              $h['payments']['unusable'] ? 'red' : 'g',
              $h['payments']['fallback'] ? 'table missing — built-ins shown'
                : number_format((int)$h['payments']['rows']) . ' configured · ' . number_format((int)$h['payments']['with_secrets']) . ' with API keys') ?>
  <?= sfy_kpi('Import transport', $h['runtime']['curl'] ? 'curl' : ($h['runtime']['fopen'] ? 'streams' : 'none'),
              $h['runtime']['ok'] ? 'g' : 'red',
              'PHP ' . $h['runtime']['php']) ?>
</div>

<div class="card">
  <div class="card-head">
    <h2>&gt; HUB_DIAGNOSTICS</h2><span class="spacer"></span>
    <span class="badge <?= $h['problems'] > 0 ? 'r' : 'g' ?>">
      <?= $h['problems'] > 0 ? '✖ ' . (int)$h['problems'] . ' PROBLEM(S)' : '✓ HEALTHY' ?>
    </span>
  </div>

  <?php if ($h['problems'] === 0): ?>
    <p class="small dim" style="margin:0">
      Schema, content, settings, import readers and the sitemap all check out. Nothing here needs doing before an upload.
    </p>
  <?php else: ?>
    <div class="msg warn">
      ◆
      <?php
      $bits = [];
      if ($h['missing_tables'])  $bits[] = count($h['missing_tables']) . ' table(s) missing';
      if ($h['missing_columns']) $bits[] = count($h['missing_columns']) . ' column(s) missing';
      if ($h['settings']['odd']) $bits[] = count($h['settings']['odd']) . ' setting(s) rewritten on read';
      if ($h['payments']['unusable']) $bits[] = count($h['payments']['unusable']) . ' payment method(s) offered but unable to collect';
      if ($h['index']['leaked']) $bits[] = 'a draft is listed in the sitemap';
      if (!$h['runtime']['ok'])  $bits[] = 'no outbound transport, so link import cannot run on this host';
      foreach ($h['offline'] as $o) if (!$o['ok']) $bits[] = 'the ' . $o['label'] . ' reader no longer matches its source';
      echo sfy_esc(implode(' · ', $bits));
      ?>
      — the sections below say which.
    </div>
  <?php endif; ?>

  <table class="hub-table-mini" style="margin-top:14px">
    <tr><th>Check</th><th>What it means</th><th>State</th></tr>
    <tr>
      <td class="mono">schema</td>
      <td>Every table and column this version declares exists in the database.</td>
      <td><span class="badge <?= $pill(!$h['missing_tables'] && !$h['missing_columns']) ?>">
        <?= (!$h['missing_tables'] && !$h['missing_columns']) ? '✓ OK' : '✖ INCOMPLETE' ?></span></td>
    </tr>
    <tr>
      <td class="mono">schema stamp</td>
      <td>The installer only skips its work when the stamp matches the code:
          <span class="mono"><?= sfy_esc($h['schema']['stamp'] === '' ? '(never stamped)' : $h['schema']['stamp']) ?></span>
          vs <span class="mono"><?= sfy_esc($h['schema']['expected']) ?></span>.</td>
      <td><span class="badge <?= $pill($h['schema']['match']) ?>"><?= $h['schema']['match'] ? '✓ MATCH' : '◆ STALE' ?></span></td>
    </tr>
    <tr>
      <td class="mono">seed</td>
      <td>The plans and the example card the first run installs.</td>
      <td><span class="badge <?= $pill((int)$h['content']['offers'] > 0) ?>">
        <?= ((int)$h['content']['offers'] > 0) ? '✓ OFFERS' : '◆ NO OFFERS' ?></span></td>
    </tr>
    <tr>
      <td class="mono">settings</td>
      <td>Values under <span class="mono">set_hub_*</span> that the module reads back unchanged.</td>
      <td><span class="badge <?= $pill(!$h['settings']['odd']) ?>">
        <?= $h['settings']['odd'] ? '◆ ' . count($h['settings']['odd']) . ' REWRITTEN' : '✓ OK' ?></span></td>
    </tr>
    <tr>
      <td class="mono">videos</td>
      <td>Every script with a video link plays it in the hero image. A link from a host this does not embed
          is kept and offered as a button instead — nothing is lost, but nothing plays either.</td>
      <td><span class="badge <?= $pill($h['videos']['odd'] === []) ?>">
        <?= $h['videos']['odd']
            ? '◆ ' . count($h['videos']['odd']) . ' NOT EMBEDDABLE'
            : ($h['videos']['total'] > 0 ? '✓ ' . (int)$h['videos']['playable'] . ' PLAY' . ((int)$h['videos']['autoplay'] > 0 ? ' · ' . (int)$h['videos']['autoplay'] . ' AUTO' : '') : '✓ NONE') ?></span></td>
    </tr>
    <tr>
      <td class="mono">payments</td>
      <td>Every method that is on offer can actually collect: a wallet has an address, a checkout has a link,
          a gateway has its keys.</td>
      <td><span class="badge <?= $pill(!$h['payments']['unusable']) ?>">
        <?= $h['payments']['unusable'] ? '◆ ' . count($h['payments']['unusable']) . ' BLOCKED' : '✓ OK' ?></span></td>
    </tr>
    <tr>
      <td class="mono">import readers</td>
      <td>Each reader still finds the fields it promises in a page of the documented shape.</td>
      <td><span class="badge <?= $pill(count(array_filter($h['offline'], fn($o) => !$o['ok'])) === 0) ?>">
        <?= count(array_filter($h['offline'], fn($o) => !$o['ok'])) === 0 ? '✓ OK' : '✖ DRIFT' ?></span></td>
    </tr>
    <tr>
      <td class="mono">sitemap</td>
      <td><span class="mono"><?= sfy_esc((string)$h['index']['url']) ?></span> —
          <?= number_format((int)$h['index']['count']) ?> URL(s),
          <?= number_format((int)$h['index']['bytes']) ?> bytes, no draft among them.</td>
      <td><span class="badge <?= $pill($h['index']['leaked'] === []) ?>">
        <?= $h['index']['leaked'] ? '✖ LEAK' : '✓ CLEAN' ?></span></td>
    </tr>
  </table>

  <hr class="sep">

  <div class="btn-row">
    <?php if (sfy_admin_can('updater')): ?>
      <form method="POST" data-hub-once style="display:inline">
        <?= sfy_csrf_field() ?>
        <input type="hidden" name="action" value="install">
        <button class="btn btn-primary" data-busy="INSTALLING…">⬆ CREATE / REPAIR TABLES + COLUMNS</button>
      </form>
      <form method="POST" data-hub-once style="display:inline">
        <?= sfy_csrf_field() ?>
        <input type="hidden" name="action" value="probe_sources">
        <button class="btn" data-busy="CHECKING SOURCES…">📡 CHECK IMPORT SOURCES LIVE</button>
      </form>
    <?php else: ?>
      <span class="hint" style="margin:0">Installing and probing need the <span class="mono">updater</span> capability.</span>
    <?php endif; ?>
    <a class="btn btn-ghost" href="<?= sfy_esc(sfy_hub_url('sitemap')) ?>" target="_blank" rel="noopener">↗ OPEN THE SITEMAP</a>
  </div>
  <p class="hint">
    Repair is additive only — it creates what is absent and never drops, renames or truncates. The live probe fetches
    each source once (a few seconds) and is never run while this page renders.
  </p>
</div>

<div class="hub-grid-2">
  <div class="card">
    <div class="card-head">
      <h2>&gt; SCHEMA</h2><span class="spacer"></span>
      <span class="badge <?= $pill($h['missing_tables'] === [] && $h['missing_columns'] === []) ?>">
        <?= ($h['missing_tables'] === [] && $h['missing_columns'] === []) ? '✓ READY' : '✖ INCOMPLETE' ?>
      </span>
    </div>
    <table class="hub-table-mini">
      <tr><th>Table</th><th>Present</th><th>Columns</th><th>Rows</th></tr>
      <?php foreach ($h['tables'] as $table => $t): ?>
        <tr>
          <td class="mono"><?= sfy_esc($table) ?></td>
          <td><?= $t['exists'] ? '✓' : '✖' ?></td>
          <td><?= $t['exists'] ? number_format((int)$t['columns'] - count($t['missing'])) . ' / ' . number_format((int)$t['columns']) : '—' ?></td>
          <td><?= $t['rows'] < 0 ? '—' : number_format((int)$t['rows']) ?></td>
        </tr>
      <?php endforeach; ?>
    </table>

    <?php if ($h['missing_columns']): ?>
      <div class="msg warn" style="margin-top:12px">
        ◆ Missing column(s): <span class="mono"><?= sfy_esc(implode(', ', array_slice($h['missing_columns'], 0, 12))) ?></span><?= count($h['missing_columns']) > 12 ? ' …' : '' ?>
        — this is what a shared host timing out halfway through an update looks like. The repair button adds them.
      </div>
    <?php else: ?>
      <p class="hint" style="margin-top:12px">
        Every column the module's own definitions declare is present. It derives this list from the same text that
        produces the ALTER, so a definition-only column cannot hide here.
      </p>
    <?php endif; ?>
  </div>

  <div class="card">
    <div class="card-head">
      <h2>&gt; CONTENT</h2><span class="spacer"></span>
      <span class="badge <?= $pill((int)$h['content']['published'] > 0) ?>">
        <?= ((int)$h['content']['published'] > 0) ? '✓ LIVE' : '◆ EMPTY' ?>
      </span>
    </div>
    <table class="hub-table-mini">
      <tr><th>What</th><th>Count</th></tr>
      <tr><td>Published scripts</td><td><?= number_format((int)$h['content']['published']) ?></td></tr>
      <tr><td>Drafts (staff only)</td><td><?= number_format((int)$h['content']['drafts']) ?></td></tr>
      <tr><td>Games with a published script</td><td><?= number_format((int)$h['content']['games']) ?></td></tr>
      <tr><td>Offers — active / total</td>
          <td><?= number_format((int)$h['content']['offers_active']) ?> / <?= number_format((int)$h['content']['offers']) ?></td></tr>
      <tr><td>Orders placed all time</td><td><?= number_format((int)($h['content']['orders']['total'] ?? 0)) ?></td></tr>
      <tr><td>Messages received</td><td><?= number_format((int)($h['content']['messages']['total'] ?? 0)) ?></td></tr>
    </table>

    <?php if ((int)$h['content']['offers'] === 0): ?>
      <div class="msg warn" style="margin-top:12px">
        ◆ No premium plans. The shop page renders an empty state instead of prices — the first run should have seeded
        three, so either that insert failed or an administrator deleted all of them.
      </div>
    <?php endif; ?>

    <?php if ($h['content']['showcase']): ?>
      <p class="hint">
        The example card <span class="mono">sfy-showcase-silent-aimbot-esp</span> is still here, as a draft. Edit it,
        publish it, or delete it — it is invisible to visitors either way.
      </p>
    <?php endif; ?>

    <?php if ((int)$h['content']['published'] === 0 && (int)$h['content']['drafts'] > 0): ?>
      <p class="hint">
        Nothing is published yet: <?= number_format((int)$h['content']['drafts']) ?> draft(s) are waiting. Visitors
        see the empty grid until one is published.
      </p>
    <?php endif; ?>

    <div class="label" style="margin:16px 0 6px">Videos</div>
    <table class="hub-table-mini">
      <tr><th>What</th><th>Count</th></tr>
      <tr><td>Scripts with a video link</td><td><?= number_format((int)$h['videos']['total']) ?></td></tr>
      <tr><td>…that play in the hero image</td><td><?= number_format((int)$h['videos']['playable']) ?></td></tr>
      <tr><td>…set to start on their own (muted)</td><td><?= number_format((int)$h['videos']['autoplay']) ?></td></tr>
    </table>

    <?php if ($h['videos']['odd']): ?>
      <div class="msg warn" style="margin-top:12px">
        ◆ These links cannot be played inside the page, so the script page keeps its picture and offers the link as
        a <b>▶ WATCH VIDEO</b> button instead — the video is not lost, it is only not embedded:
        <?php foreach (array_slice($h['videos']['odd'], 0, 8) as $o): ?><br>
          · <span class="mono"><?= sfy_esc(sfy_short($o['title'], 46)) ?></span> — <?= sfy_esc(sfy_short($o['url'], 60)) ?>
        <?php endforeach; ?>
        <?php if (count($h['videos']['odd']) > 8): ?><br>· …and <?= count($h['videos']['odd']) - 8 ?> more<?php endif; ?>
        <br>YouTube and Vimeo links play in place. Edit a script to replace one of these with either.
      </div>
    <?php elseif ((int)$h['videos']['total'] === 0): ?>
      <p class="hint">
        No script carries a video. The hero image is just an image until one does — the script editor and the
        import form both take a YouTube or Vimeo link, or the whole embed code.
      </p>
    <?php endif; ?>
  </div>
</div>

<div class="card">
  <div class="card-head">
    <h2>&gt; PAYMENT METHODS</h2><span class="spacer"></span>
    <span class="badge <?= $pill(!$h['payments']['unusable']) ?>">
      <?= $h['payments']['unusable'] ? '◆ ' . count($h['payments']['unusable']) . ' CANNOT COLLECT' : '✓ USABLE' ?>
    </span>
  </div>

  <p class="small dim" style="margin-top:0">
    The shop page only offers a method the module can actually use. A wallet with no address or a checkout with no
    link is skipped at render time — the shop keeps working and silently offers fewer ways to pay, which is exactly
    the kind of fault nobody reports. An empty address on a freshly seeded method is a template waiting to be filled,
    not a breakage, so only a method that is <b>on offer</b> and still cannot collect counts as a problem.
  </p>

  <?php if ($h['payments']['fallback']): ?>
    <div class="msg warn" style="margin-top:12px">
      ◆ <span class="mono">sfy_hub_payment_methods</span> does not exist, so the shop is falling back to the built-in
      method list. Repair the tables above to store your own methods and their API configuration.
    </div>
  <?php endif; ?>

  <table class="hub-table-mini">
    <tr><th>Method</th><th>Kind</th><th>On offer</th><th>Can collect</th><th>Missing</th></tr>
    <?php
    $pmRows = sfy_hub_payments(false);
    if (!$pmRows): ?>
      <tr><td colspan="5" class="dim">No payment method rows — the shop shows the built-in fallback list.</td></tr>
    <?php else: foreach ($pmRows as $m):
        $rd = sfy_hub_payment_ready($m);
        $on = !empty($m['is_active']);
        /* Four states, because "not ready" is not the same as "unusable": a
           method with instructions but no address is still a method a buyer
           can pay by hand, so the shop keeps it. Only the row the shop skips
           is reported as blocked. */
        $usable = sfy_hub_payment_usable($m);
        if (!$on)                    { $badge = ['◆ HIDDEN',  'gr']; }
        elseif ($rd['ok'])           { $badge = ['✓ READY',   'g'];  }
        elseif ($usable)             { $badge = ['◆ BY HAND', 'y'];  }
        else                         { $badge = ['✖ SKIPPED', 'r'];  } ?>
      <tr>
        <td>
          <?= sfy_esc((string)($m['name'] ?? $m['slug'] ?? '#')) ?>
          <span class="dim" style="font-size:11px"> · <span class="mono"><?= sfy_esc((string)($m['slug'] ?? '')) ?></span></span>
          <?php if (trim((string)($m['api_key'] ?? '')) !== ''): ?>
            <span class="hub-opt-tag">API</span>
          <?php endif; ?>
        </td>
        <td class="dim"><?= sfy_esc((string)($m['kind'] ?? 'wallet')) ?></td>
        <td><?= $on ? '✓' : '—' ?></td>
        <td><span class="badge <?= $badge[1] ?>"><?= $badge[0] ?></span></td>
        <td class="dim"><?= $rd['missing'] ? '<span class="mono">' . sfy_esc(implode(', ', $rd['missing'])) . '</span>' : '—' ?></td>
      </tr>
    <?php endforeach; endif; ?>
  </table>

  <?php if ((int)$h['payments']['rows'] > 0 && (int)$h['payments']['offered'] === 0): ?>
    <div class="msg warn" style="margin-top:12px">
      ◆ There are <?= number_format((int)$h['payments']['rows']) ?> method(s) in the table and <b>none of them is
      switched on</b>, so the buy page offers no way to pay at all. Fill one in and turn it on — a freshly seeded
      method ships switched off on purpose, because an address or a link has to be pasted into it first.
    </div>
  <?php endif; ?>

  <?php foreach ($h['payments']['unusable'] as $u): ?>
    <div class="msg warn" style="margin-top:12px">
      ◆ <b><?= sfy_esc((string)$u['name']) ?></b> is offered to buyers but cannot collect — it is missing
      <span class="mono"><?= sfy_esc(implode(', ', (array)$u['missing'])) ?></span>. The buy page skips it, so buyers
      never see this method at all.
    </div>
  <?php endforeach; ?>

  <?php if ($h['payments']['partial']): ?>
    <p class="hint">
      Gateway credentials that are half-entered:
      <?php $bits = [];
      foreach ($h['payments']['partial'] as $p) $bits[] = $p['name'] . ' (missing ' . implode(', ', (array)$p['missing']) . ')';
      echo sfy_esc(implode(' · ', $bits));
      ?>. Until every key is filled in, a callback cannot be verified, so those orders keep waiting for a human.
    </p>
  <?php endif; ?>

  <p class="hint">
    <?php if ($h['payments']['auto']): ?>
      Confirming on their own callback:
      <?= sfy_esc(implode(', ', (array)$h['payments']['auto'])) ?>.
    <?php else: ?>
      No method confirms by itself yet — every order is confirmed by hand. That is a valid way to run the shop.
    <?php endif; ?>
    Manage the methods, their addresses and their API configuration on the
    <a href="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'payments'])) ?>">Payments</a> tab.
  </p>
</div>

<div class="card">
  <div class="card-head">
    <h2>&gt; SETTINGS</h2><span class="spacer"></span>
    <span class="badge <?= $pill(!$h['settings']['odd']) ?>">
      <?= $h['settings']['odd'] ? '◆ ' . count($h['settings']['odd']) . ' REWRITTEN' : '✓ OK' ?>
    </span>
  </div>

  <p class="small dim" style="margin-top:0">
    Every knob is a row in the install's own config table under <span class="mono">set_hub_*</span>. A row whose value
    the normaliser has to change is listed below: the page renders the corrected value while the database keeps the
    old one, so the slider appears to do nothing. Saving the screen that owns the value fixes it.
  </p>

  <table class="hub-table-mini">
    <tr><th>Setting</th><th>Stored</th><th>Used instead</th><th>Owned by</th></tr>
    <?php
    $groups = sfy_hub_flag_groups();
    $owner  = function (string $key) use ($groups): string {
        if (in_array($key, $groups['appearance'] ?? [], true) || in_array($key, sfy_hub_ints(), true)) return 'Appearance';
        if (in_array($key, $groups['settings'] ?? [], true)) return 'Settings';
        return 'Settings';
    };
    if (!$h['settings']['odd']): ?>
      <tr><td colspan="4" class="dim">Nothing is rewritten — every stored value is the value in use.</td></tr>
    <?php else: foreach ($h['settings']['odd'] as $key => $v): ?>
      <tr>
        <td class="mono"><?= sfy_esc((string)$key) ?></td>
        <td class="mono"><?= sfy_esc((string)$v['stored']) ?></td>
        <td class="mono"><?= sfy_esc((string)$v['used']) ?></td>
        <td><?= sfy_esc($owner((string)$key)) ?></td>
      </tr>
    <?php endforeach; endif; ?>
  </table>

  <p class="hint">
    <?= number_format((int)$h['settings']['saved']) ?> of <?= number_format((int)$h['settings']['total']) ?> keys have
    been saved; the rest use the shipped defaults, which is a valid state, not a fault.
    <?php if ($h['settings']['odd']): ?>
      Fix a value on its own screen:
      <a href="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'appearance'])) ?>">Appearance</a> ·
      <a href="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'settings'])) ?>">Settings</a>.
    <?php endif; ?>
  </p>

  <?php if ($h['settings']['orphans']): ?>
    <div class="msg warn" style="margin-top:12px">
      ◆ <span class="mono"><?= sfy_esc(implode(', ', $h['settings']['orphans'])) ?></span> — stored, but this version
      does not know <?= count($h['settings']['orphans']) === 1 ? 'that key' : 'those keys' ?>. Left over from an older
      module version, or typed by hand. Harmless, and safe to delete from the config table if you want the panel tidy.
    </div>
  <?php endif; ?>
</div>

<div class="card">
  <div class="card-head">
    <h2>&gt; IMPORT SOURCES</h2><span class="spacer"></span>
    <span class="badge <?= $pill(count(array_filter($h['offline'], fn($o) => !$o['ok'])) === 0) ?>">
      <?= count(array_filter($h['offline'], fn($o) => !$o['ok'])) === 0 ? '✓ READERS MATCH' : '✖ READER DRIFT' ?>
    </span>
  </div>

  <table class="hub-table-mini">
    <tr><th>Source</th><th>How it is read</th><th>Offline self-test</th><th>Last live check</th></tr>
    <?php foreach ($h['offline'] as $key => $o):
          $live = $probe['rows'][$key] ?? null;
          $state = $live ? (string)$live['status'] : 'never run';
          $badge = $live ? ($state === 'ok' ? 'g' : ($state === 'skipped' ? 'y' : 'r')) : 'y'; ?>
      <tr>
        <td><?= sfy_esc((string)$o['label']) ?></td>
        <td class="dim"><?= sfy_esc((string)$o['how']) ?></td>
        <td><span class="badge <?= $pill((bool)$o['ok']) ?>"><?= $o['ok'] ? '✓ OK' : '✖ DRIFT' ?></span></td>
        <td><span class="badge <?= $badge ?>"><?= sfy_esc(strtoupper($state)) ?></span>
          <?php if ($live): ?>
            <div class="hint" style="margin-top:5px">
              <?= sfy_esc(implode(' ', (array)$live['notes'])) ?>
            </div>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>

  <?php foreach ($h['offline'] as $o): if ($o['ok']) continue; ?>
    <div class="msg warn" style="margin-top:12px">
      ◆ <b><?= sfy_esc((string)$o['label']) ?></b> — <?= sfy_esc(implode(' ', (array)$o['notes'])) ?>
    </div>
  <?php endforeach; ?>

  <p class="hint">
    <?php if ($probe): ?>
      Last live check: <?= sfy_esc(sfy_ago(date('Y-m-d H:i:s', (int)$probe['at']))) ?>. A source that answers with a
      different shape is reported as drift rather than as “the import found nothing”.
    <?php else: ?>
      The offline half runs on every load and needs no network: it feeds each reader a page of the documented shape and
      checks it still yields the fields the module promises. Press <b>CHECK IMPORT SOURCES LIVE</b> above to also ask
      the sites themselves.
    <?php endif; ?>
    <?php if (!$h['runtime']['ok']): ?>
      <b>This host has neither curl nor outbound streams</b>, so link import cannot work here at all — use the
      “paste the page source” box on the Import screen.
    <?php endif; ?>
  </p>
</div>

<div class="card">
  <div class="card-head">
    <h2>&gt; SEARCH ENGINES</h2><span class="spacer"></span>
    <span class="badge <?= $pill($h['index']['leaked'] === []) ?>">
      <?= $h['index']['leaked'] ? '✖ DRAFT LEAKED' : '✓ DRAFTS EXCLUDED' ?>
    </span>
  </div>

  <p class="small dim" style="margin-top:0">
    The sitemap is generated from the same queries the pages use, so a draft has no URL in it for the same reason it
    has none on the site. It lists
    <?= number_format((int)$h['index']['count']) ?> URL(s): the hub home, the listing, the plans, every game with a
    published script, and every published script.
  </p>

  <table class="hub-table-mini">
    <tr><th>What</th><th>Value</th></tr>
    <tr><td>Sitemap</td><td><a href="<?= sfy_esc((string)$h['index']['url']) ?>" target="_blank" rel="noopener"><?= sfy_esc((string)$h['index']['url']) ?></a></td></tr>
    <tr><td>Size</td><td><?= number_format((int)$h['index']['bytes']) ?> bytes</td></tr>
    <tr><td>Drafts found in it</td>
        <td><?= $h['index']['leaked'] === [] ? 'none' : '<span class="mono">' . sfy_esc(implode(', ', $h['index']['leaked'])) . '</span>' ?></td></tr>
    <tr><td>Canonical + robots</td>
        <td>Every page names one canonical URL; filtered and paginated variants are <span class="mono">noindex,follow</span>,
            checkout and form pages <span class="mono">noindex,nofollow</span>.</td></tr>
    <tr><td>Structured data</td>
        <td>Script pages are a <span class="mono">SoftwareApplication</span> with a breadcrumb trail; the home page is a
            <span class="mono">WebSite</span> with its search box.</td></tr>
  </table>

  <?php if (sfy_hub_live()): ?>
    <div class="card-head" style="border:0;padding:0;margin:14px 0 8px">
      <h2>&gt; ROBOTS.TXT</h2><span class="spacer"></span>
      <button type="button" class="hub-copy" data-hub-copy="#hub-robots">COPY</button>
    </div>
    <p class="hint" style="margin-top:0">
      Paste this into your <span class="mono">robots.txt</span> if you have one. The module does not write it for you:
      that file belongs to the site, not to this folder, and nothing outside <span class="mono">/hub/</span> is ever
      touched.
    </p>
    <pre id="hub-robots"><?= sfy_esc($robots) ?></pre>
  <?php endif; ?>
</div>

<div class="card">
  <div class="card-head"><h2>&gt; ENVIRONMENT</h2></div>
  <table class="hub-table-mini">
    <tr><th>Item</th><th>Value</th></tr>
    <tr><td>PHP</td><td class="mono"><?= sfy_esc((string)$h['runtime']['php']) ?></td></tr>
    <tr><td>Hub module version</td><td class="mono"><?= sfy_esc(SFY_HUB_VERSION) ?></td></tr>
    <tr><td>Schema version</td><td class="mono"><?= sfy_esc((string)$h['schema']['expected']) ?> (stored: <?= sfy_esc($h['schema']['stamp'] === '' ? '—' : $h['schema']['stamp']) ?>)</td></tr>
    <tr><td>curl / outbound streams</td>
        <td><?= $h['runtime']['curl'] ? '✓ curl' : '✖ no curl' ?> · <?= $h['runtime']['fopen'] ? '✓ streams' : '✖ no streams' ?></td></tr>
    <tr><td>mbstring</td>
        <td><?= $h['runtime']['mb'] ? 'present (not used — the module never depends on it)' : 'absent (as expected — the module never uses it)' ?></td></tr>
    <tr><td>Turnstile on hub forms</td>
        <td><?= !empty($s['captcha_forms']) ? 'on — via the install’s own gate' : 'off' ?></td></tr>
  </table>
  <p class="hint">
    Nothing on this screen writes anything except the repair button, which only ever adds. The module touches no table
    but its own four and no file outside <span class="mono">/hub/</span>.
  </p>
</div>
