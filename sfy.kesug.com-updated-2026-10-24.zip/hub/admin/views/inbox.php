<?php
declare(strict_types=1);
/**
 * Hub panel → Inbox.
 *
 * The inbox is a *queue*, so it is a list first: one line per message, filed
 * under the category it belongs to (support, bug reports, game requests,
 * other), with the game it is about on the row itself. Nothing is expanded
 * inline any more — the old screen printed every message's body and its form
 * one after another, which made twenty messages into a page nobody could
 * scan, and turned "which of these needs me?" into a reading exercise.
 *
 * Opening a row is a link (`?tab=inbox&open=12`) that renders the same
 * message in a popup over the list. Saving posts, redirects back to the list
 * URL *without* the id, and the popup is therefore gone the moment the work
 * is done — no state to unwind, and it behaves the same with scripts off.
 */

$kind   = (string)sfy_param('kind', '');
$status = (string)sfy_param('status', '');
$q      = (string)sfy_param('q', '');
$page   = max(1, sfy_int('page', 1));
$openId = (int)sfy_param('open', 0);
$open   = $openId > 0 ? sfy_hub_message($openId) : null;

$filter = ['kind' => $kind, 'status' => $status, 'q' => $q];
$total  = sfy_hub_messages_count($filter);
$rows   = sfy_hub_messages($filter, $page, 20);
$stats  = sfy_hub_message_stats();
$kinds  = sfy_hub_message_kinds();
$states = sfy_hub_message_statuses();

/* Closing the popup is a navigation back to the list — filters, search and
   page intact, so an admin who was reading page 3 of the bug reports lands
   back on page 3 of the bug reports rather than at the top of everything. */
$back = ['tab' => 'inbox'];
if ($kind !== '')   $back['kind']   = $kind;
if ($status !== '') $back['status'] = $status;
if ($q !== '')      $back['q']      = $q;
if ($page > 1)      $back['page']   = $page;
$listUrl = sfy_hub_admin_url($back);

/* The category strip: the whole queue, browsable by category, with the count
   each category holds. */
$cats = [['key' => '', 'label' => 'Everything', 'icon' => '🗂', 'n' => (int)($stats['total'] ?? 0)]];
foreach ($kinds as $k => $def) {
    $cats[] = ['key' => $k, 'label' => (string)$def['label'], 'icon' => (string)$def['icon'],
               'n' => (int)($stats[$k] ?? 0)];
}

/* Rows keep the fixed order of the kinds, so a category is a section of the
   list rather than a filter you have to already know about. */
$groups = [];
foreach ($rows as $m) $groups[(string)$m['kind']][] = $m;
$sections = [];
foreach (array_keys($kinds) as $k) if (!empty($groups[$k])) $sections[$k] = $groups[$k];

$openKind = '';
if ($open) {
    $openKind = (string)$open['kind'];
}
?>

<div class="hub-grid-3" style="margin-bottom:var(--gap)">
  <?= sfy_kpi('Unread', number_format((int)($stats['new'] ?? 0)), 'red', 'never opened') ?>
  <?= sfy_kpi('Suggestions', number_format((int)($stats['suggestion'] ?? 0)), 'blue', 'games requested') ?>
  <?= sfy_kpi('All messages', number_format((int)($stats['total'] ?? 0)), 'g', 'support, bugs and the rest') ?>
</div>

<div class="card">
  <div class="card-head">
    <h2>&gt; INBOX</h2>
    <span class="spacer"></span>
    <span class="hub-admin-badge"><?= number_format($total) ?> MATCH(ES)</span>
  </div>

  <div class="hub-cats">
    <?php foreach ($cats as $c): ?>
      <a class="hub-cat <?= $kind === $c['key'] ? 'on' : '' ?>"
         href="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'inbox', 'kind' => $c['key'], 'status' => $status, 'q' => $q])) ?>">
        <span aria-hidden="true"><?= $c['icon'] ?></span> <?= sfy_esc((string)$c['label']) ?>
        <b><?= number_format((int)$c['n']) ?></b>
      </a>
    <?php endforeach; ?>
  </div>

  <form method="GET" action="<?= sfy_esc(sfy_url('hub/admin/')) ?>" style="display:flex;gap:9px;flex-wrap:wrap;margin-bottom:13px">
    <input type="hidden" name="tab" value="inbox">
    <input type="hidden" name="kind" value="<?= sfy_esc($kind) ?>">
    <input type="search" name="q" class="grow" value="<?= sfy_esc($q) ?>" placeholder="Search messages…"
           style="flex:1 1 220px;min-width:0">
    <select name="status" style="flex:0 0 150px">
      <option value="">Every status</option>
      <?php foreach ($states as $k => $label): ?>
        <option value="<?= sfy_esc($k) ?>" <?= $status === $k ? 'selected' : '' ?>><?= sfy_esc($label) ?></option>
      <?php endforeach; ?>
    </select>
    <button class="btn btn-sm">FILTER</button>
  </form>

  <?php if (!$rows): ?>
    <div class="empty">Nothing here. The two public forms are at
      <span class="mono"><?= sfy_esc(sfy_hub_url('contact')) ?></span> and
      <span class="mono"><?= sfy_esc(sfy_hub_url('suggest')) ?></span>.</div>
  <?php else: ?>
    <?php foreach ($sections as $k => $list):
      $kd = $kinds[$k] ?? ['icon' => '✉', 'label' => ucfirst($k)]; ?>
      <div class="hub-sec">
        <div class="hub-sec-head">
          <span aria-hidden="true"><?= $kd['icon'] ?></span>
          <b><?= sfy_esc((string)$kd['label']) ?></b>
          <span class="hub-admin-badge"><?= number_format(count($list)) ?></span>
          <span class="spacer"></span>
          <span class="tiny mute"><?= sfy_esc((string)($kd['blurb'] ?? '')) ?></span>
        </div>

        <?php foreach ($list as $m):
          $isNew = (string)$m['status'] === 'new';
          $href  = sfy_hub_admin_url($back + ['open' => (int)$m['id']]); ?>
          <a class="hub-inbox-row <?= $isNew ? 'new' : '' ?>" href="<?= sfy_esc($href) ?>">
            <span class="hub-inbox-sub"><?= sfy_esc(sfy_short((string)$m['subject'], 72)) ?></span>
            <?php if (trim((string)$m['game_name']) !== ''): ?>
              <span class="hub-pill">🎮 <?= sfy_esc((string)$m['game_name']) ?></span>
            <?php endif; ?>
            <span class="spacer"></span>
            <span class="tiny mute hub-inbox-from"><?= sfy_esc((string)($m['name'] !== '' ? $m['name'] : $m['contact'])) ?></span>
            <span class="hub-pill <?= sfy_esc((string)$m['status']) ?>">
              <?= sfy_esc((string)($states[(string)$m['status']] ?? $m['status'])) ?></span>
            <span class="tiny mute"><?= sfy_esc(sfy_ago((string)$m['created_at'])) ?></span>
            <span class="hub-inbox-open" aria-hidden="true">OPEN ›</span>
          </a>
        <?php endforeach; ?>
      </div>
    <?php endforeach; ?>

    <?php $pages = max(1, (int)ceil($total / 20)); if ($pages > 1): ?>
      <div class="hub-pager">
        <?php for ($p = 1; $p <= $pages; $p++): ?>
          <a class="hub-page <?= $p === $page ? 'on' : '' ?>"
             href="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'inbox', 'q' => $q, 'kind' => $kind, 'status' => $status, 'page' => $p])) ?>"><?= $p ?></a>
        <?php endfor; ?>
      </div>
    <?php endif; ?>
  <?php endif; ?>
</div>

<?php if ($open):
  $kd = $kinds[$openKind] ?? ['icon' => '✉', 'label' => ucfirst($openKind)];

  sfy_hub_modal_start([
      'title' => (string)$open['subject'],
      'sub'   => (string)$kd['label'] . ' · ' . sfy_ago((string)$open['created_at']),
      'icon'  => (string)$kd['icon'],
      'close' => $listUrl,
      'wide'  => true,
  ]);
  ?>

  <div class="hub-modal-cols">
    <div>
      <div class="label">Message</div>
      <div class="hub-import-out"><?= sfy_esc((string)$open['message']) ?></div>

      <table class="hub-table-mini" style="margin-top:12px">
        <tr><th>Category</th><td><?= sfy_esc((string)$kd['label']) ?></td></tr>
        <tr><th>Game</th><td><?= trim((string)$open['game_name']) !== ''
            ? '🎮 ' . sfy_esc((string)$open['game_name']) : '<span class="dim">not game-specific</span>' ?></td></tr>
        <tr><th>From</th><td><?= sfy_esc((string)$open['name'] !== '' ? (string)$open['name'] : '—') ?></td></tr>
        <tr><th>Contact</th><td>
          <span class="mono"><?= sfy_esc((string)$open['contact']) ?></span>
          <?php if (str_contains((string)$open['contact'], '@')): ?>
            <a class="tiny" href="mailto:<?= sfy_esc((string)$open['contact']) ?>">➤ mail</a>
          <?php endif; ?>
        </td></tr>
        <tr><th>Received</th><td class="tiny"><?= sfy_esc((string)$open['created_at']) ?></td></tr>
        <tr><th>IP</th><td class="mono tiny"><?= sfy_esc(sfy_mask_ip((string)$open['ip'])) ?></td></tr>
      </table>
    </div>

    <div>
      <form method="POST">
        <?= sfy_csrf_field() ?>
        <input type="hidden" name="action" value="msg_status">
        <input type="hidden" name="id" value="<?= (int)$open['id'] ?>">
        <div class="field">
          <label class="label">Status</label>
          <select name="status">
            <?php foreach ($states as $sk => $label): ?>
              <option value="<?= sfy_esc($sk) ?>" <?= (string)$open['status'] === $sk ? 'selected' : '' ?>>
                <?= sfy_esc($label) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="field">
          <label class="label">Private note</label>
          <textarea name="admin_note" style="min-height:90px"
                    placeholder="What you decided, and what you answered."><?= sfy_esc((string)($open['admin_note'] ?? '')) ?></textarea>
        </div>

        <div class="modal-actions">
          <a class="btn btn-sm btn-ghost" href="<?= sfy_esc($listUrl) ?>">CANCEL</a>
          <?php if ($openKind === 'suggestion' && sfy_admin_can('games')): ?>
            <a class="btn btn-sm btn-ghost"
               href="<?= sfy_esc(sfy_hub_admin_url(['tab' => 'script', 'game' => (string)$open['game_name']])) ?>">
              ✎ START A SCRIPT</a>
          <?php endif; ?>
          <button class="btn btn-primary">SAVE MESSAGE</button>
        </div>
      </form>

      <form method="POST" data-confirm="Delete this message?" style="margin-top:9px">
        <?= sfy_csrf_field() ?>
        <input type="hidden" name="action" value="delete_message">
        <input type="hidden" name="id" value="<?= (int)$open['id'] ?>">
        <button class="btn btn-sm btn-danger btn-block">DELETE THIS MESSAGE</button>
      </form>
    </div>
  </div>

  <?php sfy_hub_modal_end(); ?>
<?php endif; ?>
