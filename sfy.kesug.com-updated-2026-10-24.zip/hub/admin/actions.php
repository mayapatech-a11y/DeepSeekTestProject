<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY HUB — PANEL ACTIONS
 *
 *  Every write in the panel goes through here, behind the install's own CSRF
 *  token and its capability matrix, and every one of them ends in a redirect
 *  (Post/Redirect/Get) so a refresh cannot repeat a save or a delete.
 *
 *  Role gates are the install's, not new ones: scripts need `games`, offers
 *  need `ads`, orders and the inbox need `sessions`, the layout needs
 *  `appearance`, the module's settings need `settings`, and installing the
 *  tables needs `updater`. A viewer can read every screen and change nothing.
 * ═══════════════════════════════════════════════════════════════════════
 */

function sfy_hub_admin_back(string $tab, array $qs = []): void {
    sfy_redirect(sfy_hub_admin_url(array_merge(['tab' => $tab], $qs)));
}

function sfy_hub_admin_note(string $msg, string $type = 'ok'): void {
    sfy_hub_flash($type, $msg);
}

/**
 * Run whatever the panel just posted.
 * @return array{0:string,1:string} [message, type] — empty when nothing ran
 */
function sfy_hub_admin_handle_post(): array {
    if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'POST') return ['', 'ok'];

    $action = (string)sfy_param('action', '');
    if ($action === '') return ['', 'ok'];

    if (!sfy_csrf_check((string)($_POST['csrf'] ?? ''))) {
        return ['Your session expired before that was saved. Reload the panel and try again.', 'err'];
    }

    /* ── scripts ─────────────────────────────────────────────────────── */
    if (in_array($action, ['save_script', 'delete_script', 'flag_script', 'publish_script', 'move_script'], true)) {
        if (!sfy_admin_can('games')) return ['Your role cannot change scripts.', 'err'];

        if ($action === 'save_script') {
            $id = (int)sfy_param('id', 0);
            $in = $_POST;
            // An import carried into the editor keeps its provenance: the panel
            // pretends nothing here is invisible, because a card that says
            // "manual" when it came from a link is a lie an admin would repeat.
            if ((string)sfy_param('import_source', '') !== '') {
                $in['source']     = (string)sfy_param('import_source');
                $in['source_url'] = (string)sfy_param('import_url');
            }
            $res = sfy_hub_script_save($in, $id);
            if (!$res['ok']) return [$res['error'], 'err'];
            sfy_audit($id > 0 ? 'hub_script_update' : 'hub_script_create', 'hub#' . $res['id']);
            return [$id > 0 ? 'Script saved.' : 'Script created and published.', 'ok'];
        }

        if ($action === 'delete_script') {
            $id = (int)sfy_param('id', 0);
            sfy_hub_script_delete($id);
            sfy_audit('hub_script_delete', 'hub#' . $id);
            sfy_hub_admin_back('scripts', ['done' => 'deleted']);
        }

        if ($action === 'flag_script') {
            $id  = (int)sfy_param('id', 0);
            $col = (string)sfy_param('column', 'is_featured');
            if (!sfy_hub_script_flag($id, $col)) return ['That flag could not be changed.', 'err'];
            sfy_hub_admin_back('scripts');
        }

        if ($action === 'publish_script') {
            $id = (int)sfy_param('id', 0);
            sfy_hub_script_publish($id, (string)sfy_param('status', 'published'));
            sfy_hub_admin_back('scripts');
        }

        if ($action === 'move_script') {
            sfy_hub_script_move((int)sfy_param('id', 0), (int)sfy_param('delta', 0));
            sfy_hub_admin_back('scripts');
        }
    }

    /* ── import from link (fetch only — the save is save_script) ─────── */
    if ($action === 'import_fetch') {
        if (!sfy_admin_can('games')) return ['Your role cannot import scripts.', 'err'];

        $url    = (string)sfy_param('url', '');
        $pasted = (string)($_POST['pasted'] ?? '');
        $res    = sfy_hub_import($url, $pasted);

        if (!$res['ok']) {
            $_SESSION['sfy_hub_import'] = ['ok' => false, 'url' => $url, 'notes' => $res['notes'], 'error' => $res['error']];
            sfy_hub_admin_back('import');
        }

        /* The video is the one field an owner often knows better than the page
           does — the site shows a trailer the card does not carry, or carries
           an ad — so a link typed into the form replaces whatever the fetch
           found, and the notes say which of the two the draft ended up with. */
        $vid = trim((string)sfy_param('video_url', ''));
        if ($vid !== '') {
            $res['fields']['video_url'] = sfy_hub_video_canonical($vid);
            $parsed = sfy_hub_video_parse($vid);
            $res['notes'][] = $parsed['embed'] !== ''
                ? 'Video: ' . $parsed['provider'] . ' (' . $parsed['id'] . ') will play in the script page\'s hero image.'
                : 'Video: that link is not one this can play in the page — the script page will offer it as a WATCH VIDEO button.';
        } elseif (trim((string)($res['fields']['video_url'] ?? '')) !== '') {
            $res['fields']['video_url'] = sfy_hub_video_canonical((string)$res['fields']['video_url']);
            $res['notes'][] = 'A video link was read off the page — check it in the editor.';
        }
        $res['fields']['video_autoplay'] = sfy_param('video_autoplay', '') !== '' ? 1 : 0;

        $_SESSION['sfy_hub_import'] = [
            'ok'      => true,
            'url'     => $url,
            'source'  => $res['source'],
            'notes'   => $res['notes'],
            'fields'  => $res['fields'],
        ];
        sfy_audit('hub_import', $res['source'] . ':' . substr($url, 0, 120));
        sfy_hub_admin_back('script', ['import' => 1]);
    }

    /* ── offers ──────────────────────────────────────────────────────── */
    if (in_array($action, ['save_offer', 'delete_offer', 'flag_offer'], true)) {
        if (!sfy_admin_can('ads')) return ['Your role cannot change offers.', 'err'];

        if ($action === 'save_offer') {
            $id  = (int)sfy_param('id', 0);
            $res = sfy_hub_offer_save($_POST, $id);
            /* An error leaves the form open with the typed values still in it;
               a success redirects to the list, which is also what closes the
               popup the form was edited in. */
            if (!$res['ok']) return [$res['error'], 'err'];
            sfy_audit($id > 0 ? 'hub_offer_update' : 'hub_offer_create', 'hub-offer#' . $res['id']);
            sfy_hub_admin_note($id > 0 ? 'Offer saved.' : 'Offer created.', 'ok');
            sfy_hub_admin_back('offers');
        }
        if ($action === 'delete_offer') {
            $id = (int)sfy_param('id', 0);
            sfy_hub_offer_delete($id);
            sfy_audit('hub_offer_delete', 'hub-offer#' . $id);
            sfy_hub_admin_back('offers', ['done' => 'deleted']);
        }
        if ($action === 'flag_offer') {
            if (!sfy_hub_offer_flag((int)sfy_param('id', 0), (string)sfy_param('column', 'is_active'))) {
                return ['That switch could not be changed.', 'err'];
            }
            sfy_hub_admin_back('offers');
        }
    }

    /* ── payment methods ───────────────────────────────────────────────
       `settings` rather than `ads`: this screen holds API keys and decides
       where the money goes, which is the same weight as the module's other
       configuration, and it is the role an owner hands out least often. */
    if (in_array($action, ['save_payment', 'delete_payment', 'flag_payment', 'test_payment'], true)) {
        if (!sfy_admin_can('settings')) return ['Your role cannot change the payment methods.', 'err'];

        if ($action === 'save_payment') {
            $id  = (int)sfy_param('id', 0);
            $res = sfy_hub_payment_save($_POST, $id);
            if (!$res['ok']) return [$res['error'], 'err'];
            sfy_audit($id > 0 ? 'hub_payment_update' : 'hub_payment_create', 'hub-pay#' . $res['id'],
                      ['kind' => (string)sfy_param('kind', '')]);
            sfy_hub_admin_note($id > 0 ? 'Payment method saved.' : 'Payment method created.', 'ok');
            sfy_hub_admin_back('payments');
        }

        if ($action === 'delete_payment') {
            $id = (int)sfy_param('id', 0);
            sfy_hub_payment_delete($id);
            sfy_audit('hub_payment_delete', 'hub-pay#' . $id);
            sfy_hub_admin_back('payments', ['done' => 'deleted']);
        }

        if ($action === 'flag_payment') {
            if (!sfy_hub_payment_flag((int)sfy_param('id', 0), (string)sfy_param('column', 'is_active'))) {
                return ['That switch could not be changed.', 'err'];
            }
            sfy_hub_admin_back('payments');
        }

        if ($action === 'test_payment') {
            $id  = (int)sfy_param('id', 0);
            $pay = sfy_hub_payment($id);
            if (!$pay) return ['That method no longer exists.', 'err'];

            $out = sfy_hub_payment_probe($pay);
            $out['name'] = (string)$pay['name'];
            $_SESSION['sfy_hub_pay_probe'] = $out;
            sfy_audit('hub_payment_probe', 'hub-pay#' . $id, ['http' => (int)$out['http']]);

            if (empty($out['ok'])) return ['Could not reach that endpoint: ' . (string)$out['error'], 'err'];
            return [(string)$out['name'] . ' — ' . (string)$out['note'], 'ok'];
        }
    }

    /* ── orders ──────────────────────────────────────────────────────── */
    if (in_array($action, ['order_status', 'delete_order'], true)) {
        if (!sfy_admin_can('sessions')) return ['Your role cannot change orders.', 'err'];

        $id = (int)sfy_param('id', 0);
        if ($action === 'delete_order') {
            sfy_hub_order_delete($id);
            sfy_audit('hub_order_delete', 'order#' . $id);
            sfy_hub_admin_back('orders', ['done' => 'deleted']);
        }
        if (!sfy_hub_order_update($id, (string)sfy_param('status', 'pending'), (string)($_POST['admin_note'] ?? ''))) {
            return ['That order status is not recognised.', 'err'];
        }
        sfy_audit('hub_order_status', 'order#' . $id, ['status' => (string)sfy_param('status', '')]);
        return ['Order updated.', 'ok'];
    }

    /* ── inbox ───────────────────────────────────────────────────────── */
    if (in_array($action, ['msg_status', 'delete_message'], true)) {
        if (!sfy_admin_can('sessions')) return ['Your role cannot change messages.', 'err'];

        $id = (int)sfy_param('id', 0);
        if ($action === 'delete_message') {
            sfy_hub_message_delete($id);
            sfy_audit('hub_message_delete', 'msg#' . $id);
            sfy_hub_admin_back('inbox', ['done' => 'deleted']);
        }
        if (!sfy_hub_message_update($id, (string)sfy_param('status', 'read'), (string)($_POST['admin_note'] ?? ''))) {
            return ['That message status is not recognised.', 'err'];
        }
        sfy_audit('hub_message_status', 'msg#' . $id, ['status' => (string)sfy_param('status', '')]);
        /* Redirect back to the list: the message was opened in a popup, and
           the popup is only on the screen because the URL asked for it. */
        sfy_hub_admin_note('Message updated.', 'ok');
        sfy_hub_admin_back('inbox');
    }

    /* ── layout / appearance ─────────────────────────────────────────── */
    if ($action === 'save_appearance') {
        if (!sfy_admin_can('appearance')) return ['Your role cannot change the look.', 'err'];
        sfy_hub_save_settings(array_merge($_POST, ['__flags' => 1, '__scope' => 'appearance']));
        sfy_audit('hub_appearance');
        return ['Look saved — the hub is already using it.', 'ok'];
    }

    /* ── module settings ─────────────────────────────────────────────── */
    if ($action === 'save_settings') {
        if (!sfy_admin_can('settings')) return ['Your role cannot change these settings.', 'err'];
        sfy_hub_save_settings(array_merge($_POST, ['__flags' => 1, '__scope' => 'settings']));
        sfy_audit('hub_settings');
        return ['Settings saved.', 'ok'];
    }

    /* ── diagnostics: the live import-source probe ───────────────────────
       Deliberately a button and never part of rendering the screen: it makes
       outbound requests, which is the slowest thing this module does. The
       result is kept for the session so the screen can show when it ran. */
    if ($action === 'probe_sources') {
        if (!sfy_admin_can('updater')) return ['Your role cannot run the source probe.', 'err'];
        $probe = sfy_hub_source_probe();
        $_SESSION['sfy_hub_probe'] = $probe;
        sfy_audit('hub_source_probe', '', ['sources' => count($probe['rows'])]);

        $bad = 0;
        foreach ($probe['rows'] as $row) if (($row['status'] ?? '') === 'drift') $bad++;
        return [$bad > 0
            ? $bad . ' import source(s) answered with a different shape — see the table below.'
            : 'Every import source still answers with the shape its reader expects.',
            $bad > 0 ? 'warn' : 'ok'];
    }

    /* ── installer ───────────────────────────────────────────────────── */
    if ($action === 'install') {
        if (!sfy_admin_can('updater')) return ['Your role cannot run the installer.', 'err'];
        $res = sfy_hub_install(true);
        sfy_audit('hub_install', '', ['created' => count($res['created']), 'failed' => count($res['failed'])]);
        if ($res['error'] !== '')   return ['The installer failed: ' . $res['error'], 'err'];
        if ($res['failed'])         return ['Created the tables but ' . count($res['failed']) . ' column(s) failed — see the panel log.', 'warn'];
        return ['Hub tables are installed and up to date'
                . ($res['created'] ? ' — created ' . count($res['created']) . ' table(s).' : '.'), 'ok'];
    }

    return ['', 'ok'];
}
