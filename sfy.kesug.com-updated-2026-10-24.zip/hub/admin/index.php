<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY HUB — CONTROL PANEL  (/hub/admin/)
 *
 *  Lives inside the module folder so the module owns its own screens. It
 *  does not own authentication: the staff session, the roles and the CSRF
 *  token are the install's (app/security.php), and a visitor who is not
 *  signed in is pointed at the main sign-in rather than given a second one.
 *
 *  Tabs:  ?tab=overview | scripts | script | import | offers | orders |
 *               inbox | appearance | settings | diagnostics
 * ═══════════════════════════════════════════════════════════════════════
 */

require dirname(__DIR__) . '/lib/bootstrap.php';
require __DIR__ . '/actions.php';
require __DIR__ . '/layout.php';

/* ── who is this? ───────────────────────────────────────────────────── */
$me = sfy_hub_staff();
if (!$me || !sfy_admin_can('view')) {
    sfy_hub_admin_need_login();
    exit;
}

/* ── writes first, then render (Post/Redirect/Get) ──────────────────── */
[$msg, $msgType] = sfy_hub_admin_handle_post();

$flash = sfy_hub_flash_take();
if ($flash && $msg === '') {
    $msg     = (string)($flash['text'] ?? '');
    $msgType = (string)($flash['kind'] ?? 'ok');
}
if ($msg !== '' && !in_array($msgType, ['ok', 'err', 'warn', 'info'], true)) $msgType = 'ok';

/* ── the tab ────────────────────────────────────────────────────────── */
$tabs = sfy_hub_admin_tabs();
$tab  = (string)sfy_param('tab', 'overview');
/* Order management now lives in Admin -> Commerce -> Orders. */
if ($tab === 'orders') {
    sfy_redirect(sfy_admin_url(['tab' => 'commerce', 'section' => 'orders']));
    exit;
}
if ($tab === 'offers' || $tab === 'payments') {
    sfy_redirect(sfy_admin_url(['tab' => 'commerce', 'section' => 'plans']));
    exit;
}
if ($tab === 'inbox') {
    sfy_redirect(sfy_admin_url(['tab' => 'inbox']));
    exit;
}
if (!isset($tabs[$tab]) || !sfy_admin_can((string)$tabs[$tab]['cap'])) $tab = 'overview';

sfy_hub_admin_head($me, $tab, sfy_hub_admin_counts());

if ($msg !== '') {
    echo '<div class="msg ' . sfy_esc($msgType) . '">'
       . ($msgType === 'ok' ? '✔ ' : ($msgType === 'err' ? '✖ ' : '◆ ')) . sfy_esc($msg) . '</div>';
}

$view = __DIR__ . '/views/' . $tab . '.php';
require is_file($view) ? $view : __DIR__ . '/views/overview.php';

sfy_hub_admin_foot();
