<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY HUB — CONTROL PANEL CHROME
 *
 *  The hub has its own panel rather than more tabs on the install's one, so
 *  the module can be installed, updated or removed without a single edit to
 *  /admin. It is *not* a second login: it renders against the same staff
 *  session (sfy_admin_current) and the same roles, so a person who can sign
 *  in to Admin can sign in here, and a viewer still cannot write.
 *
 *  The chrome deliberately reuses the install's own classes
 *  (.admin-chrome / .admin-side / .admin-nav / .admin-main …), so the hub
 *  panel looks like the panel next to it and follows the chosen theme — the
 *  only new CSS is for the module's own widgets.
 * ═══════════════════════════════════════════════════════════════════════
 */

function sfy_hub_admin_tabs(): array {
    return [
        'overview'   => ['label' => 'Hub overview', 'cap' => 'view',       'icon' => '⌂'],
        'scripts'    => ['label' => 'Scripts',      'cap' => 'games',      'icon' => '📜'],
        'script'     => ['label' => 'Script editor','cap' => 'games',      'icon' => '✎'],
        'import'     => ['label' => 'Import a link','cap' => 'games',      'icon' => '📥'],
        'appearance' => ['label' => 'Appearance',   'cap' => 'appearance', 'icon' => '🎨'],
        'settings'   => ['label' => 'Settings',     'cap' => 'settings',   'icon' => '⚙'],
        // Read-only for a viewer: it reports the install, it does not change it.
        'diagnostics'=> ['label' => 'Diagnostics',  'cap' => 'view',       'icon' => '🩺'],
    ];
}

/** Nav badge counts — cheap single queries, and never fatal. */
function sfy_hub_admin_counts(): array {
    return (array)sfy_try(function (): array {
        $msgs = sfy_hub_message_stats();
        $ord  = sfy_hub_order_stats();

        /* The Diagnostics badge is the one number here that is a fault rather
           than a queue: missing tables and missing columns. Both existence
           checks are cached for the request, and the Overview screen asks the
           same question, so this costs nothing new. */
        $broken = 0;
        foreach (sfy_hub_tables() as $table => $ddl) {
            if (!sfy_table_exists($table)) { $broken++; continue; }
            foreach (sfy_schema_defined_columns($ddl) as $column => $def) {
                if (preg_match('/AUTO_INCREMENT|PRIMARY KEY/i', (string)$def)) continue;
                if (!sfy_column_exists($table, (string)$column)) $broken++;
            }
        }

        /* A method that is offered but not finished — no address, no link, no
           keys — is the Payments tab's own to-do, so it is counted here and
           reads the same as the “needs input” badge on that screen. It is
           deliberately *not* the same number as Diagnostics reports: a method
           with instructions but no address still sells by hand, so it needs
           input without being a fault. */
        $payFaults = 0;
        foreach (sfy_hub_payments(true) as $m) {
            if (!sfy_hub_payment_ready($m)['ok']) $payFaults++;
        }

        return [
            'scripts'     => sfy_hub_scripts_count(['status' => 'any']),
            'offers'      => count(sfy_hub_offers(false)),
            'payments'    => $payFaults,
            'orders'      => (int)($ord['pending'] ?? 0),
            'inbox'       => (int)($msgs['new'] ?? 0),
            'diagnostics' => $broken,
        ];
    }, []);
}

function sfy_hub_admin_head(array $me, string $tab, array $counts = []): void {
    $tabs  = sfy_hub_admin_tabs();
    $title = (string)($tabs[$tab]['label'] ?? 'Hub');
    $icon  = (string)($tabs[$tab]['icon'] ?? '⌂');
    $hub   = sfy_hub_live();

    sfy_head([
        'title'      => 'Hub ' . $title,
        'page'       => 'admin',
        'noindex'    => true,
        'wide'       => true,
        'minimal'    => true,
        'body_class' => 'admin-shell hub-admin',
        'head'       => '<link rel="stylesheet" href="' . sfy_esc(sfy_asset('hub/assets/hub.css')) . '">'
                      . '<style id="sfy-hub-sizing">' . sfy_hub_css_vars() . '</style>',
    ]);
    ?>
<div class="admin-chrome">
<aside class="admin-side" id="sfy-admin-side" aria-label="Hub navigation">
  <div class="admin-side-head">
    <a class="brand" href="<?= sfy_esc(sfy_hub_admin_url()) ?>">
      <span>&gt;SFY_HUB</span><span class="v">v<?= sfy_esc(SFY_HUB_VERSION) ?></span>
    </a>
    <button type="button" class="admin-side-x" id="sfy-admin-close" aria-label="Close menu">✕</button>
  </div>

  <nav class="admin-nav">
    <?php foreach ($tabs as $key => $t): ?>
      <?php if (!sfy_admin_can($t['cap'])) continue; ?>
      <a class="<?= $tab === $key ? 'active' : '' ?>" href="<?= sfy_esc(sfy_hub_admin_url(['tab' => $key])) ?>"
         <?= $tab === $key ? 'aria-current="page"' : '' ?>>
        <span class="ic" aria-hidden="true"><?= $t['icon'] ?></span>
        <span class="lbl"><?= sfy_esc($t['label']) ?></span>
        <?php if (isset($counts[$key]) && $counts[$key] > 0): ?><span class="n"><?= (int)$counts[$key] ?></span><?php endif; ?>
      </a>
    <?php endforeach; ?>
  </nav>

  <div class="admin-side-foot">
    <?php if ($hub): ?>
      <a class="btn btn-sm btn-ghost btn-block" href="<?= sfy_esc(sfy_hub_url()) ?>" target="_blank" rel="noopener">↗ OPEN THE HUB</a>
    <?php endif; ?>
    <a class="btn btn-sm btn-ghost btn-block" href="<?= sfy_esc(sfy_admin_url()) ?>">⚙ MAIN ADMIN PANEL</a>
    <div class="admin-line">
      <span class="who">@<?= sfy_esc((string)$me['username']) ?></span>
      <span class="role-pill <?= sfy_esc((string)$me['role']) ?>"><?= sfy_esc((string)$me['role']) ?></span>
    </div>
    <a class="btn btn-sm btn-danger btn-block" href="<?= sfy_esc(sfy_admin_url(['logout' => 1])) ?>">LOGOUT</a>
  </div>
</aside>

<div class="admin-backdrop" id="sfy-admin-backdrop" aria-hidden="true"></div>

<div class="admin-main">
  <div class="admin-topbar">
    <button type="button" class="admin-burger" id="sfy-admin-burger" aria-controls="sfy-admin-side"
            aria-expanded="false" aria-label="Open menu">☰</button>
    <span class="admin-topbar-title"><?= $icon ?> <?= sfy_esc($title) ?></span>
    <span class="spacer"></span>
    <span class="admin-topbar-status"><span class="dot"></span> HUB</span>
    <a class="btn btn-sm btn-danger" href="<?= sfy_esc(sfy_admin_url(['logout' => 1])) ?>">LOGOUT</a>
  </div>
  <main class="admin-body">
<?php
}

function sfy_hub_admin_foot(): void {
    ?>
  </main>
</div>
</div>
<script>
(function(){
  /* Same drawer behaviour as the install's panel: the sidebar is a real
     drawer on a phone, opened by ☰ and closed by ✕, the backdrop or Escape. */
  var side   = document.getElementById('sfy-admin-side');
  var burger = document.getElementById('sfy-admin-burger');
  var closeB = document.getElementById('sfy-admin-close');
  var back   = document.getElementById('sfy-admin-backdrop');
  function setOpen(open){
    if(!side) return;
    side.classList.toggle('open', open);
    if(back) back.classList.toggle('open', open);
    document.body.classList.toggle('admin-nav-open', open);
    if(burger) burger.setAttribute('aria-expanded', open ? 'true' : 'false');
  }
  if(burger) burger.addEventListener('click', function(){ setOpen(!side.classList.contains('open')); });
  if(closeB) closeB.addEventListener('click', function(){ setOpen(false); });
  if(back)   back.addEventListener('click', function(){ setOpen(false); });
  document.addEventListener('keydown', function(e){ if(e.key === 'Escape') setOpen(false); });
  if(side) side.querySelectorAll('.admin-nav a').forEach(function(a){
    a.addEventListener('click', function(){
      if(window.matchMedia('(max-width:900px)').matches) setOpen(false);
    });
  });
  document.querySelectorAll('form[data-confirm]').forEach(function(f){
    f.addEventListener('submit', function(ev){
      if(!confirm(f.getAttribute('data-confirm'))) ev.preventDefault();
    });
  });
  document.querySelectorAll('form[data-hub-once]').forEach(function(f){
    f.addEventListener('submit', function(){
      var b = f.querySelector('button[type=submit], button:not([type])');
      if(b){ b.disabled = true; b.textContent = b.getAttribute('data-busy') || 'WORKING…'; }
    });
  });
})();
</script>
<script src="<?= sfy_esc(sfy_asset('hub/assets/hub.js')) ?>" defer></script>
<?php
    sfy_foot(['page' => 'admin']);
}

/**
 * The "sign in through the main panel" page.
 *
 * The hub deliberately has no login form of its own: two sign-in screens for
 * one session is two places for a password to leak and two ways to be locked
 * out. A visitor who is not signed in is told exactly where to go, and the
 * hub panel works the moment they come back.
 */
function sfy_hub_admin_need_login(): void {
    sfy_head(['title' => 'Hub panel', 'page' => 'admin-login', 'noindex' => true, 'minimal' => true]);
    ?>
<div class="login-wrap">
  <div class="login-box brk">
    <div class="card-head" style="border:0;padding:0;margin-bottom:8px">
      <h1>&gt;SFY_HUB</h1><span class="spacer"></span><span class="badge y">SIGN-IN REQUIRED</span>
    </div>
    <p class="hint" style="margin-top:0">
      The hub panel uses the same staff sign-in as the main control panel — there is no second account.
    </p>
    <a class="btn btn-primary btn-lg" href="<?= sfy_esc(sfy_admin_url(['tab' => 'overview'])) ?>">SIGN IN TO ADMIN</a>
    <div class="hint mt-2">
      When you are signed in, come back to
      <a href="<?= sfy_esc(sfy_hub_admin_url()) ?>"><?= sfy_esc(sfy_hub_admin_url()) ?></a>.
    </div>
    <div class="hint center mt-2"><a href="<?= sfy_esc(sfy_hub_url()) ?>">← back to the hub</a></div>
  </div>
</div>
    <?php
    sfy_foot(['page' => 'admin-login']);
}
