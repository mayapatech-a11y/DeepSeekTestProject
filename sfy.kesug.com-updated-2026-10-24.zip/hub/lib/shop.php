<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY HUB — SHOP (offers + orders)
 *
 *  An *offer* is a plan the owner configures in the hub panel ("2-Day Key —
 *  $1.50"). The offers page lists them; the buy page turns one into an
 *  *order*.
 *
 *  There is no payment gateway on this install, and pretending otherwise
 *  would be worse than saying so: an order is a request. It is written to
 *  sfy_hub_orders with a human-readable reference, the buyer is told what
 *  happens next, and staff work the queue in Hub → Orders.
 * ═══════════════════════════════════════════════════════════════════════
 */

/* ── offers ─────────────────────────────────────────────────────────── */

function sfy_hub_offers(bool $activeOnly = true): array {
    return sfy_try(function () use ($activeOnly): array {
        $sql = "SELECT * FROM sfy_hub_offers"
             . ($activeOnly ? " WHERE is_active = 1 AND (stock = 0 OR sold < stock)" : "")
             . " ORDER BY sort_order ASC, price ASC, id ASC";
        return sfy_db()->query($sql)->fetchAll();
    }, []);
}

function sfy_hub_offer(int $id): ?array {
    if ($id <= 0) return null;
    return sfy_try(function () use ($id) {
        $st = sfy_db()->prepare("SELECT * FROM sfy_hub_offers WHERE id = ? LIMIT 1");
        $st->execute([$id]);
        return $st->fetch() ?: null;
    }, null);
}

function sfy_hub_offer_by_slug(string $slug, bool $activeOnly = true): ?array {
    if ($slug === '') return null;
    return sfy_try(function () use ($slug, $activeOnly) {
        $st = sfy_db()->prepare("SELECT * FROM sfy_hub_offers WHERE slug = ?"
             . ($activeOnly ? " AND is_active = 1" : "") . " LIMIT 1");
        $st->execute([$slug]);
        return $st->fetch() ?: null;
    }, null);
}

/** The headline offer for the sidebar / home strip. */
function sfy_hub_offer_featured(): ?array {
    $rows = sfy_hub_offers(true);
    foreach ($rows as $o) if (!empty($o['is_featured'])) return $o;
    return $rows[0] ?? null;
}

function sfy_hub_offer_normalize(array $in, int $id = 0): array {
    $title = sfy_hub_line((string)($in['title'] ?? ''), 191);
    if ($title === '') return [[], 'Give the offer a title — that is the card heading.'];

    $slugSrc = trim((string)($in['slug'] ?? '')) !== '' ? (string)$in['slug'] : $title;

    $price    = (float)str_replace(',', '.', (string)($in['price'] ?? '0'));
    $oldPrice = trim((string)($in['old_price'] ?? '')) === ''
              ? null : (float)str_replace(',', '.', (string)$in['old_price']);

    $row = [
        'slug'           => sfy_hub_slug($slugSrc, 'sfy_hub_offers', $id),
        'title'          => $title,
        'subtitle'       => sfy_hub_line((string)($in['subtitle'] ?? ''), 255),
        'duration_label' => sfy_hub_line((string)($in['duration_label'] ?? ''), 48),
        'duration_days'  => max(0, min(3650, (int)($in['duration_days'] ?? 0))),
        'price'          => number_format(max(0, $price), 2, '.', ''),
        'old_price'      => $oldPrice === null ? null : number_format(max(0, $oldPrice), 2, '.', ''),
        'currency'       => sfy_hub_currency((string)($in['currency'] ?? '')),
        'description'    => sfy_hub_text((string)($in['description'] ?? ''), 4000),
        'perks'          => implode("\n", array_slice(sfy_hub_feature_list($in['perks'] ?? ''), 0, 12)),
        'badge'          => sfy_hub_line((string)($in['badge'] ?? ''), 48),
        'image_url'      => sfy_hub_url_clean((string)($in['image_url'] ?? ''), 500),
        'accent'         => preg_match('/^#[0-9a-f]{6}$/i', (string)($in['accent'] ?? '')) ? strtolower((string)$in['accent']) : '',
        'checkout_url'   => sfy_hub_url_clean((string)($in['checkout_url'] ?? ''), 500),
        'stock'          => max(0, min(999999, (int)($in['stock'] ?? 0))),
        'is_active'      => !empty($in['is_active']) ? 1 : 0,
        'is_featured'    => !empty($in['is_featured']) ? 1 : 0,
        'sort_order'     => max(-9999, min(9999, (int)($in['sort_order'] ?? 0))),
    ];
    return [$row, ''];
}

/** @return array{ok:bool,id:int,error:string} */
function sfy_hub_offer_save(array $in, int $id = 0): array {
    [$row, $err] = sfy_hub_offer_normalize($in, $id);
    if ($err !== '') return ['ok' => false, 'id' => 0, 'error' => $err];

    try {
        $db = sfy_db();
        if ($id > 0) {
            if (!sfy_hub_offer($id)) return ['ok' => false, 'id' => 0, 'error' => 'That offer no longer exists.'];
            $sets = implode(', ', array_map(fn($k) => "`$k` = ?", array_keys($row)));
            $vals = array_values($row);
            $vals[] = $id;
            $db->prepare("UPDATE sfy_hub_offers SET $sets, updated_at = NOW() WHERE id = ?")->execute($vals);
            return ['ok' => true, 'id' => $id, 'error' => ''];
        }
        $cols = array_keys($row);
        $ph   = implode(', ', array_fill(0, count($cols), '?'));
        $db->prepare("INSERT INTO sfy_hub_offers (`" . implode('`, `', $cols) . "`, created_at, updated_at)
                      VALUES ($ph, NOW(), NOW())")->execute(array_values($row));
        return ['ok' => true, 'id' => (int)$db->lastInsertId(), 'error' => ''];
    } catch (Throwable $e) {
        error_log('[SFY HUB] offer save: ' . $e->getMessage());
        return ['ok' => false, 'id' => 0, 'error' => 'Could not save that offer. Run the hub installer if this is a fresh install.'];
    }
}

function sfy_hub_offer_delete(int $id): bool {
    return (bool)sfy_try(function () use ($id): bool {
        sfy_db()->prepare("DELETE FROM sfy_hub_offers WHERE id = ?")->execute([$id]);
        return true;
    }, false);
}

function sfy_hub_offer_flag(int $id, string $column): bool {
    if (!in_array($column, ['is_active', 'is_featured'], true)) return false;
    return (bool)sfy_try(function () use ($id, $column): bool {
        sfy_db()->prepare("UPDATE sfy_hub_offers SET `$column` = 1 - `$column`, updated_at = NOW()
                           WHERE id = ?")->execute([$id]);
        return true;
    }, false);
}

/** 3-letter/word currency code, uppercased and stripped of junk. */
function sfy_hub_currency(string $in = ''): string {
    $c = strtoupper(preg_replace('/[^A-Za-z]/', '', $in !== '' ? $in : (string)sfy_hub_setting('currency', 'USD')));
    return substr($c !== '' ? $c : 'USD', 0, 8);
}

/**
 * Price with the currency symbol where we know one.
 *
 * Deliberately naive: a shop that sells one product to a global audience
 * needs "USD 4.00" more than it needs a locale database, and an unknown code
 * is simply printed as-is instead of guessing a symbol.
 */
function sfy_hub_money($amount, string $currency = ''): string {
    $currency = sfy_hub_currency($currency);
    $symbols  = ['USD' => '$', 'EUR' => '€', 'GBP' => '£', 'PHP' => '₱', 'INR' => '₹',
                 'BRL' => 'R$', 'IDR' => 'Rp', 'JPY' => '¥', 'CAD' => 'C$', 'AUD' => 'A$'];
    $n = number_format((float)$amount, 2, '.', ',');
    if ($n === '0.00') return 'FREE';
    return isset($symbols[$currency]) ? $symbols[$currency] . $n : $currency . ' ' . $n;
}

/** "% off" for an offer with a struck-through old price, or ''. */
function sfy_hub_offer_discount(array $o): string {
    $old = (float)($o['old_price'] ?? 0);
    $new = (float)($o['price'] ?? 0);
    if ($old <= 0 || $new <= 0 || $old <= $new) return '';
    return '-' . (int)round((1 - $new / $old) * 100) . '%';
}

/* ── orders ─────────────────────────────────────────────────────────── */

function sfy_hub_order_statuses(): array {
    return [
        'pending'   => 'Pending',
        'contacted' => 'Contacted',
        'paid'      => 'Paid',
        'delivered' => 'Delivered',
        'cancelled' => 'Cancelled',
    ];
}

/** Short, unambiguous, easy to read over Discord: SFY-7K3M9Q. */
function sfy_hub_reference(): string {
    $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';   // no I/O/0/1
    $out = '';
    for ($i = 0; $i < 6; $i++) $out .= $alphabet[random_int(0, strlen($alphabet) - 1)];
    return 'SFY-' . $out;
}

/**
 * Record a buy-page request.
 * @return array{ok:bool,code:int,order:?array,error:string}
 */
function sfy_hub_order_create(array $in, ?array $offer): array {
    if (!$offer) return ['ok' => false, 'code' => 404, 'order' => null, 'error' => 'That plan is no longer available.'];

    $name    = sfy_hub_line((string)($in['buyer_name'] ?? ''), 96);
    $contact = sfy_hub_line((string)($in['buyer_contact'] ?? ''), 191);
    if ($name === '')    return ['ok' => false, 'code' => 400, 'order' => null, 'error' => 'Tell us what to call you.'];
    if ($contact === '') return ['ok' => false, 'code' => 400, 'order' => null, 'error' => 'We need a way to reach you — an email or a Discord tag.'];

    /* Which method, and the buyer's answers to what that method asks for.
      
       The posted value is a *slug* now, so it is matched against the methods
       the shop is actually offering: a crafted POST cannot invent one, and an
       order can never name a method the admin has since switched off. The
       name is stored beside the slug because the reports and the printed
       order are read by people, not by callbacks. */
    $slug    = sfy_hub_line((string)($in['payment_method'] ?? ''), 96);
    $offered = sfy_hub_payment_offered();
    $chosen  = null;
    foreach ($offered as $m) if ((string)$m['slug'] === $slug) { $chosen = $m; break; }
    if ($chosen === null && $offered) {
        return ['ok' => false, 'code' => 400, 'order' => null,
                'error' => 'Pick how you are going to pay, so we know what to look for.'];
    }
    $slug = $chosen !== null ? (string)$chosen['slug'] : '';

    $collect = $chosen !== null ? sfy_hub_payment_collect($chosen, $in)
                                : ['fields' => [], 'missing' => []];
    if ($collect['missing'] && $chosen !== null) {
        return ['ok' => false, 'code' => 400, 'order' => null,
                'error' => 'We still need: ' . implode(', ', $collect['missing']) . '.'];
    }
    $fields = $collect['fields'] !== [] ? (string)json_encode($collect['fields']) : '';

    $method = $chosen !== null ? sfy_hub_line((string)$chosen['name'], 48) : '';
    $kind   = str_contains($contact, '@') && !str_contains($contact, ' ') ? 'email' : 'discord';

    try {
        $db  = sfy_db();
        $ref = sfy_hub_reference();
        for ($i = 0; $i < 8; $i++) {              // collisions are vanishingly rare
            $st = $db->prepare("SELECT 1 FROM sfy_hub_orders WHERE reference = ? LIMIT 1");
            $st->execute([$ref]);
            if (!$st->fetchColumn()) break;
            $ref = sfy_hub_reference();
        }

        $db->prepare("INSERT INTO sfy_hub_orders
            (reference, offer_id, offer_slug, offer_title, duration_label, amount, currency,
             buyer_name, buyer_contact, contact_kind, payment_method, payment_slug, payment_fields,
             message, status, ip, user_agent, created_at, updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'pending', ?, ?, NOW(), NOW())")
           ->execute([
                $ref, (int)$offer['id'], (string)$offer['slug'], (string)$offer['title'],
                (string)($offer['duration_label'] ?? ''), (string)$offer['price'],
                sfy_hub_currency((string)($offer['currency'] ?? '')),
                $name, $contact, $kind, $method, $slug, $fields,
                sfy_hub_text((string)($in['message'] ?? ''), 2000),
                sfy_client_ip(), sfy_user_agent(),
           ]);

        return ['ok' => true, 'code' => 201, 'order' => sfy_hub_order_by_reference($ref), 'error' => ''];
    } catch (Throwable $e) {
        error_log('[SFY HUB] order create: ' . $e->getMessage());
        return ['ok' => false, 'code' => 500, 'order' => null,
                'error' => 'Could not record that order. Run the hub installer if this is a fresh install.'];
    }
}

function sfy_hub_order_by_reference(string $ref): ?array {
    return sfy_try(function () use ($ref) {
        $st = sfy_db()->prepare("SELECT * FROM sfy_hub_orders WHERE reference = ? LIMIT 1");
        $st->execute([sfy_hub_line($ref, 24)]);
        return $st->fetch() ?: null;
    }, null);
}

function sfy_hub_orders(array $f = [], int $page = 1, int $perPage = 25): array {
    $w = []; $p = [];
    $status = (string)($f['status'] ?? '');
    if ($status !== '' && isset(sfy_hub_order_statuses()[$status])) { $w[] = 'status = ?'; $p[] = $status; }
    $q = trim((string)($f['q'] ?? ''));
    if ($q !== '') {
        $w[] = '(reference LIKE ? OR buyer_name LIKE ? OR buyer_contact LIKE ? OR offer_title LIKE ?)';
        $like = '%' . $q . '%';
        array_push($p, $like, $like, $like, $like);
    }
    $where = $w ? ' WHERE ' . implode(' AND ', $w) : '';
    $page  = max(1, $page);

    return sfy_try(function () use ($where, $p, $page, $perPage): array {
        $st = sfy_db()->prepare("SELECT * FROM sfy_hub_orders" . $where . " ORDER BY id DESC LIMIT "
              . (int)$perPage . " OFFSET " . (($page - 1) * (int)$perPage));
        $st->execute($p);
        return $st->fetchAll();
    }, []);
}

function sfy_hub_orders_count(array $f = []): int {
    $w = []; $p = [];
    $status = (string)($f['status'] ?? '');
    if ($status !== '' && isset(sfy_hub_order_statuses()[$status])) { $w[] = 'status = ?'; $p[] = $status; }
    $q = trim((string)($f['q'] ?? ''));
    if ($q !== '') {
        $w[] = '(reference LIKE ? OR buyer_name LIKE ? OR buyer_contact LIKE ? OR offer_title LIKE ?)';
        $like = '%' . $q . '%';
        array_push($p, $like, $like, $like, $like);
    }
    $where = $w ? ' WHERE ' . implode(' AND ', $w) : '';
    return (int)sfy_try(function () use ($where, $p): int {
        $st = sfy_db()->prepare("SELECT COUNT(*) AS n FROM sfy_hub_orders" . $where);
        $st->execute($p);
        return (int)($st->fetch()['n'] ?? 0);
    }, 0);
}

/** Move an order along and (on the first "delivered") stamp the delivery and
 *  count the sale against the offer. */
function sfy_hub_order_update(int $id, string $status, string $note = ''): bool {
    $statuses = sfy_hub_order_statuses();
    if (!isset($statuses[$status])) return false;

    return (bool)sfy_try(function () use ($id, $status, $note): bool {
        $db = sfy_db();
        $st = $db->prepare("SELECT * FROM sfy_hub_orders WHERE id = ? LIMIT 1");
        $st->execute([$id]);
        $row = $st->fetch();
        if (!$row) return false;

        $delivered = $status === 'delivered' && (string)$row['status'] !== 'delivered';
        $db->prepare("UPDATE sfy_hub_orders SET status = ?, admin_note = ?, updated_at = NOW()"
                     . ($delivered ? ", delivered_at = NOW()" : "") . " WHERE id = ?")
           ->execute([$status, sfy_hub_text($note, 4000), $id]);

        if ($delivered && (int)$row['offer_id'] > 0) {
            $db->prepare("UPDATE sfy_hub_offers SET sold = sold + 1, updated_at = NOW() WHERE id = ?")
               ->execute([(int)$row['offer_id']]);
        }
        return true;
    }, false);
}

function sfy_hub_order_delete(int $id): bool {
    return (bool)sfy_try(function () use ($id): bool {
        sfy_db()->prepare("DELETE FROM sfy_hub_orders WHERE id = ?")->execute([$id]);
        return true;
    }, false);
}

/**
 * Revenue + volume the overview card reports.
 *
 * Every key is read defensively: this runs on the panel's landing screen, and
 * a row shape it did not expect (an aggregate that came back differently, a
 * column an unfinished update has not added yet) must cost a number, never the
 * whole screen.
 */
function sfy_hub_order_stats(): array {
    return (array)sfy_try(function (): array {
        $db = sfy_db();
        $out = ['pending' => 0, 'delivered' => 0, 'paid' => 0, 'total' => 0, 'value' => 0.0];
        /* Added up rather than assigned, for the same reason the inbox stats
           are: a row is a shape, and a grouping that changes must not silently
           make a counter show the last row instead of the whole queue. */
        foreach ($db->query("SELECT status, COUNT(*) AS n FROM sfy_hub_orders GROUP BY status")->fetchAll() as $r) {
            $n      = (int)($r['n'] ?? 0);
            $status = (string)($r['status'] ?? '');
            if ($status !== '') $out[$status] = (int)($out[$status] ?? 0) + $n;
            $out['total'] += $n;
        }
        $sum = $db->query("SELECT COALESCE(SUM(amount),0) AS v FROM sfy_hub_orders
                           WHERE status IN ('paid','delivered')")->fetch();
        $out['value'] = (float)($sum['v'] ?? 0);
        return $out;
    }, ['pending' => 0, 'delivered' => 0, 'paid' => 0, 'total' => 0, 'value' => 0.0]);
}
