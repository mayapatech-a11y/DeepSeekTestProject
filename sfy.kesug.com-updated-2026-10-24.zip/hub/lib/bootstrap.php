<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY HUB — BOOTSTRAP
 *
 *  The hub is a self-contained module inside the SFY ULTIMATE install. It
 *  lives in its own folder and talks to the rest of the site through
 *  app/core.php only:
 *
 *    • the same database          (sfy_db)
 *    • the same theme + admin-chosen appearance (sfy_head / sfy_appearance_css)
 *    • the same staff session     (sfy_admin_current)
 *    • the same runtime settings  (sfy_config)
 *
 *  That is deliberate: pulling app/core.php in means every theme change the
 *  owner makes in Admin → Appearance is already reflected here, with no
 *  second stylesheet to keep in sync — and it means deleting `hub/` leaves
 *  the rest of the install untouched.
 * ═══════════════════════════════════════════════════════════════════════
 */

if (defined('SFY_HUB_LOADED')) return;
define('SFY_HUB_LOADED', true);

require_once dirname(__DIR__, 2) . '/app/core.php';

define('SFY_HUB_ROOT', dirname(__DIR__));                 // …/hub
define('SFY_HUB_VERSION', '1.0.0');

require_once __DIR__ . '/settings.php';
require_once __DIR__ . '/install.php';
require_once __DIR__ . '/forms.php';
require_once __DIR__ . '/scripts.php';
require_once __DIR__ . '/shop.php';
require_once __DIR__ . '/payments.php';
require_once __DIR__ . '/inbox.php';
require_once __DIR__ . '/import.php';
require_once __DIR__ . '/seo.php';
require_once __DIR__ . '/health.php';
require_once __DIR__ . '/ui.php';

/* The tables are created on the first request that needs them and never
   again: sfy_hub_install() compares the stored schema stamp and returns
   before it touches the database when nothing has changed. */
sfy_hub_install();
