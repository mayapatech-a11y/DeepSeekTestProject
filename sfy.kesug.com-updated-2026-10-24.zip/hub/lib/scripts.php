<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY HUB — SCRIPT LIBRARY (queries + writes)
 *
 *  Every statement the hub runs against sfy_hub_scripts lives here. Two
 *  rules the rest of the module relies on:
 *
 *   • a missing table degrades to an empty result rather than a 500
 *     (sfy_try), so a half-finished install still renders a page;
 *   • nothing a visitor types reaches SQL except as a bound parameter, and
 *     nothing is written except through a normaliser that whitelists keys.
 * ═══════════════════════════════════════════════════════════════════════
 */

/** The public listing filters, in the order the chips render. */
function sfy_hub_script_kinds(): array {
    return [
        'all'       => 'All',
        'free'      => 'Free',
        'key'       => 'Key System',
        'keyless'   => 'Keyless',
        'universal' => 'Universal',
        'featured'  => 'Featured',
    ];
}

function sfy_hub_script_sorts(): array {
    return [
        'new'   => 'Newest',
        'views' => 'Most viewed',
        'top'   => 'Most copied',
        'az'    => 'A–Z',
    ];
}

/**
 * Build the WHERE clause for a listing.
 *
 * @param array $f  q (text), game, kind, sort, status ('published'|'any'|'draft'), featured
 * @return array{0:string,1:array}
 */
function sfy_hub_script_where(array $f): array {
    $w = [];
    $p = [];

    $status = (string)($f['status'] ?? 'published');
    if ($status !== 'any') { $w[] = 'status = ?'; $p[] = $status; }

    $q = trim((string)($f['q'] ?? ''));
    if ($q !== '') {
        // One box that searches what a visitor can see on the card: the title,
        // the game, the teaser, the tags and the author.
        $w[] = '(title LIKE ? OR game_name LIKE ? OR summary LIKE ? OR tags LIKE ? OR author LIKE ?)';
        $like = '%' . str_replace(['%', '_'], ['\%', '\_'], $q) . '%';
        array_push($p, $like, $like, $like, $like, $like);
    }

    $game = trim((string)($f['game'] ?? ''));
    if ($game !== '') { $w[] = 'game_name = ?'; $p[] = $game; }

    switch ((string)($f['kind'] ?? 'all')) {
        case 'free':      $w[] = 'is_free = 1';      break;
        case 'key':       $w[] = 'key_system = 1';   break;
        case 'keyless':   $w[] = 'key_system = 0';   break;
        case 'universal': $w[] = 'is_universal = 1'; break;
        case 'featured':  $w[] = 'is_featured = 1';  break;
    }
    if (!empty($f['featured'])) $w[] = 'is_featured = 1';

    $sql = $w ? ' WHERE ' . implode(' AND ', $w) : '';

    // ORDER BY is never built from input — the key picks a fixed string.
    $order = [
        'new'   => 'COALESCE(published_at, created_at) DESC, id DESC',
        'views' => 'views DESC, id DESC',
        'top'   => 'copies DESC, likes DESC, id DESC',
        'az'    => 'title ASC',
    ][(string)($f['sort'] ?? 'new')] ?? 'COALESCE(published_at, created_at) DESC, id DESC';

    return [$sql . ' ORDER BY ' . $order, $p];
}

function sfy_hub_scripts(array $f = [], int $page = 1, int $perPage = 0): array {
    $perPage = $perPage > 0 ? min(60, $perPage) : (int)sfy_hub_setting('per_page', 12);
    $page    = max(1, $page);
    [$where, $params] = sfy_hub_script_where($f);

    return sfy_try(function () use ($where, $params, $page, $perPage): array {
        $st = sfy_db()->prepare("SELECT * FROM sfy_hub_scripts" . $where . " LIMIT " . $perPage
              . " OFFSET " . (($page - 1) * $perPage));
        $st->execute($params);
        return $st->fetchAll();
    }, []);
}

function sfy_hub_scripts_count(array $f = []): int {
    [$where, $params] = sfy_hub_script_where($f);
    return (int)sfy_try(function () use ($where, $params): int {
        $st = sfy_db()->prepare("SELECT COUNT(*) AS n FROM sfy_hub_scripts" . $where);
        $st->execute($params);
        return (int)($st->fetch()['n'] ?? 0);
    }, 0);
}

function sfy_hub_script_by_slug(string $slug, bool $publishedOnly = true): ?array {
    if ($slug === '') return null;
    return sfy_try(function () use ($slug, $publishedOnly) {
        $sql = "SELECT * FROM sfy_hub_scripts WHERE slug = ?";
        if ($publishedOnly) $sql .= " AND status = 'published'";
        $sql .= " LIMIT 1";
        $st = sfy_db()->prepare($sql);
        $st->execute([$slug]);
        return $st->fetch() ?: null;
    }, null);
}

function sfy_hub_script(int $id): ?array {
    if ($id <= 0) return null;
    return sfy_try(function () use ($id) {
        $st = sfy_db()->prepare("SELECT * FROM sfy_hub_scripts WHERE id = ? LIMIT 1");
        $st->execute([$id]);
        return $st->fetch() ?: null;
    }, null);
}

/** Games that actually have a published script, with their counts. */
function sfy_hub_games(int $limit = 14): array {
    return sfy_try(function () use ($limit): array {
        $st = sfy_db()->query("SELECT game_name, COUNT(*) AS n FROM sfy_hub_scripts
                               WHERE status = 'published' AND game_name <> ''
                               GROUP BY game_name ORDER BY n DESC, game_name ASC LIMIT " . max(1, $limit));
        return $st->fetchAll();
    }, []);
}

/** The sidebar leaderboard. */
function sfy_hub_top_scripts(int $limit = 5): array {
    return sfy_try(function () use ($limit): array {
        $st = sfy_db()->query("SELECT * FROM sfy_hub_scripts WHERE status = 'published'
                               ORDER BY views DESC, copies DESC, id DESC LIMIT " . max(1, $limit));
        return $st->fetchAll();
    }, []);
}

/** Count one look at a published script. Fire-and-forget: never fatal. */
function sfy_hub_script_view(int $id): void {
    sfy_try(function () use ($id): bool {
        sfy_db()->prepare("UPDATE sfy_hub_scripts SET views = views + 1 WHERE id = ?")->execute([$id]);
        return true;
    }, false);
}

function sfy_hub_script_copy(int $id): void {
    sfy_try(function () use ($id): bool {
        sfy_db()->prepare("UPDATE sfy_hub_scripts SET copies = copies + 1 WHERE id = ?")->execute([$id]);
        return true;
    }, false);
}

/**
 * A URL-safe, unique slug.
 *
 * The suffix loop is bounded (200 tries) and falls back to a random tail
 * rather than looping for ever on a pathological title.
 */
function sfy_hub_slug(string $source, string $table = 'sfy_hub_scripts', int $ignoreId = 0): string {
    $s = strtolower(trim($source));
    $s = (string)preg_replace('/[^a-z0-9]+/', '-', $s);
    $s = trim($s, '-');
    $s = substr($s, 0, 120);
    if ($s === '') $s = 'entry';

    $base = $s;
    for ($i = 2; $i <= 200; $i++) {
        $candidate = $i === 2 ? $base : $base . '-' . $i;
        $taken = (bool)sfy_try(function () use ($table, $candidate, $ignoreId): bool {
            $st = sfy_db()->prepare("SELECT 1 FROM `$table` WHERE slug = ? AND id <> ? LIMIT 1");
            $st->execute([$candidate, $ignoreId]);
            return (bool)$st->fetchColumn();
        }, true);   // on error assume taken: never hand back a duplicate
        if (!$taken) return $candidate;
    }
    return $base . '-' . substr(bin2hex(random_bytes(3)), 0, 6);
}

/** One feature per line → clean array. */
function sfy_hub_feature_list($v): array {
    if (is_array($v)) $v = implode("\n", $v);
    $lines = array_map('trim', preg_split('/\r?\n/', (string)$v));
    return array_values(array_filter(array_map(fn($l) => sfy_hub_line($l, 80), $lines), fn($l) => $l !== ''));
}

/**
 * "a, b, c" → clean array, capped so the column cannot overflow.
 *
 * De-duplication ignores case — "Aimbot" and "aimbot" are one tag to a
 * reader, and an import that spells it both ways must not turn a card's tag
 * row into two of the same chip. The first spelling seen wins.
 */
function sfy_hub_tag_list($v): array {
    if (is_array($v)) $v = implode(',', $v);
    $out  = [];
    $seen = [];
    foreach (explode(',', (string)$v) as $t) {
        $t = sfy_hub_line($t, 32);
        if ($t === '') continue;
        $key = strtolower($t);
        if (isset($seen[$key])) continue;
        $seen[$key] = true;
        $out[] = $t;
        if (count($out) >= 12) break;
    }
    return $out;
}

function sfy_hub_tags_string($v): string { return implode(', ', sfy_hub_tag_list($v)); }

/* ── video ───────────────────────────────────────────────────────────────
 * A video link is the one field where "whatever the owner pasted" and "what a
 * player can actually load" are two different strings. So the paste is read
 * once, here, into the parts the rest of the module needs:
 *
 *   • the *watch* address, which is what a plain link points at and what gets
 *     stored, so the column holds one canonical spelling instead of the four
 *     YouTube hands out;
 *   • the *embed* address, which is what the page puts in an iframe;
 *   • a *poster*, so a script with no thumbnail still gets a real frame of its
 *     own video rather than a letter tile.
 *
 * Anything else — a Twitch channel, a direct .mp4, a link to a file on the
 * owner's own host — is not an error and is not thrown away: it is stored as
 * typed, and the page offers it as an ordinary "watch" button. What this
 * deliberately does *not* do is put an arbitrary URL into an iframe: a field
 * an owner fills in is not a place to hand a stranger's page a frame it can
 * paint over the site.
 * ─────────────────────────────────────────────────────────────────────── */

/**
 * Read one video link.
 *
 * Takes anything an owner would realistically paste: a watch link, a share
 * link, a /shorts/ or /live/ link, the second half of an <iframe> embed code,
 * a bare 11-character YouTube id, a Vimeo page or player link.
 *
 * @return array{provider:string,kind:string,id:string,embed:string,watch:string,poster:string}
 */
function sfy_hub_video_parse(string $url): array {
    $none = ['provider' => '', 'kind' => '', 'id' => '', 'embed' => '', 'watch' => '', 'poster' => ''];
    $raw  = trim($url);
    if ($raw === '') return $none;

    /* The whole embed code is a normal thing to copy — the site's "share"
       button offers it before it offers the address — so the src is taken out
       of it first and the rest of this reads a plain URL either way. */
    if (stripos($raw, '<iframe') !== false
        && preg_match('~<iframe[^>]*\bsrc\s*=\s*["\']?([^"\'>\s]+)~i', $raw, $m)) {
        $raw = $m[1];
    }
    $raw = str_replace(['&amp;', '&#038;', '&#39;', '&quot;'], ['&', '&', '', ''], trim($raw, " \t\n\r\"'"));
    if (str_starts_with($raw, '//')) $raw = 'https:' . $raw;

    /* YouTube. The id is the only part that matters, so every address it hands
       out collapses to the same one. */
    $id = '';
    if (preg_match('~^(?:https?://)?(?:www\.|m\.)?youtu\.be/([A-Za-z0-9_\-]{6,})~i', $raw, $m)) {
        $id = $m[1];
    } elseif (preg_match('~^(?:https?://)?(?:www\.|m\.)?youtube(?:-nocookie)?\.com/(?:watch\?(?:[^#]*&)?v=|embed/|shorts/|live/|v/)([A-Za-z0-9_\-]{6,})~i', $raw, $m)) {
        $id = $m[1];
    } elseif (preg_match('~^[A-Za-z0-9_\-]{11}$~', $raw)) {
        $id = $raw;                       // the id on its own, out of a share box
    }
    if ($id !== '') {
        return ['provider' => 'YouTube', 'kind' => 'youtube', 'id' => $id,
                /* The no-cookie host on purpose: a script page should not hand
                   a tracker a visitor before they asked to watch anything. */
                'embed'  => 'https://www.youtube-nocookie.com/embed/' . $id,
                'watch'  => 'https://www.youtube.com/watch?v=' . $id,
                'poster' => 'https://i.ytimg.com/vi/' . $id . '/hqdefault.jpg'];
    }

    if (preg_match('~(?:player\.)?vimeo\.com/(?:video/)?(\d{5,})~i', $raw, $m)) {
        return ['provider' => 'Vimeo', 'kind' => 'vimeo', 'id' => $m[1],
                'embed'  => 'https://player.vimeo.com/video/' . $m[1],
                'watch'  => 'https://vimeo.com/' . $m[1],
                'poster' => ''];       // Vimeo needs an API call for its still; the tile stands in
    }

    return $none;
}

/** Is this link one the page can play in place? */
function sfy_hub_video_playable(string $url): bool {
    return sfy_hub_video_parse($url)['embed'] !== '';
}

/**
 * What to put in the player's `src`.
 *
 * $muted is the difference between the two ways a player gets onto the page:
 * a *click* may have sound, because the visitor just asked for it, while an
 * *autoplay* may not — every browser refuses a video that starts talking on
 * its own, and a request that is refused is a player that silently does not
 * play. So the automatic start is muted and offers a sound button, and the
 * clicked one has sound from the first frame.
 */
function sfy_hub_video_src(string $url, bool $muted = false): string {
    $v = sfy_hub_video_parse($url);
    if ($v['embed'] === '') return '';

    $q = $v['kind'] === 'vimeo'
        ? ['autoplay' => 1, 'muted' => $muted ? 1 : 0, 'dnt' => 1, 'title' => 0, 'byline' => 0]
        : ['autoplay' => 1, 'mute' => $muted ? 1 : 0, 'rel' => 0, 'playsinline' => 1, 'modestbranding' => 1];

    return $v['embed'] . '?' . http_build_query($q);
}

/**
 * The single spelling that gets stored.
 *
 * A recognised link is rewritten to its watch address, so the column does not
 * fill up with five spellings of one video. An unrecognised one is kept as
 * typed (bounded and scheme-checked), because "not a video this can embed" is
 * not the same thing as "not a video".
 */
function sfy_hub_video_canonical(string $url): string {
    $raw = trim($url);
    if ($raw === '') return '';
    $v = sfy_hub_video_parse($raw);
    if ($v['watch'] !== '') return $v['watch'];
    return sfy_hub_url_clean($raw, 500);
}

/**
 * Normalise a submitted script.
 *
 * @param array $in  raw (already trimmed by the caller from $_POST)
 * @param int   $id  0 = create
 * @return array{0:array,1:string} [clean row, error]
 */
function sfy_hub_script_normalize(array $in, int $id = 0): array {
    $title = sfy_hub_line((string)($in['title'] ?? ''), 191);
    if ($title === '') return [[], 'A title is required — that is what the card shows.'];

    $script = (string)($in['script_code'] ?? '');
    $script = str_replace(["\r\n", "\r"], "\n", trim($script));
    if (strlen($script) > 200000) $script = substr($script, 0, 200000);

    $desc = sfy_hub_text((string)($in['description'] ?? ''), 20000);
    $status = (string)($in['status'] ?? 'published');
    if (!in_array($status, ['published', 'draft'], true)) $status = 'published';

    $row = [
        'title'        => $title,
        'slug'         => sfy_hub_slug((string)($in['slug'] ?? '') !== '' ? (string)$in['slug'] : $title,
                                       'sfy_hub_scripts', $id),
        'game_name'    => sfy_hub_line((string)($in['game_name'] ?? ''), 191),
        'game_id'      => sfy_hub_line((string)($in['game_id'] ?? ''), 64),
        'summary'      => sfy_hub_line((string)($in['summary'] ?? ''), 400),
        'description'  => $desc,
        'script_code'  => $script,
        'features'     => implode("\n", sfy_hub_feature_list($in['features'] ?? '')),
        'tags'         => sfy_hub_tags_string($in['tags'] ?? ''),
        'thumbnail'    => sfy_hub_url_clean((string)($in['thumbnail'] ?? ''), 500),
        /* Stored canonical: whatever spelling of a video link was pasted, the
           row holds one, which is also what keeps the page's poster and
           player from disagreeing about which video this is. */
        'video_url'    => sfy_hub_video_canonical((string)($in['video_url'] ?? '')),
        'video_autoplay' => !empty($in['video_autoplay']) ? 1 : 0,
        'discord_url'  => sfy_hub_url_clean((string)($in['discord_url'] ?? ''), 500),
        'game_link'    => sfy_hub_url_clean((string)($in['game_link'] ?? ''), 500),
        'author'       => sfy_hub_line((string)($in['author'] ?? ''), 96),
        'source'       => sfy_hub_line((string)($in['source'] ?? 'manual'), 32) ?: 'manual',
        'source_url'   => sfy_hub_url_clean((string)($in['source_url'] ?? ''), 500),
        'key_system'   => !empty($in['key_system']) ? 1 : 0,
        'is_universal' => !empty($in['is_universal']) ? 1 : 0,
        'is_free'      => !empty($in['is_free']) ? 1 : 0,
        'is_featured'  => !empty($in['is_featured']) ? 1 : 0,
        'status'       => $status,
        'sort_order'   => max(-9999, min(9999, (int)($in['sort_order'] ?? 0))),
    ];
    return [$row, ''];
}

/**
 * Insert or update a script.
 * @return array{ok:bool,id:int,error:string}
 */
function sfy_hub_script_save(array $in, int $id = 0): array {
    [$row, $err] = sfy_hub_script_normalize($in, $id);
    if ($err !== '') return ['ok' => false, 'id' => 0, 'error' => $err];

    try {
        $db = sfy_db();
        if ($id > 0) {
            if (!sfy_hub_script($id)) return ['ok' => false, 'id' => 0, 'error' => 'That script no longer exists.'];
            $sets = implode(', ', array_map(fn($k) => "`$k` = ?", array_keys($row)));
            $vals = array_values($row);
            $vals[] = $id;
            $db->prepare("UPDATE sfy_hub_scripts SET $sets, updated_at = NOW() WHERE id = ?")->execute($vals);
            return ['ok' => true, 'id' => $id, 'error' => ''];
        }
        $cols = array_keys($row);
        $row['imported_at'] = (string)($in['imported_at'] ?? '') !== '' ? (string)$in['imported_at'] : null;
        $cols[] = 'imported_at';
        $ph = implode(', ', array_fill(0, count($cols), '?'));
        $sql = "INSERT INTO sfy_hub_scripts (`" . implode('`, `', $cols) . "`, published_at, created_at, updated_at)
                VALUES ($ph, NOW(), NOW(), NOW())";
        $db->prepare($sql)->execute(array_values($row));
        return ['ok' => true, 'id' => (int)$db->lastInsertId(), 'error' => ''];
    } catch (Throwable $e) {
        error_log('[SFY HUB] script save: ' . $e->getMessage());
        return ['ok' => false, 'id' => 0, 'error' => 'Could not save that script. Run the hub installer if this is a fresh install.'];
    }
}

function sfy_hub_script_delete(int $id): bool {
    return (bool)sfy_try(function () use ($id): bool {
        sfy_db()->prepare("DELETE FROM sfy_hub_scripts WHERE id = ?")->execute([$id]);
        return true;
    }, false);
}

/** Flip one flag on one row (feature / publish / free). */
function sfy_hub_script_flag(int $id, string $column): bool {
    $allowed = ['is_featured', 'is_free', 'key_system', 'is_universal'];
    if (!in_array($column, $allowed, true)) return false;
    return (bool)sfy_try(function () use ($id, $column): bool {
        sfy_db()->prepare("UPDATE sfy_hub_scripts SET `$column` = 1 - `$column`, updated_at = NOW()
                           WHERE id = ?")->execute([$id]);
        return true;
    }, false);
}

function sfy_hub_script_publish(int $id, string $status): bool {
    $status = in_array($status, ['published', 'draft'], true) ? $status : 'published';
    return (bool)sfy_try(function () use ($id, $status): bool {
        sfy_db()->prepare("UPDATE sfy_hub_scripts SET status = ?, published_at = NOW(), updated_at = NOW()
                           WHERE id = ?")->execute([$status, $id]);
        return true;
    }, false);
}

/** Move a row up/down in a manual ordering. */
function sfy_hub_script_move(int $id, int $delta): bool {
    return (bool)sfy_try(function () use ($id, $delta): bool {
        sfy_db()->prepare("UPDATE sfy_hub_scripts SET sort_order = sort_order + ?, updated_at = NOW()
                           WHERE id = ?")->execute([max(-1, min(1, $delta)), $id]);
        return true;
    }, false);
}

/** Distinct game names for the panel's datalist, drafts included. */
function sfy_hub_game_options(): array {
    return sfy_try(function (): array {
        return sfy_db()->query("SELECT game_name, COUNT(*) AS n FROM sfy_hub_scripts
                                WHERE game_name <> '' GROUP BY game_name
                                ORDER BY n DESC, game_name ASC LIMIT 200")->fetchAll();
    }, []);
}
