<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY HUB — INSTALLER
 *
 *  The hub owns four tables and creates them itself, so the install's own
 *  migration list never has to know the module exists. That is the whole
 *  point of the separate folder: drop `hub/` in, open it, and it works —
 *  remove it and nothing else in the site is affected.
 *
 *  Two properties matter:
 *
 *   • it is idempotent (CREATE TABLE IF NOT EXISTS + INSERT IGNORE), so it can
 *     run on any request without harming a populated install;
 *   • it is *free when it is not needed*. A successful install stamps the
 *     schema version into sfy_config; every later page compares that stamp and
 *     returns before touching the database at all.
 *
 *  Nothing here ever drops, renames or truncates: an added column ships as an
 *  additive ALTER guarded by the definition sweep, exactly like the install's
 *  own updater.
 * ═══════════════════════════════════════════════════════════════════════
 */

/** Bump this when a table or column is added below.
 *
 * 2 — `sfy_hub_payment_methods`, and the payment half of an order
 *     (payment_slug, payment_fields, payment_reference, paid_at).
 * 3 — `scripts.video_autoplay`: whether the hero picture starts the video by
 *     itself or waits to be clicked. */
define('SFY_HUB_SCHEMA', 3);

function sfy_hub_tables(): array {
    return [

/* ── scripts ────────────────────────────────────────────────────────────
 * One row per script card. Everything a link import can produce has a home
 * here, and every field stays editable afterwards — that is what makes an
 * imported script "customisable" rather than a frozen copy of someone
 * else's page.
 * ─────────────────────────────────────────────────────────────────────── */
'sfy_hub_scripts' => "CREATE TABLE IF NOT EXISTS `sfy_hub_scripts` (
  `id`           INT AUTO_INCREMENT PRIMARY KEY,
  `slug`         VARCHAR(191) NOT NULL,
  `title`        VARCHAR(191) NOT NULL,
  `game_name`    VARCHAR(191) NOT NULL DEFAULT '',
  `game_id`      VARCHAR(64)  NOT NULL DEFAULT '',
  `summary`      VARCHAR(400) NOT NULL DEFAULT '',
  `description`  MEDIUMTEXT   NULL,
  `script_code`  MEDIUMTEXT   NULL,
  -- One feature per line, as typed in the panel.
  `features`     TEXT         NULL,
  `tags`         VARCHAR(255) NOT NULL DEFAULT '',
  `thumbnail`    VARCHAR(500) NOT NULL DEFAULT '',
  `video_url`    VARCHAR(500) NOT NULL DEFAULT '',
  -- 1 = the hero picture starts the video on its own (muted; browsers refuse
  -- sound without a click), 0 = it waits for the visitor.
  `video_autoplay` TINYINT(1) NOT NULL DEFAULT 0,
  `discord_url`  VARCHAR(500) NOT NULL DEFAULT '',
  `game_link`    VARCHAR(500) NOT NULL DEFAULT '',
  `author`       VARCHAR(96)  NOT NULL DEFAULT '',
  -- manual | link-scriptblox | link-haxhell | link-generic
  `source`       VARCHAR(32)  NOT NULL DEFAULT 'manual',
  `source_url`   VARCHAR(500) NOT NULL DEFAULT '',
  `key_system`   TINYINT(1)   NOT NULL DEFAULT 0,
  `is_universal` TINYINT(1)   NOT NULL DEFAULT 0,
  `is_free`      TINYINT(1)   NOT NULL DEFAULT 1,
  `is_featured`  TINYINT(1)   NOT NULL DEFAULT 0,
  -- published | draft
  `status`       VARCHAR(16)  NOT NULL DEFAULT 'published',
  `views`        INT NOT NULL DEFAULT 0,
  `copies`       INT NOT NULL DEFAULT 0,
  `likes`        INT NOT NULL DEFAULT 0,
  `sort_order`   INT NOT NULL DEFAULT 0,
  `published_at` DATETIME     NULL,
  `imported_at`  DATETIME     NULL,
  `created_at`   DATETIME     NULL,
  `updated_at`   DATETIME     NULL,
  UNIQUE KEY `uniq_hub_slug` (`slug`),
  KEY `idx_hub_status` (`status`, `published_at`),
  KEY `idx_hub_game` (`game_name`),
  KEY `idx_hub_featured` (`is_featured`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

/* ── offers (the premium plans the buy page sells) ────────────────────── */
'sfy_hub_offers' => "CREATE TABLE IF NOT EXISTS `sfy_hub_offers` (
  `id`             INT AUTO_INCREMENT PRIMARY KEY,
  `slug`           VARCHAR(96)  NOT NULL,
  `title`          VARCHAR(191) NOT NULL,
  `subtitle`       VARCHAR(255) NOT NULL DEFAULT '',
  `duration_label` VARCHAR(48)  NOT NULL DEFAULT '',
  `duration_days`  INT NOT NULL DEFAULT 0,
  `price`          DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `old_price`      DECIMAL(10,2) NULL,
  `currency`       VARCHAR(8)   NOT NULL DEFAULT 'USD',
  `description`    TEXT         NULL,
  -- One perk per line.
  `perks`          TEXT         NULL,
  `badge`          VARCHAR(48)  NOT NULL DEFAULT '',
  `image_url`      VARCHAR(500) NOT NULL DEFAULT '',
  `accent`         VARCHAR(16)  NOT NULL DEFAULT '',
  -- '' = collect an order in-site; otherwise the buy button forwards here.
  `checkout_url`   VARCHAR(500) NOT NULL DEFAULT '',
  `stock`          INT NOT NULL DEFAULT 0,
  `sold`           INT NOT NULL DEFAULT 0,
  `is_active`      TINYINT(1) NOT NULL DEFAULT 1,
  `is_featured`    TINYINT(1) NOT NULL DEFAULT 0,
  `sort_order`     INT NOT NULL DEFAULT 0,
  `created_at`     DATETIME NULL,
  `updated_at`     DATETIME NULL,
  UNIQUE KEY `uniq_hub_offer` (`slug`),
  KEY `idx_hub_offer_active` (`is_active`, `sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

/* ── orders (a buy-page request the staff fulfil by hand) ─────────────── */
'sfy_hub_orders' => "CREATE TABLE IF NOT EXISTS `sfy_hub_orders` (
  `id`              INT AUTO_INCREMENT PRIMARY KEY,
  `reference`       VARCHAR(24)  NOT NULL,
  `offer_id`        INT NOT NULL DEFAULT 0,
  `offer_slug`      VARCHAR(96)  NOT NULL DEFAULT '',
  `offer_title`     VARCHAR(191) NOT NULL DEFAULT '',
  `duration_label`  VARCHAR(48)  NOT NULL DEFAULT '',
  `amount`          DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `currency`        VARCHAR(8)   NOT NULL DEFAULT 'USD',
  `buyer_name`      VARCHAR(96)  NOT NULL DEFAULT '',
  `buyer_contact`   VARCHAR(191) NOT NULL DEFAULT '',
  `contact_kind`    VARCHAR(16)  NOT NULL DEFAULT '',
  -- The method *name* is kept for the reports and the printed order; the slug
  -- is what a callback matches on, and the fields are the buyer's answers to
  -- that method's requirements, as JSON.
  `payment_method`  VARCHAR(48)  NOT NULL DEFAULT '',
  `payment_slug`    VARCHAR(96)  NOT NULL DEFAULT '',
  `payment_fields`  TEXT         NULL,
  -- What the provider called the payment, once it is confirmed.
  `payment_reference` VARCHAR(191) NOT NULL DEFAULT '',
  `paid_at`         DATETIME     NULL,
  `message`         TEXT         NULL,
  -- pending | contacted | paid | delivered | cancelled
  `status`          VARCHAR(16)  NOT NULL DEFAULT 'pending',
  `admin_note`      TEXT         NULL,
  `ip`              VARCHAR(64)  NULL,
  `user_agent`      VARCHAR(512) NULL,
  `created_at`      DATETIME NULL,
  `updated_at`      DATETIME NULL,
  `delivered_at`    DATETIME NULL,
  UNIQUE KEY `uniq_hub_ref` (`reference`),
  KEY `idx_hub_order_status` (`status`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

/* ── payment methods: where the money actually goes ─────────────────────
 * One row per way a buyer can pay. `kind` says how it is collected
 * (wallet | redirect | gateway); the address / checkout link is what the
 * buyer is shown, and the api_* columns are the credentials a gateway needs
 * to confirm an order by itself through the signed callback.
 *
 * Nothing here is ever printed on a public page: hub/lib/payments.php
 * builds the visitor-facing shape field by field, so a secret cannot leak
 * by merely being in the table.
 * ─────────────────────────────────────────────────────────────────────── */
'sfy_hub_payment_methods' => "CREATE TABLE IF NOT EXISTS `sfy_hub_payment_methods` (
  `id`             INT AUTO_INCREMENT PRIMARY KEY,
  `slug`           VARCHAR(96)  NOT NULL,
  `name`           VARCHAR(96)  NOT NULL,
  -- wallet | redirect | gateway
  `kind`           VARCHAR(16)  NOT NULL DEFAULT 'wallet',
  `icon`           VARCHAR(16)  NOT NULL DEFAULT '',
  `network`        VARCHAR(96)  NOT NULL DEFAULT '',
  `currency`       VARCHAR(8)   NOT NULL DEFAULT '',
  `summary`        VARCHAR(255) NOT NULL DEFAULT '',
  -- One requirement per line: Label | placeholder | required
  `requirements`   TEXT         NULL,
  -- Where the buyer sends the money (a wallet hash, a number, an account).
  `address`        VARCHAR(255) NOT NULL DEFAULT '',
  `instructions`   TEXT         NULL,
  `confirm_note`   TEXT         NULL,
  -- '' = collect the order here; otherwise the hosted checkout page, which
  -- may use {amount} {currency} {reference} {plan} {plan_title} {method}.
  `checkout_url`   VARCHAR(500) NOT NULL DEFAULT '',
  `api_provider`   VARCHAR(64)  NOT NULL DEFAULT '',
  `api_endpoint`   VARCHAR(500) NOT NULL DEFAULT '',
  `api_key`        VARCHAR(191) NOT NULL DEFAULT '',
  `api_secret`     VARCHAR(255) NOT NULL DEFAULT '',
  -- Extra key = value pairs a provider needs (merchant id, mode, …).
  `api_extra`      TEXT         NULL,
  `webhook_secret` VARCHAR(255) NOT NULL DEFAULT '',
  `min_amount`     DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `fee_note`       VARCHAR(191) NOT NULL DEFAULT '',
  -- 1 = an admin has to confirm the payment (the default for every method
  -- that cannot sign a callback).
  `needs_review`   TINYINT(1)   NOT NULL DEFAULT 1,
  `is_active`      TINYINT(1)   NOT NULL DEFAULT 1,
  `is_featured`    TINYINT(1)   NOT NULL DEFAULT 0,
  `sort_order`     INT NOT NULL DEFAULT 0,
  `created_at`     DATETIME NULL,
  `updated_at`     DATETIME NULL,
  UNIQUE KEY `uniq_hub_pay_slug` (`slug`),
  KEY `idx_hub_pay_active` (`is_active`, `sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

/* ── messages: game suggestions, support, bug reports ─────────────────── */
'sfy_hub_messages' => "CREATE TABLE IF NOT EXISTS `sfy_hub_messages` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `kind`       VARCHAR(16)  NOT NULL DEFAULT 'support',
  `name`       VARCHAR(96)  NOT NULL DEFAULT '',
  `contact`    VARCHAR(191) NOT NULL DEFAULT '',
  `game_name`  VARCHAR(191) NOT NULL DEFAULT '',
  `subject`    VARCHAR(191) NOT NULL DEFAULT '',
  `message`    TEXT         NULL,
  -- new | read | replied | closed
  `status`     VARCHAR(16)  NOT NULL DEFAULT 'new',
  `admin_note` TEXT         NULL,
  `ip`         VARCHAR(64)  NULL,
  `user_agent` VARCHAR(512) NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  KEY `idx_hub_msg_kind` (`kind`, `status`),
  KEY `idx_hub_msg_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    ];
}

/** Additive repair: every column the definitions declare must exist. */
function sfy_hub_repair_columns(?PDO $db = null): array {
    $db     = $db ?? sfy_db();
    $notes  = [];
    $failed = [];
    foreach (sfy_hub_tables() as $table => $ddl) {
        if (!sfy_table_exists($table, $db)) continue;      // created below
        foreach (sfy_schema_defined_columns($ddl) as $column => $definition) {
            if (preg_match('/AUTO_INCREMENT|PRIMARY KEY/i', $definition)) continue;
            try {
                if (sfy_add_column($table, $column, $definition, $db)) $notes[] = "$table.$column";
            } catch (Throwable $e) {
                error_log('[SFY HUB] repair column ' . $table . '.' . $column . ': ' . $e->getMessage());
                $failed[] = "$table.$column: " . $e->getMessage();
            }
        }
    }
    return ['notes' => $notes, 'failed' => $failed];
}

/**
 * Create/repair the hub schema.
 *
 * @param bool $force  run even when the stored stamp matches (the panel's
 *                     INSTALL / REPAIR button, and the admin's own diagnostics)
 * @return array{ran:bool,created:string[],notes:string[],failed:string[],error:string}
 */
function sfy_hub_install(bool $force = false): array {
    $out = ['ran' => false, 'created' => [], 'notes' => [], 'failed' => [], 'error' => ''];

    $stamp = (string)sfy_config_get('hub_schema', '');
    if (!$force && $stamp === (string)SFY_HUB_SCHEMA) return $out;

    try {
        $db = sfy_db();
        foreach (sfy_hub_tables() as $table => $ddl) {
            $existed = sfy_table_exists($table, $db);
            $db->exec($ddl);
            if (!$existed) { sfy_schema_flush_cache(); $out['created'][] = $table; }
        }
        sfy_schema_flush_cache();

        $repair = sfy_hub_repair_columns($db);
        $out['notes']  = $repair['notes'];
        $out['failed'] = $repair['failed'];
        $out['ran']    = true;

        // Only claim success when every column really landed — otherwise the
        // stamp stays behind and the next request tries again.
        if (!$out['failed']) {
            sfy_config_set('hub_schema', (string)SFY_HUB_SCHEMA);
            sfy_hub_seed();
        }
    } catch (Throwable $e) {
        error_log('[SFY HUB] install: ' . $e->getMessage());
        $out['error'] = $e->getMessage();
    }
    return $out;
}

/**
 * First-run content: a handful of offers so the shop page is never empty and
 * the owner has something to edit rather than something to invent. Inserted
 * only when the table has no rows at all — never re-seeded, never overwritten.
 */
function sfy_hub_seed(): void {
    try {
        $db = sfy_db();
        $n  = (int)$db->query("SELECT COUNT(*) AS n FROM sfy_hub_offers")->fetch()['n'];
        if ($n === 0) {
            $seed = [
                ['2-day',   '2-Day Key',   'Try it out',      '2 DAYS',  2,  1.50, 2.50,  'STARTER',
                 "Full premium key for 2 days\nWorks on every supported script\nPriority support"],
                ['7-day',   '7-Day Key',   'Most popular',    '7 DAYS',  7,  4.00, 6.00,  'BEST VALUE',
                 "Full premium key for 7 days\nWorks on every supported script\nPriority support\nFree re-issue if patched"],
                ['30-day',  '30-Day Key',  'Best price per day', '30 DAYS', 30, 12.00, 18.00, 'BEST PRICE',
                 "Full premium key for 30 days\nWorks on every supported script\nPriority support\nFree re-issue if patched\nEarly access to new scripts"],
            ];
            $st = $db->prepare("INSERT INTO sfy_hub_offers
                (slug, title, subtitle, duration_label, duration_days, price, old_price, currency,
                 description, perks, badge, is_active, is_featured, sort_order, created_at, updated_at)
                VALUES (?,?,?,?,?,?,?,'USD','',?,?,1,?,?,NOW(),NOW())");
            foreach ($seed as $i => $row) {
                $st->execute([$row[0], $row[1], $row[2], $row[3], $row[4], $row[5], $row[6], $row[8], $row[7],
                              $i === 1 ? 1 : 0, $i]);
            }
        }

        // One welcome message in the inbox would be noise; the *form* is the
        // feature, so nothing is seeded there.
        sfy_hub_seed_script();

        /* Payment methods ship *filled in*: a shop whose method list is empty
           is a shop that cannot take money, and "add your own method" from a
           blank form is where the address, the reference field or the
           callback secret gets forgotten. The owner edits these, and any list
           already in Hub → Settings is carried over as well. */
        if (function_exists('sfy_hub_payment_seed')) sfy_hub_payment_seed();
    } catch (Throwable $e) {
        error_log('[SFY HUB] seed: ' . $e->getMessage());
    }
}

/**
 * A ready-made example script card.
 *
 * An empty scripts grid gives the owner nothing to look at and no way to tell
 * a working layout from a broken one. This is the SFY showcase entry, marked
 * DRAFT so it is invisible to visitors until the owner publishes or deletes it.
 */
function sfy_hub_seed_script(): void {
    $db = sfy_db();
    $n  = (int)$db->query("SELECT COUNT(*) AS n FROM sfy_hub_scripts")->fetch()['n'];
    if ($n > 0) return;

    $db->prepare("INSERT INTO sfy_hub_scripts
        (slug, title, game_name, summary, description, script_code, features, tags, thumbnail,
         author, source, source_url, key_system, is_universal, is_free, is_featured, status,
         sort_order, published_at, created_at, updated_at)
        VALUES (?,?,?,?,?,?,?,?,?,'SFY_DEVs','manual','',0,1,1,0,'draft',0,NOW(),NOW(),NOW())")
       ->execute([
            'sfy-showcase-silent-aimbot-esp',
            'SILENT AIMBOT WITH ESP by SFY',
            'Universal',
            'The SFY showcase build — silent aimbot, advanced ESP, speed and more.',
            "A sample card so the hub has something to render on a fresh install.\n"
            . "Edit it, publish it, or delete it — it ships as a DRAFT and is never\n"
            . "visible to visitors until you say so.",
            "--[[ SFY showcase: Aimbot + ESP ]]\nloadstring(game:HttpGet(\"https://pastebin.com/raw/GQCgRRVR\"))()",
            "Silent aimbot\nAdvanced aimbot\nAdvanced ESP\nSpeed\nFly",
            'SFY,Aimbot,ESP,Universal',
            '',
       ]);
}
