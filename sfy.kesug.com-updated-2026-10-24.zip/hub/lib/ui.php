<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY HUB — UI
 *
 *  The hub's own chrome: a top bar shaped like the script sites people
 *  already know (logo bar, section links, one search box, one call to
 *  action), then a card grid.
 *
 *  Two rules keep it consistent with the rest of the install:
 *
 *   • every colour, radius, font and glow comes from the theme's CSS custom
 *     properties, printed by sfy_appearance_css(). The admin's Appearance
 *     tab therefore restyles the hub too, with no second theme to maintain —
 *     assets/hub.css only ever *reads* those variables.
 *   • sizing the owner controls from Hub → Appearance (shell width, columns,
 *     gap, card padding, thumbnail height, type scale, title size, radius) is
 *     emitted as an extra layer of custom properties, so a layout change is a
 *     value change and never a template edit.
 * ═══════════════════════════════════════════════════════════════════════
 */

/** Routes this module answers, and what each one claims to be. */
function sfy_hub_routes(): array {
    return [
        'home'     => ['title' => '',                  'view' => 'home'],
        'scripts'  => ['title' => 'All scripts',       'view' => 'scripts'],
        'script'   => ['title' => 'Script',            'view' => 'script'],
        'offers'   => ['title' => 'Premium keys',      'view' => 'offers'],
        'buy'      => ['title' => 'Buy a key',         'view' => 'buy'],
        'contact'  => ['title' => 'Contact support',   'view' => 'contact'],
        'suggest'  => ['title' => 'Suggest a game',    'view' => 'suggest'],
        // Not pages: XML for crawlers and the signed payment callback, listed
        // here so ?p= stays a whitelist rather than a path builder.
        'sitemap'  => ['title' => 'Sitemap',          'view' => 'sitemap'],
        'webhook'  => ['title' => 'Payment callback', 'view' => 'webhook'],
    ];
}

/** The requested route, or 'home'. Never trusts ?p= beyond the whitelist. */
function sfy_hub_route(): string {
    $p = strtolower(trim((string)sfy_param('p', 'home')));
    return isset(sfy_hub_routes()[$p]) ? $p : 'home';
}

/* ── the two links that belong to the site, not to the hub ────────────
   The hub is often the page a visitor lands on, which means the flow that
   actually *does* something — pasting a token and getting a code — would
   otherwise be one hop away with no door. These are the two addresses that
   stand in for the hub's missing halves: the guide page that explains the
   token flow, and the landing page the hub was put in front of. Both are
   overridable in Hub → Settings, and blank means the shipped target. */

/** Where the token flow is explained, and where a visitor starts it. */
function sfy_hub_site_code(): string {
    $u = trim((string)sfy_hub_setting('code_url', ''));
    return $u !== '' ? $u : sfy_url('tutorial');
}

/** The site's own landing page — behind the hub at /home by default. */
function sfy_hub_site_home(): string {
    $u = trim((string)sfy_hub_setting('home_url', ''));
    return $u !== '' ? $u : sfy_url('home');
}

/* ── owner-controlled sizing ────────────────────────────────────────── */

/**
 * The extra custom properties the panel's size controls feed.
 * Printed on hub pages only, after the theme layer, so it wins without
 * touching anything the rest of the site renders.
 */
function sfy_hub_css_vars(): string {
    $s      = sfy_hub_settings();
    $radius = (int)$s['radius'] > 0 ? (int)$s['radius'] . 'px' : 'var(--r)';
    return ':root{'
        . '--hub-shell:' . (int)$s['shell'] . 'px;'
        . '--hub-cols:' . (int)$s['cols'] . ';'
        . '--hub-gap:' . (int)$s['gap'] . 'px;'
        . '--hub-pad:' . (int)$s['card_pad'] . 'px;'
        . '--hub-thumb:' . (int)$s['thumb_h'] . 'px;'
        . '--hub-fs:' . round((int)$s['font_scale'] / 100, 2) . ';'
        . '--hub-title:' . (int)$s['title_size'] . 'px;'
        . '--hub-lines:' . (int)$s['desc_lines'] . ';'
        . '--hub-logo-h:' . (int)$s['logo_h'] . 'px;'
        . '--hub-r:' . $radius . ';'
        . '}';
}

/* ── the logo bar ───────────────────────────────────────────────────── */

/**
 * The brand as a *bar*, not an avatar.
 *
 * The install's logo is a square file, and the sites this layout follows put
 * a wide logo strip in the top bar. So the image is rendered at a fixed bar
 * height with its own aspect ratio preserved, next to the wordmark — never
 * cropped into a circle, and never stretched. A missing file degrades to the
 * wordmark alone rather than a broken-image icon.
 */
function sfy_hub_logo(): string {
    $s    = sfy_hub_settings();
    $word = (string)$s['title'] !== '' ? (string)$s['title'] : SFY_APP_NAME;

    $custom = trim((string)$s['logo_url']) !== '' ? (string)$s['logo_url'] : '';
    $file   = $custom !== '' ? $custom : 'sfyLogo.png';
    $exists = $custom !== '' ? true : is_file(SFY_ROOT . '/' . $file);
    $src    = $exists ? sfy_asset($file) : '';

    $img = $src !== ''
        ? '<img class="hub-logo" src="' . sfy_esc($src) . '" alt="' . sfy_esc($word) . '"'
          . ' decoding="async" fetchpriority="high">'
        : '';

    return '<a class="hub-brand" href="' . sfy_esc(sfy_hub_url()) . '" aria-label="' . sfy_esc($word) . ' home">'
         . $img
         . (!empty($s['logo_text']) || $img === ''
             ? '<span class="hub-word">' . sfy_esc($word) . '</span>' : '')
         . '</a>';
}

/* ── the top bar ────────────────────────────────────────────────────── */

/** Section links, filtered by the owner's switches. */
function sfy_hub_nav_items(): array {
    $s    = sfy_hub_settings();
    $page = sfy_hub_route();

    $items = [];
    /* The site's landing page first, because on an install where the hub *is*
       the home page this is the only way back to the page it replaced. */
    if (!empty($s['nav_home'])) {
        $items[] = ['key' => 'home', 'label' => 'Home', 'icon' => '⌂',
                    'url' => sfy_hub_site_home(), 'on' => false];
    }
    if (!empty($s['nav_scripts'])) {
        $items[] = ['key' => 'scripts', 'label' => 'Latest',   'icon' => '🆕',
                    'url' => sfy_hub_url('scripts'), 'on' => $page === 'scripts'];
        $items[] = ['key' => 'trending', 'label' => 'Trending', 'icon' => '🔥',
                    'url' => sfy_hub_url('scripts', ['sort' => 'views']), 'on' => false];
        $items[] = ['key' => 'popular', 'label' => 'Popular',  'icon' => '📈',
                    'url' => sfy_hub_url('scripts', ['sort' => 'top']), 'on' => false];
    }
    if (!empty($s['nav_offers'])) {
        $items[] = ['key' => 'offers', 'label' => 'Premium', 'icon' => '⚡',
                    'url' => sfy_hub_url('offers'), 'on' => $page === 'offers' || $page === 'buy'];
    }
    if (!empty($s['nav_suggest'])) {
        $items[] = ['key' => 'suggest', 'label' => 'Requests', 'icon' => '🎮',
                    'url' => sfy_hub_url('suggest'), 'on' => $page === 'suggest'];
    }
    if (!empty($s['nav_contact'])) {
        $items[] = ['key' => 'contact', 'label' => 'Contact', 'icon' => '✉',
                    'url' => sfy_hub_url('contact'), 'on' => $page === 'contact'];
    }
    return $items;
}

/**
 * The navbar.
 *
 * The search box posts to the scripts route with `q`, i.e. a plain GET the
 * results page can render on the server — no JavaScript needed for the one
 * thing a script site is used for most.
 */
function sfy_hub_navbar(): string {
    $s     = sfy_hub_settings();
    $page  = sfy_hub_route();
    $q     = (string)sfy_param('q', '');
    $links = '';
    foreach (sfy_hub_nav_items() as $it) {
        $links .= '<a class="' . ($it['on'] ? 'on' : '') . '" href="' . sfy_esc($it['url']) . '"'
                . ($it['on'] ? ' aria-current="page"' : '') . '>'
                . '<span class="hub-ni" aria-hidden="true">' . $it['icon'] . '</span>'
                . sfy_esc($it['label']) . '</a>';
    }

    $search = '';
    if (!empty($s['search'])) {
        $search = '<form class="hub-search" method="get" action="' . sfy_esc(sfy_url('hub/')) . '" role="search">'
                . '<input type="hidden" name="p" value="scripts">'
                . '<input type="search" name="q" value="' . sfy_esc($q) . '" placeholder="Search scripts…"'
                . ' aria-label="Search scripts" autocomplete="off" spellcheck="false">'
                . '<button type="submit" aria-label="Search">⌕</button></form>';
    }

    $cta = !empty($s['nav_offers'])
        ? '<a class="btn btn-gold btn-sm hub-cta" href="' . sfy_esc(sfy_hub_url('offers')) . '">⚡ GET PREMIUM</a>'
        : '';

    /* The site's own action, highlighted and right beside the shop button:
       the hub is where people land, so the one link that leads out of it
       into the token flow has to be as loud as the shop's. */
    $codeCta = !empty($s['nav_code'])
        ? '<a class="btn btn-primary btn-sm hub-cta hub-cta-code" href="' . sfy_esc(sfy_hub_site_code()) . '"'
          . '>🔑 GET CODE</a>'
        : '';
    /* The popup stacks the same two buttons: the bar hides them on a phone,
       and a heading nobody can act on is not a menu. */
    $codeCtaBlock = !empty($s['nav_code'])
        ? '<a class="btn btn-primary btn-block" href="' . sfy_esc(sfy_hub_site_code()) . '">🔑 GET CODE</a>'
        : '';

    /* The mobile menu is a *popup*, not a strip that pushes the page down.
     *
     * Below the desktop breakpoint the section links, the search box and the
     * premium button all move into this panel, so the bar itself stays two
     * things tall on a phone — brand and a burger — instead of eating the
     * first screenful. It is emitted as a sibling of the bar so it can be a
     * fixed overlay rather than part of the sticky header's flow. */
    $drawerHead = '<div class="hub-drawer-head">'
        . '<span class="hub-drawer-title" id="hub-drawer-title">MENU</span>'
        . '<button type="button" class="hub-drawer-x" id="hub-drawer-close" aria-label="Close menu">✕</button>'
        . '</div>';

    return '<header class="hub-bar" id="hub-bar">'
        . '<div class="hub-bar-in">'
        . sfy_hub_logo()
        . '<nav class="hub-nav" aria-label="Hub sections">' . $links . '</nav>'
        . '<span class="hub-bar-sp"></span>'
        . $search
        . $cta
        . $codeCta
        . '<button type="button" class="hub-burger" id="hub-burger" aria-controls="hub-drawer"'
        . ' aria-expanded="false" aria-label="Open menu">'
        . '<span class="hub-burger-box" aria-hidden="true"><i></i><i></i><i></i></span></button>'
        . '</div>'
        . '</header>'
        . '<div class="hub-scrim" id="hub-scrim" aria-hidden="true"></div>'
        . '<aside class="hub-drawer" id="hub-drawer" role="dialog" aria-modal="true"'
        . ' aria-labelledby="hub-drawer-title" aria-hidden="true">'
        . $drawerHead
        . '<nav class="hub-nav hub-nav-stack" aria-label="Hub sections">' . $links . '</nav>'
        . ($search !== '' ? '<div class="hub-drawer-search">' . $search . '</div>' : '')
        . $codeCtaBlock
        . (!empty($s['nav_offers'])
            ? '<a class="btn btn-gold btn-block" href="' . sfy_esc(sfy_hub_url('offers')) . '">⚡ GET PREMIUM</a>' : '')
        . '<div class="hub-drawer-foot">Scripts, keys and game support — everything in one place.</div>'
        . '</aside>';
}

/* ── page frame ─────────────────────────────────────────────────────── */

/**
 * <head> + chrome + the section heading.
 *
 * Every page goes through here, which is what makes the crawler-facing part of
 * it dependable: the canonical URL, the robots directive, the description and
 * the structured data are derived from the route and the query string, so a
 * new view gets them by existing. A view that knows more than the route does
 * (a script that is public at last, a preview of a draft) passes `robots`,
 * `description` or `schema` and that wins — see sfy_hub_seo().
 *
 * @param array $o title, sub, page (route), pin (pinned-bar action), head,
 *                  description, canonical, robots, noindex, schema
 */
function sfy_hub_page_start(array $o = []): void {
    $s     = sfy_hub_settings();
    $route = (string)($o['page'] ?? sfy_hub_route());
    $title = (string)($o['title'] ?? '');
    $sub   = (string)($o['sub'] ?? '');

    /* The bottom-pinned bar is the install's own component; the hub hands it
       the action that matters on this page (usually "GET PREMIUM") so the bar
       and the page never disagree about what the next step is. */
    if (!empty($o['pin']) && is_array($o['pin'])) sfy_pin_action($o['pin']);

    $seo  = sfy_hub_seo($route, $o);
    $head = sfy_hub_seo_head($seo)
          . '<link rel="stylesheet" href="' . sfy_esc(sfy_asset('hub/assets/hub.css')) . '">'
          . '<style id="sfy-hub-sizing">' . sfy_hub_css_vars() . '</style>'
          . (string)($o['head'] ?? '');

    sfy_head([
        'title'      => $title,
        'page'       => 'hub',
        'minimal'    => true,
        'wide'       => true,                 // the hub sets its own max width
        /* The route says *which page this is*; it is namespaced because a bare
           `hub-offers` / `hub-buy` / `hub-page` body class would be matched by
           the module's own component rules — `.hub-offers{display:grid}`,
           `.hub-page{border:1px …}` — and lay the whole document out as a
           grid, border it, centre its text and shrink its type. Every class
           printed here must stay out of hub.css's selector space (there is a
           test for it). */
        'body_class' => 'sfy-hub-page hub-route-' . $route,
        /* sfy_head's own switch is deliberately *not* used: it can only say
           `noindex,nofollow`, and a variant page (a search, a sort, page 3)
           should stay crawlable so the links out of it are followed. The one
           robots directive this page needs is printed in $head above, which
           keeps exactly one such tag on the page. */
        'head'       => $head,
    ]);
    echo sfy_hub_navbar();

    $flash = sfy_hub_flash_take();
    echo '<div class="hub-wrap hub-wrap-' . sfy_esc($route) . '">';
    echo sfy_hub_sidebar_open($route, $s);
    if ($flash) {
        $kind = in_array((string)($flash['kind'] ?? ''), ['ok', 'err', 'warn', 'info'], true)
              ? (string)$flash['kind'] : 'info';
        echo '<div class="msg ' . $kind . ' hub-msg">'
           . ($kind === 'ok' ? '✔ ' : ($kind === 'err' ? '✖ ' : '◆ '))
           . sfy_esc((string)($flash['text'] ?? '')) . '</div>';
    }
    if ($title !== '') {
        echo '<div class="hub-head">'
           . '<h1 class="hub-h1">' . sfy_esc($title) . '</h1>'
           . ($sub !== '' ? '<p class="hub-sub">' . sfy_esc($sub) . '</p>' : '')
           . '</div>';
    }
}

/**
 * Close the frames sfy_hub_page_start() opened.
 *
 * The rail is emitted *here*, as a sibling of `.hub-main`, which is what
 * makes it a real second grid column rather than a box inside the main one.
 * The view therefore only ever prints its own content and calls this.
 */
/* ── popup editing ─────────────────────────────────────────────────────

   Every edit in this module opens in one of these rather than in a form at
   the foot of a screen nobody scrolls to.

   The point is that it is *server-rendered*: the markup is printed only when
   the URL asks for it (`?tab=inbox&open=12`), the scrim and the ✕ are ordinary
   links back to the list, and the form inside posts to the same handler it
   always did. So the popup opens, submits and closes without a line of
   JavaScript — and because saving redirects to the list URL *without* the id,
   the popup is gone the instant the work is done. With JavaScript it also gets
   Escape, a focus trap and a scroll lock on the page behind it. */

/**
 * Open a popup; call sfy_hub_modal_end() after the form inside it.
 *
 * @param array $o title, sub, close (URL — the ✕ and the scrim), icon, wide
 */
function sfy_hub_modal_start(array $o = []): void {
    $close = trim((string)($o['close'] ?? ''));
    $title = (string)($o['title'] ?? 'Edit');
    $sub   = (string)($o['sub'] ?? '');
    $icon  = (string)($o['icon'] ?? '✎');
    if ($close === '') $close = sfy_hub_admin_url();

    echo '<div class="hub-modal' . (!empty($o['wide']) ? ' wide' : '') . '" id="hub-modal" data-hub-modal>'
       . '<a class="hub-modal-scrim" href="' . sfy_esc($close) . '" aria-label="Close" tabindex="-1"></a>'
       . '<div class="modal hub-modal-box" role="dialog" aria-modal="true"'
       . ' aria-labelledby="hub-modal-title" tabindex="-1">'
       . '<div class="modal-head"><span class="hub-modal-ic" aria-hidden="true">' . $icon . '</span>'
       . '<h3 id="hub-modal-title">' . sfy_esc($title) . '</h3>'
       . ($sub !== '' ? '<span class="hub-modal-sub">' . sfy_esc($sub) . '</span>' : '')
       . '<span class="spacer"></span>'
       . '<a class="hub-modal-x" href="' . sfy_esc($close) . '" aria-label="Close">✕</a></div>'
       . '<div class="modal-body hub-modal-body">';
}

/** Close the popup sfy_hub_modal_start() opened. */
function sfy_hub_modal_end(): void {
    echo '</div></div></div>';
}

function sfy_hub_page_end(array $o = []): void {
    echo '</div>';                       // .hub-main
    echo sfy_hub_sidebar();              // <aside> or nothing
    echo '</div>';                       // .hub-layout
    echo '</div>';                       // .hub-wrap
    sfy_foot(['page' => 'hub', 'foot' => '<script src="'
        . sfy_esc(sfy_asset('hub/assets/hub.js')) . '" defer></script>']);
}

/**
 * The two-column frame the listing pages use.
 *
 * The rail is an owner switch, so the *markup* has to follow it rather than
 * being hidden with CSS: a hidden column still costs a grid track, and on a
 * phone an empty second column is a dead scroll region.
 */
function sfy_hub_sidebar_open(string $route, array $s): string {
    $withRail = !empty($s['sidebar']) && in_array($route, ['home', 'scripts'], true);
    $GLOBALS['SFY_HUB_RAIL'] = $withRail;
    return '<div class="hub-layout' . ($withRail ? ' has-rail' : '') . '"><div class="hub-main">';
}

/** The rail itself, appended by sfy_hub_page_end() on the pages that use it. */
function sfy_hub_sidebar(): string {
    if (empty($GLOBALS['SFY_HUB_RAIL'])) return '';

    $s    = sfy_hub_settings();
    $rail = '<aside class="hub-rail">';

    $offer = sfy_hub_offer_featured();
    if ($offer) {
        $rail .= '<section class="hub-rail-box hub-rail-feature">'
               . '<div class="hub-rail-head"><span class="hub-rail-dot"></span> Featured plan</div>'
               . sfy_hub_offer_card($offer, true)
               . '</section>';
    }

    $top = sfy_hub_top_scripts(5);
    if ($top) {
        $rows = '';
        foreach ($top as $i => $t) {
            $rows .= '<a class="hub-top-row" href="' . sfy_esc(sfy_hub_script_link($t)) . '">'
                   . '<span class="hub-top-n">#' . ($i + 1) . '</span>'
                   . '<span class="hub-top-m">'
                   . '<span class="hub-top-t">' . sfy_esc(sfy_short((string)$t['title'], 34)) . '</span>'
                   . '<span class="hub-top-s">' . sfy_esc((string)($t['game_name'] !== '' ? $t['game_name'] : 'Universal'))
                   . ' · ' . number_format((int)$t['views']) . ' views</span></span></a>';
        }
        $rail .= '<section class="hub-rail-box">'
               . '<div class="hub-rail-head">🏆 Most viewed</div>' . $rows . '</section>';
    }

    $rail .= '<section class="hub-rail-box hub-rail-foot">'
           . '<div class="hub-rail-head">🔎 Missing a game?</div>'
           . '<p class="hub-rail-p">Tell us what to add — suggestions land in the admin inbox.</p>'
           . '<a class="btn btn-sm btn-block" href="' . sfy_esc(sfy_hub_url('suggest')) . '">REQUEST A GAME</a>'
           . (!empty($s['nav_contact'])
               ? '<a class="btn btn-sm btn-ghost btn-block hub-mt" href="' . sfy_esc(sfy_hub_url('contact')) . '">CONTACT SUPPORT</a>'
               : '')
           . '</section>';

    return $rail . '</aside>';
}

/* ── cards ──────────────────────────────────────────────────────────── */

function sfy_hub_script_link(array $s): string {
    return sfy_hub_url('script', ['slug' => (string)($s['slug'] ?? '')]);
}

/** Relative "when", from when the card was actually published. */
function sfy_hub_script_when(array $s): string {
    return sfy_ago((string)($s['published_at'] ?? '') !== '' ? (string)$s['published_at'] : (string)($s['created_at'] ?? ''));
}

/**
 * The card thumbnail.
 *
 * A script with no image is the normal case, not an error: the fallback is a
 * generated tile built from the title's initial and the theme's own accent,
 * so the grid keeps its rhythm instead of collapsing to a broken icon.
 */
function sfy_hub_thumb(array $s, string $cls = 'hub-thumb'): string {
    $img = trim((string)($s['thumbnail'] ?? ''));
    $alt = (string)($s['title'] ?? '');
    $ini = strtoupper(sfy_hub_cut(trim($alt) !== '' ? $alt : 'S', 1));

    if ($img !== '') {
        return '<span class="' . sfy_esc($cls) . ' has-img">'
             . '<img src="' . sfy_esc($img) . '" alt="" loading="lazy" decoding="async"'
             . ' referrerpolicy="no-referrer" onerror="this.parentNode.classList.remove(\'has-img\');this.remove()">'
             . '</span>';
    }
    return '<span class="' . sfy_esc($cls) . ' hub-thumb-fb" aria-hidden="true">'
         . '<b>' . sfy_esc($ini) . '</b></span>';
}

/**
 * The hero media of a script page: the picture, and — when the script has a
 * video this can play — the picture *as* the player.
 *
 * The still is what the visitor sees and what the page weighs; the embed is
 * only fetched when somebody asks for it, which is the difference between a
 * page that loads one image and a page that loads YouTube's whole player for
 * every visitor who never presses play. With no video, this is exactly the
 * picture the card shows, and there is no affordance promising one.
 *
 * The wrapper is an `<a href="watch">` rather than a button on purpose: with
 * no JavaScript the click still lands somewhere real — the video, on its own
 * site — instead of doing nothing at all. Everything the script needs to play
 * it in place travels in data attributes, so nothing here is inline script.
 */
function sfy_hub_hero_media(array $s, bool $autoplay = false): string {
    $url   = trim((string)($s['video_url'] ?? ''));
    $video = sfy_hub_video_parse($url);
    if ($video['embed'] === '') return sfy_hub_thumb($s);

    $still = trim((string)($s['thumbnail'] ?? ''));
    if ($still === '') $still = $video['poster'];      // the video's own frame beats a letter tile

    $inner = $still !== ''
        ? '<span class="hub-thumb has-img"><img src="' . sfy_esc($still) . '" alt="" loading="lazy" decoding="async"'
          . ' referrerpolicy="no-referrer"'
          . ' onerror="this.parentNode.classList.remove(\'has-img\');this.remove()"></span>'
        : sfy_hub_thumb($s);

    $title = (string)($s['title'] ?? '');

    return '<div class="hub-hero-media">'
         . '<a class="hub-hero-play" href="' . sfy_esc($video['watch']) . '" target="_blank" rel="noopener nofollow"'
         . ' data-hub-play="' . sfy_esc(sfy_hub_video_src($url)) . '"'
         . ' data-hub-auto="' . sfy_esc(sfy_hub_video_src($url, true)) . '"'
         . ($autoplay ? ' data-hub-autoplay="1"' : '')
         . ' aria-label="Play the video for ' . sfy_esc($title) . '">'
         . $inner
         . '<span class="hub-play-btn" aria-hidden="true"></span>'
         . '<span class="hub-play-tag">' . ($autoplay ? '▶ Autoplay' : '▶ Video')
         . ' · ' . sfy_esc($video['provider']) . '</span>'
         . '</a></div>';
}

/**
 * One script card.
 * @param array $o  'filter' => a lower-cased haystack the client-side box
 *                  matches against; kept in a data attribute so the instant
 *                  filter never has to re-render anything.
 */
function sfy_hub_script_card(array $s, array $o = []): string {
    $tags = '';
    foreach (array_slice(sfy_hub_tag_list((string)($s['tags'] ?? '')), 0, 3) as $t) {
        $tags .= '<span class="hub-tag">' . sfy_esc($t) . '</span>';
    }
    if (!empty($s['key_system'])) {
        $tags = '<span class="hub-tag hub-tag-key">🔑 Key system</span>' . $tags;
    }
    if (!empty($s['is_featured'])) {
        $tags = '<span class="hub-tag hub-tag-hot">🔥 Featured</span>' . $tags;
    }

    $desc = trim((string)($s['summary'] ?? ''));
    if ($desc === '') $desc = trim((string)($s['description'] ?? ''));
    if (function_exists('sfy_hub_import_text')) $desc = sfy_hub_import_text($desc);

    $data = isset($o['filter'])
        ? ' data-hub-text="' . sfy_esc((string)$o['filter']) . '"' : '';

    /* A card with a video says so on the picture: it is the one thing the
       detail page has that the card cannot show, and it is what makes the
       click worth making. */
    $play = sfy_hub_video_playable((string)($s['video_url'] ?? ''))
        ? '<span class="hub-card-play" aria-hidden="true"></span>' : '';

    return '<article class="hub-card"' . $data . '>'
        . '<a class="hub-card-thumb" href="' . sfy_esc(sfy_hub_script_link($s)) . '" tabindex="-1" aria-hidden="true">'
        . sfy_hub_thumb($s)
        . $play
        . '<span class="hub-card-views">👁 ' . number_format((int)($s['views'] ?? 0)) . '</span>'
        . '<span class="hub-card-when">' . sfy_esc(sfy_hub_script_when($s)) . '</span>'
        . '</a>'
        . '<div class="hub-card-bd">'
        . '<h3 class="hub-card-title"><a href="' . sfy_esc(sfy_hub_script_link($s)) . '">'
        . sfy_esc((string)($s['title'] ?? '')) . '</a></h3>'
        . '<div class="hub-card-game">'
        . sfy_esc((string)($s['game_name'] !== '' ? $s['game_name'] : 'Universal script')) . '</div>'
        . ($desc !== '' ? '<p class="hub-card-desc">' . sfy_esc($desc) . '</p>' : '')
        . ($tags !== '' ? '<div class="hub-card-tags">' . $tags . '</div>' : '')
        . '</div></article>';
}

/**
 * @param bool  $compact  the rail's tighter variant
 * @param array $opt      'buy' => false drops the button — which is what the
 *                        buy page itself wants, since a button back to the
 *                        page you are already on is noise, not a call to
 *                        action.
 */
function sfy_hub_offer_card(array $o, bool $compact = false, array $opt = []): string {
    $perks = '';
    foreach (array_slice(sfy_hub_feature_list($o['perks'] ?? ''), 0, $compact ? 4 : 8) as $p) {
        $perks .= '<li><span class="tick">✓</span>' . sfy_esc($p) . '</li>';
    }
    $accent = preg_match('/^#[0-9a-f]{6}$/i', (string)($o['accent'] ?? ''))
        ? ' style="--hub-offer-accent:' . sfy_esc((string)$o['accent']) . '"' : '';
    $off    = sfy_hub_offer_discount($o);
    $old    = (float)($o['old_price'] ?? 0) > (float)($o['price'] ?? 0)
        ? '<s class="hub-offer-old">' . sfy_esc(sfy_hub_money($o['old_price'], (string)$o['currency'])) . '</s>' : '';
    $badge  = trim((string)($o['badge'] ?? '')) !== ''
        ? '<span class="badge y hub-offer-badge">' . sfy_esc((string)$o['badge']) . '</span>' : '';
    $buy    = sfy_hub_url('buy', ['offer' => (string)$o['slug']]);

    return '<article class="hub-offer' . ($compact ? ' hub-offer-compact' : '') . '"' . $accent . '>'
        . '<div class="hub-offer-top">'
        . '<span class="hub-offer-dur">' . sfy_esc((string)($o['duration_label'] !== '' ? $o['duration_label']
            : ((int)$o['duration_days'] . ' DAY' . ((int)$o['duration_days'] === 1 ? '' : 'S')))) . '</span>'
        . $badge . '</div>'
        . '<h3 class="hub-offer-title">' . sfy_esc((string)$o['title']) . '</h3>'
        . (trim((string)$o['subtitle']) !== '' ? '<div class="hub-offer-sub">' . sfy_esc((string)$o['subtitle']) . '</div>' : '')
        . '<div class="hub-offer-price">' . sfy_esc(sfy_hub_money($o['price'], (string)$o['currency']))
        . $old . ($off !== '' ? '<span class="hub-offer-off">' . sfy_esc($off) . '</span>' : '') . '</div>'
        . ($perks !== '' ? '<ul class="hub-perks">' . $perks . '</ul>' : '')
        . ((bool)($opt['buy'] ?? true)
            ? '<a class="btn ' . (!empty($o['is_featured']) ? 'btn-gold' : 'btn-primary') . ' btn-block hub-offer-buy"'
              . ' href="' . sfy_esc($buy) . '">BUY ' . sfy_esc(strtoupper((string)$o['duration_label'] !== ''
                  ? (string)$o['duration_label'] : ((string)$o['duration_days'] . ' DAYS'))) . ' KEY</a>'
            : '')
        . '</article>';
}

/* ── payment methods ────────────────────────────────────────────────── */

/** The glyph a method wears when the owner has not chosen one. */
function sfy_hub_pay_icon(array $m): string {
    $icon = trim((string)($m['icon'] ?? ''));
    if ($icon !== '') return $icon;
    return ['wallet' => '🏦', 'redirect' => '🔗', 'gateway' => '💳'][(string)($m['kind'] ?? 'wallet')] ?? '•';
}

function sfy_hub_pay_kind_label(string $kind): string {
    return (string)(sfy_hub_payment_kinds()[$kind]['label'] ?? 'Payment');
}

/** The “needs: a, b” line under a choice, from the method's requirements. */
function sfy_hub_pay_needs(array $m): string {
    $labels = [];
    foreach ((array)($m['requirements_list'] ?? sfy_hub_payment_requirement_list($m['requirements'] ?? '')) as $r) {
        $labels[] = (string)$r['label'];
    }
    return $labels ? 'You will need: ' . implode(' · ', array_slice($labels, 0, 3)) : '';
}

/**
 * One payment method as a *choice*: a radio, a name, and what it needs.
 *
 * The whole card is the label, so tapping anywhere on it selects the method —
 * which is the difference between a usable form on a phone and a form that
 * makes people aim at a 14px circle.
 */
function sfy_hub_pay_card(array $m, bool $checked = false): string {
    $slug = (string)($m['slug'] ?? '');
    $net  = trim((string)($m['network'] ?? ''));
    $sum  = trim((string)($m['summary'] ?? ''));
    $need = sfy_hub_pay_needs($m);

    return '<label class="hub-pay">'
        . '<input type="radio" name="payment_method" value="' . sfy_esc($slug) . '"'
        . ($checked ? ' checked' : '') . ' data-hub-pay="' . sfy_esc($slug) . '">'
        . '<span class="hub-pay-ic" aria-hidden="true">' . sfy_esc(sfy_hub_pay_icon($m)) . '</span>'
        . '<span class="hub-pay-tx">'
        . '<span class="hub-pay-name">' . sfy_esc((string)$m['name']) . '</span>'
        . ($net !== '' ? '<span class="hub-pay-net">' . sfy_esc($net) . '</span>' : '')
        . ($sum !== '' ? '<span class="hub-pay-sum">' . sfy_esc($sum) . '</span>' : '')
        . ($need !== '' ? '<span class="hub-pay-req">' . sfy_esc($need) . '</span>' : '')
        . '</span>'
        . '<span class="hub-pay-tick" aria-hidden="true">✓</span>'
        . '</label>';
}

/**
 * One method as a *fact* rather than a choice — for the shop page, which is
 * read before anything is bought. Same fields as the choice card, no radio.
 */
function sfy_hub_pay_info(array $m): string {
    $auto = !empty($m['auto']);
    $net  = trim((string)($m['network'] ?? ''));
    $sum  = trim((string)($m['summary'] ?? ''));
    $need = sfy_hub_pay_needs($m);
    $min  = (float)($m['min_amount'] ?? 0);
    $fee  = trim((string)($m['fee_note'] ?? ''));

    return '<article class="hub-payinfo">'
        . '<div class="hub-paypanel-head">'
        . '<span class="hub-pay-ic" aria-hidden="true">' . sfy_esc(sfy_hub_pay_icon($m)) . '</span>'
        . '<b>' . sfy_esc((string)$m['name']) . '</b>'
        . ($auto ? '<span class="hub-pill new">auto-confirm</span>' : '')
        . '</div>'
        . ($net !== '' ? '<div class="hub-pay-net">' . sfy_esc($net) . '</div>' : '')
        . ($sum !== '' ? '<p class="hub-pay-sum">' . sfy_esc($sum) . '</p>' : '')
        . ($need !== '' ? '<div class="hub-pay-req">' . sfy_esc($need) . '</div>' : '')
        . (($min > 0 || $fee !== '')
            ? '<div class="hub-pay-foot">'
              . ($min > 0 ? 'Minimum ' . sfy_esc(sfy_hub_money($min, (string)$m['currency'])) : '')
              . ($min > 0 && $fee !== '' ? ' · ' : '') . sfy_esc($fee) . '</div>'
            : '')
        . '</article>';
}

/**
 * What a buyer is shown for one method, under the list of choices.
 *
 * Every method gets a panel; the client hides the ones that are not selected
 * (and without JavaScript they are all simply visible, which is longer but
 * never wrong). The address is the part people have to copy exactly, so it is
 * printed in a copyable, monospaced block rather than a sentence.
 */
function sfy_hub_pay_detail(array $m, array $o = []): string {
    $slug   = (string)($m['slug'] ?? '');
    $kind   = (string)($m['kind'] ?? 'wallet');
    $addr   = trim((string)($m['address'] ?? ''));
    $link   = trim((string)($m['checkout_url'] ?? ''));
    $instr  = trim((string)($m['instructions'] ?? ''));
    $note   = trim((string)($m['confirm_note'] ?? ''));
    $saved  = (array)($o['saved'] ?? []);
    $on     = !empty($o['on']);

    $out = '<section class="hub-paypanel' . ($on ? ' on' : '') . '" data-hub-pay="' . sfy_esc($slug) . '"'
         . ' aria-label="' . sfy_esc((string)$m['name']) . '">';
    $out .= '<div class="hub-paypanel-head">'
          . '<span class="hub-pay-ic" aria-hidden="true">' . sfy_esc(sfy_hub_pay_icon($m)) . '</span>'
          . '<b>' . sfy_esc((string)$m['name']) . '</b>'
          . '<span class="hub-pay-kind">' . sfy_esc(sfy_hub_pay_kind_label($kind)) . '</span></div>';

    if ($instr !== '') $out .= '<div class="hub-prose-block">' . sfy_esc($instr) . '</div>';

    if ($addr !== '') {
        $out .= '<div class="hub-addr">'
              . '<span class="hub-addr-l">' . sfy_esc($kind === 'wallet' ? 'Send to' : 'Address') . '</span>'
              . '<code id="hub-pay-addr-' . sfy_esc($slug) . '">' . sfy_esc($addr) . '</code>'
              . '<button type="button" class="hub-copy" data-hub-copy="#hub-pay-addr-' . sfy_esc($slug) . '">COPY</button>'
              . '</div>';
    }

    if ($link !== '') {
        $out .= '<div class="hub-pay-note">The payment page opens on the next screen, with the amount '
              . 'and your reference already on it.</div>';
    }

    /* The buyer's answers to this method's requirements. They live inside the
       order form, which is why they are rendered here and not in the summary. */
    $reqs = (array)($m['requirements_list'] ?? []);
    if ($reqs) {
        $out .= '<div class="hub-payreq">';
        foreach ($reqs as $r) {
            $key = (string)$r['key'];
            $val = (string)($saved[$key] ?? '');
            $out .= '<div class="hub-field">'
                  . '<label for="' . sfy_esc($key) . '">' . sfy_esc((string)$r['label'])
                  . (empty($r['required']) ? ' <span class="hub-opt-tag">optional</span>' : '') . '</label>'
                  . '<input type="text" id="' . sfy_esc($key) . '" name="' . sfy_esc($key) . '"'
                  . ' maxlength="191" value="' . sfy_esc($val) . '"'
                  . ((string)($r['hint'] ?? '') !== '' ? ' placeholder="' . sfy_esc((string)$r['hint']) . '"' : '')
                  . (empty($r['required']) ? '' : ' required') . '>'
                  . '</div>';
        }
        $out .= '</div>';
    }

    if ($note !== '') $out .= '<div class="hub-pay-note">' . sfy_esc($note) . '</div>';
    return $out . '</section>';
}

/**
 * The confirmation screen's “how to pay” panel for a placed order.
 *
 * This is where the checkout link is built — the order exists by now, so the
 * amount and the reference can actually be put into it — and where a wallet's
 * address and the buyer's own answers are echoed back.
 */
function sfy_hub_pay_summary(array $m, array $order): string {
    $auto  = sfy_hub_payment_auto_confirm($m);
    $addr  = trim((string)($m['address'] ?? ''));
    $instr = trim((string)($m['instructions'] ?? ''));
    $link  = sfy_hub_payment_link($m, $order);
    $fields = sfy_hub_payment_fields($order);

    $out = '<div class="hub-paypanel on">'
         . '<div class="hub-paypanel-head">'
         . '<span class="hub-pay-ic" aria-hidden="true">' . sfy_esc(sfy_hub_pay_icon($m)) . '</span>'
         . '<b>' . sfy_esc((string)$m['name']) . '</b>'
         . '<span class="hub-pay-kind">' . sfy_esc(sfy_hub_pay_kind_label((string)($m['kind'] ?? 'wallet'))) . '</span>'
         . '</div>';

    if ($instr !== '') $out .= '<div class="hub-prose-block">' . sfy_esc($instr) . '</div>';

    if ($addr !== '') {
        $out .= '<div class="hub-addr"><span class="hub-addr-l">Send to</span>'
              . '<code id="hub-pay-addr-confirm">' . sfy_esc($addr) . '</code>'
              . '<button type="button" class="hub-copy" data-hub-copy="#hub-pay-addr-confirm">COPY</button></div>';
    }

    if ($link !== '') {
        $out .= '<a class="btn btn-gold btn-block hub-mt" href="' . sfy_esc($link) . '" target="_blank" rel="noopener">'
              . '↗ PAY ' . sfy_esc(sfy_hub_money($order['amount'], (string)$order['currency'])) . ' ON ' . sfy_esc(strtoupper((string)$m['name'])) . '</a>';
    }

    $facts = [
        'Amount'       => sfy_hub_money($order['amount'], (string)$order['currency']),
        'Network'      => (string)($m['network'] ?? ''),
        'Minimum'      => (float)($m['min_amount'] ?? 0) > 0 ? sfy_hub_money($m['min_amount'], (string)$order['currency']) : '',
        'Fees'         => (string)($m['fee_note'] ?? ''),
        'Confirmation' => sfy_hub_payment_next_step($m, $auto),
    ];
    $out .= '<div class="hub-payfacts">';
    foreach ($facts as $label => $val) {
        if (trim((string)$val) === '') continue;
        $out .= '<div class="hub-kv"><span>' . sfy_esc($label) . '</span><span>' . sfy_esc((string)$val) . '</span></div>';
    }
    $out .= '</div>';

    if ($fields) {
        $out .= '<div class="label" style="margin-top:12px">What you told us</div><div class="hub-payfacts">';
        foreach ($fields as $f) {
            $out .= '<div class="hub-kv"><span>' . sfy_esc((string)$f['label']) . '</span><span>'
                  . sfy_esc((string)$f['value']) . '</span></div>';
        }
        $out .= '</div>';
    }

    if (!$auto && trim((string)($m['confirm_note'] ?? '')) !== '') {
        $out .= '<div class="hub-pay-note">' . sfy_esc((string)$m['confirm_note']) . '</div>';
    }
    if ($auto) {
        $out .= '<div class="hub-pay-note">This method confirms itself — this page shows the order turning '
              . "<b>paid</b> as soon as the provider calls back. Reload to see it.</div>";
    }
    return $out . '</div>';
}

/* ── filtering ──────────────────────────────────────────────────────── */

/** Current filter state, read from the query string. */
function sfy_hub_filters(): array {
    return [
        'q'     => (string)sfy_param('q', ''),
        'game'  => (string)sfy_param('game', ''),
        'kind'  => (string)sfy_param('kind', 'all'),
        'sort'  => (string)sfy_param('sort', 'new'),
        'page'  => max(1, sfy_int('page', 1)),
    ];
}

/** Keep the visitor's filters when a chip or the pager is clicked. */
function sfy_hub_filter_url(array $f, array $override = []): string {
    $keep = [];
    foreach (array_merge($f, $override) as $k => $v) {
        if ($k === 'page') continue;
        if ((string)$v === '' || ($k === 'kind' && $v === 'all') || ($k === 'sort' && $v === 'new')) continue;
        $keep[$k] = $v;
    }
    if (isset($override['page']) && (int)$override['page'] > 1) $keep['page'] = (int)$override['page'];
    return sfy_hub_url('scripts', $keep);
}

/** The kind chips + game chips. */
function sfy_hub_chips(array $f): string {
    if (empty(sfy_hub_setting('chips'))) return '';

    $out = '<div class="hub-chips">';
    foreach (sfy_hub_script_kinds() as $key => $label) {
        $count = sfy_hub_scripts_count(['kind' => $key, 'status' => 'published']);
        if ($count === 0 && $key !== 'all') continue;
        $on = (string)$f['kind'] === (string)$key;
        $out .= '<a class="hub-chip' . ($on ? ' on' : '') . '" href="'
              . sfy_esc(sfy_hub_filter_url($f, ['kind' => $key, 'page' => 1])) . '">'
              . sfy_esc($label) . ' <b>' . number_format($count) . '</b></a>';
    }
    $out .= '</div>';

    $games = sfy_hub_games(16);
    if ($games) {
        $out .= '<div class="hub-chips hub-chips-games">';
        $on = (string)$f['game'] === '';
        $out .= '<a class="hub-chip hub-chip-game' . ($on ? ' on' : '') . '" href="'
              . sfy_esc(sfy_hub_filter_url($f, ['game' => '', 'page' => 1])) . '">All games</a>';
        foreach ($games as $g) {
            $name = (string)$g['game_name'];
            $on   = (string)$f['game'] === $name;
            $out .= '<a class="hub-chip hub-chip-game' . ($on ? ' on' : '') . '" href="'
                  . sfy_esc(sfy_hub_filter_url($f, ['game' => $name, 'page' => 1])) . '">'
                  . sfy_esc(sfy_short($name, 26)) . ' <b>' . (int)$g['n'] . '</b></a>';
        }
        $out .= '</div>';
    }
    return $out;
}

/** The search + sort row above the grid. */
function sfy_hub_filter_bar(array $f, int $total): string {
    $count = '<span class="hub-count">' . number_format($total) . ' script' . ($total === 1 ? '' : 's') . '</span>';
    // Switched off in Hub → Appearance: the bar collapses to the count line,
    // and the *search box in the bar* still searches — which is the control
    // people actually use.
    if (empty(sfy_hub_setting('filters'))) {
        return '<div class="hub-filterbar">' . $count . '</div>';
    }

    $sorts = '';
    foreach (sfy_hub_script_sorts() as $key => $label) {
        $on = (string)$f['sort'] === (string)$key;
        $sorts .= '<a class="hub-sort' . ($on ? ' on' : '') . '" href="'
                . sfy_esc(sfy_hub_filter_url($f, ['sort' => $key, 'page' => 1])) . '">' . sfy_esc($label) . '</a>';
    }

    return '<div class="hub-filterbar">'
        . '<form class="hub-filterbar-search" method="get" action="' . sfy_esc(sfy_url('hub/')) . '">'
        . '<input type="hidden" name="p" value="scripts">'
        . ((string)$f['game'] !== '' ? '<input type="hidden" name="game" value="' . sfy_esc((string)$f['game']) . '">' : '')
        . ((string)$f['kind'] !== 'all' ? '<input type="hidden" name="kind" value="' . sfy_esc((string)$f['kind']) . '">' : '')
        . '<input type="search" name="q" value="' . sfy_esc((string)$f['q']) . '"'
        . ' placeholder="Search scripts, games, tags…" aria-label="Search scripts">'
        . '<button class="btn btn-sm btn-primary" type="submit">SEARCH</button></form>'
        . '<div class="hub-sorts" role="group" aria-label="Sort">' . $sorts . '</div>'
        . $count
        . '</div>';
}

/** Server-rendered pager: every page is a real link, no JavaScript needed. */
function sfy_hub_pager(array $f, int $total, int $perPage, string $route = 'scripts'): string {
    $pages = (int)ceil(max(1, $total) / max(1, $perPage));
    if ($pages <= 1) return '';
    $cur = min($pages, max(1, (int)$f['page']));

    $out = '<nav class="hub-pager" aria-label="Pages">';
    $mk  = function (int $p, string $label, bool $on = false, bool $off = false) use ($f, $route): string {
        $url = $route === 'scripts' ? sfy_hub_filter_url($f, ['page' => $p]) : sfy_hub_url($route, ['page' => $p]);
        if ($off) return '<span class="hub-page off">' . sfy_esc($label) . '</span>';
        return '<a class="hub-page' . ($on ? ' on' : '') . '" href="' . sfy_esc($url) . '">' . sfy_esc($label) . '</a>';
    };

    $out .= $mk($cur - 1, '‹ Prev', false, $cur <= 1);
    $from = max(1, $cur - 2);
    $to   = min($pages, $from + 4);
    for ($p = $from; $p <= $to; $p++) $out .= $mk($p, (string)$p, $p === $cur);
    if ($to < $pages) $out .= '<span class="hub-page dots">…</span>' . $mk($pages, (string)$pages);
    $out .= $mk($cur + 1, 'Next ›', false, $cur >= $pages);
    return $out . '</nav>';
}

/**
 * The whole listing block: chips, filter bar, grid, pager.
 *
 * Shared by the home page and the scripts page so the two can never drift —
 * the only difference between them is the heading and which filters the
 * visitor arrived with.
 *
 * @param array $o quick (client-side filter box), notice
 */
function sfy_hub_listing(array $f, array $o = []): string {
    $s      = sfy_hub_settings();
    $perPage = (int)$s['per_page'];
    $filters = ['q' => (string)$f['q'], 'game' => (string)$f['game'],
                'kind' => (string)$f['kind'], 'sort' => (string)$f['sort'],
                'status' => 'published'];
    $total  = sfy_hub_scripts_count($filters);
    $rows   = sfy_hub_scripts($filters, (int)$f['page'], $perPage);

    $out = '';
    if (trim((string)$s['home_notice']) !== '') {
        $out .= '<div class="hub-notice">' . sfy_esc((string)$s['home_notice']) . '</div>';
    }
    $out .= sfy_hub_chips($f);
    $out .= sfy_hub_filter_bar($f, $total);

    if (!empty($o['quick'])) {
        $out .= '<div class="hub-filterbar" style="padding:9px 13px">'
              . '<input class="grow" type="search" data-hub-quick placeholder="Filter what is on this page…"'
              . ' aria-label="Filter the scripts shown on this page" style="background:var(--input);border:1px solid var(--line);'
              . 'border-radius:var(--r);padding:8px 12px;color:var(--text);font-size:13px;flex:1;min-width:0">'
              . '<span class="hint" style="margin:0">Instant filter — the search box above queries every script.</span>'
              . '</div>';
    }

    if (!$rows) {
        $out .= sfy_hub_empty((string)$f['q'] !== '' ? 'Nothing matched that search' : 'No scripts published yet');
        $out .= '<div class="hub-empty hub-empty-quick" style="display:none">'
              . '<b>Nothing on this page matched</b><p>Clear the filter box to see the page again.</p></div>';
        return $out;
    }

    $out .= '<div class="hub-grid" data-hub-grid>';
    foreach ($rows as $r) {
        $hay = strtolower(trim((string)$r['title'] . ' ' . (string)$r['game_name'] . ' '
             . (string)$r['summary'] . ' ' . (string)$r['tags'] . ' ' . (string)$r['author']));
        $out .= sfy_hub_script_card($r, ['filter' => $hay]);
    }
    $out .= '</div>';
    $out .= '<div class="hub-empty hub-empty-quick" style="display:none">'
          . '<b>Nothing on this page matched</b><p>Clear the filter box to see the page again.</p></div>';
    $out .= sfy_hub_pager($f, $total, $perPage);
    return $out;
}

function sfy_hub_empty(string $what = 'Nothing here yet'): string {
    return '<div class="hub-empty"><b>' . sfy_esc($what) . '</b>'
         . '<p>Try a different search, or ask us to add it.</p>'
         . '<a class="btn btn-sm btn-primary" href="' . sfy_esc(sfy_hub_url('suggest')) . '">REQUEST A GAME</a>'
         . '</div>';
}

/**
 * The install's staff session, for the one admin link the hub shows.
 * Returns null for a visitor — there is no user account system here, by
 * design: the public hub has nothing to sign in *for*.
 */
function sfy_hub_staff(): ?array {
    return function_exists('sfy_admin_current') ? sfy_admin_current() : null;
}
