<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY HUB — IMPORT FROM LINK
 *
 *  Paste a script page's URL and the hub fills a script card from it. Three
 *  layers, tried in order, because the two sites we import from answer very
 *  differently:
 *
 *   1. scriptblox.com — a public JSON API (`/api/script/<slug>`) that returns
 *      everything cleanly. Used first when it is available.
 *   2. haxhell.com — a server-rendered page with no API this module can rely
 *      on, so it is read from the HTML: OpenGraph tags, embedded JSON
 *      payloads, the code block and the labelled feature list.
 *   3. anything else — a generic OG / JSON-LD / <pre><code> reader, so a
 *      third source needs no new code before it is at least *attempted*.
 *
 *  Whatever the layer, the result is a plain array of field suggestions. It
 *  is shown in the panel for editing BEFORE it is saved, and it can be
 *  overridden field by field afterwards — an import is a starting point, not
 *  a locked record, and nothing here writes to the database.
 *
 *  Failure is expected and handled: shared hosting blocks outbound requests,
 *  the sites behind Cloudflare refuse non-browser clients, a page changes
 *  shape. Every one of those ends in `ok:false` with a sentence the owner can
 *  act on, plus the paste-a-copy fallback in the panel.
 * ═══════════════════════════════════════════════════════════════════════
 */

/** What this module knows how to read, for the panel's hint text. */
function sfy_hub_import_sources(): array {
    return [
        'scriptblox' => ['label' => 'ScriptBlox', 'hosts' => ['scriptblox.com'],
                         'how'   => 'Public JSON API — title, game, code, features, tags, author and views.'],
        'haxhell'    => ['label' => 'HaxHell',    'hosts' => ['haxhell.com'],
                         'how'   => 'Reads the page HTML: title, game, description, feature list and the code block.'],
        'generic'    => ['label' => 'Any other site', 'hosts' => [],
                         'how'   => 'OpenGraph tags, JSON-LD and the first <pre><code> block that looks like Lua.'],
    ];
}

/** Which importer owns this URL. */
function sfy_hub_import_source(string $url): string {
    $host = strtolower((string)parse_url($url, PHP_URL_HOST));
    if ($host === '' || !preg_match('~^https?://~i', $url)) return '';
    foreach (sfy_hub_import_sources() as $key => $src) {
        foreach ($src['hosts'] as $h) {
            if ($host === $h || str_ends_with($host, '.' . $h)) return $key;
        }
    }
    return 'generic';
}

/* ── transport ──────────────────────────────────────────────────────── */

/**
 * GET a URL as a browser would, bounded in time and size.
 *
 * @return array{ok:bool,http:int,body:string,error:string,ms:int,url:string}
 */
function sfy_hub_http_get(string $url, int $timeout = 12, int $maxBytes = 1500000): array {
    $url = trim($url);
    $out = ['ok' => false, 'http' => 0, 'body' => '', 'error' => '', 'ms' => 0, 'url' => $url];

    if (!preg_match('~^https?://~i', $url)) { $out['error'] = 'That is not a full http(s) link.'; return $out; }
    $host = strtolower((string)parse_url($url, PHP_URL_HOST));
    if ($host === '') { $out['error'] = 'That link has no host name.'; return $out; }

    $t0      = (int)round(microtime(true) * 1000);
    $headers = [
        'Accept: text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8',
        'Accept-Language: en-US,en;q=0.9',
        'Cache-Control: no-cache',
    ];
    // The module's own identity, plus a browser-ish UA: Cloudflare-fronted
    // sites serve the HTML edition to a browser UA and a challenge to a bot
    // one, and the HTML edition is the one that carries the data.
    $ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
        . 'Chrome/124.0 Safari/537.36 SFY-Hub/' . SFY_HUB_VERSION;

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 4,
            CURLOPT_TIMEOUT        => max(3, $timeout),
            CURLOPT_CONNECTTIMEOUT => 6,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_ENCODING       => '',
            CURLOPT_USERAGENT      => $ua,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_RANGE          => '0-' . $maxBytes,
        ]);
        $body = curl_exec($ch);
        $out['http'] = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $err         = (string)curl_error($ch);
        $out['url']  = (string)(curl_getinfo($ch, CURLINFO_EFFECTIVE_URL) ?: $url);
        curl_close($ch);
        $out['ms'] = (int)round(microtime(true) * 1000) - $t0;

        if (!is_string($body) || ($out['http'] === 0 && $err !== '')) {
            $out['error'] = 'Could not reach ' . $host . ($err !== '' ? ' (' . $err . ')' : '') . '.';
            error_log('[SFY HUB] import transport: ' . $out['error']);
            return $out;
        }
        if ($out['http'] === 403 || $out['http'] === 503) {
            $out['error'] = $host . ' refused the request (HTTP ' . $out['http']
                          . '). Its bot protection blocks servers — use “paste the page” below.';
            return $out;
        }
        if ($out['http'] >= 400) {
            $out['error'] = $host . ' answered HTTP ' . $out['http'] . '.';
            return $out;
        }
        $out['ok']   = true;
        $out['body'] = substr((string)$body, 0, $maxBytes);
        return $out;
    }

    if (!ini_get('allow_url_fopen')) {
        $out['error'] = 'This host allows neither curl nor outbound streams, so link import cannot run here. Use “paste the page”.';
        return $out;
    }

    $ctx = stream_context_create(['http' => [
        'method'        => 'GET',
        'timeout'       => max(3, $timeout),
        'follow_location' => 1,
        'max_redirects' => 4,
        'ignore_errors' => true,
        'header'        => implode("\r\n", array_merge($headers, ['User-Agent: ' . $ua])),
    ], 'ssl' => ['verify_peer' => true, 'verify_peer_name' => true]]);

    $body = @file_get_contents($url, false, $ctx);
    $out['ms'] = (int)round(microtime(true) * 1000) - $t0;
    foreach (($http_response_header ?? []) as $h) {
        if (preg_match('~^HTTP/\S+\s+(\d{3})~', (string)$h, $m)) $out['http'] = (int)$m[1];
    }
    if (!is_string($body) || $body === '') {
        $out['error'] = 'Could not reach ' . $host . ' from this server. Use “paste the page”.';
        return $out;
    }
    if ($out['http'] >= 400) {
        $out['error'] = $host . ' answered HTTP ' . $out['http'] . '. Use “paste the page”.';
        return $out;
    }
    $out['ok']   = true;
    $out['body'] = substr($body, 0, $maxBytes);
    return $out;
}

/* ── the entry point ────────────────────────────────────────────────── */

/**
 * Import a script page by URL.
 *
 * @param string $url
 * @param string $pasted  optional page source / code the owner pasted; when
 *                        given, it is parsed instead of (or after a failed)
 *                        network fetch — the escape hatch for a host whose
 *                        bot protection blocks servers.
 * @return array{ok:bool,source:string,source_url:string,error:string,fields:array,notes:string[]}
 */
function sfy_hub_import(string $url, string $pasted = ''): array {
    $url    = trim($url);
    $pasted = trim($pasted);

    $out = ['ok' => false, 'source' => '', 'source_url' => $url, 'error' => '',
            'fields' => sfy_hub_import_blank(), 'notes' => []];

    if ($url === '' && $pasted === '') {
        $out['error'] = 'Paste a script page link — or paste the page source / the code itself.';
        return $out;
    }

    $source = $url !== '' ? sfy_hub_import_source($url) : 'generic';
    if ($url !== '' && $source === '') { $out['error'] = 'That is not a full http(s) link.'; return $out; }
    $out['source'] = $source;

    /* 1 — scriptblox's JSON API first: it is the only source that answers with
           structured data, and it is far more reliable than scraping. */
    if ($source === 'scriptblox' && $pasted === '') {
        $json = sfy_hub_import_scriptblox($url, $out['notes'], $out['error']);
        if ($json !== null) {
            $out['ok']         = true;
            $out['fields']     = $json;
            $out['source']     = 'scriptblox';
            return $out;
        }
        $out['notes'][] = 'The JSON API did not answer — falling back to the page HTML.';
    }

    /* 2 — fetch (unless the owner pasted the source) and read the HTML. */
    $body = $pasted;
    if ($body === '') {
        $res = sfy_hub_http_get($url);
        if (!$res['ok']) { $out['error'] = $res['error']; return $out; }
        $body = $res['body'];
        $out['notes'][] = 'Fetched ' . number_format(strlen($body)) . ' bytes from '
                        . (string)parse_url($res['url'], PHP_URL_HOST) . ' in ' . $res['ms'] . 'ms.';
    } elseif ($url !== '') {
        $out['notes'][] = 'Parsed the pasted page source (' . number_format(strlen($body)) . ' bytes).';
    }

    if ($source === 'scriptblox') {
        // A page fetch that worked anyway: the HTML carries the same fields.
        $fields = sfy_hub_import_html($body, $url, $out['notes']);
    } elseif ($source === 'haxhell') {
        $fields = sfy_hub_import_haxhell($body, $url, $out['notes']);
    } else {
        $fields = sfy_hub_import_html($body, $url, $out['notes']);
    }

    $fields['source_url'] = $url;
    $found = sfy_hub_import_filled($fields);
    if ($found === 0) {
        $out['error'] = 'The page was fetched but nothing usable was found in it. It may need JavaScript to '
                      . 'render — open it, copy the page source (Ctrl+U) and paste that instead.';
        return $out;
    }
    $out['ok']     = true;
    $out['fields'] = $fields;
    $out['notes'][] = $found . ' field(s) filled in. Check them before saving.';
    return $out;
}

/** The empty field set every importer returns. */
function sfy_hub_import_blank(): array {
    return [
        'title' => '', 'game_name' => '', 'game_id' => '', 'summary' => '', 'description' => '',
        'script_code' => '', 'features' => '', 'tags' => '', 'thumbnail' => '', 'video_url' => '',
        'discord_url' => '', 'game_link' => '', 'author' => '', 'key_system' => 0,
        'is_universal' => 0, 'is_free' => 1, 'source_url' => '',
    ];
}

/** How many meaningful fields an import actually produced. */
function sfy_hub_import_filled(array $f): int {
    $n = 0;
    foreach (['title', 'game_name', 'summary', 'description', 'script_code', 'features', 'thumbnail', 'author'] as $k) {
        if (trim((string)($f[$k] ?? '')) !== '') $n++;
    }
    return $n;
}

/* ── layer 1: scriptblox ────────────────────────────────────────────── */

/**
 * scriptblox.com via its own public JSON API.
 *
 * The slug is the last path segment of both the human URL and the API URL, so
 * one extraction covers `/script/<slug>`, `/api/script/<slug>` and a
 * search-result link. The *old* form of their URLs (a numeric id) is also
 * handled: a non-slug tail is looked up through the search endpoint.
 *
 * @return array|null null = the API did not give us a script.
 */
function sfy_hub_import_scriptblox(string $url, array &$notes, string &$error): ?array {
    $slug = sfy_hub_import_scriptblox_slug($url);
    if ($slug === '') { $error = 'Could not read a script slug out of that ScriptBlox link.'; return null; }

    $res = sfy_hub_http_get('https://scriptblox.com/api/script/' . rawurlencode($slug), 12, 600000);
    if (!$res['ok']) { $error = $res['error']; return null; }

    $data = json_decode($res['body'], true);
    $s    = is_array($data) ? ($data['script'] ?? null) : null;
    if (!is_array($s) || empty($s['title'])) {
        $notes[] = 'The ScriptBlox API answered with no script object.';
        return null;
    }

    $notes[] = 'Read the ScriptBlox JSON API: ' . $slug . '.';

    $feats = $s['features'] ?? '';
    if (is_array($feats)) $feats = implode("\n", array_map('strval', $feats));

    $tags = $s['tags'] ?? [];
    if (!is_array($tags)) $tags = array_filter(array_map('trim', explode(',', (string)$tags)));

    $game  = is_array($s['game'] ?? null) ? $s['game'] : [];
    $owner = is_array($s['owner'] ?? null) ? $s['owner'] : [];

    return array_merge(sfy_hub_import_blank(), [
        'title'        => (string)$s['title'],
        'game_name'    => (string)($game['name'] ?? ''),
        'game_id'      => (string)($game['gameId'] ?? ''),
        'summary'      => sfy_hub_import_one_line((string)$feats),
        'description'  => '',
        'script_code'  => sfy_hub_import_clean_code((string)($s['script'] ?? '')),
        'features'     => $feats,
        'tags'         => implode(', ', array_slice(array_map('strval', $tags), 0, 12)),
        'thumbnail'    => sfy_hub_import_abs('https://scriptblox.com', (string)($s['image'] ?? '')),
        'game_link'    => !empty($game['gameId']) && (int)$game['gameId'] > 0
                          ? 'https://www.roblox.com/games/' . (int)$game['gameId'] : '',
        'discord_url'  => (string)($s['discord'] ?? ''),
        'author'       => (string)($owner['username'] ?? ''),
        'key_system'   => empty($s['keyless']) ? 1 : 0,
        'is_universal' => !empty($s['isUniversal']) ? 1 : 0,
        'is_free'      => (string)($s['scriptType'] ?? 'free') === 'free' ? 1 : 0,
        'source_url'   => $url,
    ]);
}

function sfy_hub_import_scriptblox_slug(string $url): string {
    $path = (string)parse_url($url, PHP_URL_PATH);
    $tail = trim((string)basename($path));
    if ($tail !== '' && preg_match('~[A-Za-z]~', $tail) && strlen($tail) > 4) return $tail;

    // A numeric id or a bare link: resolve it through the search endpoint so
    // an owner can paste whatever the site gave them.
    $q = trim((string)parse_url($url, PHP_URL_QUERY));
    if ($q !== '' && preg_match('~[?&]q=([^&]+)~', '?' . $q, $m)) {
        $res = sfy_hub_http_get('https://scriptblox.com/api/script/search?q=' . rawurlencode(urldecode($m[1])), 10, 600000);
        $d   = $res['ok'] ? json_decode($res['body'], true) : null;
        $hit = $d['result']['scripts'][0]['slug'] ?? '';
        if (is_string($hit) && $hit !== '') return $hit;
    }
    return '';
}

/* ── layer 2: haxhell ───────────────────────────────────────────────── */

/**
 * haxhell.com, read from its HTML.
 *
 * The page is server-rendered, so the fields the card needs are in the markup
 * — but not always in the *same* markup, because the site embeds a JSON
 * payload for its own hydrating components. So both readings are attempted
 * and merged: embedded JSON first (it carries the exact code string), then
 * OpenGraph and the labelled sections for everything else.
 */
function sfy_hub_import_haxhell(string $html, string $url, array &$notes): array {
    $f = sfy_hub_import_html($html, $url, $notes);

    $blobs = sfy_hub_import_json_blobs($html);
    $notes[] = count($blobs) . ' embedded JSON payload(s) found.';

    $keys = [
        'title'       => ['title', 'name', 'scriptName'],
        'description' => ['description', 'desc', 'summary'],
        'script_code' => ['code', 'script', 'scriptCode', 'content', 'source'],
        'thumbnail'   => ['image', 'imageUrl', 'thumbnail', 'banner', 'cover'],
        'author'      => ['username', 'author', 'creator', 'owner', 'uploader'],
        'game_name'   => ['gameName', 'game'],
        'video_url'   => ['youtube', 'videoUrl', 'video'],
        'discord_url' => ['discord', 'discordUrl', 'discordInvite'],
        'features'    => ['features', 'featureList'],
        'tags'        => ['tags', 'keywords'],
    ];

    foreach ($keys as $field => $candidates) {
        if (trim((string)($f[$field] ?? '')) !== '' && $field !== 'script_code') continue;   // OG wins for text
        foreach ($blobs as $blob) {
            $hit = sfy_hub_import_deep_find($blob, $candidates);
            if ($hit === null) continue;
            $val = is_array($hit) ? implode("\n", array_map('strval', $hit)) : (string)$hit;
            $val = trim($val);
            if ($val === '') continue;
            if ($field === 'script_code' && !sfy_hub_import_looks_like_code($val)) continue;
            if ($field === 'game_name' && is_array($hit)) continue;
            $f[$field] = $field === 'script_code' ? sfy_hub_import_clean_code($val) : $val;
            break;
        }
    }

    // The RSC/flight stream is not a JSON document, so the keys are also read
    // straight out of the escaped text when the walk above found nothing.
    if (trim((string)$f['script_code']) === '') {
        $grab = sfy_hub_import_grab_string($html, ['code', 'script', 'scriptCode', 'content']);
        if (sfy_hub_import_looks_like_code($grab)) $f['script_code'] = sfy_hub_import_clean_code($grab);
    }

    /* The labelled sections a script page always has. Everything here is
       *additional* to what the OG tags gave, never a replacement: the point is
       to fill the parts OpenGraph has no field for. */
    if (trim((string)$f['features']) === '') {
        $items = sfy_hub_import_section_list($html, ['Feature', 'Features', 'Functions']);
        if ($items) $f['features'] = implode("\n", array_slice($items, 0, 20));
    }
    if (trim((string)$f['description']) === '') {
        $items = sfy_hub_import_section_list($html, ['Description', 'About']);
        if ($items) $f['description'] = implode("\n", array_slice($items, 0, 40));
    }
    if (trim((string)$f['game_name']) === '') {
        $f['game_name'] = sfy_hub_import_first_match($html, [
            '~href="/games/[^"]+"[^>]*>([^<]{2,80})<~i',
            '~class="[^"]*game[^"]*"[^>]*>([^<]{2,80})<~i',
        ]);
    }
    if ($f['is_free'] === 1 && stripos($html, 'key system') !== false) $f['key_system'] = 1;
    if (stripos($html, 'mobile friendly') !== false) $notes[] = 'The page advertises mobile support.';

    $f['thumbnail'] = sfy_hub_import_abs('https://haxhell.com', (string)$f['thumbnail']);
    return $f;
}

/* ── layer 3: generic HTML ──────────────────────────────────────────── */

/**
 * OpenGraph + JSON-LD + <pre><code>, for any other site.
 * @return array the blank field set, filled in as far as the page allows
 */
function sfy_hub_import_html(string $html, string $url, array &$notes): array {
    $f = sfy_hub_import_blank();
    if (trim($html) === '') return $f;

    $meta = sfy_hub_import_meta($html);

    $f['title'] = $meta['og:title'] ?? $meta['twitter:title'] ?? '';
    if ($f['title'] === '') {
        $title = sfy_hub_import_first_match($html, ['~<title[^>]*>(.*?)</title>~is']);
        $title = sfy_hub_import_text($title);
        // Strip the site suffix every one of these sites appends.
        $f['title'] = trim((string)preg_replace('~\s*[|·—-]\s*[^|·—-]{2,40}$~u', '', $title));
    }

    $f['summary']     = sfy_hub_import_text((string)($meta['og:description'] ?? $meta['description'] ?? ''));
    $f['description'] = sfy_hub_import_text((string)($meta['og:description'] ?? $meta['description'] ?? ''));
    $f['thumbnail']   = sfy_hub_import_abs($url, (string)($meta['og:image'] ?? $meta['twitter:image'] ?? ''));

    // JSON-LD is the one structured thing a generic page reliably has.
    foreach (sfy_hub_import_json_blobs($html) as $blob) {
        if (($f['title'] === '')) {
            $n = sfy_hub_import_deep_find($blob, ['name', 'headline']);
            if (is_string($n) && $n !== '') $f['title'] = sfy_hub_import_text($n);
        }
        if ($f['description'] === '') {
            $d = sfy_hub_import_deep_find($blob, ['description', 'articleBody']);
            if (is_string($d) && $d !== '') $f['description'] = sfy_hub_import_text($d);
        }
        if ($f['thumbnail'] === '') {
            $i = sfy_hub_import_deep_find($blob, ['image', 'thumbnailUrl']);
            if (is_string($i) && $i !== '') $f['thumbnail'] = sfy_hub_import_abs($url, $i);
        }
    }

    // Views / likes, when the page prints them.
    if (preg_match('~([\d.,]+)\s*[KkMm]?\s*views~i', $html, $m)) {
        $notes[] = 'The page reports ' . $m[1] . ' views.';
    }

    // Author: "by SFY_DEVs" / a /user/ link.
    $f['author'] = sfy_hub_import_first_match($html, [
        '~(?:by|author|creator)\s*[:@]?\s*<a[^>]*>([^<]{2,40})</a>~i',
        '~href="/(?:users?|u|profile)/[^"]+"[^>]*>([^<]{2,40})<~i',
    ]);
    if ($f['author'] === '' && preg_match('~\bby\s+([A-Za-z0-9_.\-]{3,24})\b~', sfy_hub_import_text($html), $m)) {
        $f['author'] = $m[1];
    }

    // Links: Discord, a video, and the game.
    $f['discord_url'] = sfy_hub_import_first_match($html, ['~https://(?:www\.)?discord(?:\.gg|\.com/invite)/[A-Za-z0-9\-]+~i'], true);
    $f['video_url']   = sfy_hub_import_first_match($html, [
        '~https://(?:www\.)?(?:youtube\.com/embed/[A-Za-z0-9_\-]+|youtu\.be/[A-Za-z0-9_\-]+)~i',
        /* Vimeo is read for the same reason YouTube is: a page that embeds a
           video is telling us which video belongs to this script, and that is
           a field the owner would otherwise have to go and find. */
        '~https://(?:www\.)?(?:player\.)?vimeo\.com/(?:video/)?\d{5,}~i'], true);
    if ($f['video_url'] === '' && preg_match('~youtube\.com/watch\?v=([A-Za-z0-9_\-]{6,})~i', $html, $m)) {
        $f['video_url'] = 'https://www.youtube.com/watch?v=' . $m[1];
    }
    /* Whatever came off the page is stored the way every other video link is
       stored, so an embed URL off a page and a share link off a clipboard end
       up as the same row. */
    if ($f['video_url'] !== '') $f['video_url'] = sfy_hub_video_canonical($f['video_url']);
    $f['game_link'] = sfy_hub_import_first_match($html, ['~https://(?:www\.)?roblox\.com/games/\d+~i'], true);

    // Tags: /tags/<x> links and a keywords meta.
    $tags = [];
    if (!empty($meta['keywords'])) {
        foreach (explode(',', (string)$meta['keywords']) as $t) {
            $t = sfy_hub_import_text($t);
            if ($t !== '' && strlen($t) < 32) $tags[] = $t;
        }
    }
    if (preg_match_all('~href="/tags?/([^"/]+)"~i', $html, $m)) {
        foreach (array_slice($m[1], 0, 10) as $t) {
            $t = sfy_hub_import_text(rawurldecode($t));
            if ($t !== '') $tags[] = $t;
        }
    }
    if ($tags) $f['tags'] = implode(', ', array_slice(array_unique($tags), 0, 12));

    // The code: the longest <pre>/<code> block that looks like Lua, then a
    // bare loadstring() call found anywhere in the page.
    $code = sfy_hub_import_code_block($html);
    if ($code === '') {
        $code = sfy_hub_import_first_match($html, [
            '~(loadstring\s*\(\s*game:HttpGet\s*\(\s*["\'][^"\']+["\']\s*\)\s*\)\s*\(\s*\))~i'], true);
    }
    if ($code === '') {
        $grab = sfy_hub_import_grab_string($html, ['code', 'script', 'scriptCode', 'content']);
        if (sfy_hub_import_looks_like_code($grab)) $code = $grab;
    }
    $f['script_code'] = sfy_hub_import_clean_code(sfy_hub_import_unescape($code));

    // A short "features" list from <li> items when the page groups them.
    $items = sfy_hub_import_section_list($html, ['Features', 'Feature']);
    if ($items) $f['features'] = implode("\n", array_slice($items, 0, 20));

    return $f;
}

/* ── HTML helpers ───────────────────────────────────────────────────── */

/** All <meta> name/property → content pairs. */
function sfy_hub_import_meta(string $html): array {
    $out = [];
    if (!preg_match_all('~<meta\s+([^>]{4,400})>~i', $html, $m)) return $out;
    foreach ($m[1] as $attrs) {
        $key = $val = '';
        if (preg_match('~(?:property|name)\s*=\s*["\']([^"\']+)["\']~i', $attrs, $k)) $key = strtolower(trim($k[1]));
        if (preg_match('~content\s*=\s*["\']([^"\']*)["\']~i', $attrs, $v))         $val = trim($v[1]);
        if ($key !== '' && $val !== '') $out[$key] = sfy_hub_import_text($val);
    }
    return $out;
}

/**
 * Every embedded JSON payload on the page, decoded and ready to walk.
 *
 * Three shapes are covered: `__NEXT_DATA__` / JSON-LD script tags, and the
 * Next.js App Router flight stream (`self.__next_f.push([1,"…"])`), whose
 * chunks are JS string literals rather than JSON — those are unescaped and
 * then scanned for JSON objects.
 */
function sfy_hub_import_json_blobs(string $html): array {
    $blobs = [];

    if (preg_match_all('~<script[^>]*type=["\']application/(?:ld\+)?json["\'][^>]*>(.*?)</script>~is', $html, $m)) {
        foreach ($m[1] as $raw) {
            $d = json_decode(trim($raw), true);
            if (is_array($d)) $blobs[] = $d;
        }
    }
    if (preg_match('~<script[^>]*id=["\']__NEXT_DATA__["\'][^>]*>(.*?)</script>~is', $html, $m)) {
        $d = json_decode(trim($m[1]), true);
        if (is_array($d)) $blobs[] = $d;
    }

    // Flight stream: collect and unescape every pushed chunk, then pull the
    // JSON objects out of the concatenated text.
    if (preg_match_all('~self\.__next_f\.push\(\[\s*\d+\s*,\s*("(?:[^"\\\\]|\\\\.)*")\s*\]\)~s', $html, $m)) {
        $text = '';
        foreach ($m[1] as $lit) {
            $decoded = json_decode($lit, true);
            if (is_string($decoded)) $text .= $decoded;
        }
        if ($text !== '') {
            /* The balanced-object walk is bounded twice: a slice of the stream
               (a flight payload can be megabytes) and a backtrack limit, so a
               page that makes PCRE give up degrades to the flat scan below
               instead of returning an error the panel cannot explain. */
            $slice = substr($text, 0, 300000);
            $ok    = @preg_match_all('~\{(?:[^{}]|(?R))*\}~s', $slice, $objs);
            if ($ok && !empty($objs[0])) {
                foreach (array_slice($objs[0], 0, 400) as $o) {
                    $d = json_decode($o, true);
                    if (is_array($d)) $blobs[] = $d;
                }
            }
            // Even when the payload is not balanced JSON, a flat key/value scan
            // of it recovers most of what a card needs.
            $flat = sfy_hub_import_flatten($text);
            if ($flat) $blobs[] = $flat;
        }
    }
    return $blobs;
}

/** Pull `"key":"value"` pairs out of an escaped text stream as a flat array. */
function sfy_hub_import_flatten(string $text): array {
    $out = [];
    /* The value half is a lazy, *unbounded* run rather than a bounded one: a
       repeat like {1,20000} compiles to a pattern PCRE refuses on some builds
       ("regular expression is too large"), and the alternatives here are
       unambiguous — each consumes a distinct first byte — so a star cannot
       backtrack exponentially. A script longer than any cap we could pick is
       exactly the value we must not silently truncate. */
    if (!preg_match_all('~"([A-Za-z_][A-Za-z0-9_]{1,24})"\s*:\s*"((?:[^"\\\\]|\\\\.)*)"~s', $text, $m, PREG_SET_ORDER)) return $out;
    foreach ($m as $pair) {
        $k = $pair[1];
        if (isset($out[$k])) continue;                 // first wins: it is the outer object
        $out[$k] = sfy_hub_import_unescape($pair[2]);
    }
    return $out;
}

/**
 * Recursively look for the first value stored under any of these keys.
 * Bounded in depth and width — a deeply nested payload must not become a
 * denial of service on the panel.
 */
function sfy_hub_import_deep_find($data, array $keys, int $depth = 0) {
    if ($depth > 8 || !is_array($data)) return null;
    foreach ($keys as $k) {
        foreach ($data as $key => $val) {
            if (is_string($key) && strcasecmp($key, (string)$k) === 0 && (is_string($val) || is_array($val))) {
                if (is_string($val) && trim($val) === '') continue;
                return $val;
            }
        }
    }
    $n = 0;
    foreach ($data as $val) {
        if (!is_array($val)) continue;
        $hit = sfy_hub_import_deep_find($val, $keys, $depth + 1);
        if ($hit !== null) return $hit;
        if (++$n > 300) break;
    }
    return null;
}

/** First regex group that matched (optionally returning the whole match). */
function sfy_hub_import_first_match(string $html, array $patterns, bool $whole = false): string {
    foreach ($patterns as $re) {
        if (preg_match($re, $html, $m)) {
            $v = $whole ? (string)$m[0] : (string)($m[1] ?? $m[0]);
            $v = sfy_hub_import_text($v);
            if ($v !== '') return $v;
        }
    }
    return '';
}

/** The best-looking <pre>/<code> block on the page. */
function sfy_hub_import_code_block(string $html): string {
    if (!preg_match_all('~<(pre|code)[^>]*>(.*?)</\1>~is', $html, $m, PREG_SET_ORDER)) return '';
    $best = '';
    foreach ($m as $block) {
        $text = sfy_hub_import_text($block[2]);
        if (strlen($text) < 12) continue;
        $score = 0;
        if (str_contains($text, 'loadstring')) $score += 4;
        if (preg_match('~\b(game:\w+|HttpGet|task\.|wait\(|local |function|end\b)~', $text)) $score += 3;
        if (str_contains($text, "\n")) $score += 1;
        // A block with markup left in it is a UI snippet, not the source.
        if (preg_match('~<[a-z/]~i', $block[2])) $score -= 2;
        if ($score > 0 && $score >= (strlen($best) > 0 ? 1 : 0) && strlen($text) > strlen($best)) $best = $text;
    }
    return $best;
}

/**
 * The items under a labelled section ("Features", "Description").
 *
 * Sites label these differently and wrap them in different elements, so this
 * finds the heading text and then reads the list items that follow it — which
 * is exactly how the two sites we import from both render it.
 */
function sfy_hub_import_section_list(string $html, array $headings, int $max = 24): array {
    $flat = sfy_hub_import_text($html);
    foreach ($headings as $h) {
        $pos = stripos($flat, $h);
        if ($pos === false) continue;
        $window = substr($flat, $pos + strlen($h), 1400);
        /* A list reads as short lines; a paragraph reads as one long one. So
           the window is cut on line breaks, bullets, a pipe and runs of
           spaces — every separator the two sites we import from use between
           list items — and only pieces that look like an item are kept. */
        $parts = preg_split('/\r?\n+|\s{2,}|[•·]|\s\|\s/', $window);
        $parts = array_values(array_filter(array_map(fn($l) => trim((string)$l), (array)$parts),
                                           fn($l) => $l !== '' && strlen($l) >= 3 && strlen($l) <= 90));
        if (count($parts) >= 2) return array_slice($parts, 0, $max);
    }
    return [];
}

/** Tags out, entities decoded, whitespace collapsed (keeps newlines). */
function sfy_hub_import_text(string $s): string {
    $s = (string)preg_replace('~<(script|style)[^>]*>.*?</\1>~is', ' ', $s);
    $s = (string)preg_replace('~<(br|/p|/div|/li|/tr|/h\d)\s*/?>~i', "\n", $s);
    $s = html_entity_decode(strip_tags($s), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    /* The unicode-aware patterns only run on text that really is UTF-8 — a
       mangled page must degrade to a byte-wise collapse, not to null (which
       is what a failed /u replace returns, silently emptying the field). */
    if (preg_match('//u', $s) === 1) {
        $s = (string)preg_replace('~[ \t\x{00A0}]+~u', ' ', $s);
        $s = (string)preg_replace('~\n[ \t]*\n[ \t]*\n+~', "\n\n", $s);
    } else {
        $s = (string)preg_replace('~[ \t]+~', ' ', $s);
    }
    return trim($s);
}

/** A single line version of a block of text. */
function sfy_hub_import_one_line(string $s): string {
    return sfy_hub_line(sfy_hub_import_text($s), 400);
}

function sfy_hub_import_unescape(string $s): string {
    // JS/JSON string escapes and unicode escapes, without json_decode (the
    // payloads we read are fragments and frequently are not valid JSON alone).
    $s = str_replace(['\\n', '\\r', '\\t', '\\"', "\\'", '\\/'], ["\n", "\r", "\t", '"', "'", '/'], $s);
    $s = (string)preg_replace_callback('~\\\\u([0-9a-fA-F]{4})~', function ($m) {
        // Emitted only when the byte sequence is valid UTF-8: a lone surrogate
        // would corrupt the column it is written into. No mbstring — the
        // project never depends on it being installed.
        $c = chr((int)hexdec($m[1]));
        return preg_match('//u', $c) === 1 ? $c : '';
    }, $s);
    return $s;
}

/** Make a path absolute against the page it came from. */
function sfy_hub_import_abs(string $base, string $path): string {
    $path = trim($path);
    if ($path === '') return '';
    if (preg_match('~^https?://~i', $path)) return $path;
    if (str_starts_with($path, '//')) return 'https:' . $path;

    $base = rtrim($base, '/');
    if (preg_match('~^https?://~i', $base)) {
        $host = (string)parse_url($base, PHP_URL_HOST);
        if (str_starts_with($path, '/')) return 'https://' . $host . $path;
        $dir = (string)preg_replace('~/[^/]*$~', '', (string)parse_url($base, PHP_URL_PATH));
        return 'https://' . $host . $dir . '/' . $path;
    }
    return $path;
}

/** Does this text look like Roblox/Lua source rather than prose? */
function sfy_hub_import_looks_like_code(string $s): bool {
    if (strlen(trim($s)) < 8) return false;
    if (str_contains($s, 'loadstring') || str_contains($s, 'game:HttpGet')) return true;
    $hits = 0;
    foreach (['game:', 'wait(', 'local ', 'function', 'end', 'task.', 'GetService', 'HttpPost'] as $needle) {
        if (str_contains($s, $needle)) $hits++;
    }
    return $hits >= 2;
}

/**
 * Give the code a tidy shape: entities decoded, CRLF normalised, the
 * "1  " line numbers some sites prefix a code block with removed.
 */
function sfy_hub_import_clean_code(string $s): string {
    $s = sfy_hub_import_unescape($s);
    $s = html_entity_decode($s, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $s = str_replace(["\r\n", "\r"], "\n", $s);
    $s = trim($s);
    if ($s === '') return '';
    // Strip the leading line-number gutter only when *every* line has it —
    // otherwise a legitimate "123 -- comment" would be mangled.
    $lines = explode("\n", $s);
    if (count($lines) > 1) {
        $all = true;
        foreach ($lines as $l) if (!preg_match('~^\s*\d+\s{1,4}\S~', $l)) { $all = false; break; }
        if ($all) $lines = array_map(fn($l) => (string)preg_replace('~^\s*\d+\s{1,4}~', '', $l), $lines);
        $s = implode("\n", $lines);
    }
    return $s;
}

/** `"key":"…"` straight out of an escaped stream, for one of these keys. */
function sfy_hub_import_grab_string(string $html, array $keys): string {
    foreach ($keys as $k) {
        if (preg_match('~"' . preg_quote($k, '~') . '"\s*:\s*"((?:[^"\\\\]|\\\\.)*)"~s', $html, $m)) {
            return sfy_hub_import_unescape($m[1]);
        }
    }
    return '';
}
