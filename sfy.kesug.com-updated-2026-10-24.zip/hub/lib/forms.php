<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY HUB — FORM PROTECTION
 *
 *  Four cheap checks in front of every public write (a message, a game
 *  suggestion, an order). None of them is exotic, and each one exists for a
 *  specific failure this kind of form actually has:
 *
 *   • CSRF  — the install's own token, so a form embedded elsewhere cannot
 *             post as this site;
 *   • a dwell clock — a signed render timestamp. A bot that reads the form
 *             and posts inside the same second gets refused; a human who
 *             takes a breath does not. This is what stops the flood that
 *             fills a support inbox with nothing;
 *   • a honeypot — a field no human can see and no browser autofills;
 *   • a rate limit — per IP, per form, because the first three checks are all
 *             passable once and a loop is not.
 *
 *  The human check (Turnstile) is *optional* here: it is used only when the
 *  owner has switched it on for the hub in Hub → Settings, and the existing
 *  install's gate decides that (set_turnstile_at_hub), so there is exactly
 *  one place that knows whether a challenge is demanded.
 * ═══════════════════════════════════════════════════════════════════════
 */

/** The captcha context string this module uses with the install's gate. */
function sfy_hub_captcha_context(): string { return 'hub'; }

/** Is a human check requested for hub forms right now? */
function sfy_hub_captcha_needed(): bool {
    return function_exists('sfy_captcha_needed') && sfy_captcha_needed(sfy_hub_captcha_context());
}

/** The widget's markup (empty string when no check is configured). */
function sfy_hub_captcha_field(): string {
    if (!sfy_hub_captcha_needed()) return '';
    return '<div class="field"><label class="label">Human check</label>'
         . sfy_captcha_widget(['compact' => true]) . '</div>';
}

/** Seconds a form must stay open before it may be submitted. */
function sfy_hub_form_min_seconds(): int { return 3; }

/**
 * A signed "this form was rendered at T" token.
 *
 * Signed with the install's own app key (sfy_sign), so it cannot be minted
 * without it, and self-expiring: a form left open for a day is stale, which
 * is what stops a token harvested once from being replayed for ever.
 */
function sfy_hub_form_stamp(): string {
    $ts = time();
    return $ts . '.' . substr(sfy_sign([$ts, 'hub-form'], 'hub'), 0, 32);
}

/** @return bool true when the stamp is ours, fresh, and old enough. */
function sfy_hub_form_stamp_ok(string $stamp): bool {
    $parts = explode('.', $stamp, 2);
    if (count($parts) !== 2) return false;
    [$ts, $sig] = $parts;
    if (!ctype_digit($ts) || strlen($sig) !== 32) return false;
    $want = substr(sfy_sign([(int)$ts, 'hub-form'], 'hub'), 0, 32);
    if (!hash_equals($want, $sig)) return false;
    $age = time() - (int)$ts;
    return $age >= sfy_hub_form_min_seconds() && $age <= 86400;
}

/** The hidden inputs every hub form carries. */
function sfy_hub_form_fields(): string {
    return sfy_csrf_field()
         . '<input type="hidden" name="t" value="' . sfy_esc(sfy_hub_form_stamp()) . '">'
         // The honeypot: off-screen, unfocusable, named like something a
         // scraper would happily fill in.
         . '<div class="hub-hp" aria-hidden="true"><label>Website'
         . '<input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>';
}

/**
 * Validate a submission.
 * @param string $form  bucket name, also the rate-limit key
 * @return array{ok:bool,error:string}
 */
function sfy_hub_guard(string $form): array {
    // A filled honeypot is never reported as such: telling a bot which field
    // gave it away just teaches the next one to leave it empty.
    if (trim((string)($_POST['website'] ?? '')) !== '') {
        return ['ok' => false, 'error' => 'That submission looked automated. Reload the page and try again.'];
    }
    if (!sfy_csrf_check((string)($_POST['csrf'] ?? ''))) {
        return ['ok' => false, 'error' => 'Your page was open too long and the security token expired. Reload and send it again.'];
    }
    if (!sfy_hub_form_stamp_ok((string)($_POST['t'] ?? ''))) {
        return ['ok' => false, 'error' => 'Give the page a moment to load, then press send again.'];
    }
    if (!sfy_rate_limit('hub-' . $form, 5, 600)) {
        return ['ok' => false, 'error' => 'Too many submissions from your connection. Wait a few minutes and try again.'];
    }
    if (sfy_hub_captcha_needed()) {
        $cap = sfy_captcha_check(sfy_hub_captcha_context(), '',
                                 (string)($_POST['cf-turnstile-response'] ?? ''), sfy_client_ip());
        if (empty($cap['ok'])) {
            $why = (string)($cap['why'] ?? '');
            return ['ok' => false, 'error' => function_exists('sfy_captcha_error_text')
                ? sfy_captcha_error_text($why) : 'Human verification failed. Try again.'];
        }
    }
    return ['ok' => true, 'error' => ''];
}

/* ── one-shot messages across a redirect ────────────────────────────── */

function sfy_hub_flash(string $kind, string $text): void {
    $_SESSION['sfy_hub_flash'] = ['kind' => $kind, 'text' => sfy_hub_cut($text, 500)];
}

/** Read and clear the pending notice. */
function sfy_hub_flash_take(): ?array {
    $f = $_SESSION['sfy_hub_flash'] ?? null;
    unset($_SESSION['sfy_hub_flash']);
    return is_array($f) ? $f : null;
}

/** Remember one form's values across a redirect, so a rejection never empties
 *  a long message the visitor just wrote. */
function sfy_hub_keep(array $values): void {
    unset($values['csrf'], $values['t'], $values['website'], $values['cf-turnstile-response']);
    $_SESSION['sfy_hub_keep'] = array_slice($values, 0, 30);
}
function sfy_hub_keep_take(): array {
    $k = $_SESSION['sfy_hub_keep'] ?? [];
    unset($_SESSION['sfy_hub_keep']);
    return is_array($k) ? $k : [];
}
/** One remembered value (escaped on the way out by the template). */
function sfy_hub_keep_get(array $keep, string $key, string $default = ''): string {
    return isset($keep[$key]) && is_scalar($keep[$key]) ? (string)$keep[$key] : $default;
}
