<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY HUB — HEALTH / DIAGNOSTICS
 *
 *  The question this answers is the one an owner asks *before* uploads, on a
 *  host they cannot open a shell on: is the module actually whole, and where
 *  did it break?
 *
 *  Five things can be wrong, and each has a probe here:
 *
 *   1. the schema — a table missing, or a column added by a later version of
 *      the module never landing, because a shared host timed out mid-ALTER;
 *   2. the content — installed but unseeded, so the grid and the shop are
 *      empty and the owner cannot tell a broken layout from an empty one;
 *   3. the settings — a row somebody edited by hand, or a value written by an
 *      older version, that the normaliser quietly rewrites on every read, so
 *      the panel and the page disagree and nothing says so;
 *   4. the import sources — a site this module reads changing its page or its
 *      API shape, which shows up as "import found nothing" with no reason;
 *   5. the module's own idea of what it reads — checked offline, so a rewrite
 *      of a parser is caught before a live site is allowed to explain it.
 *
 *  Everything degrades: a probe that cannot run reports that it could not
 *  run. Nothing here writes, and nothing here is fatal.
 * ═══════════════════════════════════════════════════════════════════════
 */

/* ── 1. schema: tables and columns ──────────────────────────────────── */

/**
 * Every declared table: does it exist, how many rows, which columns are gone.
 * @return array<string,array{exists:bool,rows:int,columns:int,missing:string[]}>
 */
function sfy_hub_health_tables(): array {
    $out = [];
    foreach (sfy_hub_tables() as $table => $ddl) {
        $exists = (bool)sfy_try(fn(): bool => sfy_table_exists($table), false);

        $defined = sfy_schema_defined_columns($ddl);
        $missing = [];
        if ($exists) {
            foreach ($defined as $col => $def) {
                if (preg_match('/AUTO_INCREMENT|PRIMARY KEY/i', $def)) continue;
                if (!sfy_try(fn(): bool => sfy_column_exists($table, (string)$col), false)) $missing[] = (string)$col;
            }
            /* A table that exists but whose definition cannot be read at all is
               worse than one column missing: the sweep below would report a
               clean bill of health for a schema it never checked. */
            if (!$defined) $missing[] = '(definition unreadable)';
        }

        $rows = -1;   // -1 = not applicable (no table to count)
        if ($exists) {
            $rows = (int)sfy_try(function () use ($table): int {
                $row = sfy_db()->query("SELECT COUNT(*) AS n FROM `$table`")->fetch();
                return is_array($row) ? (int)($row['n'] ?? 0) : 0;
            }, -1);
        }

        $out[$table] = ['exists' => $exists, 'rows' => $rows,
                        'columns' => count($defined), 'missing' => $missing];
    }
    return $out;
}

/* ── 2. content: is there anything to look at ───────────────────────── */

/** Row counts and the state the first-run seeder should have produced. */
function sfy_hub_health_content(): array {
    $drafts    = sfy_hub_scripts_count(['status' => 'draft']);
    $published = sfy_hub_scripts_count(['status' => 'published']);

    return [
        'published'     => $published,
        'drafts'        => $drafts,
        'games'         => count(sfy_hub_games(400)),
        'offers'        => count(sfy_hub_offers(false)),
        'offers_active' => count(sfy_hub_offers(true)),
        'orders'        => sfy_hub_order_stats(),
        'messages'      => sfy_hub_message_stats(),
        /* The example card ships as a draft and is meant to be published or
           deleted. Still sitting there means nobody has started yet. */
        'showcase'      => sfy_try(fn(): bool => sfy_hub_script_by_slug('sfy-showcase-silent-aimbot-esp', false) !== null, false),
    ];
}

/* ── 2a. videos: which ones the page can actually play ─────────────────
 *
 * The video field takes anything — a share link, an embed code, a link from a
 * host this module does not embed — and stores what it cannot play as typed,
 * which is right: the page still offers it as a watch button. What is worth
 * reporting is the difference between the two, because an owner who pasted a
 * Facebook or Twitch link sees a picture with no play button on it and has no
 * way to tell a working video from one that was quietly ignored.
 *
 * Not counted among the module's problems: nothing is broken and nothing is
 * lost, so this reads as an advisory line, exactly like an unpaid template.
 */
function sfy_hub_health_videos(): array {
    $rows    = sfy_try(fn(): array => sfy_hub_scripts(['status' => 'any'], 1, 60), []);
    $total   = 0;
    $played  = 0;
    $autoplay = 0;
    $odd     = [];

    foreach ($rows as $r) {
        $url = trim((string)($r['video_url'] ?? ''));
        if ($url === '') continue;
        $total++;
        $v = sfy_hub_video_parse($url);
        if ($v['embed'] !== '') {
            $played++;
            if ((int)($r['video_autoplay'] ?? 0) === 1) $autoplay++;
            continue;
        }
        /* The link is re-checked against the row, not trusted: the point of a
           probe is to notice a helper that answered with something it should
           not have. */
        $odd[] = ['title' => (string)($r['title'] ?? ('#' . ($r['id'] ?? ''))), 'url' => $url];
    }

    return ['total' => $total, 'playable' => $played, 'autoplay' => $autoplay, 'odd' => $odd];
}

/* ── 2b. payment methods: can the shop actually collect ─────────────── */

/**
 * Every method, with the two things that go wrong quietly:
 *
 *   • an offered method that cannot collect — a wallet with no address, a
 *     checkout with no link. The buy page skips it, so a shop can look
 *     healthy and offer one payment option instead of five;
 *   • a gateway whose credentials are half-entered, which reads as
 *     “API configured” in the panel while every order still waits for a human.
 *
 * Neither is an error on a fresh install (the shipped templates are wallets
 * with an empty address on purpose), which is why an empty install reports as
 * *empty* rather than broken — the same rule the rest of this screen follows.
 */
function sfy_hub_health_payments(): array {
    $rows     = sfy_hub_payments(false);
    $offered  = 0;
    $unusable = [];
    $partial  = [];
    $auto     = [];
    $secrets  = 0;

    foreach ($rows as $m) {
        $name = (string)($m['name'] ?? $m['slug'] ?? '#');
        $rd   = sfy_hub_payment_ready($m);

        if (!empty($m['is_active'])) {
            $offered++;
            if (!$rd['ok'] && !sfy_hub_payment_usable($m)) {
                $unusable[] = ['name' => $name, 'missing' => $rd['missing']];
            }
        }
        if ((string)($m['kind'] ?? '') === 'gateway') {
            if ($rd['ok'] && !empty($m['is_active'])) $auto[] = $name;
            elseif ($rd['missing'])                 $partial[] = ['name' => $name, 'missing' => $rd['missing']];
        }
        foreach (['api_key', 'api_secret', 'webhook_secret'] as $k) {
            if (trim((string)($m[$k] ?? '')) !== '') { $secrets++; break; }
        }
    }

    return ['rows' => count($rows), 'offered' => $offered, 'unusable' => $unusable,
            'partial' => $partial, 'auto' => $auto, 'with_secrets' => $secrets,
            'fallback' => !sfy_try(fn(): bool => sfy_table_exists('sfy_hub_payment_methods'), false)];
}

/* ── 3. settings: what the module is actually reading ───────────────── */

/**
 * Every setting, split into the three states that matter.
 *
 * `odd` is the interesting one: a stored row whose value is *not* what the
 * module would write. It is rewritten in memory on every read, so the value in
 * the database and the value on the page differ — which is exactly the kind of
 * thing that gets diagnosed as "the sliders do nothing".
 *
 * @return array{saved:int,total:int,defaulted:string[],odd:array<string,array{stored:string,used:string}>,orphans:string[]}
 */
function sfy_hub_health_settings(): array {
    $defaults = sfy_hub_defaults();
    $saved    = 0;
    $defaulted = [];
    $odd      = [];

    foreach ($defaults as $key => $def) {
        $raw = sfy_config_get('set_hub_' . $key, null);
        if ($raw === null) { $defaulted[] = (string)$key; continue; }
        $saved++;
        $fixed = sfy_hub_normalize(array_merge($defaults, [(string)$key => $raw]))[(string)$key];
        if ((string)$fixed !== (string)$raw) {
            $odd[(string)$key] = ['stored' => (string)$raw, 'used' => (string)$fixed];
        }
    }

    /* A `set_hub_*` row this version does not know: a leftover from an older
       module, or a key typed by hand. It is ignored, which is the safe
       behaviour — but it should be visible rather than mysterious. */
    $orphans = [];
    foreach ((array)sfy_config_all() as $key => $value) {
        $key = (string)$key;
        if (!str_starts_with($key, 'set_hub_')) continue;
        if (!array_key_exists(substr($key, 8), $defaults)) $orphans[] = $key;
    }
    sort($orphans);

    return ['saved' => $saved, 'total' => count($defaults), 'defaulted' => $defaulted,
            'odd' => $odd, 'orphans' => $orphans];
}

/* ── 4/5. import sources: what each reader needs, and still finds ───── */

/**
 * One entry per import source, describing the contract the reader relies on.
 *
 * `paths` are JSON paths (dot separated, digits index arrays) the reader reads
 * out of a payload; `markers` are the HTML it needs to see; `needles` are the
 * key names that must still appear in hub/lib/import.php, which is how a
 * rewrite of a parser is caught.
 */
function sfy_hub_source_specs(): array {
    return [
        'scriptblox' => [
            'label'   => 'ScriptBlox',
            'how'     => 'Public JSON API — /api/script/<slug>',
            'kind'    => 'json',
            'probe'   => 'https://scriptblox.com/api/script/search?q=aimbot',
            /* Where a search answer hides its first hit. More than one shape is
               accepted because the API has nested the list differently before,
               and "the answer moved one level" should read as a warning about a
               *field*, not as "this source is gone". */
            'prefixes'=> ['result.scripts.0', 'result.scripts', 'scripts.0', 'script'],
            'sample'  => 'script',             // where the stored sample payload keeps it
            'paths'   => ['title', 'slug', 'script', 'game.name', 'game.gameId', 'owner.username',
                          'tags', 'scriptType', 'keyless', 'isUniversal'],
            'needles' => ["'title'", "'script'", "'slug'", "'owner'", "'game'", "'tags'",
                          'isUniversal', 'keyless', 'scriptType'],
        ],
        'haxhell' => [
            'label'   => 'HaxHell',
            'how'     => 'Server-rendered HTML — OpenGraph, embedded JSON, the code block',
            'kind'    => 'html',
            'probe'   => 'https://haxhell.com/',
            /* Markers the parser needs: an OpenGraph block, a code or JSON
               payload it can read the source out of, and a Roblox game link. */
            'markers' => ['og:title', 'og:image', '<pre', 'roblox.com/games'],
            'needles' => ['og:title', 'og:description', 'og:image', '__next_f'],
            'promise' => ['title', 'summary', 'script_code', 'features', 'thumbnail', 'author'],
        ],
        'generic' => [
            'label'   => 'Any other site',
            'how'     => 'OpenGraph, JSON-LD and the first Lua-looking block',
            'kind'    => 'html',
            'probe'   => '',                       // no fixed URL to probe
            'markers' => ['og:title'],             // what the reader *prefers*
            'needles' => ['og:title', 'og:description', 'json', 'script_code'],
            /* What the reader must still do with a page that has only a title. */
            'promise' => ['title', 'summary', 'thumbnail'],
        ],
    ];
}

/** Walk a dotted path through decoded data. @return array{0:bool,1:mixed} */
function sfy_hub_path_get($data, string $path): array {
    $cur = $data;
    foreach (explode('.', trim($path)) as $seg) {
        if ($seg === '') continue;
        if (is_array($cur) && array_key_exists($seg, $cur)) { $cur = $cur[$seg]; continue; }
        if (is_array($cur) && ctype_digit($seg) && array_key_exists((int)$seg, $cur)) { $cur = $cur[(int)$seg]; continue; }
        return [false, null];
    }
    return [true, $cur];
}

/**
 * A page that has the shape the readers were written against.
 *
 * It is the module's own contract sample: the offline self-test feeds it to the
 * real parsers, so "the reader still finds the code block" is a fact rather
 * than a hope. The live probe below tests the other direction — whether the
 * site still serves this shape.
 */
function sfy_hub_source_reference_html(): string {
    return '<!doctype html><html><head>'
        . '<title>OP AIMBOT + ESP by SFY | HaxHell</title>'
        . '<meta property="og:title" content="Roblox SHOWDOWN: Western FPS Script - OP AIMBOT + ESP by SFY">'
        . '<meta property="og:description" content="SILENT AIMBOT ADVANCE ESP SPEED AND MORE">'
        . '<meta property="og:image" content="/thumbs/showdown.webp">'
        . '<meta name="keywords" content="SFY SCRIPTS,Roblox Scripts,Western FPS">'
        . '</head><body>'
        . '<a href="/games/showdown-western-fps">SHOWDOWN: Western FPS</a>'
        . '<div>227 views</div><span>by SFY_DEVs</span>'
        . '<section>Features</section><ul><li>AIMBOT + ESP</li><li>SILENT AIMBOT</li></ul>'
        . '<a href="https://discord.gg/abc123">Discord</a>'
        . '<a href="https://www.roblox.com/games/2753915549/Showdown">Play Game</a>'
        . '<pre><code>--[[Updated]]'
        . 'loadstring(game:HttpGet("https://gist.githubusercontent.com/x/y/raw/z/source.lua"))()</code></pre>'
        . '<script>self.__next_f.push([1,"{\"scriptCode\":\"loadstring(game:HttpGet(\'https://json.test/a.lua\'))()\",\"gameName\":\"FROM JSON GAME\"}"])</script>'
        . '</body></html>';
}

/**
 * The offline half of the source check: no network, no requests.
 *
 * Three questions, all answerable from the module's own files:
 *   • does the reader still mention every key the spec names?
 *   • does a page with the documented shape still produce the promised fields?
 *   • does the stored payload (for the JSON source) still have the paths read?
 *
 * @return array<string,array{label:string,how:string,ok:bool,notes:string[]}>
 */
function sfy_hub_source_selftest(): array {
    $importer = (string)sfy_try(fn(): string => (string)file_get_contents(__DIR__ . '/import.php'), '');
    $out      = [];

    foreach (sfy_hub_source_specs() as $key => $spec) {
        $notes = [];
        $ok    = true;

        foreach ((array)$spec['needles'] as $needle) {
            if ($importer === '' || !str_contains($importer, (string)$needle)) {
                $ok      = false;
                $notes[] = 'The reader no longer mentions “' . $needle . '”, so this source is no longer read the way it is described.';
            }
        }

        if (($spec['kind'] ?? '') === 'json') {
            $blob = sfy_try(fn() => json_decode(
                '{"script":{"title":"SILENT AIMBOT WITH ESP","slug":"sample-slug",'
                . '"script":"loadstring(game:HttpGet(\"https://example.test/a.lua\"))()",'
                . '"game":{"gameId":123,"name":"Script hub"},"owner":{"username":"SFY_DEVs"},'
                . '"tags":["SFY","Aimbot"],"scriptType":"free","keyless":false,"isUniversal":true}}', true), null);
            foreach ((array)$spec['paths'] as $path) {
                $full = trim((string)($spec['sample'] ?? ''), '.') . '.' . $path;
                [$found] = sfy_hub_path_get($blob, $full);
                if (!$found) { $ok = false; $notes[] = 'The stored sample payload has no “' . $path . '”.'; }
            }
        } else {
            $html  = sfy_hub_source_reference_html();
            $notes2 = [];                 // the readers take their notes by reference
            $seen  = [];
            if ($key === 'haxhell') {
                $seen = sfy_hub_import_haxhell($html, 'https://haxhell.com/scripts/x', $notes2);
            } elseif ($key === 'generic') {
                $seen = sfy_hub_import_html($html, 'https://example.com/x', $notes2);
            }
            foreach ((array)($spec['promise'] ?? []) as $field) {
                if (trim((string)($seen[$field] ?? '')) === '') {
                    $ok      = false;
                    $notes[] = 'A page of the documented shape no longer yields “' . $field . '”.';
                }
            }
        }

        $out[$key] = ['label' => (string)$spec['label'], 'how' => (string)$spec['how'], 'ok' => $ok, 'notes' => $notes];
    }
    return $out;
}

/**
 * Does this decoded JSON answer still have everything the spec reads?
 *
 * Its own function so the judgement is testable without a network: the probe
 * below fetches, this decides.
 *
 * @return array{ok:bool,item:?array,missing:string[]}
 */
function sfy_hub_source_payload_check($data, array $spec): array {
    $item = null;
    foreach ((array)($spec['prefixes'] ?? []) as $prefix) {
        [$found, $value] = sfy_hub_path_get($data, (string)$prefix);
        if (!$found || !is_array($value)) continue;
        // A prefix that landed on the list itself hands back its first entry.
        if (isset($value[0]) && is_array($value[0])) $value = $value[0];
        if ($value !== []) { $item = $value; break; }
    }
    if ($item === null) return ['ok' => false, 'item' => null, 'missing' => []];

    $missing = [];
    foreach ((array)($spec['paths'] ?? []) as $path) {
        [$found] = sfy_hub_path_get($item, (string)$path);
        if (!$found) $missing[] = (string)$path;
    }
    return ['ok' => $missing === [], 'item' => $item, 'missing' => $missing];
}

/** Which of the HTML markers this reader needs are missing from the page? */
function sfy_hub_source_marker_check(string $body, array $spec): array {
    $missing = [];
    foreach ((array)($spec['markers'] ?? []) as $marker) {
        if (!str_contains($body, (string)$marker)) $missing[] = (string)$marker;
    }
    return $missing;
}

/**
 * The live half: fetch each source once and check it still has the shape.
 *
 * Deliberately *not* run on page load — it makes outbound requests, which on a
 * shared host is the slowest, flakiest thing this module can do. The panel's
 * Diagnostics screen runs it from a button.
 *
 * @return array{at:int,rows:array<string,array{label:string,status:string,ms:int,notes:string[]}>}
 */
function sfy_hub_source_probe(): array {
    $out = ['at' => time(), 'rows' => []];

    foreach (sfy_hub_source_specs() as $key => $spec) {
        $label  = (string)$spec['label'];
        $url    = (string)($spec['probe'] ?? '');
        $notes  = [];
        $status = 'skipped';

        if ($url === '') {
            $notes[] = 'No fixed address to check — this reader works on whatever link you paste, so its shape is '
                     . 'verified on every import instead.';
        } else {
            $res = sfy_hub_http_get($url, 10, 400000);
            if (!$res['ok']) {
                $status  = 'unreachable';
                $notes[] = $res['error'] !== '' ? $res['error'] : 'No answer.';
            } elseif (($spec['kind'] ?? '') === 'json') {
                $check = sfy_hub_source_payload_check(json_decode((string)$res['body'], true), $spec);
                if ($check['item'] === null) {
                    $status  = 'drift';
                    $notes[] = 'The API answered, but nothing was found at “'
                             . implode('”, “', (array)($spec['prefixes'] ?? [])) . '”. The response shape has changed.';
                } else {
                    $status = $check['ok'] ? 'ok' : 'drift';
                    if ($check['missing']) $notes[] = 'This source no longer sends: ' . implode(', ', $check['missing']) . '.';
                    else                   $notes[] = 'Every field the importer reads is present.';
                }
            } else {
                $missing = sfy_hub_source_marker_check((string)$res['body'], $spec);
                $status  = $missing ? 'drift' : 'ok';
                if ($missing) $notes[] = 'The page no longer contains: ' . implode(', ', $missing) . '.';
                else         $notes[] = 'The page still carries everything the reader looks for.';
            }
            $notes[] = 'Checked ' . $url . ' in ' . (int)$res['ms'] . 'ms.';
        }

        $out['rows'][$key] = ['label' => $label, 'status' => $status,
                              'ms' => (int)($res['ms'] ?? 0), 'notes' => $notes];
    }
    return $out;
}

/** The last live probe run in this session, or null when it has never run. */
function sfy_hub_source_probe_last(): ?array {
    $p = $_SESSION['sfy_hub_probe'] ?? null;
    return is_array($p) && isset($p['rows']) ? $p : null;
}

/* ── the whole picture ──────────────────────────────────────────────── */

/** Does this install have everything the module needs to do outbound reads? */
function sfy_hub_health_transport(): array {
    $curl = function_exists('curl_init');
    $fopen = (bool)ini_get('allow_url_fopen');
    return [
        'curl'   => $curl,
        'fopen'  => $fopen,
        'ok'     => $curl || $fopen,
        'php'    => PHP_VERSION,
        'mb'     => function_exists('mb_strlen'),
    ];
}

/** Draft slugs that must not be reachable, and whether the sitemap agrees. */
function sfy_hub_health_index(): array {
    $urls = sfy_try(fn(): array => sfy_hub_sitemap_urls(), []);
    $xml  = sfy_try(fn(): string => sfy_hub_sitemap_xml(), '');

    $leaked = [];
    foreach (sfy_hub_scripts(['status' => 'draft'], 1, 60) as $r) {
        /* The row is re-checked, not trusted: the point of this probe is to
           notice a helper that answered with something it should not have. */
        if ((string)($r['status'] ?? '') !== 'draft') continue;
        $slug = trim((string)($r['slug'] ?? ''));
        if ($slug === '') continue;
        if (str_contains($xml, 'slug=' . $slug) || str_contains($xml, rawurlencode($slug))) $leaked[] = $slug;
    }

    return ['url' => sfy_hub_sitemap_url(), 'count' => count($urls),
            'bytes' => strlen($xml), 'leaked' => $leaked];
}

/**
 * Everything the Diagnostics screen shows, in one array.
 *
 * @return array{problems:int,tables:array,missing_tables:string[],missing_columns:string[],
 *               schema:array,content:array,videos:array,payments:array,settings:array,offline:array,
 *               probe:?array,index:array,runtime:array}
 */
function sfy_hub_health(): array {
    $tables  = sfy_hub_health_tables();
    $content = sfy_hub_health_content();
    $payments = sfy_hub_health_payments();
    $videos   = sfy_hub_health_videos();
    $settings = sfy_hub_health_settings();
    $offline = sfy_hub_source_selftest();
    $index   = sfy_hub_health_index();
    $runtime = sfy_hub_health_transport();

    $missingTables  = [];
    $missingColumns = [];
    foreach ($tables as $table => $t) {
        if (!$t['exists']) { $missingTables[] = $table; continue; }
        foreach ($t['missing'] as $col) $missingColumns[] = $table . '.' . $col;
    }

    $stamp = (string)sfy_config_get('hub_schema', '');
    $schema = ['stamp' => $stamp, 'expected' => (string)SFY_HUB_SCHEMA, 'match' => $stamp === (string)SFY_HUB_SCHEMA];

    /* The count on the tab badge: the conditions that actually stop the module
       working, not the advisory rows. A stale schema stamp on its own is not
       one of them — it only means the installer will run once more, which is
       what it is for. */
    $problems = count($missingTables) + count($missingColumns);
    foreach ($offline as $o) if (!$o['ok']) $problems++;
    $problems += count($settings['odd']);
    $problems += count($payments['unusable']);
    if ($index['leaked']) $problems++;
    if (!$runtime['ok'])  $problems++;      // no way to reach an import source at all

    return [
        'problems'       => $problems,
        'tables'         => $tables,
        'missing_tables' => $missingTables,
        'missing_columns'=> $missingColumns,
        'schema'         => $schema,
        'content'        => $content,
        'videos'         => $videos,
        'payments'       => $payments,
        'settings'       => $settings,
        'offline'        => $offline,
        'probe'          => sfy_hub_source_probe_last(),
        'index'          => $index,
        'runtime'        => $runtime,
    ];
}
