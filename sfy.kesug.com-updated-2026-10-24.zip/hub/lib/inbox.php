<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY HUB — INBOX (game suggestions · support · bug reports)
 *
 *  One table, one inbox. The visitor form and the game-suggestion form
 *  differ only in their copy and in which field they insist on, so they
 *  share a row shape — which is also why the panel can filter both with the
 *  same query instead of maintaining two nearly identical screens.
 * ═══════════════════════════════════════════════════════════════════════
 */

function sfy_hub_message_kinds(): array {
    return [
        'suggestion' => ['label' => 'Game suggestion', 'icon' => '🎮',
                         'blurb' => 'A game the hub should add a script for.'],
        'support'    => ['label' => 'Support',         'icon' => '🛠',
                         'blurb' => 'A problem with a script, a key or the site.'],
        'bug'        => ['label' => 'Bug report',      'icon' => '🐞',
                         'blurb' => 'Something on the site is broken.'],
        'other'      => ['label' => 'Other',           'icon' => '✉',
                         'blurb' => 'Anything else.'],
    ];
}

function sfy_hub_message_statuses(): array {
    return ['new' => 'New', 'read' => 'Read', 'replied' => 'Replied', 'closed' => 'Closed'];
}

/**
 * The game a contact message is about.
 *
 * Two fields can carry it, because the picker can never hold every game: the
 * list the hub knows, and a box to type one that is not in it. The typed name
 * wins when both are filled — somebody who typed a name meant that name — and
 * the picker's "another game" sentinel means "look in the box".
 */
function sfy_hub_message_game(array $in): string {
    $typed  = trim((string)($in['game_custom'] ?? ''));
    $picked = (string)($in['game_name'] ?? '');
    if ($picked === '__other') $picked = '';
    return sfy_hub_line($typed !== '' ? $typed : $picked, 191);
}

function sfy_hub_message_kind(string $kind): string {
    return isset(sfy_hub_message_kinds()[$kind]) ? $kind : 'support';
}

/**
 * Store one submitted message.
 * @return array{ok:bool,id:int,error:string}
 */
function sfy_hub_message_create(array $in): array {
    $kind = sfy_hub_message_kind((string)($in['kind'] ?? 'support'));
    $def  = sfy_hub_message_kinds()[$kind];

    $message = sfy_hub_text((string)($in['message'] ?? ''), 8000);
    if (strlen(trim($message)) < 5) {
        return ['ok' => false, 'id' => 0, 'error' => 'Please write a little more — ' . strtolower($def['blurb'])];
    }

    $game = sfy_hub_line((string)($in['game_name'] ?? ''), 191);
    if ($kind === 'suggestion' && $game === '') {
        return ['ok' => false, 'id' => 0, 'error' => 'Which game should we add? Put its name in the game field.'];
    }

    $contact = sfy_hub_line((string)($in['contact'] ?? ''), 191);
    if ($contact === '') {
        return ['ok' => false, 'id' => 0, 'error' => 'Leave an email or Discord tag so we can answer you.'];
    }

    $subject = sfy_hub_line((string)($in['subject'] ?? ''), 191);
    if ($subject === '') {
        $subject = $kind === 'suggestion' && $game !== '' ? 'Add ' . $game : $def['label'];
    }

    try {
        $db = sfy_db();
        $db->prepare("INSERT INTO sfy_hub_messages
            (kind, name, contact, game_name, subject, message, status, ip, user_agent, created_at, updated_at)
            VALUES (?,?,?,?,?,?, 'new', ?, ?, NOW(), NOW())")
           ->execute([
                $kind,
                sfy_hub_line((string)($in['name'] ?? ''), 96),
                $contact,
                $game,
                $subject,
                $message,
                sfy_client_ip(),
                sfy_user_agent(),
           ]);
        return ['ok' => true, 'id' => (int)$db->lastInsertId(), 'error' => ''];
    } catch (Throwable $e) {
        error_log('[SFY HUB] message create: ' . $e->getMessage());
        return ['ok' => false, 'id' => 0,
                'error' => 'Could not save that message. Run the hub installer if this is a fresh install.'];
    }
}

function sfy_hub_message(int $id): ?array {
    return sfy_try(function () use ($id) {
        $st = sfy_db()->prepare("SELECT * FROM sfy_hub_messages WHERE id = ? LIMIT 1");
        $st->execute([$id]);
        return $st->fetch() ?: null;
    }, null);
}

function sfy_hub_messages(array $f = [], int $page = 1, int $perPage = 25): array {
    [$where, $p] = sfy_hub_message_where($f);
    $page = max(1, $page);
    return sfy_try(function () use ($where, $p, $page, $perPage): array {
        $st = sfy_db()->prepare("SELECT * FROM sfy_hub_messages" . $where . " ORDER BY id DESC LIMIT "
              . (int)$perPage . " OFFSET " . (($page - 1) * (int)$perPage));
        $st->execute($p);
        return $st->fetchAll();
    }, []);
}

function sfy_hub_messages_count(array $f = []): int {
    [$where, $p] = sfy_hub_message_where($f);
    return (int)sfy_try(function () use ($where, $p): int {
        $st = sfy_db()->prepare("SELECT COUNT(*) AS n FROM sfy_hub_messages" . $where);
        $st->execute($p);
        return (int)($st->fetch()['n'] ?? 0);
    }, 0);
}

function sfy_hub_message_where(array $f): array {
    $w = []; $p = [];
    $kind = (string)($f['kind'] ?? '');
    if ($kind !== '' && isset(sfy_hub_message_kinds()[$kind])) { $w[] = 'kind = ?'; $p[] = $kind; }
    $status = (string)($f['status'] ?? '');
    if ($status !== '' && isset(sfy_hub_message_statuses()[$status])) { $w[] = 'status = ?'; $p[] = $status; }
    $q = trim((string)($f['q'] ?? ''));
    if ($q !== '') {
        $w[] = '(subject LIKE ? OR message LIKE ? OR game_name LIKE ? OR contact LIKE ? OR name LIKE ?)';
        $like = '%' . $q . '%';
        array_push($p, $like, $like, $like, $like, $like);
    }
    return [$w ? ' WHERE ' . implode(' AND ', $w) : '', $p];
}

function sfy_hub_message_update(int $id, string $status, string $note = ''): bool {
    if (!isset(sfy_hub_message_statuses()[$status])) return false;
    return (bool)sfy_try(function () use ($id, $status, $note): bool {
        sfy_db()->prepare("UPDATE sfy_hub_messages SET status = ?, admin_note = ?, updated_at = NOW()
                           WHERE id = ?")->execute([$status, sfy_hub_text($note, 4000), $id]);
        return true;
    }, false);
}

function sfy_hub_message_delete(int $id): bool {
    return (bool)sfy_try(function () use ($id): bool {
        sfy_db()->prepare("DELETE FROM sfy_hub_messages WHERE id = ?")->execute([$id]);
        return true;
    }, false);
}

/** Per-kind counts for the panel's summary strip. */
function sfy_hub_message_stats(): array {
    return (array)sfy_try(function (): array {
        $out = ['new' => 0, 'total' => 0];
        /* One row per kind *and* status, so a kind's counts have to be added
           up: assigning would leave the panel showing only whichever status
           the database happened to return last. */
        foreach (sfy_db()->query("SELECT kind, status, COUNT(*) AS n FROM sfy_hub_messages
                                  GROUP BY kind, status")->fetchAll() as $r) {
            $n    = (int)($r['n'] ?? 0);
            $kind = (string)($r['kind'] ?? '');
            if ($kind !== '') $out[$kind] = (int)($out[$kind] ?? 0) + $n;
            $out['total'] += $n;
            if ((string)($r['status'] ?? '') === 'new') $out['new'] += $n;
        }
        return $out;
    }, ['new' => 0, 'total' => 0]);
}
