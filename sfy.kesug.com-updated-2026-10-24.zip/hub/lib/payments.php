<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY HUB — PAYMENT METHODS
 *
 *  Before this file the shop kept its methods in one settings box: a handful
 *  of names, one shared paragraph of instructions, nothing a buyer could
 *  actually pay into. This turns each method into a real row with its own
 *  requirements, its own address or checkout link, and — for methods that
 *  have one — its own API credentials and signed callback URL.
 *
 *  Three kinds, and the distinction is the whole design:
 *
 *    wallet    the buyer sends money to an address you own (a crypto wallet,
 *              a GCash/GoPay number, a bank account). The address is printed
 *              on the order page; an admin confirms the payment.
 *    redirect  the buyer pays on the provider's own page — a PayPal.me or
 *              Ko-fi link, a Stripe payment link, a hosted checkout. The link
 *              is built from the order (amount, reference) via placeholders.
 *    gateway   the above *plus* an API key pair and a webhook secret, so the
 *              provider can call back and confirm the order by itself. Until
 *              every credential is present the method behaves as a redirect
 *              one and an admin confirms by hand — which is also what the
 *              panel and the diagnostics screen say out loud, rather than
 *              claiming a checkout that is not wired.
 *
 *  Two rules this file exists to enforce:
 *
 *   • **a secret never reaches a public page.** sfy_hub_payments() is the
 *     public reader and it strips the credential columns by construction;
 *     every public view goes through it. There is a test that greps the
 *     rendered pages for a seeded secret.
 *   • **a callback is only believed when it is signed.** The webhook view
 *     verifies an HMAC of the raw body with that method's webhook secret
 *     before an order is moved to PAID; an unsigned call changes nothing.
 * ═══════════════════════════════════════════════════════════════════════
 */

/* ── what a method can be ───────────────────────────────────────────── */

function sfy_hub_payment_kinds(): array {
    return [
        'wallet'   => ['label' => 'Wallet / transfer',
                       'blurb' => 'The buyer sends the money to an address or number you own. You confirm it in Orders.'],
        'redirect' => ['label' => 'Hosted checkout',
                       'blurb' => 'The buyer pays on the provider’s own page — a payment link, a donate page, a hosted checkout.'],
        'gateway'  => ['label' => 'API gateway',
                       'blurb' => 'A checkout link *and* credentials: with an endpoint, a key pair and a webhook secret, the provider can confirm the order by itself.'],
    ];
}

/** Placeholders a checkout link may use. */
function sfy_hub_payment_placeholders(): array {
    return [
        '{amount}'    => 'The order total, e.g. 4.00',
        '{currency}'  => 'The plan currency, e.g. USD',
        '{reference}' => 'The order reference, e.g. SFY-7K3M9Q',
        '{plan}'      => 'The plan slug, e.g. 7-day',
        '{plan_title}'=> 'The plan title',
        '{method}'    => 'This method’s slug',
        '{name}'      => 'The buyer’s name or username',
        '{contact}'   => 'The buyer’s email / Discord',
    ];
}

/**
 * Ready-made methods, so the panel starts from something real.
 *
 * Every one of these is editable and deletable; they exist because "add your
 * own payment method" from a blank form is where a shop that takes money gets
 * it wrong (a missing reference field, no address, no idea what to confirm).
 * The credentials are deliberately empty — no key is shipped, and a template
 * that claims to be connected is worse than one that does not.
 */
function sfy_hub_payment_templates(): array {
    return [
        'binance' => [
            'name' => 'Binance Pay', 'kind' => 'gateway', 'icon' => '🟡', 'network' => 'Binance Pay ID',
            'summary' => 'Send USDT to our Binance Pay ID — instant, low fee.',
            'requirements' => "Your Binance Pay ID or email|@you or you@mail.com\nTransaction ID (TXID)|the ID Binance gives you|required",
            'instructions' => "Open Binance → Pay → Send.\nSend the exact amount to the Binance Pay ID below.\nPut the order reference in the note if the field accepts one.",
            'confirm_note' => 'Send the TXID in a message after paying so it can be matched.',
            'checkout_url' => '', 'api_provider' => 'binance-pay',
            'api_endpoint' => 'https://bpay.binanceapi.com/binancepay/openapi/v3/order',
            'api_extra'    => "merchant_id =\nmerchant_certificate_serial =\n",
            'currency' => '', 'min_amount' => '1.00', 'fee_note' => 'Network fees are paid by the sender.',
        ],
        'crypto-wallet' => [
            'name' => 'Crypto wallet', 'kind' => 'wallet', 'icon' => '🪙', 'network' => 'USDT · TRC20 / ERC20',
            'summary' => 'Send USDT (or BTC) straight to our wallet.',
            'requirements' => "Transaction hash (TXID)|paste the hash|required\nNetwork used|TRC20 / ERC20 / BTC",
            'instructions' => "Send the exact amount to the address below on the network named above.\nA different network can lose the funds — check before you send.",
            'confirm_note' => 'Paste the transaction hash so the payment can be verified on-chain.',
            'address' => '', 'currency' => '',
        ],
        'gcash' => [
            'name' => 'GCash', 'kind' => 'wallet', 'icon' => '🔵', 'network' => 'GCash · PH',
            'summary' => 'Send via GCash and quote your reference.',
            'requirements' => "GCash number you sent from|09xx xxx xxxx|required\nGCash reference number|e.g. 0123 456 789012|required",
            'instructions' => "Open GCash → Send Money → Express Send.\nSend the exact amount to the number below.\nKeep the reference number — you will need it here.",
            'confirm_note' => 'The GCash reference is what the admin matches your payment with.',
            'address' => '', 'currency' => 'PHP',
        ],
        'maya' => [
            'name' => 'Maya (PayMaya)', 'kind' => 'wallet', 'icon' => '🟢', 'network' => 'Maya · PH',
            'summary' => 'Send via Maya and quote your reference.',
            'requirements' => "Maya number you sent from|09xx xxx xxxx|required\nMaya reference number|from your receipt|required",
            'instructions' => "Open Maya → Send Money.\nSend the exact amount to the number below and keep the receipt reference.",
            'confirm_note' => 'Send the Maya reference number in a message after paying.',
            'address' => '', 'currency' => 'PHP',
        ],
        'paypal' => [
            'name' => 'PayPal', 'kind' => 'gateway', 'icon' => '🔷', 'network' => 'PayPal · worldwide',
            'summary' => 'Pay from your PayPal balance or a card.',
            'requirements' => "PayPal email you paid from|you@mail.com|required\nPayPal transaction ID|from your activity page|required",
            'instructions' => "The button opens PayPal with the amount already filled in.\nPay, then come back and paste the transaction ID.",
            'confirm_note' => 'The PayPal transaction ID is what the admin matches your payment with.',
            'checkout_url' => 'https://www.paypal.com/paypalme/YOURNAME/{amount}',
            'api_provider' => 'paypal', 'api_endpoint' => 'https://api-m.paypal.com/v1/checkout/orders',
            'api_extra' => "client_id =\nmode = live\n",
            'address' => '', 'currency' => '',
        ],
        'card' => [
            'name' => 'Card (Visa · Mastercard)', 'kind' => 'gateway', 'icon' => '💳',
            'network' => 'Visa · Mastercard · Amex',
            'summary' => 'Pay by credit or debit card on a secure hosted page.',
            'requirements' => "Email used at checkout|you@mail.com|required\nPayment reference / receipt ID|from the confirmation email|required",
            'instructions' => "The button opens the provider’s secure checkout, where the amount is already filled in.\nYour card details are entered there and never touch this site.",
            'confirm_note' => 'Keep the receipt id from the confirmation email — that is the proof of payment.',
            'checkout_url' => 'https://buy.stripe.com/REPLACE_WITH_YOUR_LINK',
            'api_provider' => 'stripe', 'api_endpoint' => 'https://api.stripe.com/v1/checkout/sessions',
            'api_extra' => "publishable_key =\nmode = live\n",
            'address' => '', 'currency' => '',
        ],
        'bank' => [
            'name' => 'Bank transfer', 'kind' => 'wallet', 'icon' => '🏦', 'network' => 'Local bank · 1–3 days',
            'summary' => 'Deposit or transfer to our bank account.',
            'requirements' => "Name on the account you paid from|your account name|required\nTransfer reference|from your receipt|required",
            'instructions' => "Transfer the exact amount to the account below.\nUse the order reference as the transfer note if your bank allows it.",
            'confirm_note' => 'Send a photo or screenshot of the receipt so it can be confirmed faster.',
            'address' => '', 'currency' => '',
        ],
        'discord' => [
            'name' => 'Discord / other', 'kind' => 'wallet', 'icon' => '💬', 'network' => 'Arrange in chat',
            'summary' => 'Paying another way? Arrange it with us first.',
            'requirements' => "How you want to pay|e.g. gift card, GCash, other",
            'instructions' => "Message us before sending anything and we will tell you exactly where to send it.",
            'confirm_note' => 'Nothing is owed until an admin confirms the method with you.',
            'address' => '', 'currency' => '',
        ],
    ];
}

/** A filled-in row from a template, for the panel's “start from” buttons. */
function sfy_hub_payment_template(string $key): array {
    $t = sfy_hub_payment_templates()[strtolower(trim($key))] ?? null;
    if ($t === null) return [];

    $base = array_fill_keys(array_keys(sfy_hub_payment_columns()), '');
    $base = array_merge($base, ['slug' => strtolower(trim($key)), 'is_active' => 1, 'needs_review' => 1]);
    foreach ($t as $k => $v) $base[$k] = $v;
    return $base;
}

/* ── requirements: what the buyer has to give us ────────────────────── */

/**
 * “Label | placeholder | required”, one per line.
 *
 * The panel keeps it as text because that is how an owner thinks about it;
 * the public form needs it as rows. Anything malformed degrades to a plain
 * label — a broken requirement line must never cost the buyer the form.
 */
function sfy_hub_payment_requirement_list($raw, int $max = 8): array {
    $out = [];
    $lines = is_array($raw) ? $raw : preg_split('/\r?\n/', (string)$raw);
    foreach ((array)$lines as $line) {
        $parts = array_map('trim', explode('|', (string)$line));
        $label = sfy_hub_line((string)($parts[0] ?? ''), 60);
        if ($label === '') continue;
        $hint = sfy_hub_line((string)($parts[1] ?? ''), 60);
        $req  = strtolower((string)($parts[2] ?? ''));
        // No third column and no wording about it means "required": a field an
        // owner bothered to write down is one they need.
        $needed = $req === '' || !in_array($req, ['no', 'optional', '0', 'off', 'false'], true);

        $key = sfy_hub_payment_field_name($label);
        if (isset($out[$key])) continue;
        $out[$key] = ['key' => $key, 'label' => $label, 'hint' => $hint, 'required' => $needed];
        if (count($out) >= max(1, $max)) break;
    }
    return array_values($out);
}

/** The input name a requirement's answer travels under. */
function sfy_hub_payment_field_name(string $label): string {
    $key = strtolower((string)preg_replace('/[^a-z0-9]+/i', '_', $label));
    return 'pay_' . substr(trim($key, '_'), 0, 28);
}

/** The same list, back as the text the panel edits. */
function sfy_hub_payment_requirement_text($raw, int $max = 8): string {
    $lines = [];
    foreach (sfy_hub_payment_requirement_list($raw, $max) as $r) {
        $lines[] = $r['label'] . ($r['hint'] !== '' ? ' | ' . $r['hint'] : '')
                 . ($r['required'] ? ' | required' : ' | optional');
    }
    return implode("\n", $lines);
}

/* ── credential / readiness checks ──────────────────────────────────── */

/**
 * Is this method able to collect money at all, and what is missing if not?
 *
 * Reported by the panel, the public page (as a plain “an admin confirms this”
 * note rather than an error) and the Diagnostics screen. It never blocks a
 * sale: a wallet method with no address is a method that needs an address,
 * not a page that refuses to render.
 */
function sfy_hub_payment_ready(array $m): array {
    $kind    = (string)($m['kind'] ?? 'wallet');
    $missing = [];

    if ($kind === 'wallet') {
        if (trim((string)($m['address'] ?? '')) === '') $missing[] = 'address';
    } else {
        if (trim((string)($m['checkout_url'] ?? '')) === '') $missing[] = 'checkout_url';
    }
    if ($kind === 'gateway') {
        foreach (['api_endpoint', 'api_key', 'api_secret', 'webhook_secret'] as $k) {
            if (trim((string)($m[$k] ?? '')) === '') $missing[] = $k;
        }
    }

    return ['ok' => $missing === [], 'missing' => $missing, 'kind' => $kind];
}

/** Can a signed callback confirm an order for this method on its own? */
function sfy_hub_payment_auto_confirm(array $m): bool {
    return (string)($m['kind'] ?? '') === 'gateway'
        && sfy_hub_payment_ready($m)['ok']
        && !empty($m['is_active']);
}

/** One-line “where is the money” for the panel's list. */
function sfy_hub_payment_destination(array $m): string {
    $kind = (string)($m['kind'] ?? 'wallet');
    $val  = $kind === 'wallet' ? (string)($m['address'] ?? '') : (string)($m['checkout_url'] ?? '');
    return sfy_hub_line($val, 64);
}

/** Never print a secret back in full. */
function sfy_hub_payment_mask(string $secret): string {
    $secret = trim($secret);
    if ($secret === '') return '';
    return '••••••' . (strlen($secret) > 4 ? substr($secret, -4) : '');
}

/* ── the link and the callback ──────────────────────────────────────── */

/**
 * The checkout link for one order, with the placeholders filled in.
 *
 * `{amount}` and friends are substituted, and anything the owner typed that
 * is not a placeholder is left exactly as typed — a bank's URL with query
 * parameters in it must survive untouched.
 */
function sfy_hub_payment_link(array $m, array $order = []): string {
    $url = trim((string)($m['checkout_url'] ?? ''));
    if ($url === '') return '';

    $map = [
        '{amount}'     => number_format((float)($order['amount'] ?? 0), 2, '.', ''),
        '{currency}'   => (string)($order['currency'] ?? sfy_hub_currency((string)($m['currency'] ?? ''))),
        '{reference}'  => (string)($order['reference'] ?? ''),
        '{plan}'       => (string)($order['offer_slug'] ?? ''),
        '{plan_title}' => (string)($order['offer_title'] ?? ''),
        '{method}'     => (string)($m['slug'] ?? ''),
        '{name}'       => (string)($order['buyer_name'] ?? ''),
        '{contact}'    => (string)($order['buyer_contact'] ?? ''),
    ];
    $url = str_replace(array_keys($map), array_map('rawurlencode', array_values($map)), $url);

    return sfy_hub_url_clean($url, 800);
}

/** Where a provider should POST a payment callback for this method. */
function sfy_hub_payment_webhook_url(array $m): string {
    return sfy_hub_url('webhook', ['method' => (string)($m['slug'] ?? '')]);
}

/** How a provider is asked to sign the body. Printed in the panel. */
function sfy_hub_payment_signature_note(): string {
    return 'HMAC-SHA256 of the raw request body, using this method’s webhook secret, '
         . 'sent as X-SFY-Signature: sha256=<hex>.';
}

function sfy_hub_payment_signature(string $body, string $secret): string {
    return hash_hmac('sha256', $body, $secret);
}

/**
 * Verify a callback.
 *
 * Accepts the header this module documents (`X-SFY-Signature`, with or without
 * the `sha256=` prefix), the GitHub-style header several providers already
 * use, or a `signature` field in the body. Comparison is constant-time, and an
 * empty secret verifies nothing at all.
 */
function sfy_hub_payment_verify(string $body, array $m, array $headers = [], array $form = []): array {
    $secret = trim((string)($m['webhook_secret'] ?? ''));
    if ($secret === '') return ['ok' => false, 'why' => 'This method has no webhook secret, so no callback can be verified.'];

    $sent = '';
    $keys = ['HTTP_X_SFY_SIGNATURE', 'HTTP_X_HUB_SIGNATURE_256', 'HTTP_X_SIGNATURE'];
    foreach ($keys as $k) {
        if (trim((string)($headers[$k] ?? '')) !== '') { $sent = trim((string)$headers[$k]); break; }
    }
    if ($sent === '') {
        foreach (['signature', 'sig', 'sign', 'hmac'] as $k) {
            if (trim((string)($form[$k] ?? '')) !== '') { $sent = trim((string)$form[$k]); break; }
        }
    }
    if ($sent === '') return ['ok' => false, 'why' => 'No signature was sent.'];

    $sent = (string)preg_replace('/^sha256=/i', '', $sent);
    $sent = strtolower(trim($sent));
    $want = sfy_hub_payment_signature($body, $secret);

    if (!preg_match('/^[0-9a-f]{64}$/', $sent) || !hash_equals($want, $sent)) {
        return ['ok' => false, 'why' => 'The signature does not match the body. Check the webhook secret.'];
    }
    return ['ok' => true, 'why' => ''];
}

/**
 * The raw body a callback arrived with.
 *
 * The signature is computed over *this*, so it has to be the bytes the
 * provider sent rather than a re-encoded form. In a real POST that is
 * php://input; a CLI caller (the test probe) has no input stream, so an empty
 * one falls back to the parsed form, which is byte-identical to what PHP
 * received for `application/x-www-form-urlencoded`.
 */
function sfy_hub_payment_body(): string {
    $raw = '';
    if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) === 'POST') {
        $raw = (string)@file_get_contents('php://input');
    }
    if (trim($raw) === '' && $_POST) $raw = http_build_query($_POST);
    return $raw;
}

/** A callback's fields, whether it sent JSON or a form. */
function sfy_hub_payment_payload(string $raw): array {
    $json = json_decode($raw, true);
    if (is_array($json)) return $json;
    return $_POST;
}

/** The reference / transaction id / amount a callback is talking about. */
function sfy_hub_payment_payload_read(array $payload, string $body): array {
    $flat = [];
    foreach ($payload as $k => $v) {
        if (is_scalar($v)) $flat[strtolower((string)$k)] = (string)$v;
        if (is_array($v)) {
            foreach ($v as $k2 => $v2) {
                if (is_scalar($v2)) $flat[strtolower((string)$k) . '.' . strtolower((string)$k2)] = (string)$v2;
            }
        }
    }
    $pick = function (array $names) use ($flat, $body): string {
        foreach ($names as $n) {
            foreach ([$n, 'data.' . $n, 'resource.' . $n, 'metadata.' . $n] as $key) {
                if (isset($flat[$key]) && trim((string)$flat[$key]) !== '') return trim((string)$flat[$key]);
            }
            // Providers that hide it in the query string instead of the body.
            if ($body !== '' && preg_match('/(?:^|&)' . preg_quote($n, '/') . '=([^&]+)/i', $body, $m)) {
                return trim(rawurldecode($m[1]));
            }
        }
        return '';
    };

    return [
        'reference' => $pick(['reference', 'order_reference', 'merchant_reference', 'custom_id', 'order_id',
                              'merchanttradeno', 'client_reference_id', 'external_reference']),
        'txid'      => $pick(['txid', 'transaction_id', 'payment_id', 'trade_no', 'txn_id', 'charge_id',
                              'session_id', 'id']),
        'amount'    => $pick(['amount', 'total', 'value', 'price', 'gross', 'amount_paid']),
        'status'    => $pick(['status', 'event', 'state', 'result']),
    ];
}

/* ── storage ────────────────────────────────────────────────────────── */

/** The editable columns, in the order the panel shows them. */
function sfy_hub_payment_columns(): array {
    return array_fill_keys([
        'slug', 'name', 'kind', 'icon', 'network', 'currency', 'summary', 'requirements',
        'address', 'instructions', 'confirm_note', 'checkout_url',
        'api_provider', 'api_endpoint', 'api_key', 'api_secret', 'api_extra', 'webhook_secret',
        'min_amount', 'fee_note', 'needs_review', 'is_active', 'is_featured', 'sort_order',
    ], '');
}

function sfy_hub_payment_normalize(array $in, int $id = 0): array {
    $name = sfy_hub_line((string)($in['name'] ?? ''), 96);
    if ($name === '') return [[], 'Give the method a name — that is what the buyer sees.'];

    $kinds = sfy_hub_payment_kinds();
    $kind  = strtolower(trim((string)($in['kind'] ?? 'wallet')));
    if (!isset($kinds[$kind])) $kind = 'wallet';

    $slugSrc = trim((string)($in['slug'] ?? '')) !== '' ? (string)$in['slug'] : $name;
    $min     = trim((string)($in['min_amount'] ?? ''));

    $row = [
        'slug'           => sfy_hub_slug($slugSrc, 'sfy_hub_payment_methods', $id),
        'name'           => $name,
        'kind'           => $kind,
        'icon'           => sfy_hub_cut(sfy_hub_line((string)($in['icon'] ?? ''), 12), 8),
        'network'        => sfy_hub_line((string)($in['network'] ?? ''), 96),
        'currency'       => trim((string)($in['currency'] ?? '')) === ''
                            ? '' : sfy_hub_currency((string)$in['currency']),
        'summary'        => sfy_hub_line((string)($in['summary'] ?? ''), 255),
        'requirements'   => sfy_hub_payment_requirement_text($in['requirements'] ?? ''),
        /* An address is typed by hand — a wallet hash, a phone number, an
           IBAN — so it is kept as plain text (collapsed to one line). */
        'address'        => sfy_hub_line((string)($in['address'] ?? ''), 255),
        'instructions'   => sfy_hub_text((string)($in['instructions'] ?? ''), 1500),
        'confirm_note'   => sfy_hub_text((string)($in['confirm_note'] ?? ''), 600),
        'checkout_url'   => sfy_hub_url_clean((string)($in['checkout_url'] ?? ''), 800),
        'api_provider'   => sfy_hub_line((string)($in['api_provider'] ?? ''), 64),
        'api_endpoint'   => sfy_hub_url_clean((string)($in['api_endpoint'] ?? ''), 500),
        'api_key'        => sfy_hub_line((string)($in['api_key'] ?? ''), 191),
        'api_secret'     => sfy_hub_line((string)($in['api_secret'] ?? ''), 255),
        'api_extra'      => implode("\n", array_slice(
                                array_values(array_filter(array_map('trim',
                                    preg_split('/\r?\n/', (string)($in['api_extra'] ?? ''))), fn($l) => $l !== '')),
                                0, 12)),
        'webhook_secret' => sfy_hub_line((string)($in['webhook_secret'] ?? ''), 255),
        'min_amount'     => number_format(max(0, (float)str_replace(',', '.', $min !== '' ? $min : '0')), 2, '.', ''),
        'fee_note'       => sfy_hub_line((string)($in['fee_note'] ?? ''), 191),
        'needs_review'   => !empty($in['needs_review']) ? 1 : 0,
        'is_active'      => !empty($in['is_active']) ? 1 : 0,
        'is_featured'    => !empty($in['is_featured']) ? 1 : 0,
        'sort_order'     => max(-9999, min(9999, (int)($in['sort_order'] ?? 0))),
    ];

    /* A wallet with no address is not refused: the owner may be about to paste
       one, and the row is still the right shape. Leaving it out of the public
       list is sfy_hub_payment_usable()'s job, not the saver's — which is why a
       half-filled method saves and still reaches nobody. */
    return [$row, ''];
}

/** @return array{ok:bool,id:int,error:string} */
function sfy_hub_payment_save(array $in, int $id = 0): array {
    [$row, $err] = sfy_hub_payment_normalize($in, $id);
    if ($err !== '') return ['ok' => false, 'id' => 0, 'error' => $err];

    try {
        $db = sfy_db();
        if ($id > 0) {
            if (!sfy_hub_payment($id)) return ['ok' => false, 'id' => 0, 'error' => 'That method no longer exists.'];
            $sets = implode(', ', array_map(fn($k) => "`$k` = ?", array_keys($row)));
            $vals = array_values($row);
            $vals[] = $id;
            $db->prepare("UPDATE `sfy_hub_payment_methods` SET $sets, updated_at = NOW() WHERE id = ?")->execute($vals);
            return ['ok' => true, 'id' => $id, 'error' => ''];
        }
        $cols = array_keys($row);
        $ph   = implode(', ', array_fill(0, count($cols), '?'));
        $db->prepare("INSERT INTO `sfy_hub_payment_methods` (`" . implode('`, `', $cols) . "`, created_at, updated_at)
                      VALUES ($ph, NOW(), NOW())")->execute(array_values($row));
        return ['ok' => true, 'id' => (int)$db->lastInsertId(), 'error' => ''];
    } catch (Throwable $e) {
        error_log('[SFY HUB] payment save: ' . $e->getMessage());
        return ['ok' => false, 'id' => 0,
                'error' => 'Could not save that payment method. Run the hub installer if this is a fresh install.'];
    }
}

function sfy_hub_payment_delete(int $id): bool {
    return (bool)sfy_try(function () use ($id): bool {
        sfy_db()->prepare("DELETE FROM `sfy_hub_payment_methods` WHERE id = ?")->execute([$id]);
        return true;
    }, false);
}

function sfy_hub_payment_flag(int $id, string $column): bool {
    if (!in_array($column, ['is_active', 'is_featured', 'needs_review'], true)) return false;
    return (bool)sfy_try(function () use ($id, $column): bool {
        sfy_db()->prepare("UPDATE `sfy_hub_payment_methods` SET `$column` = 1 - `$column`, updated_at = NOW()
                           WHERE id = ?")->execute([$id]);
        return true;
    }, false);
}

/** Every method, ordered the way the owner arranged them. */
function sfy_hub_payments(bool $activeOnly = true): array {
    if (!sfy_try(fn(): bool => sfy_table_exists('sfy_hub_payment_methods'), false)) {
        return sfy_hub_payment_fallback();
    }
    return (array)sfy_try(function () use ($activeOnly): array {
        $sql = "SELECT * FROM sfy_hub_payment_methods"
             . ($activeOnly ? " WHERE is_active = 1" : "")
             . " ORDER BY is_featured DESC, sort_order ASC, id ASC";
        return sfy_db()->query($sql)->fetchAll();
    }, []);
}

function sfy_hub_payment(int $id): ?array {
    if ($id <= 0) return null;
    return sfy_try(function () use ($id) {
        $st = sfy_db()->prepare("SELECT * FROM sfy_hub_payment_methods WHERE id = ? LIMIT 1");
        $st->execute([$id]);
        return $st->fetch() ?: null;
    }, null);
}

function sfy_hub_payment_by_slug(string $slug): ?array {
    $slug = strtolower(trim($slug));
    if ($slug === '') return null;
    if (!sfy_try(fn(): bool => sfy_table_exists('sfy_hub_payment_methods'), false)) {
        foreach (sfy_hub_payment_fallback() as $m) if ($m['slug'] === $slug) return $m;
        return null;
    }
    return sfy_try(function () use ($slug) {
        $st = sfy_db()->prepare("SELECT * FROM sfy_hub_payment_methods WHERE slug = ? LIMIT 1");
        $st->execute([$slug]);
        return $st->fetch() ?: null;
    }, null);
}

/**
 * The public shape of a method: no credentials, ever.
 *
 * This is the only reader the visitor-facing views use, and it *builds* the
 * array rather than unsetting keys, so a column added to the table later
 * cannot leak by default — it simply is not in the list.
 */
function sfy_hub_payment_public(array $m): array {
    return [
        'id'           => (int)($m['id'] ?? 0),
        'slug'         => (string)($m['slug'] ?? ''),
        'name'         => (string)($m['name'] ?? ''),
        'kind'         => (string)($m['kind'] ?? 'wallet'),
        'icon'         => (string)($m['icon'] ?? ''),
        'network'      => (string)($m['network'] ?? ''),
        'currency'     => (string)($m['currency'] ?? ''),
        'summary'      => (string)($m['summary'] ?? ''),
        'requirements' => (string)($m['requirements'] ?? ''),
        'requirements_list' => sfy_hub_payment_requirement_list($m['requirements'] ?? ''),
        'address'      => (string)($m['address'] ?? ''),
        'instructions' => (string)($m['instructions'] ?? ''),
        'confirm_note' => (string)($m['confirm_note'] ?? ''),
        'checkout_url' => (string)($m['checkout_url'] ?? ''),
        'fee_note'     => (string)($m['fee_note'] ?? ''),
        'min_amount'   => (string)($m['min_amount'] ?? '0.00'),
        'is_featured'  => (int)($m['is_featured'] ?? 0),
        'auto'         => sfy_hub_payment_auto_confirm($m),
    ];
}

/** The public list, in the order the shop should show them. */
function sfy_hub_payments_public(bool $activeOnly = true): array {
    return array_map('sfy_hub_payment_public', sfy_hub_payments($activeOnly));
}

/**
 * Can a buyer actually pay with this one?
 *
 * A wallet with no address and a checkout with no link are half-finished rows
 * — the panel flags them, and the shop must not offer them as a choice. The
 * exception is the legacy settings list (id 0): it has no address by design,
 * because it never had one, and hiding it would empty the buy page of an
 * install that has not migrated yet.
 */
function sfy_hub_payment_usable(array $m): bool {
    if ((int)($m['id'] ?? 0) === 0) return true;
    return sfy_hub_payment_ready($m)['ok']
        || trim((string)($m['instructions'] ?? '')) !== '';
}

/**
 * The methods the shop should offer: active, usable, in the owner's order,
 * stripped of every credential. The single entry point for both the offers
 * page and the buy form, so the two can never disagree about the list.
 */
function sfy_hub_payment_offered(): array {
    $out = [];
    foreach (sfy_hub_payments(true) as $m) {
        if (!sfy_hub_payment_usable($m)) continue;
        $out[] = sfy_hub_payment_public($m);
    }
    return $out;
}

/**
 * The old settings list, kept working.
 *
 * Before this table existed, the methods were four names in Hub → Settings.
 * An install that has not run the migration yet — or whose table was dropped —
 * still has to render a buy page that names *something* a buyer can pay with,
 * so the lines are lifted into the same shape as a row.
 */
function sfy_hub_payment_fallback(): array {
    $out = [];
    foreach (sfy_hub_lines('pay_methods') as $i => $line) {
        $slug = strtolower(trim((string)preg_replace('/[^a-z0-9]+/i', '-', $line), '-'));
        if ($slug === '') continue;
        $out[] = [
            'id' => 0, 'slug' => $slug, 'name' => $line, 'kind' => 'wallet', 'icon' => '', 'network' => '',
            'currency' => '', 'summary' => '', 'requirements' => '', 'address' => '',
            'instructions' => (string)sfy_hub_setting('pay_instructions', ''), 'confirm_note' => '',
            'checkout_url' => '', 'api_provider' => '', 'api_endpoint' => '', 'api_key' => '',
            'api_secret' => '', 'api_extra' => '', 'webhook_secret' => '', 'min_amount' => '0.00',
            'fee_note' => '', 'needs_review' => 1, 'is_active' => 1, 'is_featured' => 0, 'sort_order' => $i,
        ];
    }
    return $out;
}

/**
 * Turn the shipped templates (and, on an upgrade, the old settings list) into
 * real rows. Only ever runs against an empty table.
 */
function sfy_hub_payment_seed(): void {
    try {
        if (!sfy_table_exists('sfy_hub_payment_methods')) return;
        $db = sfy_db();
        $n  = (int)$db->query("SELECT COUNT(*) AS n FROM sfy_hub_payment_methods")->fetch()['n'];
        if ($n > 0) return;

        $rows = [];
        foreach (sfy_hub_payment_templates() as $key => $t) {
            $rows[] = $t + ['slug' => $key];
        }

        /* An install that was already selling keys named its methods in the
           settings box. Those names come first, and each one is mapped onto
           the matching template so its address fields and webhooks are ready —
           anything unrecognised becomes a plain wallet method instead of
           being thrown away. */
        $ordered = [];
        foreach (sfy_hub_lines('pay_methods') as $line) {
            $slug = strtolower(trim((string)preg_replace('/[^a-z0-9]+/i', '-', $line), '-'));
            foreach ($rows as $i => $r) {
                if ($slug !== '' && (str_contains($slug, (string)$r['slug']) || str_contains((string)$r['slug'], $slug))) {
                    $ordered[] = $r; unset($rows[$i]); continue 2;
                }
            }
            $ordered[] = ['slug' => $slug !== '' ? substr($slug, 0, 90) : 'method-' . (count($ordered) + 1),
                          'name' => sfy_hub_line($line, 96), 'kind' => 'wallet', 'icon' => '', 'network' => '',
                          'summary' => '', 'requirements' => "Reference number from your receipt||required",
                          'address' => '', 'instructions' => (string)sfy_hub_setting('pay_instructions', ''),
                          'confirm_note' => '', 'checkout_url' => '', 'api_provider' => '', 'api_endpoint' => '',
                          'api_key' => '', 'api_secret' => '', 'api_extra' => '', 'webhook_secret' => '',
                          'min_amount' => '0.00', 'fee_note' => '', 'needs_review' => 1, 'is_active' => 1,
                          'is_featured' => 0];
        }

        $seed = array_merge($ordered, array_values($rows));
        $i    = 0;
        foreach ($seed as $r) {
            $r['sort_order']  = $i++;
            $r['is_featured'] = $i === 1 ? 1 : 0;
            $res = sfy_hub_payment_save($r);
            if (!$res['ok']) error_log('[SFY HUB] payment seed: ' . $res['error']);
        }
    } catch (Throwable $e) {
        error_log('[SFY HUB] payment seed: ' . $e->getMessage());
    }
}

/* ── orders: the payment half of a placed order ─────────────────────── */

/**
 * Read the buyer's answers to a method's requirements out of a POST.
 * @return array{fields:array<string,array{label:string,value:string}>,missing:string[]}
 */
function sfy_hub_payment_collect(array $m, array $post): array {
    $fields  = [];
    $missing = [];
    foreach (sfy_hub_payment_requirement_list($m['requirements'] ?? '') as $r) {
        $value = sfy_hub_line((string)($post[$r['key']] ?? ''), 191);
        if ($value === '') {
            if (!empty($r['required'])) $missing[] = $r['label'];
            continue;
        }
        $fields[$r['key']] = ['label' => $r['label'], 'value' => $value];
    }
    return ['fields' => $fields, 'missing' => $missing];
}

/** The stored answers, decoded for the Orders screen. */
function sfy_hub_payment_fields(array $order): array {
    $raw = (string)($order['payment_fields'] ?? '');
    if (trim($raw) === '') return [];
    $data = json_decode($raw, true);
    if (!is_array($data)) return [];
    $out = [];
    foreach ($data as $row) {
        if (!is_array($row)) continue;
        $label = trim((string)($row['label'] ?? ''));
        $value = trim((string)($row['value'] ?? ''));
        if ($label === '' || $value === '') continue;
        $out[] = ['label' => $label, 'value' => $value];
    }
    return $out;
}

/**
 * Believe a provider's callback: mark the order paid, keep the transaction id.
 *
 * Refuses (and says why) when the reference is unknown, when the callback
 * names a different method than the order used, or when the amount does not
 * match the plan. A cancelled order is not resurrected, and a callback that
 * arrives twice simply says “already paid”.
 *
 * @return array{ok:bool,status:string,error:string,order:?array}
 */
function sfy_hub_payment_confirm(array $m, array $payload, string $body = ''): array {
    $read = sfy_hub_payment_payload_read($payload, $body);
    if ($read['reference'] === '') {
        return ['ok' => false, 'status' => 'ignored', 'order' => null,
                'error' => 'The callback names no order reference.'];
    }

    $order = sfy_hub_order_by_reference($read['reference']);
    if (!$order) {
        return ['ok' => false, 'status' => 'unknown', 'order' => null,
                'error' => 'No order matches reference ' . $read['reference'] . '.'];
    }

    $slug = (string)($order['payment_slug'] ?? '');
    if ($slug !== '' && $slug !== (string)($m['slug'] ?? '')) {
        return ['ok' => false, 'status' => 'mismatch', 'order' => $order,
                'error' => 'That order was placed with ' . $slug . ', not ' . (string)($m['slug'] ?? '') . '.'];
    }
    if ((string)($order['status'] ?? '') === 'cancelled') {
        return ['ok' => false, 'status' => 'cancelled', 'order' => $order,
                'error' => 'That order was cancelled.'];
    }

    if ($read['amount'] !== '') {
        $paid = (float)preg_replace('/[^0-9.]/', '', $read['amount']);
        $want = (float)($order['amount'] ?? 0);
        if ($paid > 0 && $want > 0 && abs($paid - $want) > 0.02) {
            return ['ok' => false, 'status' => 'amount', 'order' => $order,
                    'error' => 'The callback paid ' . number_format($paid, 2) . ' but the order is '
                             . number_format($want, 2) . '.'];
        }
    }

    if ((string)($order['status'] ?? '') === 'paid' || (string)($order['status'] ?? '') === 'delivered') {
        return ['ok' => true, 'status' => 'already', 'order' => $order, 'error' => ''];
    }

    $ok = (bool)sfy_try(function () use ($order, $read): bool {
        sfy_db()->prepare("UPDATE sfy_hub_orders
                              SET status = 'paid', payment_reference = ?, paid_at = NOW(), updated_at = NOW()
                            WHERE id = ? AND status NOT IN ('delivered','cancelled')")
           ->execute([sfy_hub_line($read['txid'], 191), (int)$order['id']]);
        return true;
    }, false);

    if (!$ok) return ['ok' => false, 'status' => 'error', 'order' => $order,
                      'error' => 'Could not update the order.'];
    return ['ok' => true, 'status' => 'paid', 'order' => sfy_hub_order_by_reference((string)$order['reference']), 'error' => ''];
}

/**
 * Ask a method's endpoint whether it exists.
 *
 * Deliberately a bare GET: the point is to find out whether the *host
 * answers* — a typo in the host name, a link that 404s, a provider that has
 * gone away — not to authenticate. A gateway endpoint refusing an anonymous
 * call with 401 or 405 is the correct answer and is reported as such, so the
 * button never tells an owner their working integration is broken.
 *
 * @return array{ok:bool,url:string,http:int,ms:int,error:string,note:string}
 */
function sfy_hub_payment_probe(array $m): array {
    $url = trim((string)($m['api_endpoint'] ?? ''));
    if ($url === '') $url = trim((string)($m['checkout_url'] ?? ''));
    if ($url === '') {
        return ['ok' => false, 'url' => '', 'http' => 0, 'ms' => 0, 'note' => '',
                'error' => 'This method has no endpoint or checkout link to test yet.'];
    }

    $res  = sfy_hub_http_get($url, 8, 4096);
    $http = (int)($res['http'] ?? 0);
    $ok   = (bool)($res['ok'] ?? false) || $http > 0;

    $note = '';
    if ($ok && !$res['ok']) {
        $note = 'The host answered HTTP ' . $http . '. A gateway refuses an anonymous GET — that is a valid answer, '
              . 'so save the keys and let a real callback prove it.';
    } elseif ($ok) {
        $note = 'The host answered HTTP ' . $http . ' in ' . (int)$res['ms'] . ' ms.';
    }

    return ['ok' => $ok, 'url' => (string)($res['url'] ?? $url), 'http' => $http,
            'ms' => (int)($res['ms'] ?? 0), 'note' => $note, 'error' => $ok ? '' : (string)($res['error'] ?? 'No answer.')];
}

/** A short, human line about what the buyer still has to do. */
function sfy_hub_payment_next_step(array $m, bool $auto): string {
    if ($auto) return 'This method confirms your payment automatically — the order turns PAID by itself.';
    return 'An administrator confirms the payment and hands over your key.';
}
