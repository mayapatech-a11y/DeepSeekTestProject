<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY HUB — SETTINGS
 *  Every knob of the hub module lives in the existing `sfy_config` table
 *  under a `set_hub_*` key. No new config table, no edits to the install's
 *  own settings screen: the hub is configured from its own panel.
 *
 *  The point of collecting them here (instead of reading keys at the call
 *  sites) is sfy_hub_settings(): one cached, normalised array that the
 *  templates read, so a hand-edited row or a typo can never produce a
 *  broken layout — only a value outside its range, which is clamped.
 * ═══════════════════════════════════════════════════════════════════════
 */

/**
 * Shipped defaults.
 *
 * Sizes are deliberately px numbers rather than CSS strings: the panel shows
 * them as sliders/number fields, and sfy_hub_css_vars() is the single place
 * that turns them into CSS. The theme's own palette, radius and fonts are
 * *inherited* — `radius` of 0 means "whatever Appearance says", so the hub
 * follows the selected theme preference unless the owner overrides it.
 */
function sfy_hub_defaults(): array {
    return [
        // ── identity / copy ────────────────────────────────────────────
        'title'        => 'SFY Scripts',
        'tagline'      => 'Supported games and scripts — verified by SFY.',
        'home_heading' => 'Latest Scripts',
        'home_sub'     => 'Discover the most recently added scripts on our platform',
        'logo_h'       => 38,      // px — the logo bar height
        'logo_text'    => 1,       // 1 = print the wordmark next to the logo
        'logo_url'     => '',      // '' = the install's own /sfyLogo.png

        // ── layout ─────────────────────────────────────────────────────
        'shell'        => 1240,    // hub content max width (px)
        'cols'         => 4,       // cards per row on a wide screen
        'gap'          => 16,      // px between cards
        'card_pad'     => 14,      // px padding inside a script card
        'thumb_h'      => 150,     // px height of a card thumbnail
        'font_scale'   => 100,     // 85–130 % of the hub's base type size
        'title_size'   => 15,      // px — card title
        'desc_lines'   => 2,       // description lines kept in a card
        'radius'       => 0,       // 0 = inherit the theme's radius
        'sidebar'      => 1,       // show the right rail (featured + top list)
        'chips'        => 1,       // show the game/category chips
        'search'       => 1,       // show the search box in the navbar
        'filters'      => 1,       // show the "free only / keyless" toggles
        'per_page'     => 12,      // scripts per page

        // ── tabs the owner can switch off entirely ─────────────────────
        'nav_scripts'  => 1,
        'nav_offers'   => 1,
        'nav_contact'  => 1,
        'nav_suggest'  => 1,
        /* The two buttons that belong to the *site* rather than to the hub,
           sitting beside GET PREMIUM: the token flow that produces a code,
           and the way back to the page the hub now stands in front of.
           Both targets are overridable, because on an install where the hub
           was uploaded without the /home route the link has to point
           somewhere else — blank means the shipped target. */
        'nav_code'     => 1,
        'nav_home'     => 1,

        // ── forms ──────────────────────────────────────────────────────
        'contact_enabled'  => 1,
        'suggest_enabled'  => 1,
        'orders_enabled'   => 1,
        'captcha_forms'    => 0,   // 1 = Turnstile in front of hub forms
        'support_discord'  => '',  // '' = fall back to the install's own link
        'support_email'    => '',
        'support_note'     => 'Tell us what is broken, which game and which executor you use. A screenshot link helps.',

        // ── shop ───────────────────────────────────────────────────────
        'currency'        => 'USD',
        'shop_intro'      => 'Pick a plan. No tasks, no waiting — your key is delivered by hand.',
        'pay_methods'     => "GCash\nPayPal\nCrypto (USDT)\nDiscord",
        'pay_instructions'=> "Send the exact amount and keep the reference code. An admin will confirm and hand over your key.",
        'buy_note'        => 'Your order is a request — nothing is charged on this site.',

        // ── misc ───────────────────────────────────────────────────────
        'home_notice'  => '',      // optional strip above the grid
        'featured_id'  => 0,       // script shown in the sidebar's featured card
        'code_url'     => '',      // '' = the site's guide page (/tutorial)
        'home_url'     => '',      // '' = /home, the landing page behind the hub
    ];
}

/** Slider/number bounds, shared by the normaliser and the panel's inputs. */
function sfy_hub_limits(): array {
    return [
        'logo_h'     => [16, 90],
        'shell'      => [900, 1800],
        'cols'       => [2, 6],
        'gap'        => [0, 40],
        'card_pad'   => [6, 30],
        'thumb_h'    => [90, 320],
        'font_scale' => [85, 130],
        'title_size' => [12, 24],
        'desc_lines' => [0, 4],
        'radius'     => [0, 28],
        'per_page'   => [4, 48],
    ];
}

/**
 * Keys stored as 1/0 switches, grouped by the screen that owns them.
 *
 * The grouping matters because of how a browser submits a checkbox: an
 * unticked box simply is not sent. A form therefore has to say "these are the
 * switches I am responsible for — anything not sent is OFF", and it may only
 * ever say that about *its own* switches. Saving the look must not silently
 * switch off the contact form.
 */
function sfy_hub_flag_groups(): array {
    return [
        'appearance' => ['logo_text', 'sidebar', 'chips', 'search', 'filters'],
        'settings'   => ['nav_scripts', 'nav_offers', 'nav_contact', 'nav_suggest',
                         'nav_code', 'nav_home',
                         'contact_enabled', 'suggest_enabled', 'orders_enabled', 'captcha_forms'],
    ];
}

/** Every switch in the module. */
function sfy_hub_flags(): array {
    return array_merge(...array_values(sfy_hub_flag_groups()));
}

/** Keys stored as whole numbers (and clamped by sfy_hub_limits()). */
function sfy_hub_ints(): array { return array_keys(sfy_hub_limits()); }

/**
 * The live settings: defaults, then whatever the database overrides.
 * Memoised per request; pass true to re-read after a save.
 */
function sfy_hub_settings(bool $refresh = false): array {
    static $cache = null;
    if ($cache !== null && !$refresh) return $cache;

    $out = sfy_hub_defaults();
    foreach (array_keys($out) as $k) {
        $v = sfy_config_get('set_hub_' . $k, null);
        if ($v === null) continue;                  // never saved → default
        // A deliberately blank text field is a real value (an empty tagline is
        // a choice), so only the switch/number keys treat '' as "unset".
        if ($v === '' && !is_string($out[$k])) continue;
        $out[$k] = $v;
    }
    return $cache = sfy_hub_normalize($out);
}

/** Clamp + coerce one settings array. Every path in and out goes through it. */
function sfy_hub_normalize(array $in): array {
    $out    = array_merge(sfy_hub_defaults(), $in);
    $limits = sfy_hub_limits();

    foreach (sfy_hub_flags() as $k) {
        $out[$k] = !empty($out[$k]) && (string)$out[$k] !== '0' ? 1 : 0;
    }
    foreach (sfy_hub_ints() as $k) {
        [$lo, $hi] = $limits[$k];
        $out[$k] = max($lo, min($hi, (int)$out[$k]));
    }

    $out['title']         = sfy_hub_line((string)$out['title'], 60);
    $out['tagline']       = sfy_hub_line((string)$out['tagline'], 160);
    $out['home_heading']  = sfy_hub_line((string)$out['home_heading'], 80);
    $out['home_sub']      = sfy_hub_line((string)$out['home_sub'], 200);
    $out['home_notice']   = sfy_hub_line((string)$out['home_notice'], 300);
    $out['support_note']  = sfy_hub_text((string)$out['support_note'], 600);
    $out['shop_intro']    = sfy_hub_text((string)$out['shop_intro'], 400);
    $out['pay_methods']   = sfy_hub_text((string)$out['pay_methods'], 400);
    $out['pay_instructions'] = sfy_hub_text((string)$out['pay_instructions'], 800);
    $out['buy_note']      = sfy_hub_text((string)$out['buy_note'], 300);
    $out['currency']      = strtoupper(preg_replace('/[^A-Za-z]/', '', (string)$out['currency']) ?: 'USD');
    $out['currency']      = substr($out['currency'] !== '' ? $out['currency'] : 'USD', 0, 8);
    $out['logo_url']      = sfy_hub_url_clean((string)$out['logo_url'], 300);
    $out['support_discord'] = sfy_hub_url_clean((string)$out['support_discord'], 300);
    $out['support_email'] = sfy_hub_line((string)$out['support_email'], 120);
    $out['featured_id']   = max(0, (int)$out['featured_id']);
    return $out;
}

/** One line of plain text, collapsed and cut (never trusts the caller). */
function sfy_hub_line(string $s, int $max): string {
    // The unicode-aware collapse runs only on real UTF-8: a failed /u replace
    // returns null, and silently emptying the field is worse than a wide space.
    $s = preg_match('//u', $s) === 1
        ? (string)preg_replace('/\s+/u', ' ', $s)
        : (string)preg_replace('/\s+/', ' ', $s);
    return sfy_hub_cut(trim($s), $max);
}

/** Multi-line text: newlines kept, length capped. */
function sfy_hub_text(string $s, int $max): string {
    $s = str_replace(["\r\n", "\r"], "\n", trim($s));
    return sfy_hub_cut($s, $max);
}

/** Only http(s) or site-relative URLs survive. */
function sfy_hub_url_clean(string $u, int $max = 300): string {
    $u = trim($u);
    if ($u === '') return '';
    if (!preg_match('~^https?://~i', $u) && !str_starts_with($u, '/')) return '';
    return sfy_hub_cut($u, $max);
}

/**
 * UTF-8-safe truncation.
 *
 * mbstring is not guaranteed on this host and the project never leans on it,
 * so the cut goes through a UTF-8 pattern exactly like sfy_pinned_clean().
 */
function sfy_hub_cut(string $s, int $max): string {
    if ($max <= 0) return $s;
    if (preg_match('//u', $s) === 1) {
        return (string)preg_replace('/^(.{0,' . $max . '}).*$/us', '$1', $s);
    }
    return substr($s, 0, $max);
}

/**
 * Persist a submitted settings array. Only known keys are written, so a
 * crafted POST cannot invent a setting the templates then read.
 */
function sfy_hub_save_settings(array $in): array {
    $current = sfy_hub_settings(true);
    $merged  = $current;

    foreach (array_keys(sfy_hub_defaults()) as $k) {
        if (!array_key_exists($k, $in)) continue;
        $merged[$k] = $in[$k];
    }
    // Unchecked checkboxes never arrive, so a form that says `__flags` owns a
    // whole group: anything in it that was not sent is OFF. Only the group the
    // form names is touched — see sfy_hub_flag_groups().
    if (!empty($in['__flags'])) {
        $scope = (string)($in['__scope'] ?? '');
        foreach ((array)(sfy_hub_flag_groups()[$scope] ?? []) as $k) {
            if ($k === 'captcha_forms') continue;    // written through the install's own key below
            $merged[$k] = isset($in[$k]) && (string)$in[$k] !== '0' ? 1 : 0;
        }
    }
    unset($merged['__flags'], $merged['__scope']);

    $clean = sfy_hub_normalize($merged);
    foreach ($clean as $k => $v) {
        sfy_config_set('set_hub_' . $k, (string)$v);
    }
    if (array_key_exists('captcha_forms', $in)) {
        // The hub reuses the install's own Turnstile gate, so the switch it
        // writes is the one that gate already reads for an arbitrary context.
        sfy_config_set('set_turnstile_at_hub', !empty($in['captcha_forms']) ? '1' : '0');
    }
    sfy_config_all(true);
    return sfy_hub_settings(true);
}

/** One setting, for the places a full array is overkill. */
function sfy_hub_setting(string $key, $default = null) {
    $s = sfy_hub_settings();
    return array_key_exists($key, $s) ? $s[$key] : $default;
}

/** Multi-line setting → clean array of lines. */
function sfy_hub_lines(string $key): array {
    $raw = (string)sfy_hub_setting($key, '');
    if (trim($raw) === '') return [];
    return array_values(array_filter(array_map('trim', preg_split('/\r?\n/', $raw)), fn($l) => $l !== ''));
}
