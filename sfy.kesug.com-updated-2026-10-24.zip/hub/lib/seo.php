<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY HUB — SEO / DISCOVERABILITY
 *
 *  Three things make the hub's pages findable, and all three are built here:
 *
 *   • a canonical URL. The hub is addressed with query strings (?p=…), and a
 *     listing can carry a search box, a sort, a filter and a page number at
 *     once — five addresses for one page. So exactly one of them is named as
 *     the canonical one, and the variants are declared `noindex,follow`: out
 *     of the index, but still crawled, because the links out of a filtered
 *     page are how the scripts themselves get discovered.
 *
 *   • structured data. A script page is a SoftwareApplication with a name, a
 *     game, a price, a date and an author, and the home page is a WebSite with
 *     a search box — the two shapes a search engine can actually put into a
 *     result. Emitted as JSON-LD, built with json_encode() rather than string
 *     concatenation, because a title with a quote in it is normal here.
 *
 *   • a sitemap, at ?p=sitemap, covering the home page, the listing, the
 *     plans, every game that has a script and every *published* script.
 *     Drafts cannot reach it — not by a filter applied afterwards, but
 *     because it is generated from the same queries the public pages use,
 *     where `status = 'published'` is the default.
 *
 *  Nothing here reads a file or writes one; the module stays one folder.
 * ═══════════════════════════════════════════════════════════════════════
 */

/** The module's sitemap. One URL, one place to change it. */
function sfy_hub_sitemap_url(): string { return sfy_hub_url('sitemap'); }

/**
 * Text for an XML document.
 *
 * HTML escaping is not enough here: entities a browser forgives are a parse
 * error in a sitemap, and `&` shown as `&amp;amp;` in a <loc> is a broken URL.
 */
function sfy_hub_xml(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES | ENT_XML1, 'UTF-8');
}

/** A MySQL DATETIME → a W3C datetime, or '' when there is nothing usable. */
function sfy_hub_iso(string $when): string {
    $when = trim($when);
    if ($when === '' || str_starts_with($when, '0000')) return '';
    $ts = strtotime($when);
    return $ts ? gmdate('Y-m-d\TH:i:s+00:00', $ts) : '';
}

/* ── what the sitemap contains ──────────────────────────────────────── */

/**
 * Games that have a published script, with the newest change to each.
 *
 * Deliberately its own query rather than sfy_hub_games(): that one is the
 * chip list and answers with a count only, and widening it would change what
 * every listing page prints. This one adds the date the sitemap needs and
 * keeps the same "published only" rule.
 */
function sfy_hub_seo_games(int $limit = 400): array {
    return sfy_try(function () use ($limit): array {
        $st = sfy_db()->query("SELECT game_name, COUNT(*) AS n,
                 MAX(COALESCE(NULLIF(updated_at, '0000-00-00 00:00:00'), published_at, created_at)) AS last
               FROM sfy_hub_scripts
               WHERE status = 'published' AND game_name <> ''
               GROUP BY game_name ORDER BY n DESC, game_name ASC LIMIT " . max(1, $limit));
        return $st->fetchAll();
    }, []);
}

/**
 * Every URL the module wants indexed: [loc, lastmod, priority].
 * The scripts half is paged rather than fetched in one go, because a script
 * library is exactly the kind of table that eventually has more rows than one
 * query should return.
 */
function sfy_hub_sitemap_urls(): array {
    $out = [
        ['loc' => sfy_hub_url(),          'lastmod' => '', 'priority' => '1.0'],
        ['loc' => sfy_hub_url('scripts'), 'lastmod' => '', 'priority' => '0.9'],
        ['loc' => sfy_hub_url('offers'),  'lastmod' => '', 'priority' => '0.6'],
    ];

    /* One entry per game. The game listing is the page that answers "is there
       a script for X", so it is worth an index entry of its own rather than
       being folded into the unfiltered listing.

       Two independent queries have to agree before a game gets a URL: the
       public chip list (published-only by construction) and the dated list
       below. A helper that ever answered with a game that has nothing public
       in it therefore cannot put that game's page into the index. */
    $public = [];
    foreach (sfy_hub_games(400) as $g) {
        $name = trim((string)($g['game_name'] ?? ''));
        if ($name !== '') $public[strtolower($name)] = true;
    }
    foreach (sfy_hub_seo_games() as $g) {
        $name = trim((string)($g['game_name'] ?? ''));
        if ($name === '' || !isset($public[strtolower($name)])) continue;
        $out[] = ['loc'     => sfy_hub_url('scripts', ['game' => $name]),
                  'lastmod' => sfy_hub_iso((string)($g['last'] ?? '')),
                  'priority'=> '0.7'];
    }

    $per   = 60;
    $total = sfy_hub_scripts_count(['status' => 'published']);
    $pages = min(200, (int)ceil(max(0, $total) / $per));
    for ($page = 1, $last = max(1, $pages); $page <= $last; $page++) {
        $rows = sfy_hub_scripts(['status' => 'published'], $page, $per);
        if (!$rows) break;
        foreach ($rows as $r) {
            $slug = trim((string)($r['slug'] ?? ''));
            /* The status is re-checked on the row itself: a listing helper
               that grew a cache, or a caller that asked for 'any', must not be
               able to leak a draft into the index through here. */
            if ($slug === '' || (string)($r['status'] ?? 'published') !== 'published') continue;
            $when = trim((string)($r['updated_at'] ?? '')) !== ''
                ? (string)$r['updated_at'] : (string)($r['published_at'] ?? '');
            $out[] = ['loc' => sfy_hub_url('script', ['slug' => $slug]),
                      'lastmod' => sfy_hub_iso($when), 'priority' => '0.8'];
        }
        if (count($rows) < $per) break;
    }

    /* One URL, once: a game named after a slug, or a query that answered
       twice, must not produce a duplicate <loc>. */
    $seen = [];
    $uniq = [];
    foreach ($out as $u) {
        $loc = (string)$u['loc'];
        if (isset($seen[$loc])) continue;
        $seen[$loc] = true;
        $uniq[] = $u;
    }
    return $uniq;
}

/** The sitemap document. */
function sfy_hub_sitemap_xml(): string {
    $out = '<?xml version="1.0" encoding="UTF-8"?>' . "\n"
         . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
    foreach (sfy_hub_sitemap_urls() as $u) {
        $out .= '  <url><loc>' . sfy_hub_xml((string)$u['loc']) . '</loc>';
        if ((string)$u['lastmod'] !== '') $out .= '<lastmod>' . sfy_hub_xml((string)$u['lastmod']) . '</lastmod>';
        if ((string)$u['priority'] !== '') $out .= '<priority>' . sfy_hub_xml((string)$u['priority']) . '</priority>';
        $out .= "</url>\n";
    }
    return $out . "</urlset>\n";
}

/* ── canonical + robots, per route ──────────────────────────────────── */

/** The canonical form of a game-filtered listing. */
function sfy_hub_seo_game_url(string $game): string {
    $game = trim($game);
    return $game === '' ? sfy_hub_url('scripts') : sfy_hub_url('scripts', ['game' => $game]);
}

/**
 * What this page tells a crawler.
 *
 * @return array{canonical:string,robots:string,description:string,schema:array}
 *
 * robots is '' for a page that should simply be indexed, 'noindex,follow' for
 * a variant of a real page (a search, a sort, a later page — out of the index
 * but still worth crawling through), and 'noindex,nofollow' for a page that is
 * nobody's business (a checkout step, a form, a draft one of the staff is
 * previewing).
 */
function sfy_hub_seo(string $route, array $o = []): array {
    $s   = sfy_hub_settings();
    $f   = sfy_hub_filters();
    $q   = trim((string)$f['q']);
    $game = trim((string)$f['game']);

    $out = ['canonical' => sfy_hub_url(), 'robots' => '', 'description' => '', 'schema' => []];

    switch ($route) {
        case 'home':
            $out['description'] = sfy_hub_line((string)$s['tagline'], 160);
            $out['schema'][]    = sfy_hub_website_schema();
            break;

        case 'scripts':
            $out['canonical'] = sfy_hub_seo_game_url($game);
            if ($q !== '' || (string)$f['kind'] !== 'all') {
                $out['robots'] = 'noindex,follow';
            } elseif ((string)$f['sort'] !== 'new' || (int)$f['page'] > 1) {
                $out['robots'] = 'noindex,follow';
            }
            $games = count(sfy_hub_games(400));
            $out['description'] = $game !== ''
                ? sfy_hub_line($game . ' scripts — verified and ready to run. Tap a card for the code, the '
                    . 'features and the game link.', 160)
                : sfy_hub_line('Browse every SFY script: ' . number_format(sfy_hub_scripts_count(['status' => 'published']))
                    . ' scripts across ' . number_format($games) . ' games, newest first.', 160);
            break;

        case 'script':
            $slug = trim((string)sfy_param('slug', ''));
            $out['canonical'] = $slug === '' ? sfy_hub_url('scripts')
                                             : sfy_hub_url('script', ['slug' => $slug]);
            $out['robots'] = 'noindex,nofollow';      // cleared below, once the row proves it is public
            break;

        case 'offers':
            $out['description'] = sfy_hub_line((string)$s['shop_intro'], 160);
            break;

        case 'buy':
            $out['canonical'] = sfy_hub_url('offers');
            $out['robots']    = 'noindex,nofollow';
            break;

        case 'contact':
        case 'suggest':
            /* A form is not a page anyone should land on from a search, but it
               is linked from the footer and the nav, so it stays crawlable and
               names itself rather than borrowing the home page's address. */
            $out['canonical'] = sfy_hub_url($route);
            $out['robots']    = 'noindex,follow';
            break;

        case 'sitemap':
            $out['canonical'] = sfy_hub_sitemap_url();
            $out['robots']    = 'noindex,follow';
            break;

        case 'webhook':
            /* Not a page at all — it answers JSON. Stated anyway, because the
               route table is public knowledge and a crawler that found the
               URL should be told to forget it. */
            $out['canonical'] = '';
            $out['robots']    = 'noindex,nofollow';
            break;
    }

    /* A view that knows something the route cannot — a script that is public at
       last, a staff preview of a draft — says so, and that wins. */
    if (array_key_exists('robots', $o))          $out['robots']      = (string)$o['robots'];
    if (!empty($o['noindex']))                   $out['robots']      = 'noindex,nofollow';
    if (array_key_exists('description', $o))     $out['description'] = sfy_hub_line((string)$o['description'], 160);
    if (array_key_exists('canonical', $o))       $out['canonical']   = (string)$o['canonical'];
    if (!empty($o['schema']) && is_array($o['schema'])) {
        foreach ($o['schema'] as $b) if (is_array($b)) $out['schema'][] = $b;
    }
    return $out;
}

/** Canonical, robots, description, the sitemap pointer and every JSON-LD block. */
function sfy_hub_seo_head(array $seo): string {
    $html = '';

    if ((string)$seo['description'] !== '') {
        $html .= '<meta name="description" content="' . sfy_esc((string)$seo['description']) . '">';
    }
    if ((string)$seo['robots'] !== '') {
        $html .= '<meta name="robots" content="' . sfy_esc((string)$seo['robots']) . '">';
    }
    if ((string)$seo['canonical'] !== '') {
        $html .= '<link rel="canonical" href="' . sfy_esc((string)$seo['canonical']) . '">';
    }
    $html .= '<link rel="sitemap" type="application/xml" title="Sitemap" href="'
           . sfy_esc(sfy_hub_sitemap_url()) . '">';

    foreach ((array)$seo['schema'] as $block) $html .= sfy_hub_json_ld((array)$block);
    return $html;
}

/**
 * One JSON-LD block.
 *
 * The closing tag is escaped inside the string: a script code column, a
 * description or a title can contain `</script>` in the wild, and a page that
 * ends its own script element is a page an owner cannot fix from the panel.
 */
function sfy_hub_json_ld(array $block): string {
    if (!$block) return '';
    $json = (string)json_encode($block, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($json === '') return '';
    return '<script type="application/ld+json">'
         . str_replace('</', '<\/', $json) . '</script>';
}

/* ── structured data ────────────────────────────────────────────────── */

/** The site itself, plus the search box — what earns a sitelinks search box. */
function sfy_hub_website_schema(): array {
    $s    = sfy_hub_settings();
    $name = trim((string)$s['title']) !== '' ? (string)$s['title'] : SFY_APP_NAME;
    return [
        '@context'        => 'https://schema.org',
        '@type'           => 'WebSite',
        'name'            => $name,
        'url'             => sfy_hub_url(),
        'potentialAction' => [
            '@type'        => 'SearchAction',
            'target'       => ['@type' => 'EntryPoint',
                               'urlTemplate' => sfy_hub_url('scripts') . '&q={search_term_string}'],
            'query-input'  => 'required name=search_term_string',
        ],
    ];
}

/** A script page as a SoftwareApplication. */
function sfy_hub_script_schema(array $row): array {
    $s    = sfy_hub_settings();
    $slug = trim((string)($row['slug'] ?? ''));
    $url  = sfy_hub_url('script', ['slug' => $slug]);

    $desc = trim((string)($row['summary'] ?? ''));
    if ($desc === '') $desc = trim((string)($row['description'] ?? ''));

    $block = [
        '@context'                => 'https://schema.org',
        '@type'                   => 'SoftwareApplication',
        'name'                    => (string)($row['title'] ?? ''),
        'url'                     => $url,
        'applicationCategory'     => 'GameApplication',
        'operatingSystem'         => 'Windows, macOS, Android, iOS',
    ];

    $game = trim((string)($row['game_name'] ?? ''));
    if ($game !== '') $block['applicationSubCategory'] = $game;
    if ($desc !== '') $block['description'] = sfy_hub_line($desc, 400);
    if (trim((string)($row['author'] ?? '')) !== '') {
        $block['author'] = ['@type' => 'Person', 'name' => (string)$row['author']];
    }
    $img = trim((string)($row['thumbnail'] ?? ''));
    if ($img !== '' && preg_match('~^https?://~i', $img)) $block['image'] = $img;
    $when = sfy_hub_iso(trim((string)($row['published_at'] ?? '')) !== ''
        ? (string)$row['published_at'] : (string)($row['created_at'] ?? ''));
    if ($when !== '') $block['datePublished'] = $when;

    /* Price: zero is a real, meaningful price for a free script and is what a
       search result shows. A paid script quotes the live plan it is behind —
       and quotes nothing at all when there is no plan to quote, because a
       price of zero on a paid script is a lie a search result would repeat. */
    $price = '0';
    if (empty($row['is_free'])) {
        $offer = sfy_hub_offer_featured();
        $price = is_array($offer) && array_key_exists('price', $offer) ? (string)(float)$offer['price'] : '';
    }
    if ($price !== '') {
        $block['offers'] = [
            '@type'         => 'Offer',
            'price'         => $price,
            'priceCurrency' => (string)$s['currency'],
            'availability'  => 'https://schema.org/InStock',
        ];
    }
    if ((int)($row['views'] ?? 0) > 0) {
        $block['interactionStatistic'] = [
            '@type'                => 'InteractionCounter',
            'interactionType'      => 'https://schema.org/ViewAction',
            'userInteractionCount' => (int)$row['views'],
        ];
    }

    /* The video, when there is one, described as what it is.
       Only an *embeddable* link: a VideoObject with an embedUrl a crawler
       cannot load is worse than no video block at all, and the plain link is
       simply not this page's content. */
    $video = sfy_hub_video_parse(trim((string)($row['video_url'] ?? '')));
    if ($video['embed'] !== '') {
        $vo = [
            '@type'    => 'VideoObject',
            'name'     => (string)($row['title'] ?? ''),
            'embedUrl' => $video['embed'],
        ];
        if ($desc !== '')          $vo['description']  = sfy_hub_line($desc, 400);
        if ($video['poster'] !== '') $vo['thumbnailUrl'] = $video['poster'];
        elseif (isset($block['image'])) $vo['thumbnailUrl'] = (string)$block['image'];
        if (isset($block['datePublished'])) $vo['uploadDate'] = (string)$block['datePublished'];
        $block['video'] = $vo;
    }
    return $block;
}

/**
 * A breadcrumb trail.
 * @param array $crumbs  [[label, url|null], …] — the last one is the page.
 */
function sfy_hub_breadcrumb_schema(array $crumbs): array {
    $items = [];
    $i     = 1;
    foreach ($crumbs as $c) {
        $label = trim((string)($c[0] ?? ''));
        if ($label === '') continue;
        $item = ['@type' => 'ListItem', 'position' => $i++, 'name' => $label];
        if (!empty($c[1])) $item['item'] = (string)$c[1];
        $items[] = $item;
    }
    return [
        '@context'        => 'https://schema.org',
        '@type'           => 'BreadcrumbList',
        'itemListElement' => $items,
    ];
}
