<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY HUB — PUBLIC FRONT CONTROLLER
 *
 *  Reachable at /hub/ the moment the folder is uploaded: it is an ordinary
 *  directory with an index.php, so it needs no rewrite rule, no change to
 *  the site's .htaccess and no entry in the install's own router.
 *
 *  Routes are query strings on purpose (?p=scripts, ?p=script&slug=…).
 *  Pretty paths would have meant a second .htaccess inside this folder, and
 *  an .htaccess that *replaces* the parent's rules on shared hosting is a
 *  great way to lose the HTTPS redirect, the bot filter and the internal
 *  folder block in one upload. A URL is not worth that.
 *
 *  Requests:  /hub/                     → home
 *             /hub/?p=scripts            → all scripts (+ q, game, kind, sort, page)
 *             /hub/?p=script&slug=…      → one script
 *             /hub/?p=offers             → premium plans
 *             /hub/?p=buy&offer=…        → the purchase page for one plan
 *             /hub/?p=contact            → support form
 *             /hub/?p=suggest            → game suggestion form
 *             /hub/?p=sitemap            → XML for crawlers (every published script + game)
 *             /hub/admin/                → this module's control panel (staff)
 * ═══════════════════════════════════════════════════════════════════════
 */

require __DIR__ . '/lib/bootstrap.php';

$route = sfy_hub_route();
$view  = SFY_HUB_ROOT . '/views/' . (string)sfy_hub_routes()[$route]['view'] . '.php';

if (!is_file($view)) {
    sfy_hub_page_start(['page' => $route, 'title' => 'Not available']);
    echo sfy_hub_empty('That section is missing from this install');
    sfy_hub_page_end();
    exit;
}

require $view;
