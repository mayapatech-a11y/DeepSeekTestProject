/* ═══════════════════════════════════════════════════════════════════════
   SFY HUB — client behaviour

   Everything here is an *enhancement*: the search, the filters, the sorting
   and the pager are ordinary server-rendered links and form submits, so the
   hub is fully usable with this file blocked or broken. That is deliberate —
   a scripts site is mostly read on a phone over a bad connection, and a
   JavaScript-dependent grid is one failed asset away from an empty page.
   ═══════════════════════════════════════════════════════════════════════ */
(function () {
  'use strict';

  /* ── mobile menu (a popup, not a strip) ─────────────────────────────
     The panel is fixed over the page, so opening it must do three more
     things than toggling a class: dim the page behind it (the scrim), stop
     the page from scrolling underneath (body class) and tell assistive tech
     what happened (aria-expanded / aria-hidden). Closing puts focus back on
     the burger, so a keyboard user is never dropped at the top of the
     document. Any of ✕, the scrim, Escape, a link or a resize into the
     desktop layout closes it. */
  function drawer() {
    var burger = document.getElementById('hub-burger');
    var panel  = document.getElementById('hub-drawer');
    var scrim  = document.getElementById('hub-scrim');
    var close  = document.getElementById('hub-drawer-close');
    if (!burger || !panel) return;

    function open() { return panel.classList.contains('open'); }

    function set(open, focus) {
      panel.classList.toggle('open', open);
      if (scrim) scrim.classList.toggle('open', open);
      panel.setAttribute('aria-hidden', open ? 'false' : 'true');
      burger.setAttribute('aria-expanded', open ? 'true' : 'false');
      document.body.classList.toggle('hub-menu-open', open);
      if (focus === false) return;
      var target = open ? panel : burger;
      try { target.focus({ preventScroll: true }); } catch (e) { target.focus(); }
    }

    burger.addEventListener('click', function () { set(!open()); });
    if (close) close.addEventListener('click', function () { set(false); });
    if (scrim) scrim.addEventListener('click', function () { set(false); });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && open()) set(false);
      /* Keep Tab inside the popup while it is open — the page behind it is
         dimmed and inert, so tabbing into it would be a trap of a different
         kind. */
      if (e.key === 'Tab' && open()) {
        var f = panel.querySelectorAll('a[href], button:not([disabled]), input, select, textarea');
        if (!f.length) return;
        var first = f[0], last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    });
    panel.addEventListener('click', function (e) {
      if (e.target.closest('a[href]')) set(false, false);
    });
    /* The layout has its own breakpoint: leaving the phone size with the menu
       open would otherwise leave the page scroll-locked with no visible
       panel to close. */
    if (window.matchMedia) {
      var mq = window.matchMedia('(min-width:1081px)');
      var onChange = function (e) { if (e.matches && open()) set(false, false); };
      if (mq.addEventListener) mq.addEventListener('change', onChange);
      else if (mq.addListener) mq.addListener(onChange);
    }
  }

  /* ── payment methods: show the panel that belongs to the picked one ───
     Without this, every method's instructions, address and fields are on the
     page at once — which is what a browser with no JavaScript gets, and is
     merely long. With it, only the chosen method's panel is shown, and the
     *required* flag travels with it: a hidden panel holding a required input
     would otherwise stop the form from submitting while the browser pointed
     at a field nobody can see. */
  function payMethods() {
    var wrap = document.querySelector('[data-hub-paypanels]');
    if (!wrap) return;

    var radios = Array.prototype.slice.call(document.querySelectorAll('.hub-pay input[name="payment_method"]'));
    if (!radios.length) return;
    var panels = Array.prototype.slice.call(wrap.querySelectorAll('.hub-paypanel'));

    function show() {
      var picked = '';
      radios.forEach(function (r) { if (r.checked) picked = r.value; });

      panels.forEach(function (p) {
        var on = p.getAttribute('data-hub-pay') === picked;
        p.classList.toggle('on', on);
        p.querySelectorAll('input').forEach(function (i) {
          if (i.getAttribute('data-hub-required') === null) {
            i.setAttribute('data-hub-required', i.required ? '1' : '0');
          }
          i.required = on && i.getAttribute('data-hub-required') === '1';
        });
      });
      document.querySelectorAll('.hub-pay').forEach(function (card) {
        var r = card.querySelector('input[name="payment_method"]');
        card.classList.toggle('on', !!r && r.checked);
      });
    }

    wrap.setAttribute('data-hub-ready', '1');
    radios.forEach(function (r) { r.addEventListener('change', show); });
    show();
  }

  /* ── copy a script ─────────────────────────────────────────────────── */
  function copyButtons() {
    document.querySelectorAll('[data-hub-copy]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var sel = btn.getAttribute('data-hub-copy');
        var el  = document.querySelector(sel);
        if (!el) return;
        var text = el.innerText || el.textContent || '';

        var done = function () {
          var was = btn.textContent;
          btn.classList.add('done');
          btn.textContent = '✔ COPIED';
          setTimeout(function () { btn.classList.remove('done'); btn.textContent = was; }, 1800);
        };

        if (navigator.clipboard && window.isSecureContext) {
          navigator.clipboard.writeText(text).then(done, function () { legacy(text, done); });
        } else {
          legacy(text, done);
        }

        // The count of copies is a real signal about a script (and it is what
        // the "Most copied" sort reads), so it is reported best-effort: a
        // failed beacon must never interrupt the copy the user just got.
        var url = btn.getAttribute('data-hub-track');
        if (url) { try { navigator.sendBeacon ? navigator.sendBeacon(url) : fetch(url, { keepalive: true }); } catch (e) {} }
      });
    });
  }

  function legacy(text, done) {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.cssText = 'position:absolute;left:-9999px;top:0';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); done(); } catch (e) {}
    document.body.removeChild(ta);
  }

  /* ── the hero picture, as a player ───────────────────────────────────
     Two ways a video gets onto the page, and they are different on purpose:
     a *press*, which may have sound because the visitor just asked for it,
     and the owner's *autoplay*, which starts muted because every browser
     refuses a video that begins talking on its own. Both build the same
     iframe, so there is one path and no second embed to keep in step.

     Nothing is requested until one of those happens: a visitor who never
     plays the video never loads a player, and the picture is all the page
     weighs. The link it lives on is a real one to the video's own site, which
     is what makes this work with no script at all. */
  function heroVideo() {
    var links = document.querySelectorAll('[data-hub-play]');
    if (!links.length) return;

    /* Save-data and reduced-motion are the two settings a visitor has already
       used to say "do not start things on your own", so an autoplay that
       ignores them is a setting that only exists for the owner. */
    var saveData = !!(navigator.connection && navigator.connection.saveData);
    var calm     = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

    function mount(link, src) {
      var wrap  = link.parentNode;
      var frame = document.createElement('iframe');
      frame.className = 'hub-hero-frame';
      frame.setAttribute('src', src);
      frame.setAttribute('title', link.getAttribute('aria-label') || 'Video');
      /* One allow list, and no separate allowfullscreen: fullscreen is in it,
         and having both makes every browser log a warning about which wins. */
      frame.setAttribute('allow', 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen');
      frame.setAttribute('referrerpolicy', 'strict-origin-when-cross-origin');
      wrap.classList.add('on');
      wrap.replaceChild(frame, link);
      return frame;
    }

    Array.prototype.slice.call(links).forEach(function (link) {
      var press = link.getAttribute('data-hub-play') || '';
      var auto  = link.getAttribute('data-hub-auto') || '';

      if (link.getAttribute('data-hub-autoplay') === '1' && auto && !saveData && !calm) {
        var frame = mount(link, auto);
        var sound = document.createElement('button');
        sound.type = 'button';
        sound.className = 'hub-hero-sound';
        sound.textContent = '🔊 TURN SOUND ON';
        /* One press is all a browser needs to let a muted player have sound,
           so this reloads it with the very address the button would use. */
        sound.addEventListener('click', function () {
          frame.setAttribute('src', press);
          sound.parentNode.removeChild(sound);
        });
        frame.parentNode.appendChild(sound);
        return;
      }

      link.addEventListener('click', function (e) {
        /* Anything that means "open this somewhere else" keeps its own
           meaning — the link is a real one. */
        if (e.defaultPrevented || e.button || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
        if (!press) return;
        e.preventDefault();
        mount(link, press);
      });
    });
  }

  /* ── typing filters the grid that is already on screen ─────────────── */
  function quickFilter() {
    var input = document.querySelector('[data-hub-quick]');
    var grid  = document.querySelector('[data-hub-grid]');
    if (!input || !grid) return;

    var cards = Array.prototype.slice.call(grid.querySelectorAll('.hub-card'));
    var empty = grid.parentNode.querySelector('.hub-empty-quick');
    var t     = null;

    function apply() {
      var q = (input.value || '').trim().toLowerCase();
      var shown = 0;
      cards.forEach(function (card) {
        var hay = (card.getAttribute('data-hub-text') || card.textContent || '').toLowerCase();
        var hit = q === '' || hay.indexOf(q) !== -1;
        card.style.display = hit ? '' : 'none';
        if (hit) shown++;
      });
      if (empty) empty.style.display = shown === 0 ? '' : 'none';
      // The server's pager describes the unfiltered result set, so it is
      // hidden while the client is filtering — otherwise "page 2" would claim
      // to continue a list the visitor has just narrowed to three cards.
      var pager = document.querySelector('.hub-pager');
      if (pager) pager.style.display = q === '' ? '' : 'none';
    }

    input.addEventListener('input', function () {
      clearTimeout(t);
      t = setTimeout(apply, 120);
    });
  }

  /* ── number fields: show the value next to the slider ──────────────── */
  function sliders() {
    document.querySelectorAll('.hub-slider input[type=range]').forEach(function (r) {
      var out = r.parentNode.querySelector('output');
      if (!out) return;
      function show() { out.textContent = r.value + (r.getAttribute('data-suffix') || ''); }
      r.addEventListener('input', show);
      show();
    });
  }

  /* ── import form: don't let a double press fire twice ──────────────── */
  function singleSubmit() {
    document.querySelectorAll('form[data-hub-once]').forEach(function (f) {
      f.addEventListener('submit', function () {
        var b = f.querySelector('button[type=submit], button:not([type])');
        if (b) { b.disabled = true; b.textContent = b.getAttribute('data-busy') || 'WORKING…'; }
      });
    });
  }

  /* ── the bar gives up its tail, one link at a time ────────────────────
     Section links, a search box and two buttons do not fit every width, and a
     flex row that runs out of room clips its *last* item — which is how a link
     ended up sliced in half behind the search box.

     So the row is measured here, and the items that do not fit are moved into
     the popup instead of being cut: the bar keeps as many links as it can, the
     burger appears to reach the rest, and nothing is ever half a link. The
     popup holds every one of them either way, so a moved item is not lost. */
  function barFit() {
    var bar = document.querySelector('.hub-bar-in');
    var nav = bar ? bar.querySelector('.hub-nav') : null;
    var burger = bar ? bar.querySelector('.hub-burger') : null;
    if (!bar || !nav || !burger) return;

    var links = Array.prototype.slice.call(nav.children);
    if (!links.length) return;

    function fits() {
      /* +1: sub-pixel widths round down, and a row that fits exactly must not
         lose a link to rounding. */
      return nav.scrollWidth <= nav.clientWidth + 1;
    }

    function check() {
      links.forEach(function (a) { a.hidden = false; });

      var dropped = 0;
      while (dropped < links.length && !fits()) {
        links[links.length - 1 - dropped].hidden = true;
        dropped++;
      }

      if (dropped) bar.setAttribute('data-hub-dropped', '1');
      else bar.removeAttribute('data-hub-dropped');
    }

    if (window.requestAnimationFrame) requestAnimationFrame(check); else check();

    var t = null;
    window.addEventListener('resize', function () {
      clearTimeout(t);
      t = setTimeout(check, 120);
    });
    /* A webfont that arrives after load changes every width on the bar. */
    if (document.fonts && document.fonts.ready && document.fonts.ready.then) {
      document.fonts.ready.then(function () { check(); });
    }
  }

  /* ── the popup is already open ────────────────────────────────────────
     The server printed it because the URL asked for it, so there is nothing
     to open here: this only adds what a popup should also have. The ✕, the
     scrim and the save button are ordinary links and forms, which is why it
     opens, submits and closes with no script at all. */
  function modal() {
    var box = document.querySelector('[data-hub-modal]');
    if (!box) return;

    var panel = box.querySelector('.hub-modal-box');
    var scrim = box.querySelector('.hub-modal-scrim');
    var back  = scrim ? scrim.getAttribute('href') : '';
    var touch = window.matchMedia && window.matchMedia('(pointer: coarse)').matches;

    document.body.classList.add('hub-modal-open');

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        e.preventDefault();
        if (back) location.href = back;
        return;
      }
      if (e.key !== 'Tab' || !panel) return;
      /* Keep Tab inside the popup: the page behind it is dimmed and locked,
         so tabbing into it would be a trap of a different kind. */
      var f = panel.querySelectorAll('a[href], button:not([disabled]), input:not([type=hidden]):not([disabled]), select:not([disabled]), textarea:not([disabled])');
      if (!f.length) return;
      var first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    });

    /* Focus the box, or the first field on a device with a real keyboard.
       On a touch screen, focusing a field would throw the on-screen keyboard
       over the very content the popup was opened to show. */
    if (!panel) return;
    var field = touch ? null
        : panel.querySelector('input:not([type=hidden]):not([disabled]), textarea:not([disabled]), select:not([disabled])');
    if (field && typeof field.focus === 'function') field.focus();
    else if (typeof panel.focus === 'function') panel.focus();
  }

  /* ── the contact form's game picker ───────────────────────────────────
     Choosing "another game" reveals the text box; anything else hides it
     again. Without a script both are simply visible, which is why the box is
     never `required`: an input that is hidden and required at the same time
     stops a form nobody can fix from the outside. */
  function contactGame() {
    document.querySelectorAll('[data-hub-game]').forEach(function (sel) {
      var form = sel.closest('form');
      var wrap = form ? form.querySelector('[data-hub-game-other]') : null;
      if (!wrap) return;
      var box = wrap.querySelector('input');

      function show(focus) {
        /* A typed name keeps the box visible even when the picker still shows
           a game — the typed one is the one that will be saved. */
        var other = sel.value === '__other' || (box && box.value.trim() !== '');
        wrap.hidden = !other;
        if (focus && other && box && typeof box.focus === 'function') box.focus();
      }

      sel.addEventListener('change', function () { show(true); });
      show(false);
    });
  }

  function boot() {
    drawer();
    barFit();
    modal();
    contactGame();
    payMethods();
    heroVideo();
    copyButtons();
    quickFilter();
    sliders();
    singleSubmit();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
