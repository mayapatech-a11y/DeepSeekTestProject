<?php
declare(strict_types=1);
/**
 * All scripts — the search results page.
 *
 * Everything on it is server-rendered from the query string, so a search
 * result is a URL that can be shared, bookmarked and indexed. The instant
 * filter box only narrows *this page* further, and says so.
 */

$s = sfy_hub_settings();
$f = sfy_hub_filters();

$sortLabels = sfy_hub_script_sorts();
$title = 'All scripts';
if ((string)$f['q'] !== '') {
    $title = 'Results for “' . sfy_short((string)$f['q'], 40) . '”';
} elseif ((string)$f['game'] !== '') {
    $title = (string)$f['game'] . ' scripts';
} elseif (isset($sortLabels[(string)$f['sort']]) && (string)$f['sort'] !== 'new') {
    $title = $sortLabels[(string)$f['sort']] . ' scripts';
}

sfy_hub_page_start([
    'page'  => 'scripts',
    'title' => $title,
    'sub'   => 'Verified SFY scripts, newest first. Tap a card for the code, the features and the game link.',
    'pin'   => !empty($s['nav_offers'])
        ? ['url' => sfy_hub_url('offers'), 'kind' => 'guide', 'icon' => '⚡', 'label' => 'GET PREMIUM KEY']
        : null,
]);

echo sfy_hub_listing($f, ['quick' => true]);

sfy_hub_page_end();
