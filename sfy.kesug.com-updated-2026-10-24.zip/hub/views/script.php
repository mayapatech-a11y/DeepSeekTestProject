<?php
declare(strict_types=1);
/**
 * One script — the page the whole module exists for.
 *
 * The code is the product, so it gets the middle of the page, a copy button
 * that works without a clipboard API (see hub.js), and a plain-text download
 * for anyone who would rather save it. Everything else — features,
 * description, game link, Discord — is arranged around it.
 *
 * A draft script is only visible to signed-in staff, which is what makes
 * "import first, publish later" a usable workflow.
 */

$slug = (string)sfy_param('slug', '');
$row  = sfy_hub_script_by_slug($slug, false);

$staff = sfy_hub_staff();
if ($row && (string)$row['status'] !== 'published' && !$staff) $row = null;

if (!$row) {
    /* No slug here points at anything public, so the canonical is the listing
       rather than a 404, and the page stays out of the index. */
    sfy_hub_page_start(['page' => 'script', 'title' => 'Script not found',
                        'canonical' => sfy_hub_url('scripts'), 'robots' => 'noindex,nofollow']);
    echo sfy_hub_empty('That script is not here');
    sfy_hub_page_end();
    exit;
}

/* 204 beacon from the copy button: counts a copy and nothing else, before a
   single byte of markup is produced. */
if (sfy_int('copy', 0) === 1) {
    sfy_hub_script_copy((int)$row['id']);
    while (ob_get_level() > 0) @ob_end_clean();
    if (!headers_sent()) { http_response_code(204); header('Content-Type: text/plain'); }
    exit;
}

if (sfy_int('download', 0) === 1 && trim((string)$row['script_code']) !== '') {
    while (ob_get_level() > 0) @ob_end_clean();
    if (!headers_sent()) {
        header('Content-Type: text/plain; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . preg_replace('/[^a-z0-9\-_]/i', '-', (string)$row['slug']) . '.lua"');
        header('X-Content-Type-Options: nosniff');
    }
    echo (string)$row['script_code'];
    exit;
}

sfy_hub_script_view((int)$row['id']);

$code     = trim((string)$row['script_code']);
$game     = trim((string)$row['game_name']);
$features = sfy_hub_feature_list((string)$row['features']);
$tags     = sfy_hub_tag_list((string)$row['tags']);
$desc     = trim((string)$row['description']);
if ($desc === '' && trim((string)$row['summary']) !== '') $desc = (string)$row['summary'];

$srcHost = (string)parse_url((string)$row['source_url'], PHP_URL_HOST);

/* The video, if this script has one: a YouTube/Vimeo link plays in the hero
   itself (on click, or on its own when the owner switched autoplay on),
   and anything else stays a plain button next to the copy button. */
$video    = trim((string)$row['video_url']);
$playable = sfy_hub_video_playable($video);
$autoplay = (int)($row['video_autoplay'] ?? 0) === 1 && $playable;

/* The trail the page prints, in the one form a crawler can read: the same
   four steps as the .hub-crumb nav below it, so the two cannot disagree. */
$crumbs = [['SFY Hub', sfy_hub_url()], ['Scripts', sfy_hub_url('scripts')]];
if ($game !== '') $crumbs[] = [$game, sfy_hub_seo_game_url($game)];
$crumbs[] = [(string)$row['title'], null];
$isPublic = (string)$row['status'] === 'published';

sfy_hub_page_start([
    'page'        => 'script',
    'title'       => (string)$row['title'],
    'description' => sfy_hub_line($desc !== '' ? $desc : (string)$row['title'], 155),
    /* A draft is staff-only, so it gets no canonical URL — there is no public
       address to point at — and a hard noindex, so a link pasted out of the
       panel cannot be indexed before the script is published. */
    'robots'      => $isPublic ? '' : 'noindex,nofollow',
    'canonical'   => $isPublic ? sfy_hub_url('script', ['slug' => (string)$row['slug']]) : '',
    'schema'      => $isPublic
        ? [sfy_hub_script_schema($row), sfy_hub_breadcrumb_schema($crumbs)]
        : [],
]);
?>

<nav class="hub-crumb">
  <a href="<?= sfy_esc(sfy_hub_url()) ?>">Hub</a> ›
  <a href="<?= sfy_esc(sfy_hub_url('scripts')) ?>">Scripts</a>
  <?php if ($game !== ''): ?> ›
    <a href="<?= sfy_esc(sfy_hub_url('scripts', ['game' => $game])) ?>"><?= sfy_esc($game) ?></a>
  <?php endif; ?>
</nav>

<div class="hub-script">
  <div class="hub-script-main">

    <section class="hub-sd-hero">
      <?= sfy_hub_hero_media($row, $autoplay) ?>
      <div class="hub-sd-body">
        <h1 class="hub-sd-title"><?= sfy_esc((string)$row['title']) ?></h1>
        <div class="hub-sd-meta">
          <?php if ($game !== ''): ?>
            <span class="hub-tag hub-tag-game"><?= sfy_esc($game) ?></span>
          <?php endif; ?>
          <?php if (!empty($row['is_universal'])): ?><span class="hub-tag">Universal</span><?php endif; ?>
          <?php if (!empty($row['key_system'])): ?><span class="hub-tag hub-tag-key">🔑 Key system</span><?php endif; ?>
          <?php if (empty($row['key_system'])): ?><span class="hub-tag">Keyless</span><?php endif; ?>
          <?php if (!empty($row['is_featured'])): ?><span class="hub-tag hub-tag-hot">🔥 Featured</span><?php endif; ?>
          <?php if ((string)$row['status'] !== 'published'): ?>
            <span class="hub-tag hub-tag-hot">DRAFT — staff only</span>
          <?php endif; ?>
          <?php foreach (array_slice($tags, 0, 6) as $t): ?>
            <span class="hub-tag"><?= sfy_esc($t) ?></span>
          <?php endforeach; ?>
        </div>
        <div class="hub-sd-stats">
          <span>👁 <?= number_format((int)$row['views']) ?> views</span>
          <span>📋 <?= number_format((int)$row['copies']) ?> copies</span>
          <span>🕒 <?= sfy_esc(sfy_hub_script_when($row)) ?></span>
          <?php if (trim((string)$row['author']) !== ''): ?>
            <span>✍ <?= sfy_esc((string)$row['author']) ?></span>
          <?php endif; ?>
        </div>
        <div class="hub-sd-actions">
          <?php if ($code !== ''): ?>
            <button type="button" class="btn btn-primary" data-hub-copy="#hub-code"
                    data-hub-track="<?= sfy_esc(sfy_hub_url('script', ['slug' => (string)$row['slug'], 'copy' => 1])) ?>">
              📋 COPY SCRIPT
            </button>
            <a class="btn" href="<?= sfy_esc(sfy_hub_url('script', ['slug' => (string)$row['slug'], 'download' => 1])) ?>">⤓ DOWNLOAD .LUA</a>
          <?php endif; ?>
          <?php if (trim((string)$row['game_link']) !== ''): ?>
            <a class="btn btn-ghost" href="<?= sfy_esc((string)$row['game_link']) ?>" target="_blank" rel="noopener nofollow">▶ PLAY GAME</a>
          <?php endif; ?>
          <?php if ($video !== '' && !$playable): ?>
            <a class="btn btn-ghost" href="<?= sfy_esc($video) ?>" target="_blank" rel="noopener nofollow">▶ WATCH VIDEO</a>
          <?php endif; ?>
          <?php if (trim((string)$row['discord_url']) !== ''): ?>
            <a class="btn btn-ghost" href="<?= sfy_esc((string)$row['discord_url']) ?>" target="_blank" rel="noopener nofollow">💬 DISCORD</a>
          <?php endif; ?>
        </div>
      </div>
    </section>

    <?php if ($code !== ''): ?>
      <section class="hub-panel">
        <h2>Script</h2>
        <div class="hub-code">
          <div class="hub-code-bar">
            <span>lua</span>
            <span class="spacer"></span>
            <button type="button" class="hub-copy" data-hub-copy="#hub-code"
                    data-hub-track="<?= sfy_esc(sfy_hub_url('script', ['slug' => (string)$row['slug'], 'copy' => 1])) ?>">COPY</button>
          </div>
<pre id="hub-code"><?= sfy_esc($code) ?></pre>
        </div>
        <p class="hub-note">Paste this into your executor's script box and execute.</p>
      </section>
    <?php endif; ?>

    <?php if ($features): ?>
      <section class="hub-panel">
        <h2>Features</h2>
        <ul class="hub-features">
          <?php foreach ($features as $ft): ?>
            <li><span class="tick">✓</span><?= sfy_esc($ft) ?></li>
          <?php endforeach; ?>
        </ul>
      </section>
    <?php endif; ?>

    <?php if ($desc !== ''): ?>
      <section class="hub-panel">
        <h2>Description</h2>
        <div class="hub-prose"><?= sfy_esc($desc) ?></div>
      </section>
    <?php endif; ?>

    <section class="hub-panel">
      <h2>Something wrong?</h2>
      <p class="hub-note" style="margin:0 0 12px">
        Patched, broken, or wrong game — tell us and it gets looked at. Suggestions for new games are welcome too.
      </p>
      <div class="btn-row">
        <a class="btn btn-sm btn-primary" href="<?= sfy_esc(sfy_hub_url('contact', ['about' => (string)$row['title']])) ?>">REPORT A PROBLEM</a>
        <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_hub_url('suggest')) ?>">REQUEST A GAME</a>
      </div>
    </section>

  </div>

  <aside class="hub-rail">
    <section class="hub-rail-box">
      <div class="hub-rail-head">ℹ Details</div>
      <div class="hub-kv"><span>Game</span><span><?= sfy_esc($game !== '' ? $game : 'Universal') ?></span></div>
      <div class="hub-kv"><span>Added</span><span><?= sfy_esc(sfy_hub_script_when($row)) ?></span></div>
      <div class="hub-kv"><span>Access</span><span><?= !empty($row['key_system']) ? 'Key system' : 'Keyless' ?></span></div>
      <div class="hub-kv"><span>Price</span><span><?= !empty($row['is_free']) ? 'Free' : 'Paid' ?></span></div>
      <?php if ($playable): ?>
        <div class="hub-kv"><span>Video</span><span><?= sfy_esc(sfy_hub_video_parse($video)['provider']) ?><?= $autoplay ? ' · autoplay' : '' ?></span></div>
      <?php endif; ?>
      <?php if ($srcHost !== ''): ?>
        <div class="hub-kv"><span>Imported from</span><span><?= sfy_esc($srcHost) ?></span></div>
      <?php endif; ?>
      <?php if (trim((string)$row['source_url']) !== '' && $staff): ?>
        <div class="hub-kv"><span>Source</span>
          <span><a href="<?= sfy_esc((string)$row['source_url']) ?>" target="_blank" rel="noopener nofollow">open page</a></span></div>
      <?php endif; ?>
    </section>

    <?php
    $related = $game !== ''
        ? sfy_hub_scripts(['game' => $game, 'status' => 'published', 'sort' => 'new'], 1, 5)
        : [];
    $related = array_values(array_filter($related, fn($r) => (int)$r['id'] !== (int)$row['id']));
    if ($related):
    ?>
      <section class="hub-rail-box">
        <div class="hub-rail-head">🎮 More for <?= sfy_esc(sfy_short($game, 20)) ?></div>
        <?php foreach (array_slice($related, 0, 4) as $r): ?>
          <a class="hub-top-row" href="<?= sfy_esc(sfy_hub_script_link($r)) ?>">
            <span class="hub-top-m">
              <span class="hub-top-t"><?= sfy_esc(sfy_short((string)$r['title'], 34)) ?></span>
              <span class="hub-top-s"><?= number_format((int)$r['views']) ?> views · <?= sfy_esc(sfy_hub_script_when($r)) ?></span>
            </span>
          </a>
        <?php endforeach; ?>
      </section>
    <?php endif; ?>

    <?php if (!empty(sfy_hub_setting('nav_offers'))): ?>
      <?php $offer = sfy_hub_offer_featured(); if ($offer): ?>
        <section class="hub-rail-box">
          <div class="hub-rail-head">⚡ Skip the tasks</div>
          <?= sfy_hub_offer_card($offer, true) ?>
        </section>
      <?php endif; ?>
    <?php endif; ?>
  </aside>
</div>

<?php sfy_hub_page_end(); ?>
