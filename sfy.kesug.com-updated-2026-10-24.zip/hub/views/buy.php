<?php
declare(strict_types=1);
/**
 * Buy — the purchase page for one plan.
 *
 * This is where an advertisement for a premium key lands
 * (/hub/?p=buy&offer=2-day). It is deliberately a *request*, not a checkout:
 * there is no payment gateway on this install, so the visitor is asked for
 * the minimum (a name and a way to reach them), handed a reference code to
 * quote, and told what happens next. The order lands in Hub → Orders where
 * staff work it.
 *
 * Post/Redirect/Get throughout: a refresh after a successful order shows the
 * same confirmation instead of placing a second one.
 */

$s     = sfy_hub_settings();
$slug  = (string)sfy_param('offer', '');
$offer = sfy_hub_offer_by_slug($slug);
$ref   = (string)sfy_param('ref', '');

/* ── place an order ─────────────────────────────────────────────────── */
if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) === 'POST' && (string)sfy_param('action') === 'order') {
    $target = $offer ? (string)$offer['slug'] : '';

    if (!$offer) {
        sfy_hub_flash('err', 'That plan is no longer available.');
        sfy_redirect(sfy_hub_url('offers'));
    }
    if (empty($s['orders_enabled'])) {
        sfy_hub_flash('warn', 'Orders are closed right now. Send us a message instead and we will sort it out.');
        sfy_redirect(sfy_hub_url('contact'));
    }

    $guard = sfy_hub_guard('buy');
    if (!$guard['ok']) {
        sfy_hub_keep($_POST);
        sfy_hub_flash('err', $guard['error']);
        sfy_redirect(sfy_hub_url('buy', ['offer' => $target]));
    }

    $res = sfy_hub_order_create($_POST, $offer);
    if (!$res['ok']) {
        sfy_hub_keep($_POST);
        sfy_hub_flash('err', $res['error']);
        sfy_redirect(sfy_hub_url('buy', ['offer' => $target]));
    }

    sfy_hub_flash('ok', 'Order received — keep your reference code.');
    sfy_redirect(sfy_hub_url('buy', ['offer' => $target, 'ref' => (string)$res['order']['reference']]));
}

$order = $ref !== '' ? sfy_hub_order_by_reference($ref) : null;
$keep  = sfy_hub_keep_take();

/* ── no plan chosen: show the plans to pick from ────────────────────── */
if (!$offer) {
    $all = sfy_hub_offers(true);
    sfy_hub_page_start(['page' => 'buy', 'title' => 'Choose a plan', 'sub' => 'Pick the plan you want and the buy page opens with it ready.']);
    if (!$all) {
        echo sfy_hub_empty('No plans are on sale right now');
    } else {
        echo '<div class="hub-offers">';
        foreach ($all as $o) echo sfy_hub_offer_card($o);
        echo '</div>';
    }
    sfy_hub_page_end();
    exit;
}

/* The methods the shop is offering *now*, in the buyer's shape: names, what
   each one needs, where the money goes — and never a credential. */
$methods = sfy_hub_payment_offered();
$cur     = (string)$offer['currency'];
$chosen  = (string)sfy_hub_keep_get($keep, 'payment_method');
if ($chosen === '' && $methods) $chosen = (string)$methods[0]['slug'];

sfy_hub_page_start([
    'page'  => 'buy',
    'title' => 'Buy: ' . (string)$offer['title'],
    'sub'   => 'No account needed — leave a name and a way to reach you.',
    'pin'   => ['url' => sfy_hub_url('offers'), 'kind' => 'guide', 'icon' => '⚡', 'label' => 'SEE ALL PLANS'],
]);
?>

<?php
/* The method this order was placed with — looked up live, so a method the
   owner has since renamed or re-configured shows its *current* instructions
   rather than the ones frozen at checkout time. A method that has been
   deleted degrades to the shared payment note. */
$paidWith = (string)($order['payment_slug'] ?? '') !== ''
    ? sfy_hub_payment_by_slug((string)$order['payment_slug']) : null;
$paidWith = $paidWith ? sfy_hub_payment_public($paidWith) : null;
?>

<?php if ($order): ?>

  <div class="hub-panel hub-order">
    <div class="hub-order-top">
      <div>
        <h2>Order received</h2>
        <p class="hub-note" style="margin:0 0 12px">
          Save this reference — it is what matches your payment to this order, and support can look you up by it.
        </p>
        <div class="hub-ref"><?= sfy_esc((string)$order['reference']) ?></div>
      </div>
      <span class="hub-pill big <?= sfy_esc((string)$order['status']) ?>">
        <?= sfy_esc((string)(sfy_hub_order_statuses()[(string)$order['status']] ?? $order['status'])) ?></span>
    </div>

    <table class="hub-table-mini" style="margin-top:16px">
      <tr><th>Plan</th><td><?= sfy_esc((string)$order['offer_title']) ?>
        <?php if (trim((string)$order['duration_label']) !== ''): ?>
          <span class="hub-pill"><?= sfy_esc((string)$order['duration_label']) ?></span>
        <?php endif; ?></td></tr>
      <tr><th>Amount</th><td id="hub-order-amount"><?= sfy_esc(sfy_hub_money($order['amount'], (string)$order['currency'])) ?></td></tr>
      <tr><th>Paying with</th><td><?= sfy_esc((string)($order['payment_method'] !== '' ? $order['payment_method'] : '— to be agreed —')) ?></td></tr>
      <tr><th>Contact</th><td><?= sfy_esc((string)$order['buyer_contact']) ?></td></tr>
      <tr><th>Placed</th><td><?= sfy_esc(sfy_ago((string)$order['created_at'])) ?></td></tr>
    </table>

    <?php if ($paidWith): ?>
      <div class="label" style="margin-top:18px">How to pay this order</div>
      <?= sfy_hub_pay_summary($paidWith, $order) ?>
    <?php elseif (trim((string)$s['pay_instructions']) !== ''): ?>
      <div class="label" style="margin-top:18px">What to do now</div>
      <div class="hub-prose-block"><?= sfy_esc((string)$s['pay_instructions']) ?></div>
    <?php endif; ?>

    <?php if ($methods): ?>
      <div class="label" style="margin-top:16px">Other methods we accept</div>
      <ul class="hub-pays">
        <?php foreach ($methods as $m): ?><li><?= sfy_esc((string)$m['name']) ?></li><?php endforeach; ?>
      </ul>
    <?php endif; ?>

    <div class="btn-row" style="margin-top:18px">
      <?php if (trim((string)$s['support_discord']) !== '' || trim((string)sfy_config_get('set_support_discord', '')) !== ''): ?>
        <a class="btn btn-sm btn-primary" href="<?= sfy_esc(trim((string)$s['support_discord']) !== ''
            ? (string)$s['support_discord'] : (string)sfy_config_get('set_support_discord', '')) ?>"
           target="_blank" rel="noopener">💬 MESSAGE US YOUR RECEIPT</a>
      <?php endif; ?>
      <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_hub_url('contact', ['about' => (string)$order['reference']])) ?>">
        SEND A SUPPORT MESSAGE
      </a>
      <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_hub_url('scripts')) ?>">BACK TO SCRIPTS</a>
    </div>
  </div>

<?php else: ?>

  <div class="hub-buy">
    <div>
      <form class="hub-panel" method="POST" action="<?= sfy_esc(sfy_hub_url('buy', ['offer' => (string)$offer['slug']])) ?>"
            data-hub-once>
        <?= sfy_hub_form_fields() ?>
        <input type="hidden" name="action" value="order">
        <h2>Your details</h2>

        <div class="hub-form-row two">
          <div class="hub-field">
            <label for="b-name">Name or username</label>
            <input id="b-name" type="text" name="buyer_name" maxlength="96" required
                   value="<?= sfy_esc(sfy_hub_keep_get($keep, 'buyer_name')) ?>" placeholder="Who is buying?">
          </div>
          <div class="hub-field">
            <label for="b-contact">Email or Discord</label>
            <input id="b-contact" type="text" name="buyer_contact" maxlength="191" required
                   value="<?= sfy_esc(sfy_hub_keep_get($keep, 'buyer_contact')) ?>" placeholder="you@example.com or @you">
          </div>
        </div>

        <?php if ($methods): ?>
          <div class="hub-field">
            <label id="hub-pay-legend">How will you pay?</label>
            <div class="hub-paylist" role="radiogroup" aria-labelledby="hub-pay-legend">
              <?php foreach ($methods as $m): ?>
                <?= sfy_hub_pay_card($m, (string)$m['slug'] === $chosen) ?>
              <?php endforeach; ?>
            </div>
            <div class="hub-paypanels" data-hub-paypanels>
              <?php foreach ($methods as $m): ?>
                <?= sfy_hub_pay_detail($m, [
                        'on'    => (string)$m['slug'] === $chosen,
                        'saved' => (array)$keep,
                    ]) ?>
              <?php endforeach; ?>
            </div>
          </div>
        <?php endif; ?>

        <div class="hub-field">
          <label for="b-msg">Anything we should know? (optional)</label>
          <textarea id="b-msg" name="message" maxlength="2000"
                    placeholder="Preferred delivery time, a question, a note…"><?= sfy_esc(sfy_hub_keep_get($keep, 'message')) ?></textarea>
        </div>

        <?= sfy_hub_captcha_field() ?>

        <label class="hub-check" style="margin-bottom:14px">
          <input type="checkbox" required>
          <span>I understand nothing is charged on this site — I pay with the method above, and the key is handed over once the payment is confirmed.</span>
        </label>

        <button class="btn btn-gold btn-lg" type="submit" data-busy="SENDING…">
          ⚡ PLACE ORDER — <?= sfy_esc(sfy_hub_money($offer['price'], $cur)) ?>
        </button>
        <p class="hub-note" style="margin-top:10px"><?= sfy_esc((string)$s['buy_note']) ?></p>
      </form>

      <?php if (trim((string)$offer['description']) !== ''): ?>
        <section class="hub-panel">
          <h2>About this plan</h2>
          <div class="hub-prose-block"><?= sfy_esc((string)$offer['description']) ?></div>
        </section>
      <?php endif; ?>
    </div>

    <aside class="hub-rail">
      <section class="hub-rail-box">
        <div class="hub-rail-head">Your plan</div>
        <?= sfy_hub_offer_card($offer, true, ['buy' => false]) ?>
        <div class="hub-payfacts">
          <div class="hub-kv"><span>Delivery</span><span>By hand, once the payment shows</span></div>
        </div>
      </section>

      <section class="hub-rail-box">
        <div class="hub-rail-head">What happens next</div>
        <ol class="hub-steps">
          <li>You place the order and get a reference code.</li>
          <li>You pay with any method below and quote the code.</li>
          <li>An administrator confirms it and sends your key.</li>
        </ol>
        <?php if (trim((string)$offer['checkout_url']) !== ''): ?>
          <a class="btn btn-sm btn-block hub-mt" href="<?= sfy_esc((string)$offer['checkout_url']) ?>"
             target="_blank" rel="noopener">↗ PAY ON OUR CHECKOUT PAGE</a>
        <?php endif; ?>
        <?php if ($methods): ?>
          <div class="label" style="margin-top:14px">Methods</div>
          <ul class="hub-pays">
            <?php foreach ($methods as $m): ?>
              <li title="<?= sfy_esc((string)($m['summary'] ?? '')) ?>"><?= sfy_esc(sfy_hub_pay_icon($m)) ?> <?= sfy_esc((string)$m['name']) ?></li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </section>

      <?php if (!empty($s['nav_contact'])): ?>
        <section class="hub-rail-box">
          <div class="hub-rail-head">✉ Questions first?</div>
          <p class="hub-rail-p">Ask before you pay — nobody minds.</p>
          <a class="btn btn-sm btn-block btn-ghost" href="<?= sfy_esc(sfy_hub_url('contact')) ?>">CONTACT SUPPORT</a>
        </section>
      <?php endif; ?>
    </aside>
  </div>

<?php endif; ?>

<?php sfy_hub_page_end(); ?>
