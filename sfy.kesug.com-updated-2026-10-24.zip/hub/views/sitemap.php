<?php
declare(strict_types=1);
/**
 * The sitemap — /hub/?p=sitemap
 *
 * XML, not a page: no theme, no navbar, no markup. Served by the module's own
 * front controller because the folder deliberately ships no .htaccess (see
 * hub/index.php — replacing the parent's rules to win one pretty URL is a bad
 * trade), so `?p=sitemap` is the sitemap's address, and it is exactly the
 * address the panel's Diagnostics screen prints for robots.txt.
 *
 * What it lists is decided by sfy_hub_sitemap_urls(), which reads the same
 * queries the public pages do — a draft has no URL here for the same reason it
 * has none on the site.
 *
 * No output buffer is touched and nothing is flushed: the caller's buffer is
 * its own, and the render probe reads the document out of it.
 */

if (!headers_sent()) {
    /* A sitemap served as text/html is a sitemap a crawler ignores. */
    header('Content-Type: application/xml; charset=utf-8');
    header('X-Robots-Tag: noindex');
}

echo sfy_hub_sitemap_xml();
