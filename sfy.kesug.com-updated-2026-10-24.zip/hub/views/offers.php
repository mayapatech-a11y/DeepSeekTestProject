<?php
declare(strict_types=1);
/* Plans now live on the main /pricing page. */
sfy_redirect(sfy_url('pricing'));
exit;
/**
 * Offers — the premium plans.
 *
 * This is the page an advertisement for a "premium key" should point at: the
 * plans, the prices and the per-plan perks, nothing else. The ad manager's
 * target URL can be set to /hub/?p=offers (or to a single plan's buy page)
 * with no code change, and the same page is reachable from the hub navbar.
 */

$s       = sfy_hub_settings();
$offers  = sfy_hub_offers(true);
$methods = sfy_hub_payment_offered();

sfy_hub_page_start([
    'page'  => 'offers',
    'title' => 'Premium keys',
    'sub'   => (string)$s['shop_intro'],
    'pin'   => $offers
        ? ['url' => sfy_hub_url('buy', ['offer' => (string)$offers[0]['slug']]),
           'kind' => 'guide', 'icon' => '⚡', 'label' => 'BUY A KEY']
        : null,
]);
?>

<?php if (!$offers): ?>
  <div class="hub-empty">
    <b>No plans are on sale right now</b>
    <p>An administrator has not published an offer yet — check back shortly, or ask in support.</p>
    <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_hub_url('contact')) ?>">CONTACT SUPPORT</a>
  </div>
<?php else: ?>

  <div class="hub-offers">
    <?php foreach ($offers as $o) echo sfy_hub_offer_card($o); ?>
  </div>

  <section class="hub-panel" style="margin-top:var(--hub-gap)">
    <h2>How a purchase works here</h2>
    <div class="hub-prose-block"><?= sfy_esc((string)$s['buy_note']) ?></div>
    <ol class="hub-steps">
      <li><b>Pick a plan</b> — the buy page opens with it already selected.</li>
      <li><b>Send your details</b> — a name and a way to reach you. That is all we ask for.</li>
      <li><b>Get a reference code</b> — quote it when you pay so the order can be matched.</li>
      <li><b>Receive your key</b> — an administrator confirms and hands it over.</li>
    </ol>

    <?php if ($methods): ?>
      <div class="label" style="margin-top:16px">How you can pay</div>
      <div class="hub-paygrid">
        <?php foreach ($methods as $m) echo sfy_hub_pay_info($m); ?>
      </div>
    <?php endif; ?>

    <?php if (trim((string)$s['pay_instructions']) !== ''): ?>
      <div class="label" style="margin-top:16px">Payment instructions</div>
      <div class="hub-prose-block"><?= sfy_esc((string)$s['pay_instructions']) ?></div>
    <?php endif; ?>

    <div class="btn-row" style="margin-top:16px">
      <?php if (!empty($s['nav_contact'])): ?>
        <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_hub_url('contact')) ?>">TROUBLE BUYING? CONTACT SUPPORT</a>
      <?php endif; ?>
      <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_hub_url('scripts')) ?>">BROWSE FREE SCRIPTS</a>
    </div>
  </section>

<?php endif; ?>

<?php sfy_hub_page_end(); ?>
