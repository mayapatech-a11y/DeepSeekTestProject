<?php
declare(strict_types=1);
/* The main site now owns support requests: email + code + chat. */
sfy_redirect(sfy_url('support?category=other'));
exit;
/**
 * Contact support — the page the site's "Contact us" link points at.
 *
 * Deliberately a page, not a redirect into Discord: the visitor writes the
 * problem here first, in their own words, and the message is stored so it can
 * be answered even when nobody is online. The Discord invite is offered at
 * the end for anyone who would rather chat than read.
 */

$s      = sfy_hub_settings();
$kinds  = sfy_hub_message_kinds();
$about  = (string)sfy_param('about', '');
/* The games the hub already covers, which is what turns a support message
   into a categorised one: a report that says which game it is about can be
   filed under it in the inbox instead of being a wall of text in one queue. */
$games  = sfy_hub_games(80);

if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) === 'POST' && (string)sfy_param('action') === 'contact') {
    $guard = sfy_hub_guard('contact');
    if (!$guard['ok']) {
        sfy_hub_keep($_POST);
        sfy_hub_flash('err', $guard['error']);
        sfy_redirect(sfy_hub_url('contact'));
    }
    $res = sfy_hub_message_create([
        'kind'      => (string)sfy_param('kind', 'support'),
        'name'      => (string)sfy_param('name', ''),
        'contact'   => (string)sfy_param('contact', ''),
        'subject'   => (string)sfy_param('subject', ''),
        /* The picker and the free-text box are resolved in one place that can
           be tested without a browser: see sfy_hub_message_game(). */
        'game_name' => sfy_hub_message_game($_POST),
        'message'   => (string)($_POST['message'] ?? ''),
    ]);
    sfy_hub_flash($res['ok'] ? 'ok' : 'err',
        $res['ok'] ? 'Message received — an admin will see it in the inbox. Keep an eye on your contact address.'
                   : $res['error']);
    if (!$res['ok']) sfy_hub_keep($_POST);
    sfy_redirect(sfy_hub_url('contact'));
}

$keep = sfy_hub_keep_take();

sfy_hub_page_start([
    'page'  => 'contact',
    'title' => 'Contact support',
    'sub'   => 'Stuck on a script, a key or the site? Write it here and it lands in the admin inbox.',
    'pin'   => ['url' => sfy_hub_url('suggest'), 'kind' => 'guide', 'icon' => '🎮', 'label' => 'REQUEST A GAME'],
]);
?>

<?php if (empty($s['contact_enabled'])): ?>

  <div class="hub-empty">
    <b>Messages are paused right now</b>
    <p>The contact form is switched off. Try again later, or browse the scripts while you wait.</p>
    <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_hub_url('scripts')) ?>">BACK TO SCRIPTS</a>
  </div>

<?php else: ?>

  <div class="hub-buy">
    <div>
      <form class="hub-panel" method="POST" action="<?= sfy_esc(sfy_hub_url('contact')) ?>" data-hub-once>
        <?= sfy_hub_form_fields() ?>
        <input type="hidden" name="action" value="contact">
        <h2>Send a message</h2>

        <div class="hub-field">
          <label>What is this about?</label>
          <div class="hub-opt">
            <?php $i = 0; foreach ($kinds as $key => $def): if ($key === 'suggestion') continue; ?>
              <label>
                <input type="radio" name="kind" value="<?= sfy_esc($key) ?>"
                  <?= sfy_hub_keep_get($keep, 'kind') === $key || ($i === 0 && sfy_hub_keep_get($keep, 'kind') === '')
                      ? 'checked' : '' ?>>
                <?= $def['icon'] ?> <?= sfy_esc($def['label']) ?>
              </label>
            <?php $i++; endforeach; ?>
          </div>
        </div>

        <div class="hub-form-row two">
          <div class="hub-field">
            <label for="c-name">Name <span class="mute">(optional)</span></label>
            <input id="c-name" type="text" name="name" maxlength="96"
                   value="<?= sfy_esc(sfy_hub_keep_get($keep, 'name')) ?>" placeholder="What should we call you?">
          </div>
          <div class="hub-field">
            <label for="c-contact">Email or Discord</label>
            <input id="c-contact" type="text" name="contact" maxlength="191" required
                   value="<?= sfy_esc(sfy_hub_keep_get($keep, 'contact')) ?>" placeholder="you@example.com or @you">
          </div>
        </div>

        <div class="hub-form-row two">
          <div class="hub-field">
            <label for="c-game">Which game is this about?</label>
            <?php $keptGame = sfy_hub_keep_get($keep, 'game_name'); ?>
            <select id="c-game" name="game_name" data-hub-game>
              <option value="">Not game-specific</option>
              <?php foreach ($games as $g):
                $name = (string)($g['game_name'] ?? '');
                if ($name === '') continue; ?>
                <option value="<?= sfy_esc($name) ?>" <?= strcasecmp($name, $keptGame) === 0 ? 'selected' : '' ?>>
                  <?= sfy_esc($name) ?><?= (int)($g['n'] ?? 0) > 0 ? ' (' . (int)$g['n'] . ')' : '' ?></option>
              <?php endforeach; ?>
              <option value="__other" <?= $keptGame !== '' && !array_filter($games, fn($g) => strcasecmp((string)($g['game_name'] ?? ''), $keptGame) === 0) ? 'selected' : '' ?>>
                Another game — type it beside this</option>
            </select>
          </div>
          <div class="hub-field" data-hub-game-other>
            <label for="c-game-custom">…or type the game</label>
            <input id="c-game-custom" type="text" name="game_custom" maxlength="120"
                   value="<?= sfy_esc(sfy_hub_keep_get($keep, 'game_custom')) ?>"
                   placeholder="Blox Fruits, or the script's name">
            <div class="hint">Whatever is here becomes the category this message is filed under in the inbox —
              the hub's own games come from the picker, anything else from this box.</div>
          </div>
        </div>

        <div class="hub-field">
          <label for="c-subject">Subject</label>
          <input id="c-subject" type="text" name="subject" maxlength="191"
                 value="<?= sfy_esc(sfy_hub_keep_get($keep, 'subject', $about)) ?>"
                 placeholder="Script name, game, or a one-line summary">
        </div>

        <div class="hub-field">
          <label for="c-message">Message</label>
          <textarea id="c-message" name="message" maxlength="8000" required
                    placeholder="What happened, which script, which game, which executor…"><?= sfy_esc(sfy_hub_keep_get($keep, 'message')) ?></textarea>
        </div>

        <?= sfy_hub_captcha_field() ?>

        <button class="btn btn-primary btn-lg" type="submit" data-busy="SENDING…">✉ SEND TO SUPPORT</button>
        <p class="hub-note" style="margin-top:10px"><?= sfy_esc((string)$s['support_note']) ?></p>
      </form>
    </div>

    <aside class="hub-rail">
      <section class="hub-rail-box">
        <div class="hub-rail-head">What to include</div>
        <ol class="hub-steps">
          <li>The script or game name — a link is even better.</li>
          <li>What you expected, and what actually happened.</li>
          <li>Your executor (Delta, Solara, Xeno…) if it is a code problem.</li>
          <li>Your reference code if the message is about a key order.</li>
        </ol>
      </section>

      <?php $discord = trim((string)$s['support_discord']) !== ''
          ? (string)$s['support_discord'] : trim((string)sfy_config_get('set_support_discord', '')); ?>
      <?php if ($discord !== '' || trim((string)$s['support_email']) !== ''): ?>
        <section class="hub-rail-box">
          <div class="hub-rail-head">Prefer to talk?</div>
          <?php if (trim((string)$s['support_email']) !== ''): ?>
            <p class="hub-rail-p">Email: <a href="mailto:<?= sfy_esc((string)$s['support_email']) ?>"><?= sfy_esc((string)$s['support_email']) ?></a></p>
          <?php endif; ?>
          <?php if ($discord !== ''): ?>
            <a class="btn btn-sm btn-block btn-ghost hub-mt" href="<?= sfy_esc($discord) ?>"
               target="_blank" rel="noopener">💬 OPEN THE DISCORD</a>
            <p class="hub-note" style="margin-top:8px">Discord is faster if someone is around — the form above is
              answered either way.</p>
          <?php endif; ?>
        </section>
      <?php endif; ?>

      <?php if (!empty($s['nav_suggest'])): ?>
        <section class="hub-rail-box">
          <div class="hub-rail-head">🎮 Want a game added?</div>
          <p class="hub-rail-p">Use the request page — suggestions get their own queue.</p>
          <a class="btn btn-sm btn-block" href="<?= sfy_esc(sfy_hub_url('suggest')) ?>">REQUEST A GAME</a>
        </section>
      <?php endif; ?>
    </aside>
  </div>

<?php endif; ?>

<?php sfy_hub_page_end(); ?>
