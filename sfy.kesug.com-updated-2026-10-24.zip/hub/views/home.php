<?php
declare(strict_types=1);
/**
 * Hub home — the "welcome" landing page of the module.
 *
 * This is *not* the site's index. It is a separate page, reachable from the
 * main site's header and footer, that answers one question: which games and
 * scripts does SFY support right now? So it opens with the count, then gets
 * out of the way and shows the grid.
 */

$s = sfy_hub_settings();
$f = sfy_hub_filters();

/* Cheap numbers, and every one of them tolerated being unavailable: a fresh
   install has no rows and must still render. */
$scripts = sfy_hub_scripts_count(['status' => 'published']);
$games   = count(sfy_hub_games(60));
$plans   = count(sfy_hub_offers(true));
$stats   = sfy_hub_order_stats();
$delivered = (int)($stats['delivered'] ?? 0);

sfy_hub_page_start([
    'page' => 'home',
    // On a phone the pinned bar is the fastest route to the thing we sell.
    'pin'  => !empty($s['nav_offers'])
        ? ['url' => sfy_hub_url('offers'), 'kind' => 'guide', 'icon' => '⚡', 'label' => 'GET PREMIUM KEY']
        : null,
]);
?>

<section class="hub-hero">
  <div class="hub-hero-l">
    <h1 class="hub-h1"><?= sfy_esc((string)$s['title'] !== '' ? (string)$s['title'] : 'Script library') ?></h1>
    <p class="hub-sub"><?= sfy_esc((string)$s['tagline']) ?></p>
    <div class="hub-hero-cta">
      <a class="btn btn-primary" href="<?= sfy_esc(sfy_hub_url('scripts')) ?>">▶ BROWSE ALL SCRIPTS</a>
      <?php if (!empty($s['nav_offers'])): ?>
        <a class="btn btn-gold" href="<?= sfy_esc(sfy_hub_url('offers')) ?>">⚡ SKIP THE TASKS</a>
      <?php endif; ?>
      <?php if (!empty($s['nav_suggest'])): ?>
        <a class="btn btn-ghost" href="<?= sfy_esc(sfy_hub_url('suggest')) ?>">🎮 REQUEST A GAME</a>
      <?php endif; ?>
    </div>
    <div class="hub-hero-stats">
      <span><b><?= number_format($scripts) ?></b> scripts</span>
      <span><b><?= number_format($games) ?></b> games</span>
      <?php if ($plans > 0): ?><span><b><?= number_format($plans) ?></b> premium plans</span><?php endif; ?>
      <?php if ($delivered > 0): ?><span><b><?= number_format($delivered) ?></b> keys delivered</span><?php endif; ?>
    </div>
  </div>
  <div class="hub-hero-r">
    <form class="hub-hero-search" method="get" action="<?= sfy_esc(sfy_url('hub/')) ?>" role="search">
      <input type="hidden" name="p" value="scripts">
      <label class="label" for="hub-home-q">Find a script</label>
      <div class="hub-hero-search-row">
        <input id="hub-home-q" type="search" name="q" value="<?= sfy_esc((string)$f['q']) ?>"
               placeholder="Game name, script, tag…" autocomplete="off">
        <button class="btn btn-primary" type="submit">SEARCH</button>
      </div>
    </form>
    <div class="hub-hero-links">
      <?php foreach (sfy_hub_games(6) as $g): ?>
        <a class="hub-chip hub-chip-game" href="<?= sfy_esc(sfy_hub_url('scripts', ['game' => (string)$g['game_name']])) ?>">
          <?= sfy_esc(sfy_short((string)$g['game_name'], 22)) ?> <b><?= (int)$g['n'] ?></b>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<div class="hub-head">
  <h2 class="hub-h2"><?= sfy_esc((string)$s['home_heading']) ?></h2>
  <p class="hub-sub"><?= sfy_esc((string)$s['home_sub']) ?></p>
</div>

<?= sfy_hub_listing($f, ['notice' => true]) ?>

<?php sfy_hub_page_end(); ?>
