<?php
declare(strict_types=1);
/**
 * Payment callback — the one public endpoint that writes without a form.
 *
 *   POST /hub/?p=webhook&method=<slug>
 *
 * A wallet or a hosted checkout cannot confirm itself, so an admin reads the
 * receipt and marks the order paid. A *gateway* method can: the provider is
 * told where to POST (the panel prints the exact URL), and when it does, the
 * order turns PAID on its own.
 *
 * Three things make that safe enough to expose:
 *
 *   • the body must carry an HMAC-SHA256 of itself, in
 *     `X-SFY-Signature: sha256=<hex>`, signed with that method's webhook
 *     secret. No secret, no verification, no change — an unsigned or wrongly
 *     signed call is refused with 401 and does nothing at all.
 *   • the callback is matched to an *existing* order by reference, and the
 *     method it names must be the method that order used.
 *   • if the callback states an amount, it has to match the plan (a 50-cent
 *     "payment" must not buy a 4-dollar key).
 *
 * It answers JSON and never HTML: nothing here is a page, and a provider that
 * gets a login screen or a template error back cannot tell whether to retry.
 * Every answer is 2xx when the call was understood — including "already paid",
 * so a retrying provider stops retrying.
 */

$raw    = sfy_hub_payment_body();
$slug   = (string)sfy_param('method', '');
$method = sfy_hub_payment_by_slug($slug);

if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'POST') {
    sfy_json(['ok' => false, 'error' => 'POST a signed payload to this URL.'], 405);
}
if (!$method) {
    sfy_json(['ok' => false, 'error' => 'Unknown payment method.'], 404);
}
/* Callbacks arrive in bursts after a drop; a provider that hammers this gets
   rate-limited rather than allowed to fill the log. */
if (!sfy_rate_limit('hub-webhook-' . sfy_client_ip(), 120, 60)) {
    sfy_json(['ok' => false, 'error' => 'Too many callbacks — slow down.'], 429);
}

$verify = sfy_hub_payment_verify($raw, $method, $_SERVER, $_POST);
if (empty($verify['ok'])) {
    sfy_audit('hub_payment_callback_reject', '', ['method' => $slug, 'why' => (string)$verify['why']]);
    sfy_json(['ok' => false, 'error' => (string)$verify['why']], 401);
}

$payload = sfy_hub_payment_payload($raw);
$result  = sfy_hub_payment_confirm($method, $payload, $raw);

sfy_audit('hub_payment_callback', (string)($result['order']['reference'] ?? ''),
          ['method' => $slug, 'status' => (string)$result['status']]);

if (empty($result['ok'])) {
    /* 'already' is not a failure: it is a provider retrying a callback this
       module has already acted on, so it is answered with a 200 below. */
    $code = in_array((string)$result['status'], ['unknown'], true) ? 404 : 422;
    sfy_json(['ok' => false, 'status' => (string)$result['status'], 'error' => (string)$result['error']], $code);
}

sfy_json([
    'ok'        => true,
    'status'    => (string)$result['status'],
    'reference' => (string)($result['order']['reference'] ?? ''),
    'order'     => (string)($result['order']['status'] ?? ''),
], 200);
