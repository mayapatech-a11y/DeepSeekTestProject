<?php
declare(strict_types=1);
/* The main site now owns requests: email + unique code + chat. */
sfy_redirect(sfy_url('support?category=game'));
exit;
/**
 * Request a game — the game-suggestion form.
 *
 * Same inbox as the support page, different row: the game name is required
 * here, and the panel filters the two apart. Suggestions are also shown back
 * to the visitor (recent asks) so a request that has already been made is
 * visible instead of being sent five more times.
 */

$s = sfy_hub_settings();

if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) === 'POST' && (string)sfy_param('action') === 'suggest') {
    $guard = sfy_hub_guard('suggest');
    if (!$guard['ok']) {
        sfy_hub_keep($_POST);
        sfy_hub_flash('err', $guard['error']);
        sfy_redirect(sfy_hub_url('suggest'));
    }
    $game = (string)sfy_param('game_name', '');
    $res  = sfy_hub_message_create([
        'kind'      => 'suggestion',
        'name'      => (string)sfy_param('name', ''),
        'contact'   => (string)sfy_param('contact', ''),
        'game_name' => $game,
        'subject'   => 'Add ' . ($game !== '' ? $game : 'a game'),
        'message'   => (string)($_POST['message'] ?? ''),
    ]);
    sfy_hub_flash($res['ok'] ? 'ok' : 'err',
        $res['ok'] ? 'Thanks — "' . $game . '" is in the queue. We will post the script when it is ready.'
                   : $res['error']);
    if (!$res['ok']) sfy_hub_keep($_POST);
    sfy_redirect(sfy_hub_url('suggest'));
}

$keep = sfy_hub_keep_take();

/* Recent asks, so the same game is not requested ten times. Only the game
   name and the age are shown — this is a public page, and what somebody
   wrote to support is not. */
$recent = sfy_hub_messages(['kind' => 'suggestion'], 1, 8);

sfy_hub_page_start([
    'page'  => 'suggest',
    'title' => 'Request a game',
    'sub'   => 'Tell us the game and we will look at adding a script for it.',
    'pin'   => ['url' => sfy_hub_url('scripts'), 'kind' => 'guide', 'icon' => '🎮', 'label' => 'BROWSE SCRIPTS'],
]);
?>

<?php if (empty($s['suggest_enabled'])): ?>

  <div class="hub-empty">
    <b>Suggestions are paused right now</b>
    <p>The request form is switched off. Send a support message instead and we will still read it.</p>
    <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_hub_url('contact')) ?>">CONTACT SUPPORT</a>
  </div>

<?php else: ?>

  <div class="hub-buy">
    <div>
      <form class="hub-panel" method="POST" action="<?= sfy_esc(sfy_hub_url('suggest')) ?>" data-hub-once>
        <?= sfy_hub_form_fields() ?>
        <input type="hidden" name="action" value="suggest">
        <h2>Which game?</h2>

        <div class="hub-field">
          <label for="s-game">Game name</label>
          <input id="s-game" type="text" name="game_name" maxlength="191" required list="hub-known-games"
                 value="<?= sfy_esc(sfy_hub_keep_get($keep, 'game_name')) ?>"
                 placeholder="e.g. Blox Fruits, Rivals, Showdown…">
          <datalist id="hub-known-games">
            <?php foreach (sfy_hub_games(40) as $g): ?>
              <option value="<?= sfy_esc((string)$g['game_name']) ?>"></option>
            <?php endforeach; ?>
          </datalist>
          <p class="hub-note">Already listed above? Click the game in the list to reuse its exact name.</p>
        </div>

        <div class="hub-form-row two">
          <div class="hub-field">
            <label for="s-name">Name <span class="mute">(optional)</span></label>
            <input id="s-name" type="text" name="name" maxlength="96"
                   value="<?= sfy_esc(sfy_hub_keep_get($keep, 'name')) ?>" placeholder="What should we call you?">
          </div>
          <div class="hub-field">
            <label for="s-contact">Email or Discord</label>
            <input id="s-contact" type="text" name="contact" maxlength="191" required
                   value="<?= sfy_esc(sfy_hub_keep_get($keep, 'contact')) ?>"
                   placeholder="you@example.com or @you">
          </div>
        </div>

        <div class="hub-field">
          <label for="s-message">What should the script do?</label>
          <textarea id="s-message" name="message" maxlength="8000" required
                    placeholder="Anything specific you need — aimbot, ESP, auto farm…"><?= sfy_esc(sfy_hub_keep_get($keep, 'message')) ?></textarea>
        </div>

        <?= sfy_hub_captcha_field() ?>

        <button class="btn btn-primary btn-lg" type="submit" data-busy="SENDING…">🎮 SEND REQUEST</button>
        <p class="hub-note" style="margin-top:10px">
          Suggestions are read by an administrator. If a script gets made, it appears in the library.
        </p>
      </form>
    </div>

    <aside class="hub-rail">
      <section class="hub-rail-box">
        <div class="hub-rail-head">🎮 Recently requested</div>
        <?php if (!$recent): ?>
          <p class="hub-rail-p">No requests yet — yours would be the first.</p>
        <?php else: ?>
          <?php foreach ($recent as $r): ?>
            <div class="hub-top-row" style="cursor:default">
              <span class="hub-top-m">
                <span class="hub-top-t"><?= sfy_esc(sfy_short((string)($r['game_name'] !== '' ? $r['game_name'] : $r['subject']), 30)) ?></span>
                <span class="hub-top-s"><?= sfy_esc(sfy_ago((string)$r['created_at'])) ?></span>
              </span>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </section>

      <section class="hub-rail-box">
        <div class="hub-rail-head">Before you send</div>
        <ol class="hub-steps">
          <li>Search the library first — it may already be there.</li>
          <li>One game per request keeps the queue readable.</li>
          <li>Leave a contact address if you want a reply.</li>
        </ol>
        <a class="btn btn-sm btn-block btn-ghost hub-mt" href="<?= sfy_esc(sfy_hub_url('scripts')) ?>">SEARCH THE LIBRARY</a>
      </section>
    </aside>
  </div>

<?php endif; ?>

<?php sfy_hub_page_end(); ?>
