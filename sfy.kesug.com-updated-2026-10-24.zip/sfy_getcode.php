<?php
declare(strict_types=1);
/** Legacy path → /out/<session> (pages/code.php). */
require __DIR__ . '/pages/code.php';
