<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/app/core.php';
header('Cache-Control: no-store, max-age=0, must-revalidate');

if (!sfy_pricing_enabled() && sfy_param('preview') !== '1') {
    sfy_redirect(sfy_url(''));
    exit;
}
$cfg      = sfy_pricing_config();
$plans    = array_values(array_filter($cfg['plans'], fn($p) => !empty($p['enabled'])));
$payments = $cfg['payments'];
$pp       = sfy_premium_copy();
$support  = sfy_setting_text('support_discord');
$periods  = sfy_pricing_periods();
$byPeriod = [];
foreach ($plans as $plan) $byPeriod[(string)($plan['period'] ?? 'instant')][] = $plan;
$active   = (string)sfy_param('billing', 'instant');
if (!isset($periods[$active]) || empty($byPeriod[$active])) {
    $active = '';
    foreach ($periods as $k => $lbl) { if (!empty($byPeriod[$k])) { $active = $k; break; } }
}
$page     = 'pricing';

sfy_head(['title' => 'Plans & pricing', 'page' => $page]);
?>
<div class="shell">
  <?= sfy_ad_slot('top', $page) ?>

  <section class="pricing-hero">
    <span class="badge y">PLANS</span>
    <h1><?= sfy_esc((string)$cfg['title']) ?></h1>
    <p><?= sfy_esc((string)$cfg['intro']) ?></p>
    <div class="pricing-chips">
      <?php foreach (array_slice($pp['bullets'], 0, 4) as $b): ?>
        <span>✓ <?= sfy_esc($b) ?></span>
      <?php endforeach; ?>
    </div>
  </section>

  <div class="pricing-tabs" role="tablist" aria-label="Billing period">
    <?php foreach ($periods as $key => $label): if (empty($byPeriod[$key])) continue; ?>
      <button type="button" class="pricing-tab<?= $active === $key ? ' active' : '' ?>" data-pricing-tab="<?= sfy_esc($key) ?>" role="tab" aria-selected="<?= $active === $key ? 'true' : 'false' ?>"><?= sfy_esc(strtoupper($label)) ?></button>
    <?php endforeach; ?>
  </div>

  <?php foreach ($periods as $key => $label): if (empty($byPeriod[$key])) continue; ?>
    <div class="pricing-panel<?= $active === $key ? ' active' : '' ?>" data-pricing-panel="<?= sfy_esc($key) ?>">
      <div class="pricing-grid">
        <?php foreach ($byPeriod[$key] as $plan): $suffix = $key === 'weekly' ? 'per week' : ($key === 'monthly' ? 'per month' : 'one-time'); ?>
          <article class="pricing-card<?= !empty($plan['featured']) ? ' featured' : '' ?>">
            <?php if (!empty($plan['featured'])): ?><span class="pricing-flag">BEST VALUE</span><?php endif; ?>
            <div class="pricing-name"><?= sfy_esc((string)$plan['name']) ?></div>
            <div class="pricing-price"><span>$</span><?= sfy_esc(rtrim(rtrim(number_format((float)$plan['price'], 2, '.', ''), '0'), '.')) ?></div>
            <div class="pricing-days"><?= sfy_esc($suffix) ?> · <?= (int)$plan['days'] ?> day<?= (int)$plan['days'] === 1 ? '' : 's' ?></div>
            <?php if ((float)($plan['savings'] ?? 0) > 0): ?><span class="pricing-save">SAVE $<?= sfy_esc(rtrim(rtrim(number_format((float)$plan['savings'], 2, '.', ''), '0'), '.')) ?></span><?php endif; ?>
            <p class="pricing-note"><?= sfy_esc((string)$plan['note']) ?></p>
            <ul class="pricing-perks">
              <?php foreach (array_slice($pp['bullets'], 0, 4) as $b): ?><li><span>✓</span><?= sfy_esc($b) ?></li><?php endforeach; ?>
            </ul>
            <a class="btn <?= !empty($plan['featured']) ? 'btn-gold' : 'btn-primary' ?> btn-block" href="#payments" data-plan="<?= sfy_esc((string)$plan['id']) ?>">CHOOSE <?= sfy_esc(strtoupper((string)$plan['name'])) ?></a>
          </article>
        <?php endforeach; ?>
      </div>
    </div>
  <?php endforeach; ?>
  <?php if (!$plans): ?><div class="empty">No plans are enabled right now.</div><?php endif; ?>

  <section class="pricing-section" id="payments">
    <div class="pricing-section-head">
      <div><span class="eyebrow">PAYMENT</span><h2>Complete your payment</h2>
        <p>Choose a plan above, then use one of the methods below. Include your token or account email in the payment note.</p></div>
      <?php if ($support !== ''): ?><a class="btn btn-ghost" href="<?= sfy_esc($support) ?>" target="_blank" rel="noopener">CONTACT SUPPORT</a><?php endif; ?>
    </div>
    <div class="payment-grid">
      <?php foreach ($payments as $m): $url = trim((string)$m['url']); $isUrl = (bool)preg_match('~^https?://~i', $url); ?>
        <?php if ($url !== '' && $isUrl): ?>
          <a class="payment-card" href="<?= sfy_esc($url) ?>" target="_blank" rel="noopener">
            <strong><?= sfy_esc((string)$m['label']) ?></strong>
            <span><?= sfy_esc((string)$m['note']) ?></span>
            <em>OPEN PAYMENT →</em>
          </a>
        <?php elseif ($url !== ''): ?>
          <div class="payment-card">
            <strong><?= sfy_esc((string)$m['label']) ?></strong>
            <span><?= sfy_esc((string)$m['note']) ?></span>
            <span class="mono" style="font-size:10px;word-break:break-all"><?= sfy_esc($url) ?></span>
            <em>WALLET / ADDRESS</em>
          </div>
        <?php else: ?>
          <div class="payment-card off">
            <strong><?= sfy_esc((string)$m['label']) ?></strong>
            <span><?= sfy_esc((string)$m['note']) ?></span>
            <em>SETUP COMING SOON</em>
          </div>
        <?php endif; ?>
      <?php endforeach; ?>
      <?php if (!$payments): ?><div class="empty">No payment methods configured yet.</div><?php endif; ?>
    </div>
    <div class="pricing-fine">Payments are activated after the transfer is confirmed. Keep your receipt and include your token in the note. Plans are time-limited access, not a subscription.</div>
  </section>

  <section class="pricing-section">
    <div class="pricing-section-head"><div><span class="eyebrow">INCLUDED</span><h2>What every plan includes</h2></div></div>
    <div class="pricing-benefits">
      <?php foreach ($pp['bullets'] as $b): ?><div><span>✓</span><?= sfy_esc($b) ?></div><?php endforeach; ?>
    </div>
  </section>

  <section class="pricing-section pricing-faq">
    <div class="pricing-section-head"><div><span class="eyebrow">FAQ</span><h2>Before you pay</h2></div></div>
    <details><summary>How is access delivered?</summary><p>After the payment is confirmed, support activates the plan for the token or account you include in the payment note.</p></details>
    <details><summary>Do plans replace the task flow?</summary><p>Yes. While a plan is active, you skip the task steps and go straight to your code.</p></details>
    <details><summary>Can I use a plan on more than one device?</summary><p>Plans follow the account or token you purchase them for. Use the same token when you open the code.</p></details>
    <details><summary>Are refunds available?</summary><p>Contact support before paying if you are unsure. Digital access is activated after payment and is generally non-refundable once used.</p></details>
  </section>

  <?= sfy_ad_slot('bottom', $page) ?>
</div>
<script>
(function(){
  var tabs = document.querySelectorAll('[data-pricing-tab]');
  var panels = document.querySelectorAll('[data-pricing-panel]');
  tabs.forEach(function(tab){
    tab.addEventListener('click', function(){
      var key = tab.getAttribute('data-pricing-tab');
      tabs.forEach(function(t){
        var on = t === tab;
        t.classList.toggle('active', on);
        t.setAttribute('aria-selected', on ? 'true' : 'false');
      });
      panels.forEach(function(p){
        p.classList.toggle('active', p.getAttribute('data-pricing-panel') === key);
      });
    });
  });
})();
</script>
<?php sfy_foot(['page' => $page]); ?>