<?php
declare(strict_types=1);
/**
 * /done — the page every task link lands back on.
 *
 * It never advances a step by itself. It looks at what the *verified* signal
 * did (the signed postback that /api/hook recorded) and, when the provider's
 * postback cannot reach this install at all, it falls back to the return
 * check: the player must have clicked into the task and stayed away for at
 * least `return_dwell_seconds`, which the server tracks itself.
 *
 * This page is also the only thing that may record a return
 * (`sfy_step_tokens.returned_at`), and only when the request itself proves the
 * provider sent the player here — a cross-site document navigation from a
 * provider host. Typing this URL, bookmarking it or fetching it from the
 * console therefore confirms nothing: see sfy_return_landing_evidence().
 */
require_once dirname(__DIR__) . '/app/core.php';

sfy_install_if_empty();

$sid  = sfy_param('sid');
$page = 'task';
/* The per-run return ticket. It rides ONLY inside the encrypted `&data=`
   destination, so a landing that carries one came through LootLabs. */
$rt   = trim((string)sfy_param('rt'));

if ($sid !== '' && !preg_match('/^[a-f0-9]{16,64}$/i', $sid)) $sid = '';
$sess = $sid !== '' ? sfy_load_session($sid) : null;
/*
 * A landing that names a session still has to *be* that device's landing.
 * The session id travels in the player's own task URL, so without this a
 * browser on the same network (or a copied link) could record the provider
 * return for somebody else's unfinished step. A sid that is not this device's
 * falls back to the normal resolution — its own cookie, or its own
 * identity-checked session — instead of being trusted.
 */
if ($sess && !sfy_session_belongs_here($sess)) $sess = null;
if (!$sess) $sess = sfy_resolve_current_session();
/*
 * A landing that carries the ticket names its own step, so the session can be
 * found even when the cookie is missing — a provider redirect that opened a
 * fresh context. The ticket is trusted for nothing else: the gate below still
 * checks it against the step's own row, and the step still has to pass every
 * other rule (dwell, landing evidence, single use).
 */
if (!$sess && $rt !== '') {
    $tRow = sfy_return_ticket_step($rt);
    if ($tRow) {
        $cand = sfy_load_session((string)$tRow['session_id']);
        if ($cand && sfy_session_belongs_here($cand)) $sess = $cand;
    }
}

if (!$sess) {
    sfy_head(['title' => 'Waiting for your task', 'page' => $page, 'noindex' => true]);
    ?>
    <div class="shell">
      <?= sfy_ad_slot('top', $page) ?>
      <div class="card brk" style="--accent:#FFCB3D">
        <div class="card-head"><h1>&gt; NO TASK IN PROGRESS</h1></div>
        <p class="dim" style="margin:0 0 12px">
          There is no unfinished verification on this browser. Start again from your token — paste it on the
          home page and the tasks will be waiting for you.
        </p>
        <div class="btn-row">
          <a class="btn btn-primary btn-lg" href="<?= sfy_esc(sfy_url('')) ?>">▶ START WITH A TOKEN</a>
          <a class="btn" href="<?= sfy_esc(sfy_url('tutorial')) ?>">📖 HOW IT WORKS</a>
        </div>
      </div>
      <?= sfy_ad_slot('banner', $page) ?>
      <?= sfy_ad_slot('bottom', $page) ?>
    </div>
    <?= sfy_ad_slot('popup', $page) ?>
    <?php sfy_foot(['page' => $page]); ?>
    <?php
    exit;
}

$sid    = (string)$sess['session_id'];

/* If the relay is configured, collect any postback waiting there before the
   page decides what the verified signal did. A verified postback clears the
   flags, so this must run before the hard block. */
if (function_exists('sfy_relay_pull')) {
    sfy_relay_pull();
    $sess = sfy_load_session($sid) ?: $sess;
}

/* Hard block: a flagged run cannot record a landing or advance a step. */
sfy_bypass_block_page($sess, 'task');

$start  = time();
$waited = 0;
$rc     = sfy_return_check_state();
$soft   = null;

/*
 * Is this really the provider landing the player back, or just a visit to a
 * URL someone knows? Only the first may stand in for a postback, so the
 * landing is recorded and the step is looked at *only* when the browser says
 * the player arrived from the task. Everything else is refused (and logged for
 * the admin) — that is what makes "change the task URL to /done" useless.
 */
$landing = sfy_return_landing_evidence();

/*
 * The ticket gate, before anything is recorded.
 *
 * This page used to be the same fixed address for every visitor, guarded only
 * by the browser's own headers — which a bypass service reproduces by stripping
 * the referrer, or by calling it from a server. So the ticket is checked first:
 * when this step was handed off through the encrypted destination it can only be
 * confirmed by a landing that presents the ticket that handoff minted. It is
 * validated and burned here, which is what lets the dwell run out afterwards —
 * the step remembers the ticket WAS presented, so the status poll that finishes
 * the confirmation does not have to carry it again.
 */
$ticketWhy = '';
$stepRow   = null;
if (!empty($rc['active'])) {
    $stepRow = sfy_step_open($sid, max(1, (int)($sess['current_step'] ?? 1)));
}
if (!empty($rc['active']) && !empty($rc['require_ticket'])) {
    if ($stepRow && trim((string)($stepRow['return_ticket'] ?? '')) !== ''
        && empty($stepRow['return_ticket_used_at'])) {
        $tr = sfy_return_ticket_present($stepRow, $rt);
        /*
         * `ticket_used` is not a fresh refusal: it means THIS run already
         * presented it (the player landed, the landing was recorded, and they
         * are back — a reload, the Back button, a slow redirect). The step
         * already remembers that, so it falls through to the ordinary path
         * instead of being answered with a message about somebody else's link.
         */
        if (empty($tr['ok']) && ($tr['reason'] ?? '') !== 'ticket_used') {
            $ticketWhy = (string)($tr['reason'] ?? 'ticket_missing');
        }
    }
}

/*
 * P1-1 / P1-2 (2026-10-24): a step that carries a return ticket is only
 * confirmed by the browser the handoff was issued to (the HttpOnly cookie set
 * on /go) and from the network it was issued to (the connection address, never
 * a query parameter). A resolver holds the destination URL but neither of these.
 */
if (!empty($rc['active']) && $stepRow
    && (bool)sfy_cfg('security.landing_bind', true)
    && trim((string)($stepRow['return_ticket'] ?? '')) !== '') {
    if (!sfy_step_cookie_ok($sid, (int)$stepRow['step'], (string)$stepRow['nonce'])) {
        $ticketWhy = 'no_handoff_cookie';
    } elseif (trim((string)($stepRow['issued_ip'] ?? '')) !== ''
           && !sfy_ip_same_net((string)$stepRow['issued_ip'], sfy_client_ip())) {
        $ticketWhy = 'landing_ip_mismatch';
    }
}

if (!empty($rc['active'])) {
    if ($ticketWhy !== '') {
        /* The landing did not carry this step's ticket. Refused and recorded
           (deduped to one row a minute) so the owner can see it happen. */
        if ((bool)sfy_cfg('security.show_bypass_warning', false)
            && in_array($ticketWhy, ['ticket_missing', 'ticket_invalid', 'no_handoff_cookie'], true)
            && (int)($sess['bypass_flags'] ?? 0) === 0) {
            sfy_session_flag($sid, 'bypass_' . $ticketWhy, 30);
            $sess['bypass_flags'] = max(1, (int)($sess['bypass_flags'] ?? 0) + 1);
        }
        if ((int)($sess['is_completed'] ?? 0) !== 1) {
            sfy_log_return_reject($sid, $sess, $ticketWhy, $rt !== '' ? 'ticket' : 'no-ticket');
        }
        $soft = ['ok' => false, 'reason' => $ticketWhy];
        error_log('[SFY] /done ticket refused for session ' . $sid . ': ' . $ticketWhy
                  . ' (ticket ' . ($rt !== '' ? 'present but not this step\'s' : 'absent') . ')');
    } elseif (empty($rc['require_provider']) || !empty($landing['ok'])) {
        /* The player is back from the task — remember that, and let the return
           check look at it (it is a no-op while real postbacks are arriving). */
        sfy_step_mark_returned($sid, max(1, (int)($sess['current_step'] ?? 1)));
        /* Guarded: this page must always render. A failed write is reported to
           the player as "retry this step" — never as a 500 they cannot act on. */
        $soft = sfy_try(function () use ($sid) { return sfy_step_advance_soft($sid, 'return'); },
                        ['ok' => false, 'reason' => 'error']);
        if (is_array($soft) && empty($soft['ok']) && ($soft['reason'] ?? '') === 'write_failed') {
            error_log('[SFY] /done write_failed: ' . (string)($soft['detail'] ?? ''));
        }
    } elseif ((int)($sess['is_completed'] ?? 0) !== 1) {
        /* A visit we do not believe — a typed URL, our own link, a console
           fetch. Refused, explained, and recorded for the admin (deduped). */
        if ((bool)sfy_cfg('security.show_bypass_warning', false)
            && ($landing['why'] ?? '') === 'blocked_referrer'
            && (int)($sess['bypass_flags'] ?? 0) === 0) {
            sfy_session_flag($sid, 'bypass_blocked_referrer', 30);
            $sess['bypass_flags'] = max(1, (int)($sess['bypass_flags'] ?? 0) + 1);
        }
        sfy_log_return_reject($sid, $sess, (string)$landing['why'], (string)$landing['referer_host']);
        $soft = ['ok' => false, 'reason' => 'no_provider_return', 'landing' => (string)$landing['why']];
        error_log('[SFY] /done landing refused for session ' . $sid . ': ' . $landing['why']
                  . ' (site=' . $landing['site'] . ', referer=' . $landing['referer_host'] . ')');
    }
}

/* Give a real postback a moment to land before deciding. This used to block
   for ten seconds — which meant ten seconds of a page that had not rendered at
   all, and players reading that as a stall or a refresh. The poll below picks
   up anything later, so a short check is all that is useful here. */
$watchSeconds = 3;
while (time() - $start < $watchSeconds) {
    $fresh = sfy_load_session($sid);
    if (!$fresh) break;
    $sess = $fresh;
    if ((int)($sess['is_completed'] ?? 0) === 1 || (int)($sess['current_step'] ?? 1) > 1) break;
    usleep(700000);
    $waited++;
}

$step  = max(1, (int)($sess['current_step'] ?? 1));
$total = max(1, (int)($sess['total_steps'] ?? 1));

if ((int)($sess['is_completed'] ?? 0) === 1 || $step > $total) {
    sfy_redirect(sfy_url('out/' . urlencode($sid)));
}

/*
 * The step the player came back for is confirmed — go straight to what's next.
 *
 * There is nothing left to read on this page in that case, and the card that
 * used to be rendered here asked for one more tap to reach a page the server
 * already knew how to open: a redundant click between every pair of tasks, and
 * an extra page in the history for every step. The redirect puts the flow's own
 * URL in the address bar (`/go/<session>`), where the next step, its hand-off
 * and the reset button already live.
 *
 * From step 2 on, that page opens with the confirmation card — "mission
 * accomplished", and one button — and *its* button carries the continuation
 * (`?zt=1` while the zero-tap flow is on), so the hand-off is still issued at
 * the moment the player presses through to the task. Landing on a flagged
 * continuation from here would skip that page, which is the one page in the
 * chain with something to say.
 */
if ($step > 1) sfy_redirect(sfy_step_next_url($sid));

$softReason = is_array($soft) ? (string)($soft['reason'] ?? '') : '';
$waitLeft   = is_array($soft) ? (int)($soft['wait'] ?? 0) : 0;
/* A refused landing explains itself; anything else falls back to the generic
   "still watching" copy so nobody is ever left without a next step. */
if ($softReason === 'no_provider_return') {
    $softText = sfy_return_landing_text((string)($landing['why'] ?? 'no_provider_return'));
} elseif (in_array($softReason, ['ticket_missing', 'ticket_invalid', 'ticket_used',
                                    'no_handoff_cookie', 'landing_ip_mismatch'], true)) {
    $softText = sfy_return_landing_text($softReason);
} else {
    $softText = '';
}
?>
<?php sfy_head(['title' => 'Checking your task', 'page' => $page, 'noindex' => true]); ?>
<div class="shell">
  <?= sfy_ad_slot('top', $page) ?>
  <?= sfy_bypass_warning($sess) ?>
  <div class="card brk" style="--accent:#FFCB3D">
    <div class="card-head">
      <h1>&gt; CHECKING_YOUR_TASK</h1>
      <span class="spacer"></span>
      <span class="badge y">WAITING</span>
    </div>

    <?= sfy_task_status([
          ['Your task', 'Still open — waiting for the task to report back'],
          ['Checked', (int)$waited . '/' . (int)$watchSeconds . ' seconds — still watching automatically'],
          ['Status', '<span class="dot static y"></span> Waiting for confirmation', 'sfy-live'],
      ]) ?>

    <?= sfy_strict_wait_warning($sess) ?>

    <?php if ($rc['active']): ?>
      <div class="msg <?= $softText !== '' ? 'bad' : 'warn' ?> mt-2">
        ◆ <?php if ($softText !== ''): ?>
            <?= sfy_esc($softText) ?>
          <?php elseif ($softReason === 'return_too_fast' && $waitLeft > 0): ?>
            Almost there — hold on about <b><?= (int)$waitLeft ?>s</b> more so the task counts as completed.
          <?php elseif ($softReason === 'task_never_opened'): ?>
            We have not seen you open the task yet. Press <b>OPEN TASK &amp; RETURN</b> on the task page first.
          <?php else: ?>
            Confirmation is being retried automatically. You can also press <b>CHECK AGAIN</b> or go back to the task.
          <?php endif; ?>
      </div>
    <?php endif; ?>

    <div class="btn-row mt-2">
      <a class="btn btn-primary grow" href="<?= sfy_esc(sfy_url('go/' . $sid)) ?>">↻ BACK TO THE TASK</a>
      <button class="btn" id="sfy-check">↻ CHECK AGAIN</button>
      <button class="btn btn-gold" id="sfy-reset" data-sid="<?= sfy_esc($sid) ?>">⟲ RESET &amp; START OVER</button>
    </div>
    <div class="hint">
      Still on the task? <a href="<?= sfy_esc(sfy_url('go/' . $sid)) ?>">re-open it</a>, finish every offer
      on it, then come straight back here. Stuck for good? <b>RESET &amp; START OVER</b> starts this
      link over — you keep the same link and nothing else to re-enter.
    </div>
    <div class="term mt-2" id="sfy-status" style="display:none;max-height:none"></div>
  </div>

  <?= sfy_ad_slot('banner', $page) ?>
  <?= sfy_premium_block(['head' => 'Skip every task', 'compact' => true]) ?>
  <?= sfy_ad_slot('bottom', $page) ?>
</div>
<script>
(function(){
  var sid = <?= json_encode($sid) ?>;
  /* The step this page is showing. Sending it is what keeps a poll from
     reporting an "advance" that already happened — see sfy_step_status_decision(). */
  var cur = <?= (int)$step ?>;
  var live = document.getElementById('sfy-live');
  var outUrl = <?= json_encode(sfy_url('out/' . urlencode($sid))) ?>;

  /* Rewrite only when the text actually changes: rebuilding the row on every
     poll is what made this page look like it was refreshing itself. */
  function setLive(txt, tone){
    if (!live || live.getAttribute('data-live') === txt) return;
    live.setAttribute('data-live', txt);
    var dot = live.querySelector('.dot');
    if (dot) dot.className = 'dot static ' + (tone || 'y');
    var tail = live.lastChild;
    if (tail && tail.nodeType === 3) tail.nodeValue = ' ' + txt;
    else live.appendChild(document.createTextNode(' ' + txt));
  }
  function statusUrl(){ return <?= json_encode(sfy_url('api/step.php')) ?> + '?a=status&ret=1&cur=' + cur + '&sid=' + encodeURIComponent(sid); }

  function handle(d){
    if (d.status === 'completed' || d.status === 'advanced') { location.href = d.redirect; return true; }
    /* Same step still: nothing to do, and nothing to repaint. */
    if (d.step && d.step === cur) { if (d.return_note === 'return_too_fast' && d.wait > 0) setLive('Hold on ' + d.wait + 's more…', 'y'); return false; }
    if (d.return_note === 'task_never_opened') setLive('Open the task first', 'r');
    else if (d.return_note === 'no_provider_return') setLive('Open the task, not this link', 'r');
    return false;
  }

  var tries = 0;
  var t = setInterval(function(){
    tries++;
    fetch(statusUrl(), {credentials: 'same-origin', cache: 'no-store'})
      .then(function(r){ return r.json(); })
      .then(function(d){ if (handle(d) || tries > 60) clearInterval(t); })
      .catch(function(){ if (tries > 60) clearInterval(t); });
  }, 3500);

  document.getElementById('sfy-check').addEventListener('click', function(){
    var box = document.getElementById('sfy-status');
    box.style.display = 'block';
    box.textContent = '> checking again…';
    fetch(statusUrl(), {credentials: 'same-origin', cache: 'no-store'}).then(function(r){ return r.json(); }).then(function(d){
      if (handle(d)) return;
      box.textContent = '> not confirmed yet\n> make sure you completed every offer on the task, then check again.';
    }).catch(function(){ box.textContent = '> check failed — retry in a moment.'; });
  });

  var rst = document.getElementById('sfy-reset');
  if(rst) rst.addEventListener('click', function(){
    if(!confirm('Start this link over? The progress on the task you are on is lost.')) return;
    var box = document.getElementById('sfy-status');
    box.style.display = 'block';
    box.textContent = '> resetting…';
    fetch(<?= json_encode(sfy_url('api/step.php')) ?> + '?a=reset&sid=' + encodeURIComponent(sid))
      .then(function(r){ return r.json(); })
      .then(function(d){
        if (d.status === 'reset') { location.href = d.redirect; return; }
        /* A finished session cannot be reset — it can only hand over its code. */
        if (d.redirect) { location.href = d.redirect; return; }
        box.textContent = '> reset failed (' + (d.reason || 'error') + ')';
      })
      .catch(function(){ box.textContent = '> reset failed — retry in a moment.'; });
  });
})();
</script>
<?= sfy_ad_slot('popup', $page) ?>
<?php
/* One label, two places: the card's own button and the bar pinned to the bottom
   of the screen (the label is the page's, never the step-counting default). */
sfy_foot(['page' => $page, 'pinned' => [
    'url'   => sfy_url('go/' . $sid),
    'kind'  => 'task',
    'icon'  => '▶',
    'label' => 'BACK TO THE TASK',
]]);
?>
