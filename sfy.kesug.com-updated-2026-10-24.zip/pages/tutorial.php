<?php
declare(strict_types=1);
/**
 * /tutorial — the step-by-step guide.
 *
 * One page covering both routes a player can take:
 *   A. the script's "Copy link" handoff (open the link in any browser)
 *   B. the raw token code (paste it on the landing page and press CLAIM)
 *
 * Nothing here touches the verification logic: the claim box at the bottom
 * posts to exactly the same /claim/<token> route the landing page uses.
 */
require_once dirname(__DIR__) . '/app/core.php';

sfy_install_if_empty();

if ((string)sfy_config_get('set_tutorial_enabled', '1') !== '1') {
    sfy_redirect(sfy_url(''));
}

$page = 'tutorial';

/* Resume hint, worked out exactly like the landing page does it. */
$current = sfy_resolve_current_session();
$resume  = '';
if ($current && (int)($current['is_completed'] ?? 0) === 0 && sfy_session_is_live($current)) {
    $resume = (string)($current['session_id'] ?? '');
}
$GLOBALS['SFY_RESUME_SESSION'] = $resume;

/* ── the guide, as data ────────────────────────────────────────────── */
$linkSteps = [
    ['Open the game and run the script',
     'Join the Roblox game, execute the SFY loader, then open the SFY window it creates.'],
    ['Press “Copy link”',
     'The script builds your personal claim link — it already contains your token.'],
    ['Paste the link into any browser',
     'Chrome, Edge, Firefox, mobile Safari — any browser works. A brand-new tab is best.'],
    ['Read the token checkpoint',
     'The page confirms your token, registers this device and shows which step you are on.'],
    ['Press “Continue to task”',
     'You are handed to the task provider with a signed, one-time step token. Keep our tab open.'],
    ['Finish the task completely',
     'Do not close the task early. When you finish, the provider calls our server back and the step is verified automatically.'],
    ['Repeat for every step',
     'Most tokens are two steps. The counter at the top of the task page shows your progress.'],
    ['Copy your unlock code',
     'When every step is verified the code appears instantly. Press 📋 COPY CODE and paste it into the Roblox menu.'],
];

$codeSteps = [
    ['Run the script and press “Copy code”',
     'Instead of a link you get a short token code, something like SFY-XXXXXX-YY.'],
    ['Open a browser and go to the site',
     'Type the address in the bar, or paste it: ' . SFY_DOMAIN . ' — the landing page opens.'],
    ['Paste the code into the token box',
     'Put the whole code (or even the whole pasted line) into “HAVE A TOKEN?” — the token is extracted for you.'],
    ['Press CLAIM',
     'Your code is checked and, if it is still unused, a verification session opens on this device.'],
    ['Follow the numbered steps',
     'Each step opens a task. Complete it and return — the signed postback advances you.'],
    ['Copy the unlock code',
     'Once everything is verified the code appears. Copy it and paste it into the Roblox menu.'],
];

$faq = [
    ['Why does a step say “waiting for postback”?',
     'The provider has not called us back yet. Open the task again with the button on that step, finish it fully, then press “I finished — check status”.'],
    ['Can I use the same code twice?',
     'No. A token is single-use and it is locked to the device and browser that claimed it.'],
    ['Can I share my claim link?',
     'No. Sharing is detected — the link is bound to one device, and a second device gets an error instead of a code.'],
    ['What if the link expired?',
     'Sessions last ' . (int)sfy_setting_int('session_ttl_minutes', 30) . ' minutes. Just run the script again and take the fresh link or code.'],
    ['Do I need to keep the page open?',
     'Yes, keep the tab open while a task runs. It polls our server to notice the verified postback straight away.'],
    ['I never get the code — what now?',
     'Open the support link in the footer and send your token. Staff can see every step and postback in the admin panel.'],
];

sfy_head(['title' => 'Tutorial — how to get your code', 'page' => $page]);
?>
<div class="shell">

  <?= sfy_ad_slot('top', $page) ?>

  <div class="card brk">
    <div class="card-head">
      <h1>&gt; HOW_IT_WORKS</h1>
      <span class="spacer"></span>
      <span class="badge g"><span class="dot static"></span> STEP BY STEP</span>
    </div>
    <p style="font-size:17px;color:var(--text);margin:2px 0 4px">
      Getting your unlock code takes about two minutes.
    </p>
    <p class="dim" style="margin:0 0 16px">
      There are two ways in: the <b>link</b> the script copies for you, or the raw <b>token code</b> you paste on the front page.
      Pick the one you are holding — everything below is covered.
    </p>

    <div class="seg wide" id="sfy-tut-seg">
      <button type="button" class="active" data-route="link">🔗 I have a link</button>
      <button type="button" data-route="code">⌨ I have a token code</button>
    </div>

    <div class="msg info mt-2">
      ◆ Whichever route you use, the same three rules apply: finish each task fully, keep our tab open, and never share your code.
    </div>
  </div>

  <?= sfy_ad_slot('banner', $page) ?>

  <div class="layout-split-2">
    <div>
      <section class="card tut-route" data-route="link">
        <div class="card-head"><h2>&gt; ROUTE_A — THE COPIED LINK</h2>
          <span class="spacer"></span><span class="badge p"><?= count($linkSteps) ?> STEPS</span></div>
        <ol class="tut-list">
          <?php foreach ($linkSteps as $i => [$t, $d]): ?>
            <li>
              <span class="n"><?= str_pad((string)($i + 1), 2, '0', STR_PAD_LEFT) ?></span>
              <div><b><?= sfy_esc($t) ?></b><div class="small dim"><?= sfy_esc($d) ?></div></div>
            </li>
          <?php endforeach; ?>
        </ol>
        <div class="term" style="max-height:none;font-size:11.5px">
<span class="line">script → copy link → browser → claim → the task → CODE</span>
<span class="line dim">the link already contains your token, so nothing to type</span>
        </div>
      </section>

      <section class="card tut-route" data-route="code" hidden>
        <div class="card-head"><h2>&gt; ROUTE_B — THE TOKEN CODE</h2>
          <span class="spacer"></span><span class="badge p"><?= count($codeSteps) ?> STEPS</span></div>
        <ol class="tut-list">
          <?php foreach ($codeSteps as $i => [$t, $d]): ?>
            <li>
              <span class="n"><?= str_pad((string)($i + 1), 2, '0', STR_PAD_LEFT) ?></span>
              <div><b><?= sfy_esc($t) ?></b><div class="small dim"><?= sfy_esc($d) ?></div></div>
            </li>
          <?php endforeach; ?>
        </ol>
        <div class="term" style="max-height:none;font-size:11.5px">
<span class="line">script → copy code → <?= sfy_esc(SFY_DOMAIN) ?> → paste → CLAIM → the task → CODE</span>
<span class="line dim">paste the whole line if you want — the token is extracted automatically</span>
        </div>
      </section>
    </div>

    <aside>
      <div class="card">
        <div class="card-head"><h2>&gt; QUICK_START</h2></div>
        <div class="tut-mini">
          <span class="n">01</span><span>Run the script in your Roblox game</span>
          <span class="n">02</span><span>Copy the <b>link</b> or the <b>code</b></span>
          <span class="n">03</span><span>Open it in <b>any browser</b></span>
          <span class="n">04</span><span>Finish every task in order</span>
          <span class="n">05</span><span>Copy the unlock code into the menu</span>
        </div>
      </div>

      <?= sfy_ad_slot('side', $page) ?>

      <div class="card">
        <div class="card-head"><h2>&gt; RULES</h2></div>
        <div class="term" style="max-height:none;font-size:11.5px">
<span class="line warn">closing a task early fails the step</span>
<span class="line">one token = one device, one use</span>
<span class="line bad">bypassing or scripting the postback flags your device</span>
<span class="line">stuck? open the support link below</span>
        </div>
        <?php if ($d = (string)sfy_config_get('set_support_discord', '')): ?>
          <a class="btn btn-gold btn-block mt-2" href="<?= sfy_esc($d) ?>" target="_blank" rel="noopener">GET HELP</a>
        <?php endif; ?>
      </div>
    </aside>
  </div>

  <section class="card mt-2">
    <div class="card-head"><h2>&gt; FAQ</h2></div>
    <?php foreach ($faq as [$q, $a]): ?>
      <details class="faq"><summary><?= sfy_esc($q) ?></summary>
        <div class="small dim"><?= sfy_esc($a) ?></div></details>
    <?php endforeach; ?>
  </section>

  <section class="card brk mt-2" id="sfy-tut-claim">
    <div class="card-head"><h2>&gt; READY? CLAIM YOUR TOKEN</h2></div>
    <p class="dim" style="margin:0 0 12px">Paste the token code — or the whole copied link — and press CLAIM.</p>
    <div class="inline">
      <input class="grow mono" id="sfy-token-input" placeholder="--// paste your token or link //--"
             autocomplete="off" spellcheck="false" inputmode="text">
      <button class="btn btn-primary" id="sfy-claim-btn">▶ CLAIM</button>
    </div>
    <div class="hint">You can also paste the full link — the token is extracted automatically.</div>
    <?php if ($resume !== ''): ?>
      <hr class="sep">
      <div class="msg info">◆ You already have a session in progress on this device.</div>
      <a class="btn btn-gold btn-block" href="<?= sfy_esc(sfy_url('go/' . $resume)) ?>">RESUME MY TASK</a>
    <?php endif; ?>
  </section>

  <?= sfy_ad_slot('bottom', $page) ?>
</div>

<script>
(function(){
  // Route tabs
  var seg = document.getElementById('sfy-tut-seg');
  if (seg) {
    seg.addEventListener('click', function(e){
      var b = e.target.closest('button[data-route]');
      if (!b) return;
      var want = b.getAttribute('data-route');
      seg.querySelectorAll('button').forEach(function(x){ x.classList.toggle('active', x === b); });
      document.querySelectorAll('.tut-route').forEach(function(s){
        s.hidden = s.getAttribute('data-route') !== want;
      });
    });
  }

  // Claim box (same behaviour as the landing page)
  var input = document.getElementById('sfy-token-input');
  var btn   = document.getElementById('sfy-claim-btn');
  if (!input || !btn) return;
  function go(){
    var raw = (input.value || '').trim();
    if (!raw) { input.focus(); return; }
    var m = raw.match(/\/claim\/([A-Za-z0-9\-]{4,64})/);
    var tok = m ? m[1] : raw.replace(/[^A-Za-z0-9\-]/g, '');
    if (!tok) { input.focus(); return; }
    location.href = <?= json_encode(sfy_url('claim/')) ?> + encodeURIComponent(tok);
  }
  btn.addEventListener('click', go);
  input.addEventListener('keydown', function(e){ if (e.key === 'Enter') go(); });
})();
</script>
<?= sfy_ad_slot('popup', $page) ?>
<?= sfy_ad_slot('float', $page) ?>
<?= sfy_ad_slot('sticky', $page) ?>
<?php sfy_foot(['page' => $page]); ?>
