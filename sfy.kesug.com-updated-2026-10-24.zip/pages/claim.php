<?php
declare(strict_types=1);
/**
 * /claim/<token> — token checkpoint.
 * Validates the token, registers the device, opens (or reopens) the
 * verification session and hands the user to /go/<session>.
 */
require_once dirname(__DIR__) . '/app/core.php';

sfy_install_if_empty();
sfy_rate_limit_hit('claim', sfy_client_ip());

$token    = sfy_param_any(['token', 'short', 't']);
$page     = 'claim';
$error    = sfy_param('error');
$isPost   = ($_SERVER['REQUEST_METHOD'] === 'POST');

if (!sfy_validate_token($token)) {
    sfy_fatal('Missing token',
        'This link does not contain a valid verification token. Copy the full link from the Roblox menu.',
        400, ['retry' => sfy_url('')]);
}

$db  = sfy_db();
$tok = sfy_token_find($token);

if (!$tok) {
    // A schema that is missing its token table is a *configuration* problem,
    // not a bad link — say so, otherwise it looks like every link is broken.
    if (!sfy_table_exists('sfy_tokens')) {
        sfy_fatal('Database not ready',
            'The verification tables are missing on this install. Sign in to the admin panel and run the updater.',
            503, ['retry' => sfy_url('claim/' . urlencode($token)), 'admin' => true]);
    }
    sfy_fatal('Unknown token',
        'This token was not found in the database. Generate a fresh link from the Roblox menu.',
        404, ['retry' => sfy_url('')]);
}

/* ── token state checks ────────────────────────────────────────────── */
$deviceProfile = null;
$deviceRow     = null;

if (!empty($tok['expires_at']) && strtotime((string)$tok['expires_at']) < time()) {
    sfy_fatal('Token expired', 'This token expired on ' . date('M j, Y H:i', strtotime((string)$tok['expires_at'])) . '.',
        410, ['retry' => sfy_url('')]);
}

/*
 * ── the bot check ──────────────────────────────────────────────────
 *
 * Deliberately *not* here. It is decided further down, next to the session
 * it protects (see "THE BOT CHECK, EXACTLY HERE"), because it is about
 * starting a run and not about reading a link: a player who already earned
 * their code must never be asked to prove they are human before getting it
 * back. Everything above this line is read-only.
 */

/* ── device registry ──────────────────────────────────────────────── */
$deviceProfile = sfy_device_profile($_POST + $_GET);
$deviceRow     = sfy_device_upsert($deviceProfile, true);

if ($deviceRow && (int)$deviceRow['is_blocked'] === 1) {
    sfy_fatal('Device blocked',
        'This device has been blocked by the administrator. Contact support if you believe this is a mistake.',
        403);
}

/* ── already used? send them back to their code when possible ─────── */
$sid = null;
$ip  = sfy_client_ip();

/*
 * A reusable token ignores its own "used" flag completely: the same link must
 * keep working for every player who runs it, which is the point of the setting
 * (and the cure for "the token errors for everybody once one person finishes").
 *
 * Under the default OPEN policy *every* token behaves that way, because the
 * duplicate is prevented where it actually happens — in the token pool the
 * script draws from. There is nothing to protect here, and a page that refuses
 * a finished link is a page the site owner has to unstick by hand.
 */
$reuse   = sfy_token_reusable($tok);
$wasUsed = (int)($tok['is_used'] ?? 0) === 1;

if (!$reuse && $wasUsed) {
    $done = sfy_token_completed_session($token, (int)($deviceRow['id'] ?? 0));

    /*
     * An already-finished token is a *normal* state, not a failure: the player
     * ran the script, finished the tasks and is coming back for their code.
     * So the first thing we do is hand the code back — whatever device asks,
     * unless the owner deliberately switched device lock on.
     */
    if ($done && sfy_code_handoff_allows($done, $deviceRow)) {
        sfy_redirect(sfy_url('out/' . urlencode((string)$done['session_id'])));
    }

    /*
     * Nothing to send them to. Never an error page: give them the facts, the
     * route back to their code and the two things that actually help (a fresh
     * token, or the walkthrough).
     */
    $stats   = sfy_token_code_stats($token);
    $locked  = $done && !sfy_code_handoff_allows($done, $deviceRow);
    $head    = $locked ? 'THIS CODE IS ON ANOTHER DEVICE' : 'THIS TOKEN IS ALREADY FINISHED';
    $line    = $locked
        ? 'The tasks for this token were completed on a different device, and device lock is on, so only that '
          . 'device can display the code again. Open this same link there.'
        : 'Its tasks were already completed, so there is nothing left to verify — the code was shown at the time. '
          . 'Run the script again for a fresh token and it will take you straight through.';

    sfy_head(['title' => 'Token already finished', 'page' => $page, 'noindex' => true]);
    ?>
    <div class="shell">
      <?= sfy_ad_slot('top', $page) ?>

      <div class="card brk" style="--accent:#FFCB3D">
        <div class="card-head">
          <h1>&gt; <?= sfy_esc($head) ?></h1>
          <span class="spacer"></span>
          <span class="badge y">FINISHED</span>
          <?php if ((int)($tok['is_used'] ?? 0) && $stats['opens'] > 0): ?>
            <span class="badge gr">OPENED <?= (int)$stats['opens'] ?>×</span>
          <?php endif; ?>
        </div>

        <div class="msg warn">◆ <?= sfy_esc($line) ?></div>

        <div class="grid grid-3" style="margin-top:14px">
          <?= sfy_kpi('Token', sfy_short($token, 14), 'gold', (string)($tok['game_name'] ?? '') ?: 'no game set') ?>
          <?= sfy_kpi('Times opened', (int)$stats['opens'], '', (int)$stats['devices'] . ' device(s)') ?>
          <?= sfy_kpi('Last opened from',
                      is_array($stats['last'] ?? null) ? sfy_short(sfy_code_open_where($stats['last']), 22) : '—',
                      '', $stats['last'] ? sfy_ago((string)($stats['last']['created_at'] ?? '')) : 'never') ?>
        </div>

        <div class="btn-row mt-2">
          <a class="btn btn-primary grow" href="<?= sfy_esc(sfy_url('')) ?>">▶ GET A FRESH TOKEN</a>
          <a class="btn" href="<?= sfy_esc(sfy_url('tutorial')) ?>">📖 HOW IT WORKS</a>
        </div>
        <?php if ($locked): ?>
          <div class="hint">Finished it on your phone and want it again there? Open the same claim link on that
            device. The site owner can allow any device under Settings → Code device lock.</div>
        <?php else: ?>
          <div class="hint">Already ran the script? Paste the new link or token on the home page — tokens are
            single-use, so a finished one never starts a second verification.</div>
        <?php endif; ?>
      </div>

      <?= sfy_premium_block(['head' => 'Skip the tasks next time']) ?>
      <?= sfy_ad_slot('banner', $page) ?>
      <?= sfy_ad_slot('bottom', $page) ?>
    </div>
    <?= sfy_ad_slot('popup', $page) ?>
    <?= sfy_ad_slot('sticky', $page) ?>
    <?php
    sfy_foot(['page' => $page]);
    exit;
}

/* ── anti-sharing: is another *device* mid-session on this token? ───
   Passing this device is the point: an IP change on your own phone is not
   sharing, and it must not be treated as if it were. A reusable token skips
   the check entirely — a shared link is *meant* to be claimed by many players
   at the same time. */
$fp = (string)($deviceProfile['device_key'] ?? '');
if (!$reuse && ($other = sfy_token_session_elsewhere($token, $ip, (int)($deviceRow['id'] ?? 0), $fp))) {
    sfy_fatal('Token already in use',
        'This token is currently being verified from another connection. Finish there or start a new link.',
        409, ['retry' => sfy_url('')]);
}

/* ══════════════════════════════════════════════════════════════════════
   THE BOT CHECK, EXACTLY HERE

   This is the moment the flow is created, and it is the only request in the
   whole chain that costs nothing and leaves something behind — so this is
   where a human check belongs. Everything after it is already signed and
   single-use; asking again later would only tax real players, which is why
   the code hand-off above is not gated at all.

   Two properties worth keeping when this is touched:

     • A challenge is only ever demanded when the install can *enforce* it
       (`sfy_captcha_wanted()`: switch on, both keys present, host able to
       make an outbound request). A half-configured toggle therefore blocks
       nobody and reports itself in Admin → Security instead of walling the
       claim page off from real players.
     • One pass per *run*. The verdict is stored on the session it created
       (`sfy_captcha_mark_run`), so refreshing the claim link — or coming
       back to it mid-run — never asks the same player twice.
   ══════════════════════════════════════════════════════════════════════ */
/* ══════════════════════════════════════════════════════════════════════
   WHERE DO YOU WANT TO EARN IT? — asked in a popup, answered in one tap

   The choice lives on this page, next to the bot check, because it is part of
   "what am I about to do" and not a question to be asked halfway through. The
   answer is stored with exactly the tool the task page uses
   (`sfy_session_set_provider`), so a hand-posted value can only ever change
   where a task is opened — never whether it counted.

   It is asked as a small popup of boxes rather than a pair of radio buttons: a
   radio answers a question the player has not been given the facts for (what
   is Work.ink? which is quicker?), and it turns one decision into two taps —
   pick, then press PROCEED. Each box carries the network, what kind it is and
   its own one line, and pressing the box is the whole answer: the run starts
   (or the session already has) and the pass-through hub hands the browser
   straight into that network's task.

   Two properties worth keeping when this is touched:

     • a network that cannot serve this step is still SHOWN — greyed, with the
       reason on it. "Under maintenance" is the owner saying so; a box that
       quietly disappears is indistinguishable from a broken site, and it is
       what a player who had already picked that network would see;
     • the popup is only ever a *question*. Nothing inside it writes anything:
       the box submits (or links to) the same `pick` the old radios did, and
       that value is validated against this very list below.

   With a single candidate nothing is asked anywhere: there is nowhere else to
   go, so there is nothing to decide.
   ══════════════════════════════════════════════════════════════════════ */
$existing    = sfy_session_find_live($token, (int)($deviceRow['id'] ?? 0), $fp, $ip);
$liveSess    = $existing ?: null;

$claimPlan    = sfy_provider_plan($liveSess ?: []);
$claimChoices = [];
foreach ($claimPlan['providers'] as $row) {
    if (!empty($row['available'])) $claimChoices[] = $row;
}

/* The listed set decides *whether* the question is asked — parked networks
   included, because hiding one is the thing this popup exists to avoid. */
$claimPickRows = (array)($claimPlan['providers'] ?? []);
$claimHasPick  = count($claimPickRows) > 1;

/*
 * Every network parked at once is not a broken install, it is the owner
 * saying "not right now". Starting a run for a player nobody can serve would
 * only walk them into the hub's maintenance page, so the start is skipped
 * entirely and the card says why.
 */
$claimParked  = empty($claimPlan['ok']) && ($claimPlan['reason'] ?? '') === 'maintenance';
$gateNeeded  = sfy_captcha_needed('claim', $liveSess);
$captchaWhy  = '';
$captchaOk   = !$gateNeeded;

if ($gateNeeded && $isPost) {
    $verdict    = sfy_captcha_check('claim', (string)($liveSess['session_id'] ?? ''),
                                    sfy_param('cf-turnstile-response'), $ip);
    $captchaOk  = !empty($verdict['ok']);
    $captchaWhy = (string)$verdict['why'];
    if (!$captchaOk) $error = 'captcha';
}

/*
   Starting the run is the *only* write this page performs, and it is the step
   every player must cross, so a failure here is never allowed to reach the
   browser as a bare "Something broke": the cause is logged, the schema is
   asked to repair itself once, and the player gets a page that says what to do
   (with the exact statement in the detail when the owner is looking through
   ?sfy_key=… — see sfy_diag_active()).
 */
if ($captchaOk && !$claimParked) {
  try {
    /* Reuse this device's live session, otherwise create one. */
    $sid = $liveSess ? (string)$liveSess['session_id'] : null;

    if (!$sid) {
        sfy_purge_stale();
        $sid = sfy_session_create($tok, $ip, sfy_user_agent(), $fp, (int)($deviceRow['id'] ?? 0));
    } else {
        sfy_session_extend($sid);
    }

    sfy_set_session_cookie($sid);
    $_SESSION['sfy_sid']   = $sid;
    $_SESSION['sfy_token'] = $token;

    /*
     * The form may carry the provider the player picked. It is validated
     * against the very list that was rendered, and then it is a preference on
     * this session's row like any other — it opens a task somewhere, it cannot
     * confirm one.
     */
    $wantPick = (int)sfy_param('pick', '0');
    if ($wantPick > 0) {
        foreach ($claimChoices as $row) {
            if ((int)$row['provider']['id'] === $wantPick) { sfy_session_set_provider($sid, $wantPick); break; }
        }
    }

    /* This run is checked now — remember it against the run itself, so a
       reload of the link, the pinned button or a later step never asks a
       second time. Marking is what makes the gate a door and not a toll. */
    if ($gateNeeded) sfy_captcha_mark_run($sid);

    /*
     * A check that was *submitted* (and passed) hands the browser straight to
     * the task. The player already pressed the only button this page has; a
     * second "CONTINUE" screen after it would be the page asking them to
     * confirm what they just asked for. A check that was never needed keeps
     * the button below, because nothing was submitted at all.
     */
    if ($gateNeeded) sfy_redirect(sfy_url('go/' . $sid));
    if (sfy_param('auto') === '1') sfy_redirect(sfy_url('go/' . $sid));
  } catch (Throwable $e) {
    $where = basename($e->getFile()) . ':' . $e->getLine();
    error_log('[SFY] run start failed: ' . get_class($e) . ': ' . $e->getMessage() . ' @ ' . $where);

    /* One repair sweep, then one retry — the same self-healing the session
       insert does on its own, widened to everything the run start touches, so
       a database that is merely behind the code heals on the player's request
       instead of needing the owner to press a button. */
    try {
        sfy_schema_repair_columns();
        sfy_schema_flush_cache();
        /* Reuse the run if the first attempt got as far as creating it —
           retrying blindly would leave two live runs on one token and trip the
           anti-sharing check on the next step. */
        $again = $liveSess ?: sfy_session_find_live($token, (int)($deviceRow['id'] ?? 0), $fp, $ip);
        $sid   = $again ? (string)$again['session_id']
                        : sfy_session_create($tok, $ip, sfy_user_agent(), $fp, (int)($deviceRow['id'] ?? 0));
        sfy_set_session_cookie($sid);
        $_SESSION['sfy_sid']   = $sid;
        $_SESSION['sfy_token'] = $token;
        if ($gateNeeded) sfy_captcha_mark_run($sid);
        sfy_redirect(sfy_url('go/' . $sid));
    } catch (Throwable $e2) {
        error_log('[SFY] run start still failing: ' . get_class($e2) . ': ' . $e2->getMessage()
                . ' @ ' . basename($e2->getFile()) . ':' . $e2->getLine());
        $detail = 'The server could not store a new verification just now. Nothing was lost — press RETRY, and if it '
                . 'keeps happening the administrator can read the exact cause in Admin → Updater → ERROR_LOG.';
        if (sfy_diag_active()) {
            $detail = 'cause: ' . get_class($e2) . ': ' . $e2->getMessage()
                    . '  (' . basename($e2->getFile()) . ':' . $e2->getLine() . ')';
        }
        sfy_fatal('Could not start your run', $detail, 503,
            ['retry' => (string)($_SERVER['REQUEST_URI'] ?? sfy_url('')), 'admin' => true]);
    }
  }
}

$sess     = $sid ? sfy_load_session($sid) : null;
$step     = $sess ? max(1, (int)($sess['current_step'] ?? 1)) : 1;
$total    = $sess ? max(1, (int)($sess['total_steps'] ?? 1)) : sfy_setting_int('default_tasks_required', 2);
$gameName = (string)($tok['game_name'] ?? '');

/*
 * One label, one place.
 *
 * It used to change with the number of providers — "CHOOSE YOUR TASK" whenever
 * there was a choice to make — because the choice was a *second screen* the
 * button led to. The choice is now the popup below, which this very button
 * opens, so pressing it means the same thing on every install and the bar
 * pinned to the bottom of the screen can honestly say it too.
 *
 * The wording names the *outcome* rather than the mechanic: "PROCEED" describes
 * a form being submitted, which is the one thing the player does not care
 * about. What they are earning is the code, so the button says where the tap
 * leads.
 */
$claimGoLabel = 'PROCEED TO GET CODE';

/**
 * One box of the picker: which network, what kind, and its own one line about
 * itself. A box that cannot serve this step is rendered disabled with the
 * reason printed on it — never removed, because a network that disappears
 * without a word is exactly what a player who had already picked it reads as a
 * broken site.
 *
 * `$asForm` picks the half of the flow this popup was opened from: inside the
 * bot-check form the box *is* the submit, so the pick and the challenge verdict
 * travel together (and the pick still cannot confirm anything); on a session
 * that already exists it is a plain link, which a blocked script leaves
 * working.
 */
$pickBox = function (array $row, bool $asForm) use ($sid, $total): string {
    $p       = $row['provider'];
    $label   = sfy_provider_label($p);
    $avail   = !empty($row['available']);
    $parked  = !empty($row['maintenance']);
    [$state, $tone] = sfy_provider_state_badge($row);
    $desc    = trim((string)($p['description'] ?? ''));
    if ($desc === '') $desc = 'Complete this provider\'s steps to unlock your code.';
    $allowed = (int)($p['tasks_allowed'] ?? 0);
    $cp      = $allowed > 0 ? min($allowed, $total) : $total;
    $cpWord  = $cp === 1 ? sfy_setting_text('checkpoint_label', 'checkpoint') : sfy_setting_text('checkpoint_label_plural', 'checkpoints');
    $cpLabel = $cp . ' ' . $cpWord;
    $icon    = strtoupper(substr((string)preg_replace('/[^A-Za-z0-9]/', '', $label), 0, 1));
    if ($icon === '') $icon = '?';
    $kindClass = preg_replace('/[^a-z0-9_-]/', '', strtolower((string)($p['kind'] ?? '')));

    $inner = '<span class="pick-icon' . ($kindClass !== '' ? ' kind-' . $kindClass : '') . '" aria-hidden="true">' . sfy_esc($icon) . '</span>'
           . '<span class="pick-main">'
           . '<span class="pick-name">' . sfy_esc($label)
           . sfy_badge($state, $tone)
           . sfy_badge(sfy_provider_kind_label((string)$p['kind']), 'b') . '</span>'
           . '<span class="pick-desc">' . sfy_esc($desc) . '</span>'
           . '<span class="pick-meta"><span class="pick-cp">' . sfy_esc($cpLabel) . '</span>'
           . ($avail ? '' : '<span class="pick-off-note">' . sfy_esc(sfy_provider_unavailable_note($row)) . '</span>')
           . '</span></span>'
           . '<span class="pick-chev" aria-hidden="true">' . ($avail ? '›' : '×') . '</span>';

    if (!$avail) return '<div class="pick-row off">' . $inner . '</div>';

    return $asForm
        ? '<button class="pick-row" type="submit" form="sfy-claim-form" name="pick" value="' . (int)$p['id'] . '">' . $inner . '</button>'
        : '<a class="pick-row" href="' . sfy_esc(sfy_url('go/' . $sid . '?pick=' . (int)$p['id'])) . '">' . $inner . '</a>';
};

/**
 * The popup itself: one box per network, opened by the card's own button.
 *
 * It is a question and nothing more — every box carries the same `pick` the old
 * radio pair did, and the answer is validated against the list rendered here
 * before it is stored (see the run-start block above). The popup re-opens on a
 * failed human check, so a player whose box was refused because the challenge
 * was unsolved lands on the same question instead of a closed popup with no
 * visible reason.
 */
$pickOverlay = function (bool $asForm) use ($claimPickRows, $pickBox, $error): string {
    $pp        = sfy_premium_copy();
    $promoLink = sfy_pricing_url();
    if ($promoLink === '') $promoLink = sfy_url('tutorial');
    $out = '<div class="modal-bg' . ($error === 'captcha' ? ' show' : '') . '" id="sfy-picker">'
         . '<div class="modal sfy-picker" role="dialog" aria-modal="true" aria-labelledby="sfy-picker-title">'
         . '<div class="pick-head">'
         . '<button class="pick-x" type="button" id="sfy-picker-close" aria-label="Close">✕</button>'
         . '<div><h3 id="sfy-picker-title">Choose your task provider</h3>'
         . '<p>Choose a provider and complete its steps. Your code unlocks when the provider confirms.</p></div>'
         . '</div>'
         . '<div class="pick-steps"><span class="on"><b>1</b> Choose</span><span class="pick-line"></span><span><b>2</b> Verify</span></div>'
         . '<a class="pick-promo" href="' . sfy_esc($promoLink) . '" target="_blank" rel="noopener" aria-label="See premium plans">'
         . '<div class="pick-promo-art" aria-hidden="true">'
         . '<span class="pp-card pp-a"><b>$0</b><small>BASIC</small></span>'
         . '<span class="pp-card pp-b"><b>7D</b><small>PRO</small></span>'
         . '<span class="pp-card pp-c"><b>★</b><small>PLUS</small></span>'
         . '</div>'
         . '<div class="pick-promo-copy"><h4>' . sfy_esc((string)$pp['title']) . '</h4>'
         . '<p>' . sfy_esc((string)$pp['text']) . '</p>'
         . '<span class="pick-plans">SEE PLANS</span></div>'
         . '<span class="pick-promo-arrow" aria-hidden="true">›</span>'
         . '</a>'
         . '<div class="pick-list">';
    foreach ($claimPickRows as $row) $out .= $pickBox($row, $asForm);
    $out .= '</div>'
          . '<div class="pick-help"><a href="' . sfy_esc(sfy_url('tutorial')) . '">Need help? Open guide <span aria-hidden="true">›</span></a></div>'
          . '<button class="pick-cancel" type="button" id="sfy-picker-cancel">Cancel</button>'
          . '</div></div>';
    return $out;
};

/* The card's own button, printed next to the popup it opens. */
$pickTrigger = '<button class="btn btn-primary btn-lg btn-block mt-2" type="button" id="sfy-pick-open">▶ '
             . sfy_esc($claimGoLabel) . '</button>';
$pickOverlayHtml = '';

sfy_head(['title' => 'Claim token', 'page' => $page, 'noindex' => true]);
?>
<div class="shell">
  <?= sfy_ad_slot('top', $page) ?>

  <div class="layout-split">
    <div>
      <div class="card brk">
        <div class="card-head">
          <h1>&gt; VERIFY_TOKEN</h1>
          <span class="spacer"></span>
          <span class="badge g"><?= $wasUsed ? 'USED' : 'UNUSED' ?></span>
        </div>

        <?php if ($error === 'captcha'): ?>
          <div class="msg err">◆ <?= sfy_esc(sfy_captcha_error_text($captchaWhy !== '' ? $captchaWhy : 'rejected')) ?></div>
        <?php endif; ?>

        <?php
        /*
         * `?restart=1` (a task link opened on a different browser or device)
         * says nothing on the page. It used to explain that this device starts
         * at task 1 — but the second device has done nothing wrong, and the
         * paragraph read like a warning about the token being used elsewhere,
         * which is how a player ends up believing the task they just finished
         * was not counted. The hand-off is silent: the flow below simply starts
         * at task 1 here while the other device keeps its own progress.
         * The parameter still rides along for the log and the admin.
         *
         * The card itself is deliberately three things: the token, the check,
         * and one button. It used to carry the task count, a KPI row and a
         * nine-line terminal log — everything a player does not need in order
         * to start, including the one number ("2") that makes people close
         * the tab. None of it was ever required by the flow: the session,
         * the step numbers and the anti-bypass chain are all still exactly what
         * they were, they are just not printed on the way in.
         */
        ?>

        <div class="label">Your token</div>
        <span class="token-pill"><?= sfy_esc($token) ?></span>
        <?php if ($gameName !== ''): ?>
          <div class="hint">Reward for <b><?= sfy_esc($gameName) ?></b>.</div>
        <?php endif; ?>

        <?php if ($claimParked): ?>
          <div class="msg warn mt-2">◆ Every task network is under maintenance right now. Nothing is wrong with
            your link — come back in a few minutes and it picks up exactly here.</div>
        <?php elseif ($gateNeeded && !$captchaOk): ?>
          <form method="POST" class="mt-2" id="sfy-claim-form">
            <input type="hidden" name="token" value="<?= sfy_esc($token) ?>">
            <?php /* `auto` is what the START VERIFICATION route carried, so the
                     challenge keeps the player on the way they were already
                     going. Nothing else rides along: this page deliberately
                     says nothing about a device change. */
                  if (sfy_param('auto') === '1'): ?><input type="hidden" name="auto" value="1"><?php endif; ?>

            <div class="label mt-2">Quick human check</div>
            <?= sfy_captcha_widget() ?>

            <?php if ($claimHasPick): ?>
              <?= $pickTrigger ?>
              <?php $pickOverlayHtml = $pickOverlay(true); ?>
            <?php else: ?>
              <button class="btn btn-primary btn-lg btn-block mt-2" type="submit">▶ <?= sfy_esc($claimGoLabel) ?></button>
            <?php endif; ?>
          </form>
          <div class="hint">Asked once per verification, not once per task. Box not showing? Reload this
            page — the check is what keeps automated runs out, and it is never shared with advertisers.</div>
        <?php elseif ($sid): ?>
          <?php if ($claimHasPick): ?>
            <?= $pickTrigger ?>
            <?php $pickOverlayHtml = $pickOverlay(false); ?>
            <div class="hint">Either one unlocks your code — pick whichever you prefer. The task opens straight
              away and the page moves on by itself when you finish it.</div>
          <?php else: ?>
            <a class="btn btn-primary btn-lg btn-block mt-2" href="<?= sfy_esc(sfy_url('go/' . $sid)) ?>">▶ <?= sfy_esc($claimGoLabel) ?></a>
            <div class="hint">Keep this tab open — the link is bound to this device and browser.</div>
          <?php endif; ?>
        <?php else: ?>
          <a class="btn btn-primary btn-lg btn-block mt-2" href="<?= sfy_esc(sfy_url('claim/' . urlencode($token) . '?auto=1')) ?>">▶ START VERIFICATION</a>
        <?php endif; ?>
      </div>

      <?= sfy_ad_slot('banner', $page) ?>
    </div>

    <aside>
      <?= sfy_ad_slot('side', $page) ?>

      <div class="card">
        <div class="card-head"><h2>&gt; PREMIUM</h2></div>
        <?php $off = sfy_premium_copy();
              $shop = sfy_pricing_url(); ?>
        <div class="ad-title" style="color:var(--gold)"><?= sfy_esc($off['title']) ?></div>
        <div class="ad-text"><?= sfy_esc($off['text']) ?></div>
        <?php if ($shop !== ''): ?>
          <a class="btn btn-gold btn-block mt-2" href="<?= sfy_esc($shop) ?>" target="_blank" rel="noopener"><?= sfy_esc($off['button']) ?></a>
        <?php endif; ?>
      </div>

      <div class="card">
        <div class="card-head"><h2>&gt; HOW_IT_WORKS</h2></div>
        <div class="term" style="max-height:none;font-size:11.5px">
<span class="line">open the token link</span>
<span class="line">finish the task that opens</span>
<span class="line">postback is verified server side</span>
<span class="line">your code appears instantly</span>
        </div>
      </div>
    </aside>
  </div>

  <?= sfy_ad_slot('bottom', $page) ?>
</div>
<?= sfy_ad_slot('popup', $page) ?>
<?= sfy_ad_slot('float', $page) ?>
<?= sfy_ad_slot('sticky', $page) ?>
<?= $pickOverlayHtml ?>
<?php if ($claimHasPick && !$claimParked): ?>
<script>
/*
 * The picker: open, close, and nothing else. Every box inside it is a real
 * submit or a real link (rendered above), so this script only decides whether
 * the popup is on screen — with it blocked, the card's button is the one thing
 * that stops working, and the same `?pick=` route the boxes use is still
 * reachable from the hub. Nothing here writes, validates or decides anything.
 */
(function(){
  var bg      = document.getElementById('sfy-picker');
  var trigger = document.getElementById('sfy-pick-open');
  var close   = document.getElementById('sfy-picker-close');
  if (!bg) return;

  function show(on){ bg.classList[on ? 'add' : 'remove']('show'); }

  if (trigger) trigger.addEventListener('click', function(){ show(true); });
  if (close)   close.addEventListener('click',   function(){ show(false); });
  var cancelBtn = document.getElementById('sfy-picker-cancel');
  if (cancelBtn) cancelBtn.addEventListener('click', function(){ show(false); });
  /* The dimmed area closes it; a click that started inside the panel does not. */
  bg.addEventListener('click', function(e){ if (e.target === bg) show(false); });
  document.addEventListener('keydown', function(e){ if (e.key === 'Escape') show(false); });
})();
</script>
<?php endif; ?>
<?php
/*
 * Inside the flow the pinned bar is the card's own action — the same
 * /go/<session> the button above points at, which is where the picker's boxes
 * lead too — and the token guide is left to the pages that are outside it (the
 * home page, a visitor who has not started). While the picker is on screen the
 * bar carries the same wording as the card: the popup itself cannot be opened
 * from a link, so the bar keeps pointing at the hub, which asks the same
 * question in the same words for anyone who never taps the card.
 */
sfy_foot(['page' => $page, 'pinned' => $sid ? [
    'url'   => sfy_url('go/' . $sid),
    'kind'  => 'task',
    'step'  => $step,
    'total' => $total,
    'icon'  => '▶',
    'label' => $claimGoLabel,
] : null]);
?>
