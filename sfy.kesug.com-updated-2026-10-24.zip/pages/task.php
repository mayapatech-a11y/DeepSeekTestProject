<?php
declare(strict_types=1);
/**
 * /go/<session> — task handoff.
 *
 * First it works out WHERE the player earns this step: with more than one task
 * provider ready (LootLabs, Work.ink, or anything added in Admin → Task
 * providers) they are asked, and the answer is remembered on the session until
 * that provider's task budget runs out. Then it issues the one-time signed
 * nonce for the step and sends them into that provider's task.
 *
 * Nothing about the anti-bypass chain changes with the provider: the step can
 * only be completed by a postback that carries the nonce (or arrives from the
 * same IP inside the nonce window), or by a return the provider's own domain
 * really performed.
 */
require_once dirname(__DIR__) . '/app/core.php';

sfy_install_if_empty();
sfy_rate_limit_hit('task', sfy_client_ip());

$sid = sfy_param('sid');
if ($sid === '') $sid = (string)pathinfo((string)parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), PATHINFO_BASENAME);

[$sess, $device] = sfy_session_gate($sid, 'task');

/* A verified postback can arrive while a flagged player is here; pull it
   before the block so the flags can be cleared by the provider's proof. */
if (function_exists('sfy_relay_pull')) {
    sfy_relay_pull();
    $sess = sfy_load_session($sid) ?: $sess;
}

if ((int)($sess['is_completed'] ?? 0) === 1) sfy_redirect(sfy_url('out/' . $sid));

/* Hard block: a flagged run gets no new task and no handoff. */
sfy_bypass_block_page($sess, 'task');

/*
 * This page accepts a provider landing as well as /done.
 *
 * /done is the usual landing: the encrypted handoff points there and the player
 * is moved straight on to their next task. An install may instead point the
 * handoff at its own task page (`set_return_url` with a session macro, e.g.
 * `/go/{SESSION_ID}`), and then this is where the provider drops the player —
 * so this is where the return has to be recorded, with exactly the same rule:
 * only when the browser says the provider sent them here.
 *
 * Unlike /done, this page is also opened by players all the time, so nothing
 * here is ever refused or logged — a visit that is not a landing simply does
 * not advance anything.
 */
$rc = sfy_return_check_state();
if (!empty($rc['active'])) {
    $land = sfy_return_landing_evidence();
    /*
     * When this install points the encrypted destination at its own task page
     * (`set_return_url` carrying a session macro) the per-run ticket arrives
     * here too, so it is presented with the ordinary rule: validate it, burn it,
     * and only then record the landing. A step whose ticket has already been
     * presented (the player landed once) is not asked for it again — the
     * confirmation may simply still be waiting out its dwell.
     */
    $ticketOk = true;
    $sRow     = null;
    if (!empty($rc['require_ticket'])) {
        $sRow = sfy_step_open($sid, max(1, (int)($sess['current_step'] ?? 1)));
        if ($sRow && trim((string)($sRow['return_ticket'] ?? '')) !== ''
            && empty($sRow['return_ticket_used_at'])) {
            $ticketOk = !empty(sfy_return_ticket_present($sRow, (string)sfy_param('rt'))['ok']);
        }
    }
    /*
     * P1-1 / P1-2 (2026-10-24): a ticket step is only confirmed by the browser
     * that was handed off and from the network the handoff was issued to. The
     * cookie is set on /go below; the address is the connection's, not a
     * query parameter.
     */
    if ($sRow && $ticketOk && (bool)sfy_cfg('security.landing_bind', true)
        && trim((string)($sRow['return_ticket'] ?? '')) !== '') {
        if (!sfy_step_cookie_ok($sid, (int)$sRow['step'], (string)$sRow['nonce'])) {
            $ticketOk = false;
        } elseif (trim((string)($sRow['issued_ip'] ?? '')) !== ''
               && !sfy_ip_same_net((string)$sRow['issued_ip'], sfy_client_ip())) {
            $ticketOk = false;
        }
    }
    if ($ticketOk && (empty($rc['require_provider']) || !empty($land['ok']))) {
        sfy_step_mark_returned($sid, max(1, (int)($sess['current_step'] ?? 1)));
        sfy_try(function () use ($sid) { return sfy_step_advance_soft($sid, 'return'); }, null);
        $sess = sfy_load_session($sid) ?: $sess;
        if ((int)($sess['is_completed'] ?? 0) === 1) sfy_redirect(sfy_url('out/' . $sid));
    }
}

$db    = sfy_db();
$step  = max(1, (int)($sess['current_step'] ?? 1));
$total = max(1, (int)($sess['total_steps'] ?? 1));
$page  = 'task';

/* ── token → account chain ─────────────────────────────────────────── */
$st = $db->prepare("SELECT * FROM sfy_tokens WHERE token=? LIMIT 1");
$st->execute([(string)$sess['token']]);
$tok   = $st->fetch() ?: [];
$chain = (string)($tok['account_chain'] ?? '');
if ($chain === '') $chain = (string)sfy_setting('default_account_chain', '1,2');

/* ══════════════════════════════════════════════════════════════════════
   WHERE ARE THEY EARNING THIS STEP?

   Every task provider an administrator added (LootLabs, Work.ink, or
   anything pasted into Admin → Task providers) is offered here, each with
   its own accounts and its own budget of how many tasks one verification may
   run on it. The answer is remembered on the session, so the flow keeps
   using the provider the player picked until that budget runs out and then
   asks again.

   Two important properties:

     • with a single offerable provider nothing is asked and no budget is
       enforced — the flow behaves exactly as it did before providers
       existed, and nobody is stranded mid-flow for a limit they cannot
       satisfy anyway;
     • the pick itself can complete nothing. It is a preference stored on
       this session's own row, so a hand-typed ?pick= can only ever change
       where a task is opened, never whether it counted.
   ══════════════════════════════════════════════════════════════════════ */
$plan = sfy_provider_plan($sess);

if (!$plan['ok']) {
    /*
     * Every network parked is not a broken install — it is the owner saying
     * "not right now" — so it gets its own words and a retry that costs
     * nothing. Nothing about the run was touched: the session is still live and
     * the same link opens the same task the moment one network is resumed.
     */
    if (($plan['reason'] ?? '') === 'maintenance') {
        sfy_fatal('Networks under maintenance',
            'Every task network is paused for maintenance right now, so there is no task to open. Nothing was lost — '
            . 'this link keeps working; try again in a few minutes.',
            503, ['retry' => sfy_url('go/' . $sid)]);
    }
    sfy_fatal('No active task provider',
        'No task provider can serve step ' . $step . ' — a provider needs to be active, have at least one '
        . 'active account and (for its own link) a task URL. Add one in Admin → Task providers, then retry.',
        503, ['retry' => sfy_url('go/' . $sid), 'hint' => 'Admin → Task providers → + ADD PROVIDER']);
}

/* A rejection is worth saying out loud, but never a dead end: the chooser
   below is rendered with the reason attached. */
$pickNote = '';
$pick     = (int)sfy_param('pick', '0');
if ($pick > 0) {
    $chosen = null;
    foreach ($plan['providers'] as $row) if ((int)$row['provider']['id'] === $pick) $chosen = $row;

    if ($chosen === null) {
        $pickNote = 'That provider is no longer available.';
    } elseif (!empty($chosen['maintenance'])) {
        /* Parked by the owner while the player was mid-flow: say which one and
           why, instead of letting the box look like a broken button. */
        $pickNote = sfy_provider_label($chosen['provider']) . ' is under maintenance right now — '
                  . 'pick another network to carry on.';
    } elseif (empty($chosen['available'])) {
        /* No counts: how many tasks a network has done is the admin's business,
           not a number to read mid-run. */
        $pickNote = sfy_provider_label($chosen['provider']) . ' has already done its part for this link'
                  . ' — pick the other one.';
    } else {
        sfy_session_set_provider($sid, $pick);
        /*
         * Deliberately *not* written to the postback log: that table is what
         * the Postback Doctor and the status poll read, and a choice is not a
         * postback — one parked there would read as a rejected call and put
         * "postback rejected" on the player's screen. The truth about who
         * served a step is already on the handoff itself
         * (sfy_step_tokens.provider_id, shown in Admin → Sessions).
         */
        error_log('[SFY] provider picked for session ' . $sid . ' step ' . $step . ': '
                  . (string)($chosen['provider']['slug'] ?? $pick));
        /* A real navigation, so a refresh cannot re-pick and the URL keeps no
           state at all. Nothing was verified by it. */
        sfy_redirect(sfy_url('go/' . $sid));
    }
}

/* ══════════════════════════════════════════════════════════════════════
   THE PAGE BETWEEN TWO STEPS — "mission accomplished"

   The player is here because the step before this one was just verified: the
   landing page moved them on (sfy_step_next_url()). What they get is one card
   — the token that is verified, and one button (sfy_reward_ready_card()).

   What they used to get, at this exact moment, was a card headed "TASK 2/2"
   with a step strip, a task-status table and a countdown: the site telling a
   player mid-run exactly how much of a run is left. The numbers are still
   tracked — session, handoff, log, admin — the player just never reads them,
   because a person who reads "2" starts doing arithmetic about how long this
   will take, and that is the moment they leave.

   Deliberately shown *instead of* the handoff below, for two reasons:

     • nothing is minted for a step nobody has opened. No nonce, no log line
       and, most importantly, no click clock: the return check measures the
       dwell from the moment the player went into the task, so stamping it
       here would let somebody who reads this page for a minute (and then
       bounces straight back from the provider) satisfy the dwell on time they
       never spent in the task. The button carries the ordinary continuation
       (`?zt=1` while the zero-tap flow is on), where the handoff, its log and
       its clock all still happen;
     • it is shown once. `clicked_at` on the step's own handoff is what makes
       it a door and not a lobby: the moment the task has been opened (or
       reopened — the player coming back for another attempt) this page steps
       aside for the ordinary task card.
   ══════════════════════════════════════════════════════════════════════ */
$openBefore   = sfy_step_open($sid, $step);
$openedAt     = trim((string)($openBefore['clicked_at'] ?? ''));
$notOpenedYet = ($openedAt === '' || $openedAt === '0000-00-00 00:00:00');

/*
 * ── the pass-through ────────────────────────────────────────────────
 *
 * Nothing has opened this step yet, so there is nothing on this page to read:
 * the hand-off below is issued and the browser goes straight to the provider
 * (see sfy_hub_pass() in app/flow.php). The page itself is untouched — it is
 * still the only place the nonce, the log line and the click clock are made,
 * and every other reason to be here is served normally: a step that *has* been
 * opened (the Back button, a status refresh, the reload after the provider
 * lands), a choice that is still open, an exhausted budget, a reset.
 */
$passThrough = sfy_hub_pass() && $notOpenedYet;

/* ══════════════════════════════════════════════════════════════════════
   THE CHECKPOINT AFTER THE FIRST TASK

   The first completed task gets a short page of its own, so the player is told
   that it counted before the browser moves on. It is shown for the step that
   directly follows step 1 (`$step === 2`) and only while that step is still
   unopened, so a reload or the Back button never re-presents it. Later
   crossings keep the ordinary behaviour.

   Its button and its countdown are the same URL: the step's own continuation,
   flagged `cp=1`. That flag is what makes the move automatic *whatever the
   site's flow mode is* — the hand-off is still issued, logged and clocked by
   the page it lands on (nothing here can verify anything), but the browser goes
   from here straight into the task instead of being shown a second page asking
   the same question five seconds later.

   It is never rendered in front of the network chooser, which asks its
   question first and gets this page after the answer, on the way into the task.
   ══════════════════════════════════════════════════════════════════════ */
$cpAuto = (sfy_param('cp') === '1');

if ($step === 2 && $notOpenedYet && empty($plan['needs_choice']) && !$cpAuto) {
    $cpLabel = 'CLAIM CODE NOW';
    $cpUrl   = sfy_step_next_url($sid) . '?cp=1';

    sfy_head(['title' => 'Token registered', 'page' => $page, 'noindex' => true]);
    ?>
    <div class="shell">
      <?= sfy_ad_slot('top', $page) ?>
      <?= sfy_token_registered_card([
            'token'   => (string)($tok['token'] ?? $sess['token'] ?? ''),
            'url'     => $cpUrl,
            'label'   => $cpLabel,
            'seconds' => sfy_zerotap_handoff_seconds(),
        ]) ?>
      <?= sfy_ad_slot('banner', $page) ?>
      <?= sfy_ad_slot('bottom', $page) ?>
    </div>
    <?= sfy_ad_slot('popup', $page) ?>
    <?= sfy_ad_slot('float', $page) ?>
    <?= sfy_ad_slot('sticky', $page) ?>
    <?php
    sfy_foot(['page' => $page, 'pinned' => [
        'url'   => $cpUrl,
        'kind'  => 'task',
        'icon'  => '🏆',
        'label' => $cpLabel,
    ]]);
    exit;
}

/* …and never in front of the network chooser: a link that needs a provider
   picked for this step asks that question first, and gets this page after the
   answer, on the way into the task. Nor in front of the pass-through, which
   has nothing to claim between two tasks. */
if ($step > 1 && $notOpenedYet && empty($plan['needs_choice']) && !$passThrough && !$cpAuto && sfy_param('zt') !== '1') {
    /* One label, two places: the card's button and the pinned bar below. */
    $rewardLabel = 'CLAIM YOUR REWARD';
    $rewardUrl   = sfy_task_continue_url($sid);

    sfy_head(['title' => 'Mission accomplished', 'page' => $page, 'noindex' => true]);
    ?>
    <div class="shell">
      <?= sfy_ad_slot('top', $page) ?>
      <?= sfy_reward_ready_card([
            'token' => (string)($tok['token'] ?? $sess['token'] ?? ''),
            'url'   => $rewardUrl,
            'label' => $rewardLabel,
        ]) ?>
      <?= sfy_premium_block(['head' => 'Skip the tasks next time']) ?>
      <?= sfy_ad_slot('banner', $page) ?>
      <?= sfy_ad_slot('bottom', $page) ?>
    </div>
    <?= sfy_ad_slot('popup', $page) ?>
    <?= sfy_ad_slot('float', $page) ?>
    <?= sfy_ad_slot('sticky', $page) ?>
    <?php
    sfy_foot(['page' => $page, 'pinned' => [
        'url'   => $rewardUrl,
        'kind'  => 'task',
        'step'  => $step,
        'total' => $total,
        'icon'  => '🏆',
        'label' => $rewardLabel,
    ]]);
    exit;
}

if (!empty($plan['needs_choice'])) {
    $exhausted = ($plan['reason'] ?? '') === 'exhausted';
    sfy_head(['title' => 'Choose your task', 'page' => $page, 'noindex' => true]);
    ?>
    <div class="shell">
      <?= sfy_ad_slot('top', $page) ?>
      <?= sfy_bypass_warning($sess) ?>

      <div class="layout-split">
        <div>
          <div class="card brk" data-step="<?= (int)$step ?>" data-provider-choice="1">
            <div class="card-head">
              <h1>&gt; WHERE DO YOU WANT TO EARN IT?</h1>
              <span class="spacer"></span>
              <span class="badge b">CHOOSE ONE</span>
            </div>

            <?php if ($pickNote !== ''): ?>
              <div class="msg warn">◆ <?= sfy_esc($pickNote) ?></div>
            <?php endif; ?>

            <div class="msg info">
              ◆ <?= $exhausted
                    ? 'That network has done its part for this link. Pick the other one below to carry on.'
                    : 'Pick where you want to earn it — the task opens straight away and the page moves on by itself when you finish it.' ?>
            </div>

            <?php foreach ($plan['providers'] as $row):
                  $p        = $row['provider'];
                  $avail    = !empty($row['available']);
                  $parked   = !empty($row['maintenance']);
                  [$stateLabel, $stateTone] = sfy_provider_state_badge($row); ?>

              <div class="card<?= $avail ? '' : ' off' ?>" style="margin-top:10px">
                <div class="card-head" style="border:0;padding:0">
                  <h2>&gt; <?= sfy_esc(strtoupper(sfy_provider_label($p))) ?></h2>
                  <span class="spacer"></span>
                  <?= sfy_badge($stateLabel, $stateTone) ?>
                  <?= sfy_badge(sfy_provider_kind_label((string)$p['kind']), 'b') ?>
                </div>
                <?php if (trim((string)$p['description']) !== ''): ?>
                  <div class="ad-text"><?= sfy_esc((string)$p['description']) ?></div>
                <?php endif; ?>
                <div class="hint">
                  <?= $avail ? 'Ready to go — press the button and the task opens.'
                             : sfy_esc(sfy_provider_unavailable_note($row)) ?>
                </div>
                <?php if ($avail): ?>
                  <a class="btn btn-primary btn-lg btn-block"
                     href="<?= sfy_esc(sfy_url('go/' . $sid . '?pick=' . (int)$p['id'])) ?>">
                    ▶ EARN ON <?= sfy_esc(strtoupper(sfy_provider_label($p))) ?>
                  </a>
                <?php elseif ($parked): ?>
                  <span class="btn btn-block" aria-disabled="true" style="opacity:.45">
                    ⛔ UNDER MAINTENANCE
                  </span>
                <?php else: ?>
                  <span class="btn btn-block" aria-disabled="true" style="opacity:.55">ALREADY USED FOR THIS LINK</span>
                <?php endif; ?>
              </div>
            <?php endforeach; ?>

            <hr class="sep">
            <div class="btn-row">
              <button class="btn btn-gold" id="sfy-reset" data-sid="<?= sfy_esc($sid) ?>">⟲ RESET &amp; START OVER</button>
              <a class="btn btn-ghost" href="<?= sfy_esc(sfy_url('')) ?>">ABORT</a>
            </div>
            <div class="hint">Only the task itself can confirm a step — picking one here just decides where
              it opens. A reset gives you a fresh run and puts every network back on offer.</div>
            <div class="term mt-2" id="sfy-status" style="display:none;max-height:none"></div>
          </div>

          <?= sfy_ad_slot('banner', $page) ?>
          <?= sfy_premium_block(['head' => 'Skip every task', 'compact' => true]) ?>
        </div>

        <aside>
          <?= sfy_ad_slot('side', $page) ?>
          <div class="card">
            <div class="card-head"><h2>&gt; NETWORKS</h2></div>
            <div class="term" style="max-height:none;font-size:11.5px">
              <?php foreach ($plan['providers'] as $row): ?>
<span class="line <?= empty($row['available']) ? 'warn' : '' ?>"><?= sfy_esc(sfy_provider_label($row['provider'])) ?>:
  <?= !empty($row['maintenance']) ? 'under maintenance' : (empty($row['available']) ? 'used' : 'ready') ?></span>
              <?php endforeach; ?>
            </div>
            <div class="hint">A network that has done its part for this link stops being offered — carry on with
              the other one.</div>
          </div>
        </aside>
      </div>

      <?= sfy_ad_slot('bottom', $page) ?>
    </div>

    <script>
    /* The only thing this page does: the reset button, which throws the run
       away and puts every provider back on offer. Nothing here can confirm a
       step — that is still the postback or the verified return. */
    (function(){
      var sid    = <?= json_encode($sid) ?>;
      var apiUrl = <?= json_encode(sfy_url('api/step.php')) ?>;
      var el     = document.querySelector('#sfy-status');
      var rst    = document.querySelector('#sfy-reset');
      if (!rst) return;
      rst.addEventListener('click', function(){
        if (!confirm('Start this link over? The progress on the task you are on is lost.')) return;
        if (el) { el.style.display = 'block'; el.textContent = '> resetting…'; }
        fetch(apiUrl + '?a=reset&sid=' + encodeURIComponent(sid), {credentials:'same-origin', cache:'no-store'})
          .then(function(r){ return r.json(); })
          .then(function(d){
            if (d.redirect) { location.href = d.redirect; return; }
            if (el) el.textContent = '> reset failed (' + (d.reason || 'error') + ')';
          })
          .catch(function(){ if (el) el.textContent = '> reset failed — retry in a moment.'; });
      });
    })();
    </script>
    <?= sfy_ad_slot('popup', $page) ?>
    <?= sfy_ad_slot('float', $page) ?>
    <?= sfy_ad_slot('sticky', $page) ?>
    <?php
    sfy_foot(['page' => $page]);
    exit;
}

$provider = $plan['current']['provider'];
/*
 * A network may hold several links (two LootLabs rows are one network with two
 * accounts). The step walks the *pooled* rotation of every live member, so task
 * 1 opens on the first link and task 2 on the second.
 */
$members = array_values((array)($plan['current']['members'] ?? [$provider]));
$liveIds = array_values(array_filter(array_map('intval', (array)($plan['current']['live_ids'] ?? [])), fn($i) => $i > 0));
if (!$liveIds) $liveIds = [(int)$provider['id']];

$account  = sfy_resolve_account($chain, $step, [
    'provider_id'  => (int)$provider['id'],
    'provider_ids' => $liveIds,
]);

if (!$account) {
    sfy_fatal('No active task provider',
        'No active ' . sfy_provider_label($provider) . ' account can serve step ' . $step . ' of this chain ('
        . ($chain !== '' ? $chain : 'empty') . '). Add one in Admin → Task providers, then retry.',
        503, ['retry' => sfy_url('go/' . $sid), 'hint' => 'Admin → Task providers → accounts of '
                                                        . sfy_provider_label($provider)]);
}

/*
 * The link that owns the resolved account builds the handoff.
 *
 * Each link of a network carries its own task URL, its own Redirect API key and
 * its own postback URL, so a step earned on the second link has to be built by
 * that row — the network's first row would send the player into the wrong task
 * with the wrong key. The handoff also records that row's id, which is what the
 * network's budget is counted against.
 */
$link = $provider;
foreach ($members as $m) {
    if ((int)$m['id'] === (int)($account['provider_id'] ?? 0)) { $link = $m; break; }
}

/* ── anti-bypass bookkeeping ─────────────────────────────────────────
   The step's own row was read once, above (the confirmation page needs
   `clicked_at`); nothing has written to it since. */
$hand = sfy_step_issue($sid, $step, (int)$account['id'], (int)$link['id']);
$hand['sid'] = $sid;

/* P1-1 (2026-10-24): remember this browser was handed off for this step. /done
   requires it on the way back, which a server-side resolver cannot present. */
sfy_step_cookie_set($sid, $step, (string)$hand['nonce']);

// Reset the dwell clock for a freshly issued step.
if (!$openBefore) {
    sfy_try(function () use ($db, $sid) {
        $db->prepare("UPDATE sfy_sessions SET step_started_at=NOW() WHERE session_id=?")->execute([$sid]);
        return true;
    }, false);
}

/* The chosen link builds the URL: LootLabs keeps its Redirect API
   anti-bypass, Work.ink and anything custom use their own template. */
$built = sfy_provider_build_handoff($link, $account, $tok, $hand);

if ($built['url'] === '') {
    /*
     * The handoff could not be built on purpose: anti-bypass is REQUIRED on
     * this account and the encryptor refused, or the provider has no task URL.
     * Say exactly why instead of silently downgrading the protection.
     */
    $why = (string)($built['encrypt']['error'] ?? $built['error'] ?? 'the handoff was rejected');
    sfy_fatal('Task link unavailable',
        'The handoff to ' . sfy_provider_label($provider) . ' could not be generated (' . $why . '). '
        . 'An administrator can test the account in Admin → Task providers, or switch the anti-bypass mode '
        . 'to AUTO so a plain link is used when the API is down.',
        503, ['retry' => sfy_url('go/' . $sid), 'hint' => 'Admin → Task providers']);
}

sfy_account_touch((int)$account['id']);

/*
 * ── the pinned bar is this page's button, linked ─────────────────────
 *
 * On a phone the bar pinned to the bottom of the screen is the *continue*
 * affordance: outside the flow it is the "how to get token" guide, and inside
 * it must be the same action the card asks for, not a second, different answer.
 * So the bar is handed the identical handoff URL — the same single-use nonce —
 * and, in the main branch below, the same nonce/sid pair the button's beacon
 * posts, because the return check refuses a step whose click clock never
 * started. The label comes from Settings (`pinned_label_continue`).
 */
$bar = [
    'url'   => $built['url'],
    'kind'  => 'task',
    'step'  => $step,
    'total' => $total,
    'icon'  => '▶',
];

/* One label, two places: the card's button below and the pinned bar print the
   same string, so the bar can never advertise a different action from the one
   on screen. The countdown card's button is the same link again. */
$openLabel     = 'OPEN TASK & RETURN';
$openNextLabel = 'OPEN TASK NOW';

/*
 * ── zero-tap continuation ────────────────────────────────────────────
 *
 * `/done` forwards a player whose step was just confirmed to this page with
 * `zt=1` instead of making them read a card and press OPEN TASK & RETURN for
 * a handoff the server generates anyway. With the zero-tap flow on, the
 * handoff above is already issued, so there is nothing left to press: stamp
 * the click clock the button's beacon would have stamped and hand the browser
 * to the provider.
 *
 * The anti-bypass chain is exactly the one a tap produces — the single-use
 * nonce belongs to this step, the handoff is logged, and the step still only
 * advances through the signed postback or the verified provider return. A
 * hand-typed `?zt=1` merely skips the card; it cannot complete anything.
 */
/*
 * The pass-through always hands over on an unopened step; zero-tap only when
 * the crossing carried `zt=1` (the continuation a confirmed step forwards).
 * Either way this is an *auto-open*: nothing was pressed at the provider.
 */
$auto = $passThrough || (sfy_zerotap_enabled() && sfy_param('zt') === '1') || $cpAuto;

try {
    $db->prepare("INSERT INTO sfy_postback_log (session_id, account_id, step, unique_id, nonce, verified, accepted,
                                                reason, user_agent, raw_query, created_at)
                  VALUES (?,?,?,?,?,0,0,?,?,?,NOW())")
       ->execute([$sid, (int)$account['id'], $step, $sid, $hand['nonce'],
                  ($auto ? 'task_autoopen_' : 'task_handoff_') . $built['mode'],
                  sfy_user_agent(),
                  ($auto ? 'handoff_auto' : 'handoff') . ';provider=' . (string)($link['slug'] ?? $link['id'])]);
} catch (Throwable $e) { error_log('[SFY] handoff log: ' . $e->getMessage()); }

if ($auto) {
    /* The return check refuses a step whose clock never started, so the clock
       must be stamped here: there is no button to send its beacon. */
    sfy_step_begin($sid, (string)$hand['nonce']);

    /*
     * Pass-through: the hand-off is complete (nonce, log line, click clock), so
     * there is nothing left for a screen to do. A real 302 rather than a
     * rendered page that redirects itself, because "the player never sees this"
     * is the whole point — and the browser's Back button still lands here, on
     * the ordinary task card, now that the step it belongs to has been opened.
     */
    if ($passThrough || $cpAuto) sfy_redirect($built['url']);

    /*
     * Say what happened, then move. Going straight from the provider's page to
     * the next task with no word is indistinguishable from the previous task
     * being retried — the same task page, the same shape — so the hand-off is
     * shown as its own card: which task is done and counted, which one is
     * opening, and a short countdown before the browser goes there.
     *
     * The handoff itself (nonce, click clock, log) is already issued above, so
     * the wait changes nothing about how the step can be verified. The URL is a
     * plain link too, so a blocked script still lets the player through. How
     * long the wait is the admin's `Hand-off countdown (s)` (2–15s, shipped 5)
     * — reading time for the message, never a second path to the next task.
     */
    sfy_head(['title' => 'Your next task', 'page' => $page, 'noindex' => true]);
    ?>
    <div class="shell">
      <?= sfy_ad_slot('top', $page) ?>
      <?= sfy_bypass_warning($sess) ?>
      <?= sfy_task_handoff_card([
            'done'     => max(1, $step - 1),
            'next'     => $step,
            'total'    => $total,
            'url'      => $built['url'],
            'seconds'  => sfy_zerotap_handoff_seconds(),
            'provider' => sfy_provider_label($provider) . ' · ' . (string)$account['name'],
            'label'    => $openNextLabel,
        ]) ?>
      <?= sfy_ad_slot('bottom', $page) ?>
    </div>
    <?php
    /* The countdown card's own link, so a thumb can skip the wait — the
       handoff is already issued and its clock already stamped. */
    sfy_foot(['page' => $page, 'pinned' => $bar + ['label' => $openNextLabel]]);
    exit;
}

$expiresAt = (string)($sess['expires_at'] ?? '');
$expiresIn = $expiresAt === '' ? 0 : max(0, strtotime($expiresAt) - time());

sfy_head(['title' => 'Your task', 'page' => $page, 'noindex' => true]);
?>
<div class="shell">
  <?= sfy_ad_slot('top', $page) ?>
  <?= sfy_bypass_warning($sess) ?>

  <div class="layout-split">
    <div>
      <div class="card brk" data-step="<?= (int)$step ?>" data-expires="<?= (int)$expiresIn ?>">
        <div class="card-head">
          <h1>&gt; YOUR_TASK</h1>
          <span class="spacer"></span>
          <?php [$abLabel, $abTone, $abHint] = sfy_provider_handoff_badge($built); ?>
          <span class="badge <?= sfy_esc($abTone) ?>" title="<?= sfy_esc($abHint) ?>">
            <?= sfy_esc($abLabel) ?>
          </span>
          <span class="badge gr" title="the network this task is being earned on">
            <?= sfy_esc(strtoupper(sfy_provider_label($provider))) ?>
          </span>
        </div>

        <?php $rc = sfy_return_check_state(); ?>
        <?= sfy_task_status([
              ['Your task', sfy_esc(sfy_provider_label($provider)) . ' · ' . sfy_esc((string)$account['name'])],
              ['Time left', (int)floor($expiresIn / 60) . 'm ' . ($expiresIn % 60) . 's', 'sfy-timer', 'mono'],
              ['Confirmation', 'Automatic — nothing to type or paste'],
              ['Status', '<span class="dot static gold"></span> Waiting for you to finish the task', 'sfy-live'],
          ]) ?>

        <div class="msg info mt-2">
          ◆ Open the task below and finish it completely. Keep this tab open — the page moves on by itself
          <?= $rc['active'] ? 'the moment you come back from the task' : 'the moment the task reports back' ?>.
        </div>

        <a class="btn btn-primary btn-lg mt-2"
           id="sfy-open-task"
           href="<?= sfy_esc($built['url']) ?>"
           data-sid="<?= sfy_esc($sid) ?>" data-nonce="<?= sfy_esc($hand['nonce']) ?>">
          ▶ <?= sfy_esc($openLabel) ?>
        </a>
        <div class="hint">If the task page does not load, use the mirror link:
          <a href="<?= sfy_esc($built['url']) ?>" target="_blank" rel="noopener">open in a new tab</a>.
        </div>

        <hr class="sep">

        <div class="btn-row">
          <button class="btn" id="sfy-check">↻ I FINISHED — CHECK STATUS</button>
          <button class="btn btn-gold" id="sfy-reset" data-sid="<?= sfy_esc($sid) ?>">⟲ RESET &amp; START OVER</button>
          <a class="btn btn-ghost" href="<?= sfy_esc(sfy_url('')) ?>">ABORT</a>
        </div>
        <div class="hint">Stuck on a task that will not light up? <b>RESET &amp; START OVER</b> starts this
          link over — you keep the same link and nothing else to re-enter.</div>
        <div class="term mt-2" id="sfy-status" style="display:none;max-height:none"></div>
      </div>

      <?= sfy_ad_slot('banner', $page) ?>
      <?= sfy_premium_block(['head' => 'Skip every task', 'compact' => true]) ?>
    </div>

    <aside>
      <?= sfy_ad_slot('side', $page) ?>
      <div class="card">
        <div class="card-head"><h2>&gt; RULES</h2></div>
        <div class="term" style="max-height:none;font-size:11.5px">
<span class="line warn">closing the task early fails the step</span>
<span class="line">one device per token by default</span>
<span class="line bad">faking the postback flags your device</span>
        </div>
      </div>
    </aside>
  </div>

  <?= sfy_ad_slot('bottom', $page) ?>
</div>

<script>
/*
 * Everything here happens in the background. Nothing on this page reloads
 * itself: the poll reports the step it is showing (`cur`) so a step that is
 * already on screen is never mistaken for an advance, and a genuine advance
 * swaps the card in place instead of reloading the document.
 */
(function(){
  var sid    = <?= json_encode($sid) ?>;
  var apiUrl = <?= json_encode(sfy_url('api/step.php')) ?>;
  var goUrl  = <?= json_encode(sfy_url('go/' . $sid)) ?>;

  var card = document.querySelector('.card.brk');
  if (!card) return;

  var cur   = readCur();
  var timer = null;
  var watch = null;
  var busy  = false;   // one swap at a time

  function readCur(){
    var n = parseInt(card.getAttribute('data-step') || '1', 10);
    return isNaN(n) || n < 1 ? 1 : n;
  }

  /* ret=1: a return that was already recorded (the provider landed the player
     somewhere in this flow) may be confirmed here once the dwell has passed.
     It can never *record* a return — only /done and this page do that, and only
     for a real provider landing. */
  function statusUrl(extra){
    return apiUrl + '?a=status&ret=1' + (extra || '') + '&cur=' + cur + '&sid=' + encodeURIComponent(sid);
  }

  /* Update the status text without rebuilding the row — replacing the dot on
     every poll is exactly the flicker this page used to have. */
  function setLive(txt, tone){
    var live = card.querySelector('#sfy-live');
    if (!live || live.getAttribute('data-live') === txt) return;
    live.setAttribute('data-live', txt);
    var dot = live.querySelector('.dot');
    if (dot) dot.className = 'dot static ' + (tone || 'gold');
    var tail = live.lastChild;
    if (tail && tail.nodeType === 3) tail.nodeValue = ' ' + txt;
    else live.appendChild(document.createTextNode(' ' + txt));
  }

  function startTimer(){
    if (timer) clearInterval(timer);
    var left = parseInt(card.getAttribute('data-expires') || '0', 10);
    if (isNaN(left) || left < 0) left = 0;
    var el = card.querySelector('#sfy-timer');
    function paint(){
      if (!el) return;
      var t = Math.floor(left / 60) + 'm ' + (left % 60) + 's';
      if (el.textContent !== t) el.textContent = t;
    }
    paint();
    timer = setInterval(function(){
      left--;
      if (left <= 0) { left = 0; paint(); clearInterval(timer); return; }
      paint();
    }, 1000);
  }

  /* A real advance: fetch the same URL and replace only the card, so the ads,
     the layout and the scroll position stay untouched. */
  function swapIn(){
    if (busy) return;
    busy = true;
    fetch(goUrl, {credentials: 'same-origin', cache: 'no-store'})
      .then(function(r){ return r.text(); })
      .then(function(html){
        var doc   = new DOMParser().parseFromString(html, 'text/html');
        var fresh = doc.querySelector('.card.brk');
        var here  = document.querySelector('.card.brk');
        /* Only a *task* card may be swapped in. If the session finished in the
           meantime the server answered with the code page, whose copy button
           needs its own script — that must be a real navigation. */
        if (!fresh || !here || !fresh.getAttribute('data-step')) throw new Error('not a task card');
        var node = document.importNode(fresh, true);
        here.replaceWith(node);
        /* The pinned bar lives in the footer, outside the card, so it is refilled
           from the same response: its link and nonce belong to the step now on
           screen, never to the one that was just confirmed. */
        var freshBar = doc.querySelector('.tut-fab');
        var hereBar  = document.querySelector('.tut-fab');
        if (freshBar && hereBar) hereBar.replaceWith(document.importNode(freshBar, true));
        card = node;
        cur  = readCur();
        busy = false;
        bind();
        startTimer();
        startWatch();
        setLive('Your task is ready', 'g');
      })
      .catch(function(){ busy = false; location.href = goUrl; });
  }

  function box(msg){
    var el = card.querySelector('#sfy-status');
    if (!el) return null;
    el.style.display = 'block';
    if (msg !== undefined) el.textContent = msg;
    return el;
  }

  /* A step really moved on and the server already said where the new step
     lives. Zero-tap hands over a *different* URL (the flagged continuation,
     which opens the next task itself) and that has to be a real navigation —
     a fetch would only return the provider's page. Without zero-tap the URL is
     this same page, which must be swapped in place so the ads and the scroll
     position survive. */
  function advanceToNext(next){
    if (next && next !== goUrl) { location.href = next; return; }
    swapIn();
  }

  function follow(d, el){
    if (d.status === 'completed') { if (el) el.textContent = '> confirmed! loading your code…'; location.href = d.redirect; return true; }
    if (d.status === 'advanced')  { if (el) el.textContent = '> step confirmed — next task ready';
                                    advanceToNext(d.redirect); return true; }
    return false;
  }

  function poll(silent){
    fetch(statusUrl(''), {credentials: 'same-origin', cache: 'no-store'})
      .then(function(r){ return r.json(); })
      .then(function(d){
        if (follow(d, null)) return;
        /* The session moved somewhere else (reset in another tab, or a step the
           server already advanced past). Re-sync quietly. */
        if (d.step && d.step !== cur) { advanceToNext(d.redirect); return; }
        if (!silent){
          if (d.return_note === 'return_too_fast' && d.wait > 0) setLive('Hold on ' + d.wait + 's — confirming your task', 'y');
          else if (d.return_note === 'task_never_opened') setLive('Open the task first', 'r');
          else setLive('Waiting for you to finish the task', 'gold');
        }
      })
      .catch(function(){ if (!silent) setLive('Connection hiccup — still watching', 'r'); });
  }

  function startWatch(){
    if (watch) clearInterval(watch);
    var rounds = 0;
    watch = setInterval(function(){
      if (++rounds > 75) { clearInterval(watch); return; }
      poll(!document.hidden);
    }, 4000);
  }

  /* Stamp the step's click clock. Called by the card's button and by the copy
     of it in the pinned bar — the return check refuses a step whose clock never
     started, so the two must be the same thing to the server. */
  function stampOpen(nonce){
    try{
      var u = apiUrl + '?a=start&sid=' + encodeURIComponent(sid) + '&n=' + encodeURIComponent(nonce || '');
      if (navigator.sendBeacon) navigator.sendBeacon(u); else fetch(u,{keepalive:true}).catch(function(){});
    }catch(e){}
  }

  /* The pinned bar is rendered after this script, so its click is caught as it
     bubbles instead of by a direct binding. */
  document.addEventListener('click', function(ev){
    var el = ev.target;
    while (el && el !== document) {
      if (el.id === 'sfy-open-task-fab') { stampOpen(el.getAttribute('data-nonce')); return; }
      el = el.parentNode;
    }
  });

  function bind(){
    var open = card.querySelector('#sfy-open-task');
    if (open) open.addEventListener('click', function(){
      stampOpen(open.getAttribute('data-nonce'));
    });

    var ck = card.querySelector('#sfy-check');
    if (ck) ck.addEventListener('click', function(){
      var el = box('> checking task status…');
      fetch(statusUrl(''), {credentials: 'same-origin', cache: 'no-store'})
        .then(function(r){ return r.json(); })
        .then(function(d){
          if (follow(d, el)) return;
          if (d.step && d.step !== cur) { advanceToNext(d.redirect); return; }
          if (el) el.textContent = '> not confirmed yet\n> finish every step of the task, then check again.';
        })
        .catch(function(){ if (el) el.textContent = '> status check failed — retry in a moment.'; });
    });

    var rst = card.querySelector('#sfy-reset');
    if (rst) rst.addEventListener('click', function(){      if(!confirm('Start this link over? The progress on the task you are on is lost.')) return;
      var el = box('> resetting…');
      fetch(apiUrl + '?a=reset&sid=' + encodeURIComponent(sid))
        .then(function(r){ return r.json(); })
        .then(function(d){
          if (d.status === 'reset') { location.href = d.redirect; return; }
          /* Finished sessions cannot be reset — they hand over their code. */
          if (d.redirect) { location.href = d.redirect; return; }
          if (el) el.textContent = '> reset failed (' + (d.reason || 'error') + ')';
        })
        .catch(function(){ if (el) el.textContent = '> reset failed — retry in a moment.'; });
    });
  }

  bind();
  startTimer();
  startWatch();

  /* A tab that comes back to the foreground checks straight away. */
  document.addEventListener('visibilitychange', function(){ if (!document.hidden) poll(false); });
})();
</script>
<?= sfy_ad_slot('popup', $page) ?>
<?= sfy_ad_slot('float', $page) ?>
<?= sfy_ad_slot('sticky', $page) ?>
<?php sfy_foot(['page' => $page, 'pinned' => $bar + ['label' => $openLabel, 'sid' => $sid, 'nonce' => $hand['nonce']]]); ?>
