<?php
declare(strict_types=1);
/**
 * Landing page (/).
 *
 * The body is assembled from the section stack the administrator builds in
 * Admin → Homepage (stored as JSON in sfy_config). Nothing in this file
 * decides what the page looks like; it only provides the claim-box behaviour
 * and hands the sections to sfy_layout_render().
 */
require_once dirname(__DIR__) . '/app/core.php';
header('Cache-Control: no-store, max-age=0, must-revalidate');

sfy_install_if_empty();

$page = 'home';

/* Context the section renderers read (kept global so sections stay pure). */
$GLOBALS['SFY_HOME_ERROR'] = sfy_param('e');

$current = sfy_resolve_current_session();
$resume  = '';
if ($current && (int)($current['is_completed'] ?? 0) === 0 && sfy_session_is_live($current)) {
    $resume = (string)($current['session_id'] ?? '');
}
$GLOBALS['SFY_RESUME_SESSION'] = $resume;

sfy_head(['title' => '', 'page' => $page]);
?>
<div class="shell">
  <?= sfy_layout_render(sfy_layout(sfy_is_preview()), $page) ?>
</div>

<script>
(function(){
  var input = document.getElementById('sfy-token-input');
  var btn   = document.getElementById('sfy-claim-btn');
  if(!input || !btn) return;
  function go(){
    var raw = (input.value || '').trim();
    if(!raw){ input.focus(); return; }
    var m = raw.match(/\/claim\/([A-Za-z0-9\-]{4,64})/);
    var tok = m ? m[1] : raw.replace(/[^A-Za-z0-9\-]/g, '');
    if(!tok){ input.focus(); return; }
    location.href = <?= json_encode(sfy_url('claim/')) ?> + encodeURIComponent(tok);
  }
  btn.addEventListener('click', go);
  input.addEventListener('keydown', function(e){ if(e.key === 'Enter') go(); });
  if(!document.body.classList.contains('preview-mode')) input.focus();
})();
</script>
<?php
sfy_foot(['page' => $page]);
