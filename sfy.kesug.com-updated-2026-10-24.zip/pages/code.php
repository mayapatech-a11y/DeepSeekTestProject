<?php
declare(strict_types=1);
/**
 * /out/<session> — final code page.
 * Only reachable by a verified, completed session that is still inside the
 * code-view window and under the view cap. The device is logged here too.
 */
require_once dirname(__DIR__) . '/app/core.php';

sfy_install_if_empty();
sfy_rate_limit_hit('code', sfy_client_ip());

$sid = sfy_param('sid');
if ($sid === '') $sid = (string)pathinfo((string)parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), PATHINFO_BASENAME);

$page = 'code';

if ($sid === '' || !preg_match('/^[a-f0-9]{16,64}$/i', $sid)) {
    sfy_fatal('Invalid link', 'This code link is malformed. Start again from the Roblox menu.', 400, ['retry' => sfy_url('')]);
}

$sess = sfy_load_session($sid);
if (!$sess) {
    sfy_fatal('Session not found', 'We could not find this verification session. Start again from the Roblox menu.',
        404, ['retry' => sfy_url('')]);
}

/* A verified postback can clear the flags and release the code; pull before
   the hard block. */
if (function_exists('sfy_relay_pull')) {
    sfy_relay_pull();
    $sess = sfy_load_session($sid) ?: $sess;
}

$device   = (int)($sess['device_id'] ?? 0) > 0 ? sfy_device_find((int)$sess['device_id']) : null;
$retryUrl = sfy_url('claim/' . urlencode((string)$sess['token']));

if ($device && (int)$device['is_blocked'] === 1) {
    sfy_fatal('Device blocked', 'This device has been blocked by the administrator.', 403);
}

/* Hard block: a flagged run never releases the code, even if something
   advanced it through the return check. A verified postback clears the flags
   first (see api/hook.php). */
sfy_bypass_block_page($sess, 'code');

if ((int)($sess['is_completed'] ?? 0) !== 1) {
    $step  = max(1, (int)($sess['current_step'] ?? 1));
    $total = max(1, (int)($sess['total_steps'] ?? 1));
    sfy_head(['title' => 'Verification incomplete', 'page' => $page, 'noindex' => true]);
    ?>
    <div class="shell">
      <?= sfy_ad_slot('top', $page) ?>
      <?= sfy_bypass_warning($sess) ?>
      <div class="card brk" style="--accent:#FFCB3D">
        <div class="card-head"><h1>&gt; VERIFICATION INCOMPLETE</h1><span class="spacer"></span>
          <span class="badge y">NOT FINISHED</span></div>
        <div class="term" style="max-height:none">
&gt; code withheld
&gt; reason: a task of this link was never verified
&gt; anti-bypass gate is active — the code cannot be skipped
        </div>
        <?php $resumeLabel = 'RESUME STEP ' . $step; ?>
        <a class="btn btn-primary btn-lg mt-2" href="<?= sfy_esc(sfy_url('go/' . $sid)) ?>">▶ <?= sfy_esc($resumeLabel) ?></a>
        <div class="hint">Expires <?= sfy_esc((string)($sess['expires_at'] ?? 'soon')) ?> — finish the task before then.</div>
      </div>
      <?= sfy_ad_slot('banner', $page) ?>
      <?= sfy_ad_slot('bottom', $page) ?>
    </div>
    <?= sfy_ad_slot('popup', $page) ?>
    <?= sfy_ad_slot('sticky', $page) ?>
    <?php /* The bar is the same button again, wording included. */
          sfy_foot(['page' => $page, 'pinned' => [
              'url'   => sfy_url('go/' . $sid),
              'kind'  => 'task',
              'step'  => $step,
              'total' => $total,
              'icon'  => '▶',
              'label' => $resumeLabel,
          ]]); ?>
    <?php
    exit;
}

/*
 * P1-4 (2026-10-24), opt-in: release the code only to the browser that claimed
 * the run. Off by default because code_handoff = any promises that a fresh
 * phone/browser can reopen the code; turn it on when that convenience is not
 * needed. It stops a server-side fetch of /out/<sid>.
 */
if ((bool)sfy_cfg('security.code_bind_browser', false) && sfy_get_session_cookie() !== $sid) {
    sfy_fatal('Open this link in the browser that ran the tasks',
        'The code is released to the browser that completed the verification. Open the same link there, '
        . 'or ask the site owner to allow any device.',
        403, ['retry' => sfy_url('')]);
}

/* ── who is asking, and are they allowed to see this code? ────────────
   The viewer is registered server-side as well as by the beacon, so the
   device log records who looked at a code even with JavaScript blocked. */
$viewer    = sfy_device_upsert(sfy_device_profile($_POST + $_GET), false);
$handoff   = sfy_code_handoff_mode();
$elsewhere = !sfy_code_device_matches($sess, $viewer);

if (!sfy_code_handoff_allows($sess, $viewer)) {
    sfy_fatal('Code belongs to another device',
        'These tasks were completed on a different device and device lock is on, so this code can only be '
        . 'displayed there. Open the same link on the device that finished the tasks.',
        403, [
            'retry' => sfy_url(''),
            'hint'  => 'The site owner can let any device reopen a finished code under Settings → Code device lock.',
        ]);
}

$gate = sfy_code_gate($sess);
if (!$gate['ok']) {
    if ($gate['reason'] === 'expired') {
        sfy_fatal('Code expired', 'The code for this session expired ' . (int)sfy_setting_int('code_view_ttl_minutes', 30)
            . ' minutes after completion. Claim a new token from the Roblox menu.', 410, ['retry' => sfy_url('')]);
    }
    if ($gate['reason'] === 'too_many_views') {
        $whyShare = $handoff === 'device'
            ? 'Only the device that completed the tasks may display it, and the limit is spent.'
            : 'Every display is counted, so a code cannot be passed around freely.';
        sfy_fatal('Code view limit reached',
            'This code was displayed ' . (int)sfy_setting_int('max_code_views', 4) . ' times already (limit '
            . (int)sfy_setting_int('max_code_views', 4) . '). ' . $whyShare, 429, ['retry' => sfy_url('')]);
    }
    sfy_fatal('Not verified', 'This session has not completed all tasks yet.', 403, ['retry' => $retryUrl]);
}

/* ── approved: release the code ────────────────────────────────────── */
$st = sfy_db()->prepare("SELECT code, game_name FROM sfy_tokens WHERE token=? LIMIT 1");
$st->execute([(string)$sess['token']]);
$tokRow = $st->fetch() ?: [];
$code   = (string)($tokRow['code'] ?? 'N/A');
$game   = (string)($tokRow['game_name'] ?? '');

sfy_code_view_log($sid, (int)($sess['device_id'] ?? 0));
sfy_code_open_record($sess, $viewer, sfy_client_ip());

$stats   = sfy_token_code_stats((string)($sess['token'] ?? ''));
$lastWho = is_array($stats['last'] ?? null) ? sfy_code_open_where($stats['last']) : '';

$viewLimit = sfy_setting_int('max_code_views', 4);
$viewsLeft = $viewLimit > 0 ? max(0, $viewLimit - ((int)($sess['code_views'] ?? 0) + 1)) : -1;

sfy_head(['title' => 'Mission complete', 'page' => $page, 'noindex' => true]);
?>
<div class="shell">
  <?= sfy_ad_slot('top', $page) ?>
  <?= sfy_bypass_warning($sess) ?>

  <div class="layout-split">
    <div>
      <div class="card brk" style="--accent:#3BF5D0">
        <div class="card-head">
          <h1>&gt; MISSION_COMPLETE</h1>
          <span class="spacer"></span>
          <?php if ($elsewhere): ?>
            <span class="badge y">○ REOPENED ON ANOTHER DEVICE</span>
          <?php endif; ?>
          <span class="badge g">● VERIFIED</span>
        </div>

        <div class="msg ok">◆ Your reward is ready for collection — here is your code.</div>

        <div class="label">Your reward code</div>
        <div class="code-box" id="sfy-code"><?= sfy_esc($code) ?></div>

        <div class="btn-row">
          <button class="btn btn-primary grow" id="sfy-copy">📋 COPY CODE</button>
          <a class="btn" href="<?= sfy_esc(sfy_url('')) ?>">DONE</a>
        </div>

        <hr class="sep">

        <div class="label">Mission token</div>
        <div class="inline">
          <input class="grow mono" id="sfy-token" value="<?= sfy_esc((string)$sess['token']) ?>" readonly spellcheck="false">
          <button class="btn" id="sfy-copy-token">🔑 COPY TOKEN</button>
        </div>

        <div class="grid grid-3 mt-2">
          <?= sfy_kpi('Device', sfy_short((string)($device['device_name'] ?? $sess['device_name'] ?? 'unknown'), 12), 'blue') ?>
          <?= sfy_kpi('Location', (string)(($sess['country'] ?? '') ?: 'Unknown'), '') ?>
          <?= sfy_kpi('Opened', (int)$stats['opens'], '', (int)$stats['devices'] . ' device(s)') ?>
        </div>

        <div class="grid grid-2" style="margin-top:14px">
          <?= sfy_kpi('Views left', $viewsLeft < 0 ? '∞' : $viewsLeft, 'purple', 'limit ' . (int)$viewLimit) ?>
          <?= sfy_kpi('Last opened from', $lastWho !== '' ? sfy_short($lastWho, 26) : '—', '',
                      ($stats['foreign'] > 0 ? (int)$stats['foreign'] . ' from another device' : 'same device every time')) ?>
        </div>

        <div class="term mt-2" style="max-height:none;font-size:11.5px">
&gt; completed at .. <?= sfy_esc((string)($sess['completed_at'] ?? $sess['created_at'])) ?>

&gt; postbacks ..... <?= (int)($sess['postback_count'] ?? 0) ?> verified

&gt; device ........ <?= sfy_esc((string)($device['browser'] ?? '')) ?> on <?= sfy_esc((string)($device['os'] ?? '')) ?>

&gt; fingerprint ... <?= sfy_esc(sfy_short((string)($device['device_key'] ?? $sess['device_fingerprint'] ?? 'n/a'), 26)) ?>
        </div>

        <div class="hint">
          Paste the code into the Roblox menu.
          <?= $handoff === 'device'
              ? 'Do not share it — this code only opens on the device that completed the tasks.'
              : 'Do not share it — it is tied to your token and every display is counted.' ?>
        </div>
      </div>

      <?= sfy_ad_slot('banner', $page) ?>
    </div>

    <aside>
      <?= sfy_ad_slot('side', $page) ?>
      <div class="card">
        <div class="card-head"><h2>&gt; NEXT_TIME</h2></div>
        <div class="term" style="max-height:none;font-size:11.5px">
<span class="line">get a fresh token in the menu</span>
<span class="line">open the claim link on this device</span>
<span class="line">premium users skip all tasks</span>
        </div>
        <?php if ($d = sfy_setting_text('support_discord')): ?>
          <a class="btn btn-gold btn-block mt-2" href="<?= sfy_esc($d) ?>" target="_blank" rel="noopener">GO PREMIUM</a>
        <?php endif; ?>
      </div>
    </aside>
  </div>

  <?= sfy_ad_slot('bottom', $page) ?>
</div>

<script>
(function(){
  /* Two things are worth copying off this page: the code the player came for,
     and the token they would otherwise have to dig out of their history. */
  var btn   = document.getElementById('sfy-copy');
  var tbtn  = document.getElementById('sfy-copy-token');
  var tsrc  = document.getElementById('sfy-token');
  var code  = document.getElementById('sfy-code').textContent.trim();
  var token = tsrc ? String(tsrc.value) : '';

  function wire(el, was, text, value){
    if (!el || value === '') return;
    var told = false;
    function done(){
      if (told) return;
      told = true; el.textContent = text;
      setTimeout(function(){ el.textContent = was; told = false; }, 1600);
    }
    function fallback(){
      var t = document.createElement('textarea'); t.value = value; document.body.appendChild(t);
      t.select(); try { document.execCommand('copy'); } catch(e) {}
      document.body.removeChild(t); done();
    }
    el.addEventListener('click', function(){
      if (navigator.clipboard) navigator.clipboard.writeText(value).then(done).catch(function(){ fallback(); });
      else fallback();
    });
  }

  wire(btn,  '📋 COPY CODE',  '✅ COPIED',  code);
  wire(tbtn, '🔑 COPY TOKEN', '✅ COPIED',  token);
  // Log this device against the completed session (server side counters).
  try {
    fetch(<?= json_encode(sfy_url('api/device.php')) ?>, {
      method:'POST', headers:{'Content-Type':'application/json'}, keepalive:true,
      body: JSON.stringify(Object.assign(window.SFY_device ? window.SFY_device() : {}, {
        session_id: <?= json_encode($sid) ?>, token: <?= json_encode((string)($sess['token'] ?? '')) ?>,
        event: 'code_view'
      }))
    }).catch(function(){});
  } catch(e){}
})();
</script>
<?= sfy_ad_slot('popup', $page) ?>
<?= sfy_ad_slot('float', $page) ?>
<?= sfy_ad_slot('sticky', $page) ?>
<?php sfy_foot(['page' => $page]); ?>
