<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/app/core.php';
header('Cache-Control: no-store, max-age=0, must-revalidate');
sfy_support_ensure();

$page   = 'support';
$code   = strtoupper(trim((string)sfy_param('code')));
$req    = $code !== '' ? sfy_support_find_code($code) : null;
$msgs   = $req ? sfy_support_messages((int)$req['id']) : [];
$error  = '';
$sent   = sfy_param('sent') === '1';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    if (!sfy_csrf_check((string)($_POST['csrf'] ?? ''))) {
        $error = 'Security token expired — reload and try again.';
    } elseif ((string)sfy_param('website') !== '') {
        $error = 'Could not send that request.';
    } elseif ((string)sfy_param('action') === 'support_new') {
        $res = sfy_support_create([
            'name' => sfy_param('name'), 'email' => sfy_param('email'),
            'category' => sfy_param('category'), 'subject' => sfy_param('subject'),
            'message' => sfy_param('message'),
        ]);
        if ($res['ok']) {
            sfy_redirect(sfy_url('support?code=' . rawurlencode((string)$res['code'])));
        }
        $error = (string)$res['error'];
    } elseif ((string)sfy_param('action') === 'support_reply') {
        $code  = strtoupper(trim((string)sfy_param('code')));
        $req   = sfy_support_find_code($code);
        if (!$req) {
            $error = 'That request code was not found.';
        } else {
            $res = sfy_support_reply((int)$req['id'], 'user', (string)sfy_param('message'), sfy_client_ip());
            if ($res['ok']) {
                sfy_redirect(sfy_url('support?code=' . rawurlencode($code) . '&sent=1'));
            }
            $error = (string)$res['error'];
            $msgs  = sfy_support_messages((int)$req['id']);
        }
    }
}

$cats = sfy_support_categories();
sfy_head(['title' => 'Support & requests', 'page' => $page]);
?>
<div class="shell support-shell">
  <section class="support-hero">
    <span class="badge y">SUPPORT</span>
    <h1>Requests & community</h1>
    <p>Suggest a game, report a problem, or ask about a payment. Every request gets a private code and a chat thread.</p>
  </section>

  <?php if ($error !== ''): ?><div class="msg err">◆ <?= sfy_esc($error) ?></div><?php endif; ?>
  <?php if ($sent): ?><div class="msg ok">✔ Message sent. We will reply in this thread.</div><?php endif; ?>

  <?php if ($req): ?>
    <div class="card support-thread">
      <div class="card-head">
        <h2>&gt; <?= sfy_esc((string)$req['code']) ?> <button class="btn btn-sm btn-ghost" type="button" onclick="navigator.clipboard && navigator.clipboard.writeText('<?= sfy_esc((string)$req['code']) ?>');this.textContent='COPIED'">COPY CODE</button></h2>
        <span class="spacer"></span>
        <?= sfy_badge(sfy_support_status_label((string)$req['status']), (string)$req['status'] === 'resolved' ? 'g' : ((string)$req['status'] === 'closed' ? 'gr' : 'y')) ?>
        <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_url('support')) ?>">NEW REQUEST</a>
      </div>
      <div class="support-meta">
        <span><?= sfy_esc((string)($cats[(string)$req['category']] ?? 'Request')) ?></span>
        <span>·</span><span><?= sfy_esc((string)($req['subject'] ?: 'No subject')) ?></span>
        <span>·</span><span><?= sfy_esc(sfy_ago((string)$req['created_at'])) ?></span>
      </div>
      <div class="support-messages">
        <?php foreach ($msgs as $m): $admin = (string)$m['sender'] === 'admin'; ?>
          <div class="support-msg<?= $admin ? ' admin' : '' ?>">
            <div class="support-msg-head"><?= $admin ? 'SFY_Devs Team' : 'You' ?> <span><?= sfy_esc(sfy_ago((string)$m['created_at'])) ?></span></div>
            <div class="support-msg-body"><?= nl2br(sfy_esc((string)$m['body'])) ?></div>
          </div>
        <?php endforeach; ?>
      </div>
      <form method="POST" class="support-reply" autocomplete="off">
        <?= sfy_csrf_field() ?>
        <input type="hidden" name="action" value="support_reply">
        <input type="hidden" name="code" value="<?= sfy_esc((string)$req['code']) ?>">
        <div class="field"><label class="label">Your reply</label>
          <textarea name="message" rows="4" maxlength="3000" required placeholder="Write a message..."></textarea>
          <div class="hint">5-second cooldown between messages. Keep the same code to return to this thread.</div></div>
        <button class="btn btn-primary">SEND MESSAGE</button>
      </form>
    </div>
  <?php else: ?>
    <div class="support-grid">
      <div class="card">
        <div class="card-head"><h2>&gt; NEW_REQUEST</h2></div>
        <form method="POST" autocomplete="off">
          <?= sfy_csrf_field() ?>
          <input type="hidden" name="action" value="support_new">
          <input type="text" name="website" value="" tabindex="-1" autocomplete="off" style="position:absolute;left:-9999px" aria-hidden="true">
          <div class="grid grid-2">
            <div class="field"><label class="label">Your name</label><input type="text" name="name" maxlength="96" autocomplete="off" required></div>
            <div class="field"><label class="label">Email</label><input type="email" name="email" maxlength="191" autocomplete="off" required placeholder="you@example.com"></div>
            <div class="field"><label class="label">Category</label>
              <select name="category"><?php foreach ($cats as $k => $lbl): ?><option value="<?= sfy_esc($k) ?>"><?= sfy_esc($lbl) ?></option><?php endforeach; ?></select></div>
            <div class="field"><label class="label">Subject</label><input type="text" name="subject" maxlength="191" placeholder="Short summary"></div>
          </div>
          <div class="field"><label class="label">Message</label>
            <textarea name="message" rows="6" maxlength="3000" required placeholder="What game should we add, or what do you need help with?"></textarea>
            <div class="hint">You will get a private request code. Save the code to check the status and chat with us.</div></div>
          <button class="btn btn-primary btn-block">SEND REQUEST</button>
        </form>
      </div>

      <div class="card">
        <div class="card-head"><h2>&gt; CHECK_STATUS</h2></div>
        <form method="GET" autocomplete="off">
          <div class="field"><label class="label">Request code</label><input type="text" name="code" maxlength="32" autocomplete="off" placeholder="SFY-R-XXXXXX" required></div>
          <button class="btn btn-gold btn-block">OPEN MY REQUEST</button>
        </form>
        <div class="hint">Use the code from your request. The thread opens with that code.</div>
      </div>
    </div>
  <?php endif; ?>
</div>
<?php sfy_foot(['page' => $page]); ?>