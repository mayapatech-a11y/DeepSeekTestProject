<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY ULTIMATE — SECURITY
 *  Turnstile, rate limiting, staff accounts + roles, login lockout,
 *  hardened admin sessions and the audit trail. (admin-only hardening)
 * ═══════════════════════════════════════════════════════════════════════
 */

/*
 * ── Cloudflare Turnstile ────────────────────────────────────────────
 * The one-line `sfy_verify_turnstile` helper that used to live here is gone: it
 * read its key straight from config.php, answered a bare yes/no and could not
 * tell "the player failed" from "our secret is wrong". The human check now
 * lives in app/captcha.php as a module (configuration, verdicts, the fail
 * mode, the pass memory, the widget and the log), so there is exactly one
 * implementation of what a challenge means. Nothing else in this file changed.
 */

/* ── Rate limiting (per bucket + key) ──────────────────────────────── */
function sfy_rate_limit(string $bucket, int $max = 0, int $window = 0, string $key = ''): bool {
    $key    = $key !== '' ? $key : sfy_client_ip();
    $max    = $max    > 0 ? $max    : (int)sfy_cfg('security.rate_limit_max', 40);
    $window = $window > 0 ? $window : (int)sfy_cfg('security.rate_limit_window', 60);

    try {
        $db = sfy_db();
        $db->prepare("DELETE FROM sfy_rate_limits WHERE window_start < DATE_SUB(NOW(), INTERVAL 10 MINUTE)")->execute();
        /* The window is measured with a bound amount too — the negative form of
           it is the same "the window has run out" test the placeholder-free
           INTERVAL used to express (see sfy_sql_now_offset()). */
        $stale = sfy_sql_now_offset('SECOND');
        $db->prepare("INSERT INTO sfy_rate_limits (bucket, rl_key, window_start, hits)
                      VALUES (?,?,NOW(),1)
                      ON DUPLICATE KEY UPDATE hits = IF(window_start < $stale, 1, hits + 1),
                                              window_start = IF(window_start < $stale, NOW(), window_start)")
           ->execute([$bucket, $key, -$window, -$window]);
        $st = $db->prepare("SELECT hits FROM sfy_rate_limits WHERE bucket=? AND rl_key=?");
        $st->execute([$bucket, $key]);
        $hits = (int)($st->fetch()['hits'] ?? 0);
        return $hits <= $max;
    } catch (Throwable $e) {
        error_log('[SFY] rate limit: ' . $e->getMessage());
        return true;   // fail open — never lock the whole site out
    }
}

function sfy_rate_limit_hit(string $bucket, string $key = ''): void {
    if (!sfy_rate_limit($bucket, 0, 0, $key)) {
        if (sfy_wants_json()) sfy_json(['status' => 'error', 'reason' => 'rate_limited'], 429);
        sfy_fatal('Slow down', 'Too many requests from your connection. Wait a moment and retry.', 429);
    }
}

/* ── login attempt log + lockout ───────────────────────────────────── */
function sfy_login_log(string $username, bool $ok, string $reason = ''): void {
    try {
        sfy_db()->prepare("INSERT INTO sfy_login_attempts (username, ip, user_agent, success, reason)
                           VALUES (?,?,?,?,?)")
                 ->execute([substr($username, 0, 64), sfy_client_ip(), sfy_user_agent(), $ok ? 1 : 0, substr($reason, 0, 128)]);
    } catch (Throwable $e) { error_log('[SFY] login log: ' . $e->getMessage()); }
}

/** How many failures for this username (and this IP) inside the window. */
function sfy_login_failures(string $username, string $ip = ''): array {
    $ip     = $ip !== '' ? $ip : sfy_client_ip();
    $window = (int)sfy_cfg('security.login_window_minutes', 10);
    try {
        $st = sfy_db()->prepare("SELECT
              SUM(CASE WHEN username=? THEN 1 ELSE 0 END) AS by_user,
              SUM(CASE WHEN ip=? THEN 1 ELSE 0 END)       AS by_ip
            FROM sfy_login_attempts
            WHERE success=0 AND created_at > " . sfy_sql_now_offset('MINUTE'));
        $st->execute([$username, $ip, -$window]);
        $r = $st->fetch() ?: [];
        return ['user' => (int)($r['by_user'] ?? 0), 'ip' => (int)($r['by_ip'] ?? 0)];
    } catch (Throwable $e) { return ['user' => 0, 'ip' => 0]; }
}

/** Max failures observed since the last success — drives the "blocked" counter. */
function sfy_login_blocked_count(string $username): int {
    try {
        $st = sfy_db()->prepare("SELECT COUNT(*) AS n FROM sfy_login_attempts
                                 WHERE success=0 AND username=?
                                   AND created_at > COALESCE(
                                       (SELECT MAX(created_at) FROM sfy_login_attempts WHERE username=? AND success=1),
                                       '1970-01-01')");
        $st->execute([$username, $username]);
        return (int)($st->fetch()['n'] ?? 0);
    } catch (Throwable $e) { return 0; }
}

function sfy_login_locked_reason(string $username): ?string {
    $f = sfy_login_failures($username);
    if ($f['user'] >= (int)sfy_cfg('security.max_login_attempts', 5)) {
        return 'Account temporarily locked after ' . $f['user'] . ' failed attempts. Try again in '
             . (int)sfy_cfg('security.lockout_minutes', 15) . ' minutes.';
    }
    if ($f['ip'] >= (int)sfy_cfg('security.ip_login_attempts', 12)) {
        return 'Too many failed attempts from your network. Please wait a few minutes.';
    }
    return null;
}

/* ── staff accounts + roles ────────────────────────────────────────── */
function sfy_roles(): array {
    return [
        'owner'  => 4,
        'admin'  => 3,
        'staff'  => 2,
        'viewer' => 1,
    ];
}
function sfy_role_level(string $role): int { return sfy_roles()[$role] ?? 0; }

/** Capability matrix — first entry is the minimum role required. */
function sfy_caps(): array {
    return [
        'view'        => 'viewer',
        'tokens'      => 'staff',
        'games'       => 'staff',
        'accounts'    => 'staff',
        'sessions'    => 'staff',
        'devices'     => 'staff',
        'ads'         => 'staff',
        'appearance'  => 'admin',
        'homepage'    => 'admin',
        'stats'       => 'viewer',
        'import'      => 'admin',
        'updater'     => 'admin',
        'settings'    => 'admin',
        'security'    => 'admin',
        'staff'       => 'owner',
        'danger'      => 'admin',
    ];
}

function sfy_staff_all(): array {
    try { return sfy_db()->query("SELECT * FROM sfy_staff ORDER BY FIELD(role,'owner','admin','staff','viewer'), username")->fetchAll(); }
    catch (Throwable $e) { return []; }
}

function sfy_staff_find(string $username): ?array {
    $st = sfy_db()->prepare("SELECT * FROM sfy_staff WHERE username=? LIMIT 1");
    $st->execute([$username]);
    return $st->fetch() ?: null;
}

/**
 * Verify a staff login.
 * @return array{ok:bool,error?:string,staff?:array}
 */
function sfy_staff_login(string $username, string $password): array {
    $username = strtolower(trim($username));
    if ($username === '' || $password === '') return ['ok' => false, 'error' => 'Username and password are required.'];

    if ($reason = sfy_login_locked_reason($username)) {
        sfy_login_log($username, false, 'locked');
        return ['ok' => false, 'error' => $reason, 'locked' => true];
    }

    $staff = sfy_staff_find($username);

    // Legacy: first ever login accepts the old single admin password and
    // upgrades it into a full owner account.
    $legacyHash = (string)sfy_config_get('admin_password_hash', '');
    if (!$staff && $legacyHash !== '' && password_verify($password, $legacyHash) && $username === 'admin') {
        sfy_staff_create('admin', $password, 'owner', 'Administrator');
        $staff = sfy_staff_find('admin');
    }

    if (!$staff) {
        sfy_login_log($username, false, 'unknown_user');
        return ['ok' => false, 'error' => 'Invalid credentials.'];
    }
    if ((int)$staff['is_active'] !== 1) {
        sfy_login_log($username, false, 'inactive');
        return ['ok' => false, 'error' => 'This account has been disabled.'];
    }
    if (!password_verify($password, (string)$staff['password_hash'])) {
        $st = sfy_db()->prepare("UPDATE sfy_staff SET failed_attempts=failed_attempts+1, last_failed_at=NOW() WHERE id=?");
        $st->execute([(int)$staff['id']]);
        sfy_login_log($username, false, 'bad_password');
        $left = max(0, (int)sfy_cfg('security.max_login_attempts', 5) - sfy_login_failures($username)['user']);
        return ['ok' => false, 'error' => 'Invalid credentials.' . ($left > 0 ? " ($left attempt(s) left)" : '')];
    }

    $db = sfy_db();
    $db->prepare("UPDATE sfy_staff SET failed_attempts=0, last_login_at=NOW(), last_login_ip=? WHERE id=?")
       ->execute([sfy_client_ip(), (int)$staff['id']]);
    sfy_login_log($username, true, 'ok');

    return ['ok' => true, 'staff' => $staff];
}

function sfy_staff_create(string $username, string $password, string $role = 'staff', string $display = '', int $createdBy = 0): int {
    $st = sfy_db()->prepare("INSERT INTO sfy_staff (username, display_name, password_hash, role, is_active, created_by, created_at)
                             VALUES (?,?,?,?,1,?,NOW())");
    $st->execute([
        strtolower(substr(trim($username), 0, 64)),
        substr($display !== '' ? $display : ucfirst($username), 0, 96),
        password_hash($password, PASSWORD_BCRYPT),
        sfy_role_level($role) > 0 ? $role : 'staff',
        $createdBy,
    ]);
    return (int)sfy_db()->lastInsertId();
}

/* ── admin session ─────────────────────────────────────────────────── */
function sfy_admin_boot_session(array $staff): void {
    $_SESSION['sfy_admin']          = true;
    $_SESSION['sfy_admin_time']     = time();
    $_SESSION['sfy_staff_id']       = (int)$staff['id'];
    $_SESSION['sfy_staff_user']     = (string)$staff['username'];
    $_SESSION['sfy_staff_role']     = (string)$staff['role'];
    $_SESSION['sfy_staff_name']     = (string)$staff['display_name'];
    $_SESSION['sfy_admin_fp']       = hash('sha256', sfy_user_agent() . '|' . sfy_client_ip());
    sfy_audit('login', 'staff#' . $staff['id']);
}

function sfy_admin_logout(): void {
    sfy_audit('logout', 'staff#' . ($_SESSION['sfy_staff_id'] ?? 0));
    /* The sign-in pass dies with the sign-in: whoever comes next on this
       machine solves its own challenge. (No-op while the module is absent.) */
    if (function_exists('sfy_captcha_reset')) sfy_captcha_reset(null, 'admin');
    foreach (['sfy_admin','sfy_admin_time','sfy_staff_id','sfy_staff_user','sfy_staff_role','sfy_staff_name','sfy_admin_fp'] as $k) {
        unset($_SESSION[$k]);
    }
}

function sfy_admin_current(): ?array {
    if (empty($_SESSION['sfy_admin'])) return null;
    $ttl = (int)sfy_cfg('security.admin_ttl_minutes', 90) * 60;
    if (time() - (int)($_SESSION['sfy_admin_time'] ?? 0) > $ttl) { sfy_admin_logout(); return null; }

    if (sfy_cfg('security.bind_admin_to_browser', true)) {
        $fp = hash('sha256', sfy_user_agent() . '|' . sfy_client_ip());
        if (!empty($_SESSION['sfy_admin_fp']) && !hash_equals((string)$_SESSION['sfy_admin_fp'], $fp)) {
            sfy_audit('session_fingerprint_mismatch', 'staff#' . ($_SESSION['sfy_staff_id'] ?? 0));
            sfy_admin_logout();
            return null;
        }
    }

    $staff = null;
    try {
        $st = sfy_db()->prepare("SELECT * FROM sfy_staff WHERE id=? LIMIT 1");
        $st->execute([(int)($_SESSION['sfy_staff_id'] ?? 0)]);
        $staff = $st->fetch() ?: null;
    } catch (Throwable $e) { /* table missing → fall through to legacy mode */ }

    if ($staff) {
        if ((int)$staff['is_active'] !== 1) { sfy_admin_logout(); return null; }
        $_SESSION['sfy_staff_role'] = (string)$staff['role'];
        $_SESSION['sfy_admin_time'] = time();   // sliding expiry
        return $staff;
    }

    // Legacy single-password mode (no staff table yet): treat as owner.
    return ['id' => 0, 'username' => 'admin', 'display_name' => 'Administrator', 'role' => 'owner', 'is_active' => 1];
}

function sfy_admin_can(string $cap): bool {
    $me = sfy_admin_current();
    if (!$me) return false;
    $need = sfy_caps()[$cap] ?? 'owner';
    return sfy_role_level((string)$me['role']) >= sfy_role_level($need);
}

function sfy_admin_require(string $cap = 'view'): array {
    $me = sfy_admin_current();
    if (!$me) { header('Location: ' . sfy_url('admin/?need=login')); exit; }
    if (!sfy_admin_can($cap)) {
        if (sfy_wants_json()) sfy_json(['status' => 'error', 'reason' => 'forbidden', 'cap' => $cap], 403);
        sfy_fatal('Access denied', 'Your role (' . sfy_esc((string)$me['role']) . ') cannot open this section.', 403);
    }
    return $me;
}

/* ── audit trail ───────────────────────────────────────────────────── */
function sfy_audit(string $action, string $target = '', array $meta = []): void {
    try {
        sfy_db()->prepare("INSERT INTO sfy_audit_log (staff_id, username, action, target, meta, ip, created_at)
                           VALUES (?,?,?,?,?,?,NOW())")
                 ->execute([
                     (int)($_SESSION['sfy_staff_id'] ?? 0),
                     substr((string)($_SESSION['sfy_staff_user'] ?? 'system'), 0, 64),
                     substr($action, 0, 64),
                     substr($target, 0, 191),
                     $meta ? substr(json_encode($meta, JSON_UNESCAPED_SLASHES), 0, 2000) : null,
                     sfy_client_ip(),
                 ]);
    } catch (Throwable $e) { error_log('[SFY] audit: ' . $e->getMessage()); }
}

function sfy_audit_recent(int $limit = 100): array {
    try {
        $st = sfy_db()->prepare("SELECT * FROM sfy_audit_log ORDER BY id DESC LIMIT ?");
        $st->bindValue(1, $limit, PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll();
    } catch (Throwable $e) { return []; }
}

function sfy_login_attempts_recent(int $limit = 100): array {
    try {
        $st = sfy_db()->prepare("SELECT * FROM sfy_login_attempts ORDER BY id DESC LIMIT ?");
        $st->bindValue(1, $limit, PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll();
    } catch (Throwable $e) { return []; }
}
