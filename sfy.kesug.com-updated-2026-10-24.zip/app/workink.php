<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY ULTIMATE — WORK.INK
 *
 *  Work.ink is the second kind of task provider (after LootLabs) and it is
 *  set up completely differently, so it gets its own module — exactly like
 *  LootLabs has one for the Redirect API.
 *
 *  What is different about it:
 *
 *    • the task itself is a plain Work.ink link. This install sends the
 *      player there with its step parameters appended (`unique_id`,
 *      `sub_id`, `acct`, `sig`) and the *return* is what confirms a step:
 *      the player lands back on /done and the provider-landing gate
 *      accepts it because `work.ink` / `workink.com` are in the provider's
 *      accepted return hosts;
 *    • nothing is minted with a key, so there is no anti-bypass handoff to
 *      build. The key below is the **Key System** key from the Work.ink
 *      creator panel, and it is *checked* rather than used per handoff.
 *
 *  ── the key check ─────────────────────────────────────────────────────
 *
 *  `GET https://work.ink/_api/v2/token/verify/{TOKEN}` with the header
 *  `X-Api-Key: <key>` answers about a *specific* token the player earned.
 *  Asking about a token this install invented therefore reports on the key:
 *
 *    401  the key is wrong (or revoked)                  → bad key
 *    403  the key is fine, that token belongs to another link → key works
 *    200  the key is fine, that token is unknown/expired  → key works
 *
 *  That is the whole test: HTTP 401 is the only answer that means "fix the
 *  key". No key is ever sent anywhere except work.ink, and the result is
 *  stored per provider so the panel can show it without testing again on
 *  every page load.
 * ═══════════════════════════════════════════════════════════════════════
 */

/** The Key System endpoint used for the check (and by the provider's own docs). */
function sfy_workink_verify_url(string $token): string {
    return 'https://work.ink/_api/v2/token/verify/' . rawurlencode($token);
}

/**
 * GET a Work.ink endpoint with the Key System key.
 *
 * @return array{ok:bool,http:int,body:string,error:string,ms:int}
 *   `ok` is about the *transport* (we heard something back), not about the
 *   key — the verdict is sfy_workink_key_check()'s job.
 *
 * `$GLOBALS['SFY_WORKINK_HTTP']` may be a callable returning
 * ['http' => int, 'body' => string]; the test suite uses it so the verdict
 * logic is exercised without a network. Like the captcha hook it is not a
 * configuration surface — nothing in the panel or the request can set it.
 */
function sfy_workink_http(string $url, string $key): array {
    $override = $GLOBALS['SFY_WORKINK_HTTP'] ?? null;
    if (is_callable($override)) {
        $r    = (array)$override($url, $key);
        $body = (string)($r['body'] ?? '');
        if ($body === '') return ['ok' => false, 'http' => 0, 'body' => '', 'error' => 'no answer', 'ms' => 0];
        return ['ok' => true, 'http' => (int)($r['http'] ?? 0), 'body' => substr($body, 0, 4000), 'error' => '', 'ms' => 0];
    }

    $t0     = (int)round(microtime(true) * 1000);
    $header = 'X-Api-Key: ' . $key . "\r\n"
            . 'Accept: application/json' . "\r\n"
            . 'User-Agent: SFY-Ultimate/' . (defined('SFY_VERSION') ? SFY_VERSION : '0') . "\r\n";

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => ['X-Api-Key: ' . $key, 'Accept: application/json'],
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_CONNECTTIMEOUT => 6,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_USERAGENT      => 'SFY-Ultimate/' . (defined('SFY_VERSION') ? SFY_VERSION : '0'),
        ]);
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $err  = (string)curl_error($ch);
        curl_close($ch);
        $ms = (int)round(microtime(true) * 1000) - $t0;
        if (!is_string($body) || ($code === 0 && $err !== '')) {
            error_log('[SFY] work.ink transport: ' . ($err !== '' ? $err : 'empty response'));
            return ['ok' => false, 'http' => $code, 'body' => '', 'error' => $err !== '' ? $err : 'no answer', 'ms' => $ms];
        }
        return ['ok' => true, 'http' => $code, 'body' => substr($body, 0, 4000), 'error' => '', 'ms' => $ms];
    }

    if (!sfy_captcha_on(ini_get('allow_url_fopen'))) {
        return ['ok' => false, 'http' => 0, 'body' => '', 'error' => 'this host cannot make outbound HTTPS requests', 'ms' => 0];
    }

    $ctx  = stream_context_create(['http' => [
        'method'        => 'GET',
        'header'        => $header,
        'timeout'       => 10,
        'ignore_errors' => true,          // a 401/403 body and status still arrive
    ]]);
    $body = @file_get_contents($url, false, $ctx);
    $ms   = (int)round(microtime(true) * 1000) - $t0;
    $code = 0;
    foreach (($http_response_header ?? []) as $h) {
        if (preg_match('#^HTTP/\S+\s+(\d{3})#', (string)$h, $m)) $code = (int)$m[1];
    }
    if (!is_string($body) || $body === '') {
        return ['ok' => false, 'http' => $code, 'body' => '', 'error' => 'no answer', 'ms' => $ms];
    }
    return ['ok' => true, 'http' => $code, 'body' => substr($body, 0, 4000), 'error' => '', 'ms' => $ms];
}

/**
 * What does Work.ink think of this key?
 *
 * @return array{ok:bool,status:string,http:int,ms:int,error:string,detail:string,checked_at:string}
 *   status: no_key | ok | bad_key | unreachable | unexpected
 *   Only `bad_key` and `unexpected` need the owner to do something.
 */
function sfy_workink_key_check(string $key, string $probe = ''): array {
    $out = ['ok' => false, 'status' => 'no_key', 'http' => 0, 'ms' => 0, 'error' => '', 'detail' => '',
            'checked_at' => date('c')];

    $key = trim($key);
    if ($key === '') {
        $out['error'] = 'no API key on this provider';
        return $out;
    }
    /* A token this install invents: it can never be valid, so whatever comes
       back is an answer about the *key*. */
    if ($probe === '') $probe = bin2hex(random_bytes(12));

    $r = sfy_workink_http(sfy_workink_verify_url($probe), $key);
    $out['http'] = (int)$r['http'];
    $out['ms']   = (int)$r['ms'];
    $out['detail'] = substr(trim((string)$r['body']), 0, 180);

    if (empty($r['ok'])) {
        $out['status'] = 'unreachable';
        $out['error']  = (string)$r['error'];
        return $out;
    }

    switch ((int)$r['http']) {
        case 200:
            /* Either {"valid":false,…} for an unknown token (the expected
               answer for a probe) or — impossible here — a valid one. Both
               mean the key was accepted. */
            $out['ok']     = true;
            $out['status'] = 'ok';
            return $out;
        case 403:
            /* Documented as "this token is not from your link", which is an
               answer only a *working* key can get. */
            $out['ok']     = true;
            $out['status'] = 'ok';
            $out['error']  = 'the key works — that probe token simply belongs to another link';
            return $out;
        case 401:
            $out['status'] = 'bad_key';
            $out['error']  = 'Work.ink refused the key (HTTP 401) — paste the Key System key from the creator panel';
            return $out;
        case 0:
            $out['status'] = 'unreachable';
            $out['error']  = 'no HTTP status came back';
            return $out;
    }

    $out['status'] = 'unexpected';
    $out['error']  = 'Work.ink answered HTTP ' . (int)$r['http'];
    return $out;
}

/* ── the stored result ─────────────────────────────────────────────── */

/** Last key check for one provider (empty when it was never tested). */
function sfy_workink_last_test(array $p): array {
    $id = (int)($p['id'] ?? 0);
    if ($id <= 0) return [];
    $j = json_decode((string)sfy_config_get('set_workink_test_' . $id, ''), true);
    if (!is_array($j) || trim((string)($j['status'] ?? '')) === '') return [];
    return [
        'status'     => (string)$j['status'],
        'http'       => (int)($j['http'] ?? 0),
        'ms'         => (int)($j['ms'] ?? 0),
        'error'      => (string)($j['error'] ?? ''),
        'detail'     => (string)($j['detail'] ?? ''),
        'checked_at' => (string)($j['checked_at'] ?? ''),
    ];
}

function sfy_workink_record_test(int $providerId, array $r): void {
    if ($providerId <= 0) return;
    sfy_try(function () use ($providerId, $r) {
        sfy_config_set('set_workink_test_' . $providerId, json_encode($r, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
        return true;
    }, false);
}

/**
 * How the panel should describe this provider's Work.ink key.
 *
 * Same shape as sfy_redirect_api_status_label() so the two panels read the
 * same way: [label, badge tone, one-line hint].
 *
 * @return array{0:string,1:string,2:string}
 */
function sfy_workink_status_label(array $p): array {
    $p = sfy_provider_normalize($p);
    if (trim((string)$p['api_key']) === '') {
        return ['NO KEY', 'r', 'no Key System key on this provider or its accounts — add one to check it'];
    }
    if ((int)$p['id'] <= 0) {
        return ['UNSAVED', 'gr', 'save the provider first, then its key can be checked'];
    }
    $last = sfy_workink_last_test($p);
    if (!$last) {
        return ['NOT TESTED', 'gr', 'the key has never been checked — press TEST KEY below'];
    }
    switch ($last['status']) {
        case 'ok':
            return ['KEY OK', 'g', 'Work.ink accepted the key (HTTP ' . (int)$last['http'] . ')'];
        case 'bad_key':
            return ['KEY REFUSED', 'r', (string)$last['error']];
        case 'unreachable':
            return ['NO ANSWER', 'y', 'Work.ink could not be reached: ' . (string)$last['error']];
    }
    return [strtoupper((string)$last['status']), 'y', (string)$last['error']];
}
