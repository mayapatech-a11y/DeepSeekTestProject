<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY ULTIMATE — HOMEPAGE LAYOUT BUILDER
 *  The landing page is not hard-coded: it is an ordered list of sections
 *  stored as JSON in sfy_config. The admin can add, remove, reorder,
 *  resize, retitle or disable any block, and nothing here ever touches the
 *  verification logic itself.
 * ═══════════════════════════════════════════════════════════════════════
 */

/** Section kinds the builder understands. */
function sfy_layout_types(): array {
    return [
        'hero'    => ['label' => 'Token claim box',   'hint' => 'Headline, sub-text and the token input. Keep one.',        'boxed' => true],
        'stats'   => ['label' => 'Live counters',     'hint' => 'Codes unlocked, devices seen, unlocks today.',             'boxed' => true],
        'howto'   => ['label' => 'How it works',      'hint' => 'Numbered steps. One step per line in the text box.',       'boxed' => true],
        'premium' => ['label' => 'Premium offer',     'hint' => 'Uses the premium copy from Settings.',                     'boxed' => true],
        'tutorial'=> ['label' => 'Tutorial button',   'hint' => 'A card that links to the step-by-step guide page.',        'boxed' => true],
        'status'  => ['label' => 'Security status',   'hint' => 'Live anti-bypass / device-lock state.',                    'boxed' => true],
        'features'=> ['label' => 'Feature list',      'hint' => 'One feature per line, format: Title :: description.',      'boxed' => false],
        'faq'     => ['label' => 'FAQ',               'hint' => 'One entry per line, format: Question :: answer.',          'boxed' => true],
        'cta'     => ['label' => 'Call to action',    'hint' => 'A line of text plus one button.',                          'boxed' => true],
        'heading' => ['label' => 'Section heading',   'hint' => 'A title, optional sub-text, no card.',                     'boxed' => false],
        'custom'  => ['label' => 'Custom HTML',       'hint' => 'Anything you paste is rendered as-is. Admin only.',        'boxed' => false],
        'ad'      => ['label' => 'Ad slot',           'hint' => 'An ad placement managed in the Ads tab.',                  'boxed' => false],
        'divider' => ['label' => 'Divider',           'hint' => 'A thin rule with optional label.',                         'boxed' => false],
    ];
}

/** Width presets → 12-column grid spans. */
function sfy_layout_widths(): array {
    return [
        'full'       => ['label' => 'Full width',   'span' => 12],
        'two-thirds' => ['label' => 'Two thirds',   'span' => 8],
        'half'       => ['label' => 'Half',         'span' => 6],
        'third'      => ['label' => 'One third',    'span' => 4],
        'quarter'    => ['label' => 'One quarter',  'span' => 3],
    ];
}

function sfy_layout_span(string $width): int {
    return sfy_layout_widths()[$width]['span'] ?? 12;
}

function sfy_layout_new_id(): string { return 's_' . bin2hex(random_bytes(3)); }

/**
 * Read a text setting, treating a blank value as "not set".
 *
 * Saving Settings with an empty field stores an empty string, and
 * `sfy_config_get($key, $default)` then returns '' instead of the default —
 * which is why the premium card used to render with no offer text at all.
 */
function sfy_setting_text(string $key, string $default = ''): string {
    foreach (['set_' . $key, $key] as $k) {
        $v = trim((string)sfy_config_get($k, ''));
        if ($v !== '') return $v;
    }
    return $default;
}

/** Premium copy, with the shipped marketing defaults. */
function sfy_premium_copy(): array {
    return [
        'title'  => sfy_setting_text('premium_offer_title', 'Skip every task — plans from $2'),
        'text'   => sfy_setting_text('premium_offer_text', 'No tasks. Instant access. Choose 2, 7, 15 or 30 days.'),
        'button' => sfy_setting_text('premium_button_label', 'SEE PLANS'),
        'note'   => sfy_setting_text('premium_note', 'Instant activation · limited time offer'),
        'bullets'=> array_values(array_filter(array_map('trim', preg_split('/\r?\n/',
                        sfy_setting_text('premium_bullets',
                            "Skip every numbered task\nGet your code immediately\nPriority support\nWorks on any device"))))),
    ];
}

/** Pricing page defaults and stored configuration. */
function sfy_pricing_periods(): array {
    return ['instant' => 'Instant', 'weekly' => 'Weekly', 'monthly' => 'Monthly'];
}

function sfy_pricing_defaults(): array {
    return [
        'title' => 'Choose your access',
        'intro' => 'Skip the task steps and unlock your code instantly. Pick the plan that fits how long you need.',
        'plans' => [
            ['id' => '2d',   'period' => 'instant', 'name' => '2 Days',   'days' => 2,   'price' => '2',  'savings' => '',  'note' => 'A quick unlock for one code.', 'featured' => 0, 'enabled' => 1],
            ['id' => '7d',   'period' => 'instant', 'name' => '7 Days',   'days' => 7,   'price' => '4',  'savings' => '',  'note' => 'A full week of instant access.', 'featured' => 1, 'enabled' => 1],
            ['id' => '15d',  'period' => 'instant', 'name' => '15 Days',  'days' => 15,  'price' => '7',  'savings' => '',  'note' => 'Two weeks without tasks.', 'featured' => 0, 'enabled' => 1],
            ['id' => '30d',  'period' => 'instant', 'name' => '30 Days',  'days' => 30,  'price' => '19', 'savings' => '',  'note' => 'The best value for regular use.', 'featured' => 0, 'enabled' => 1],
            ['id' => '1w',   'period' => 'weekly',  'name' => '1 Week',   'days' => 7,   'price' => '7',  'savings' => '',  'note' => '$7 per week.', 'featured' => 0, 'enabled' => 1],
            ['id' => '2w',   'period' => 'weekly',  'name' => '2 Weeks',  'days' => 14,  'price' => '13', 'savings' => '1', 'note' => 'Two weeks of access.', 'featured' => 0, 'enabled' => 1],
            ['id' => '4w',   'period' => 'weekly',  'name' => '4 Weeks',  'days' => 28,  'price' => '24', 'savings' => '4', 'note' => 'Four weeks of access.', 'featured' => 1, 'enabled' => 1],
            ['id' => '1m',   'period' => 'monthly', 'name' => '1 Month',  'days' => 30,  'price' => '13', 'savings' => '20', 'note' => 'One month — save $20.', 'featured' => 1, 'enabled' => 1],
            ['id' => '3m',   'period' => 'monthly', 'name' => '3 Months', 'days' => 90,  'price' => '35', 'savings' => '25', 'note' => 'Three months of access.', 'featured' => 0, 'enabled' => 1],
            ['id' => '6m',   'period' => 'monthly', 'name' => '6 Months', 'days' => 180, 'price' => '65', 'savings' => '25', 'note' => 'Six months of access.', 'featured' => 0, 'enabled' => 1],
        ],
        'payments' => [
            ['id' => 'paypal',  'label' => 'PayPal',       'url' => '', 'note' => 'Card or PayPal balance.'],
            ['id' => 'crypto',  'label' => 'Crypto wallet', 'url' => '', 'note' => 'USDT, BTC or ETH.'],
            ['id' => 'binance', 'label' => 'Binance',      'url' => '', 'note' => 'Binance Pay / transfer.'],
            ['id' => 'other',   'label' => 'Other',        'url' => '', 'note' => 'Contact support for another method.'],
        ],
    ];
}

/**
 * Read the saved plan rows from the dedicated table.
 * Falls back to the JSON copy only to migrate an older install once.
 */
function sfy_pricing_plans_table(): array {
    if (!function_exists('sfy_table_exists') || !function_exists('sfy_db')) return [];
    return sfy_try(function (): array {
        if (!sfy_table_exists('sfy_pricing_plans')) {
            /* Create it here so an existing install gets the table without
               running the Updater first. */
            sfy_db()->exec("CREATE TABLE IF NOT EXISTS `sfy_pricing_plans` (
              `id` VARCHAR(48) NOT NULL,
              `period` VARCHAR(20) NOT NULL DEFAULT 'instant',
              `name` VARCHAR(60) NOT NULL,
              `days` INT NOT NULL DEFAULT 0,
              `price` DECIMAL(10,2) NOT NULL DEFAULT 0,
              `savings` DECIMAL(10,2) NULL,
              `note` VARCHAR(180) NULL,
              `featured` TINYINT(1) NOT NULL DEFAULT 0,
              `enabled` TINYINT(1) NOT NULL DEFAULT 1,
              `sort_order` INT NOT NULL DEFAULT 0,
              `updated_at` DATETIME NULL,
              PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            sfy_schema_flush_cache();
        }
        $st = sfy_db()->query('SELECT * FROM sfy_pricing_plans ORDER BY sort_order ASC, price ASC');
        return $st->fetchAll() ?: [];
    }, []);
}

function sfy_pricing_config(): array {
    $def = sfy_pricing_defaults();
    $raw = (string)sfy_config_get('set_pricing_json', '');
    $got = $raw !== '' ? json_decode($raw, true) : null;
    if (!is_array($got)) $got = [];

    $cfg = [
        'title' => trim((string)($got['title'] ?? $def['title'])) ?: $def['title'],
        'intro' => trim((string)($got['intro'] ?? $def['intro'])) ?: $def['intro'],
        'plans' => [],
        'payments' => [],
    ];

    /* Plans live in their own table. If it is present but empty, migrate the
       legacy JSON plan list once; if there is no JSON either, seed defaults. */
    $rows = sfy_pricing_plans_table();
    if (!$rows) {
        $seed = [];
        $legacy = (array)($got['plans'] ?? []);
        if ($legacy) {
            foreach ($legacy as $p) {
                if (!is_array($p) || trim((string)($p['name'] ?? '')) === '') continue;
                $period = strtolower(trim((string)($p['period'] ?? 'instant')));
                if (!isset(sfy_pricing_periods()[$period])) $period = 'instant';
                $seed[] = [
                    'id' => preg_replace('/[^a-z0-9_-]/', '', strtolower((string)($p['id'] ?? ''))) ?: 'plan-' . count($seed),
                    'period' => $period,
                    'name' => substr(trim((string)$p['name']), 0, 60),
                    'days' => max(0, (int)($p['days'] ?? 0)),
                    'price' => is_numeric($p['price'] ?? '') ? (string)(float)$p['price'] : '0',
                    'savings' => is_numeric($p['savings'] ?? '') ? (string)(float)$p['savings'] : '',
                    'note' => substr(trim((string)($p['note'] ?? '')), 0, 180),
                    'featured' => !empty($p['featured']) ? 1 : 0,
                    'enabled' => empty($p['enabled']) ? 0 : 1,
                ];
            }
        }
        if (!$seed) $seed = $def['plans'];
        if (function_exists('sfy_table_exists') && sfy_table_exists('sfy_pricing_plans')) {
            $n = 0;
            foreach ($seed as $p) {
                sfy_try(function () use ($p, &$n): void {
                    sfy_db()->prepare('INSERT IGNORE INTO sfy_pricing_plans
                        (id,period,name,days,price,savings,note,featured,enabled,sort_order,updated_at)
                        VALUES (?,?,?,?,?,?,?,?,?,?,NOW())')
                       ->execute([
                           $p['id'], $p['period'], $p['name'], (int)$p['days'],
                           (float)$p['price'], ($p['savings'] === '' ? null : (float)$p['savings']),
                           $p['note'], (int)($p['featured'] ?? 0), (int)($p['enabled'] ?? 1), $n++,
                       ]);
                }, null);
            }
            $rows = sfy_pricing_plans_table();
        }
        if (!$rows) $cfg['plans'] = $seed;   // table unavailable: behave as before
    }
    foreach ($rows as $p) {
        $cfg['plans'][] = [
            'id' => (string)$p['id'],
            'period' => (string)$p['period'],
            'name' => (string)$p['name'],
            'days' => (int)$p['days'],
            'price' => (string)(float)$p['price'],
            'savings' => ($p['savings'] === null || $p['savings'] === '' ? '' : (string)(float)$p['savings']),
            'note' => (string)($p['note'] ?? ''),
            'featured' => (int)$p['featured'],
            'enabled' => (int)$p['enabled'],
        ];
    }
    if (!$cfg['plans']) $cfg['plans'] = $def['plans'];

    foreach ((array)($got['payments'] ?? $def['payments']) as $m) {
        if (!is_array($m) || trim((string)($m['label'] ?? '')) === '') continue;
        $cfg['payments'][] = [
            'id' => preg_replace('/[^a-z0-9_-]/', '', strtolower((string)($m['id'] ?? ''))) ?: 'pay-' . count($cfg['payments']),
            'label' => substr(trim((string)$m['label']), 0, 50),
            'url' => trim((string)($m['url'] ?? '')),
            'note' => substr(trim((string)($m['note'] ?? '')), 0, 140),
        ];
    }
    if (!$cfg['payments']) $cfg['payments'] = $def['payments'];
    return $cfg;
}

function sfy_pricing_enabled(): bool {
    $raw = strtolower(trim((string)sfy_config_get('set_pricing_enabled', '1')));
    return !in_array($raw, ['0', 'off', 'no', 'false'], true);
}

function sfy_pricing_url(): string {
    return sfy_pricing_enabled() ? sfy_url('pricing') : sfy_setting_text('support_discord');
}

/**
 * The premium offer card.
 *
 * Shared by the landing page, the task flow and the return page so the offer
 * — and the copy behind it — is identical everywhere the player looks. The
 * premium offer is the product's upsell; it must never render blank and must
 * never drift between pages.
 *
 * @param array{head?:string,text?:string,label?:string,compact?:bool} $opts
 */
function sfy_premium_block(array $opts = []): string {
    $p      = sfy_premium_copy();
    $link   = sfy_pricing_url();
    $accent = sfy_setting_text('premium_accent');
    $style  = preg_match('/^#[0-9a-fA-F]{6}$/', $accent)
        ? ' style="--gold:' . sfy_esc($accent) . ';--premium-accent:' . sfy_esc($accent) . '"' : '';
    $head    = trim((string)($opts['head'] ?? ''))  !== '' ? (string)$opts['head']  : 'Premium';
    $label   = trim((string)($opts['label'] ?? '')) !== '' ? (string)$opts['label'] : $p['button'];
    $sub     = trim((string)($opts['text'] ?? ''))  !== '' ? (string)$opts['text']  : $p['text'];
    $compact = !empty($opts['compact']);

    $perks = '';
    foreach ($p['bullets'] as $b) {
        $perks .= '<li><span class="tick">✓</span>' . sfy_esc($b) . '</li>';
    }

    return '<div class="card premium-card' . ($compact ? ' premium-compact' : '') . '"' . $style . ' data-premium>'
         . '<div class="card-head premium-head">'
         . '<h2>&gt; ' . sfy_esc(strtoupper($head)) . '</h2>'
         . '<span class="spacer"></span>'
         . '<span class="badge y premium-badge">⚡ FAST PASS</span></div>'
         . '<div class="premium-offer">'
         . '<div class="premium-title">' . sfy_esc($p['title']) . '</div>'
         . '<div class="premium-sub">' . sfy_esc($sub) . '</div>'
         . ($perks !== '' ? '<ul class="premium-perks">' . $perks . '</ul>' : '')
         . ($link !== ''
             ? '<a class="btn btn-gold btn-lg btn-block premium-cta" href="' . sfy_esc($link) . '" target="_blank" rel="noopener">'
               . sfy_esc($label) . '</a>'
               . ($p['note'] !== '' ? '<div class="premium-note">' . sfy_esc($p['note']) . '</div>' : '')
             : '<div class="premium-note warn-note">◆ Set your shop / support link in Admin → Settings → Site copy to switch this offer on.</div>')
         . '</div></div>';
}

/**
 * Home premium section — the actual plans, not a second marketing card.
 */
function sfy_home_plans_block(array $opts = []): string {
    $p      = sfy_premium_copy();
    $cfg    = sfy_pricing_config();
    $accent = sfy_setting_text('premium_accent');
    $style  = preg_match('/^#[0-9a-fA-F]{6}$/', $accent)
        ? ' style="--gold:' . sfy_esc($accent) . ';--premium-accent:' . sfy_esc($accent) . '"' : '';
    $head   = trim((string)($opts['head'] ?? '')) !== '' ? (string)$opts['head'] : 'Premium plans';
    $text   = trim((string)($opts['text'] ?? '')) !== '' ? (string)$opts['text'] : (string)$p['text'];
    $plans  = array_values(array_filter($cfg['plans'], fn($x) => !empty($x['enabled'])));
    usort($plans, function ($a, $b) {
        $fa = (int)!empty($a['featured']); $fb = (int)!empty($b['featured']);
        if ($fa !== $fb) return $fb <=> $fa;
        return (float)$a['price'] <=> (float)$b['price'];
    });
    $plans = array_slice($plans, 0, 4);
    $perks = '';
    foreach (array_slice($p['bullets'], 0, 4) as $b) $perks .= '<li><span class="tick">✓</span>' . sfy_esc($b) . '</li>';
    $cards = '';
    foreach ($plans as $plan) {
        $suffix = ($plan['period'] ?? 'instant') === 'weekly' ? '/ week' : (($plan['period'] ?? 'instant') === 'monthly' ? '/ month' : 'one-time');
        $cards .= '<a class="home-plan" href="' . sfy_esc(sfy_pricing_url()) . '">'
                . '<span class="home-plan-name">' . sfy_esc((string)$plan['name']) . '</span>'
                . '<span class="home-plan-price"><b>$</b>' . sfy_esc(rtrim(rtrim(number_format((float)$plan['price'], 2, '.', ''), '0'), '.')) . '</span>'
                . '<span class="home-plan-period">' . sfy_esc($suffix) . '</span>'
                . (!empty($plan['featured']) ? '<span class="home-plan-flag">POPULAR</span>' : '')
                . '</a>';
    }
    return '<div class="card premium-card home-plans"' . $style . ' data-premium>'
         . '<div class="card-head premium-head"><h2>&gt; ' . sfy_esc(strtoupper($head)) . '</h2><span class="spacer"></span>'
         . '<span class="badge y premium-badge">⚡ FAST PASS</span></div>'
         . '<div class="premium-title">' . sfy_esc((string)$p['title']) . '</div>'
         . '<div class="premium-sub">' . sfy_esc($text) . '</div>'
         . '<ul class="premium-perks">' . $perks . '</ul>'
         . '<div class="home-plan-grid">' . $cards . '</div>'
         . '<a class="btn btn-gold btn-lg btn-block premium-cta" href="' . sfy_esc(sfy_pricing_url()) . '">SEE ALL PLANS</a>'
         . '<div class="premium-note">' . sfy_esc((string)$p['note']) . '</div>'
         . '</div>';
}

/**
 * Player-facing task status panel.
 *
 * Deliberately free of session ids, nonces, account ids and database talk:
 * the player needs to know which step they are on, how long is left and what
 * is being waited for — nothing else. Shared by the task page and the return
 * page so the two can never disagree.
 *
 * @param array<int, array{0:string,1:string,2?:string,3?:string}> $rows [label, html, id, extra class]
 */
function sfy_task_status(array $rows): string {
    $out = '<div class="task-status">';
    foreach ($rows as $r) {
        $label = sfy_esc((string)($r[0] ?? ''));
        $html  = (string)($r[1] ?? '');
        $id    = trim((string)($r[2] ?? ''));
        $cls   = trim((string)($r[3] ?? ''));
        $out  .= '<div class="ts-row"><span class="ts-k">' . $label . '</span>'
               . '<span class="ts-v' . ($cls !== '' ? ' ' . sfy_esc($cls) : '') . '"'
               . ($id !== '' ? ' id="' . sfy_esc($id) . '"' : '') . '>' . $html . '</span></div>';
    }
    return $out . '</div>';
}

/**
 * The zero-tap hand-off card: "that task is done and counted — the next one
 * opens by itself".
 *
 * A confirmed step that forwards the player into the next task used to do it
 * silently, and that is indistinguishable from the previous task being retried:
 * the browser lands on a task page again with no word about what just happened.
 * So the hand-off gets a card of its own — what was completed, what is coming,
 * and a countdown — and only then does the browser move.
 *
 * The task URL is rendered as a normal link *and* used by the countdown, so a
 * blocked `<script>` (or a player who prefers to press) still gets through; a
 * `<noscript>` meta refresh covers the case where the countdown cannot run.
 *
 * `seconds` is the admin's `set_zerotap_handoff_seconds` (2–15s, shipped 5);
 * the clamp is repeated here because the value ends up inside the meta refresh
 * and the ticker. It is a delay on a handoff that already exists — never a
 * second path to the next task.
 *
 * Nothing here is numbered any more. The card used to announce "task 1 of 2 is
 * done, step 2 is opening" — that is the site telling a player in the middle of
 * a run how many tasks are left, which is exactly what makes people stop. The
 * numbers are still tracked (the session, the handoff, the log), the player just
 * never reads them.
 *
 * @param array{done?:int,next?:int,total?:int,url?:string,seconds?:int,provider?:string} $opts
 */
function sfy_task_handoff_card(array $opts = []): string {
    $next    = max(1, (int)($opts['next'] ?? 2));
    $total   = max(1, (int)($opts['total'] ?? $next));
    $url     = (string)($opts['url'] ?? '');
    $seconds = (int)($opts['seconds'] ?? (function_exists('sfy_zerotap_handoff_seconds') ? sfy_zerotap_handoff_seconds() : 5));
    $seconds = max(2, min(15, $seconds));
    $who     = trim((string)($opts['provider'] ?? ''));
    $last    = $next >= $total;
    /* The button's text comes from the caller, so the page and the bar pinned to
       the bottom of the screen can print the same string instead of two that
       drift apart. */
    $goLabel = trim((string)($opts['label'] ?? '')) !== '' ? (string)$opts['label'] : 'OPEN TASK NOW';

    $out  = '<div class="card brk" style="--accent:#3DDC97" data-handoff="1">'
          . '<div class="card-head"><h1>&gt; TASK COMPLETE</h1><span class="spacer"></span>'
          . '<span class="badge g">✓ CONFIRMED</span></div>'
          . '<div class="msg ok mt-2">◆ That task is finished and counted — '
          . 'there is nothing to redo. Your next task opens'
          . ' by itself in <b><span id="sfy-handoff-cd">' . $seconds . '</span>s</b>.'
          . ($last ? ' Your code comes right after it.' : '') . '</div>'
          . sfy_task_status([
                ['Completed', 'Confirmed on this device' . ($who !== '' ? ' · ' . sfy_esc($who) : '')],
                ['Next up', 'Opening automatically'],
                ['Status', '<span class="dot static"></span> Taking you to the next task…', 'sfy-live'],
            ]);

    if ($url !== '') {
        $out .= '<a class="btn btn-primary btn-lg mt-2" id="sfy-handoff-go" href="' . sfy_esc($url) . '">'
              . '▶ ' . sfy_esc($goLabel) . '</a>'
              . '<div class="hint">Keep this tab open — the next task opens on its own. If it does not load, '
              . 'press the button above.</div>'
              . '<noscript><meta http-equiv="refresh" content="' . $seconds . ';url=' . sfy_esc($url) . '"></noscript>'
              . '<script>(function(){'
              . 'var u=' . json_encode($url) . ',n=' . $seconds . ',el=document.getElementById("sfy-handoff-cd");'
              . 'function tick(){ if(el) el.textContent=String(n); }'
              . 'tick();'
              . 'var t=setInterval(function(){ n--; if(n<=0){ clearInterval(t); location.replace(u); return; } tick(); },1000);'
              . '})();</script>';
    } else {
        $out .= '<div class="hint">This step is confirmed. Reload this page to carry on.</div>';
    }

    return $out . '</div>';
}

/**
 * The page between two confirmed steps: "mission accomplished — claim your
 * reward".
 *
 * A step that opens on the back of a verified one is the only page in the flow
 * with something to say: the token really is verified, the run really did move
 * on, and one press opens the task that finishes it. So it says that — and it
 * says it in one card with one button.
 *
 * Two properties worth keeping:
 *
 *   • nothing is numbered. No count of tasks, no "step 2 of 3", no strip — a
 *     player who reads "2" starts doing arithmetic about how long this will
 *     take, which is the moment they leave;
 *   • it advertises no work of its own. The button carries the continuation the
 *     landing page used to send them to (`?zt=1`), so the hand-off, its single
 *     nonce, its log line and its click clock all still happen where they did:
 *     at the moment the player presses through to the task.
 *
 * `label` comes from the caller so the bottom-pinned bar can print the very
 * same string as the button instead of a second, different answer.
 *
 * @param array{token?:string,url?:string,label?:string,hint?:string} $opts
 */
function sfy_reward_ready_card(array $opts = []): string {
    $token = trim((string)($opts['token'] ?? ''));
    $url   = trim((string)($opts['url'] ?? ''));
    $label = trim((string)($opts['label'] ?? '')) !== '' ? (string)$opts['label'] : 'CLAIM YOUR REWARD';
    $hint  = trim((string)($opts['hint'] ?? '')) !== ''
           ? (string)$opts['hint']
           : 'Your next task opens the moment you press it. Keep this tab open — there is nothing to type in.';

    $out = '<div class="card brk" style="--accent:#3DDC97" data-step-ready="1">'
         . '<div class="card-head"><h1>&gt; MISSION_ACCOMPLISHED</h1><span class="spacer"></span>'
         . '<span class="badge g">✓ VERIFIED</span></div>'
         . '<div class="msg ok">◆ Mission accomplished! Your token is verified and ready for the reward.</div>';

    if ($token !== '') {
        $out .= '<div class="label">Your token</div>'
              . '<span class="token-pill">' . sfy_esc($token) . '</span>';
    }

    if ($url !== '') {
        $out .= '<a class="btn btn-primary btn-lg btn-block mt-2" id="sfy-claim-reward" href="' . sfy_esc($url) . '">'
              . '🏆 ' . sfy_esc($label) . '</a>'
              . '<div class="hint">' . sfy_esc($hint) . '</div>';
    } else {
        $out .= '<div class="hint">This step is confirmed. Reload this page to carry on.</div>';
    }

    return $out . '</div>';
}

/**
 * The checkpoint after the first task.
 *
 * Finishing the first task is the moment a player most wants to be told that
 * something happened: the provider's page is gone, the next task's page looks
 * exactly like the one before it, and with the pass-through hub on there is
 * usually nothing in between at all. So the first completed task gets a short
 * page of its own — one sentence, one button — before the browser moves on by
 * itself.
 *
 * It is deliberately *only* the first one (`pages/task.php` renders it for the
 * step right after step 1). Every later crossing is the ordinary flow, and a
 * page shown between all of them is a page players learn to click through
 * without reading.
 *
 * Two properties are inherited from the hand-off card it sits beside:
 *
 *   • nothing is numbered. It says the token is registered and a task is
 *     counted — never "task 1 of 2", which is the site telling a player mid-run
 *     how much is left and exactly what makes people leave;
 *   • the URL is a real link *and* the address the countdown follows, so a
 *     blocked `<script>` still gets through and a `<noscript>` meta refresh
 *     covers a browser that cannot run the ticker.
 *
 * The countdown is the admin's `Hand-off countdown` (2–15s, shipped 5) — one
 * number to change for both this page and the zero-tap hand-off.
 *
 * @param array{token?:string,url?:string,label?:string,hint?:string,seconds?:int} $opts
 */
function sfy_token_registered_card(array $opts = []): string {
    $token   = trim((string)($opts['token'] ?? ''));
    $url     = trim((string)($opts['url'] ?? ''));
    $seconds = (int)($opts['seconds'] ?? (function_exists('sfy_zerotap_handoff_seconds') ? sfy_zerotap_handoff_seconds() : 5));
    $seconds = max(2, min(15, $seconds));
    $label   = trim((string)($opts['label'] ?? '')) !== '' ? (string)$opts['label'] : 'CLAIM CODE NOW';
    $hint    = trim((string)($opts['hint'] ?? '')) !== ''
             ? (string)$opts['hint']
             : 'Keep this tab open — your next task opens on its own. If it does not load, press the button above.';

    $out = '<div class="card brk" style="--accent:#3DDC97" data-token-registered="1">'
         . '<div class="card-head"><h1>&gt; TOKEN_REGISTERED</h1><span class="spacer"></span>'
         . '<span class="badge g">✓ REGISTERED</span></div>'
         . '<div class="msg ok">◆ Your token is successfully registered — the task you just finished is '
         . 'done and counted. Your next task opens by itself in <b><span id="sfy-cp-cd">' . $seconds . '</span>s</b>.</div>';

    if ($token !== '') {
        $out .= '<div class="label">Your token</div>'
              . '<span class="token-pill">' . sfy_esc($token) . '</span>';
    }

    if ($url !== '') {
        $out .= '<a class="btn btn-primary btn-lg btn-block mt-2" id="sfy-cp-go" href="' . sfy_esc($url) . '">'
              . '🏆 ' . sfy_esc($label) . '</a>'
              . '<div class="hint">' . sfy_esc($hint) . '</div>'
              . '<noscript><meta http-equiv="refresh" content="' . $seconds . ';url=' . sfy_esc($url) . '"></noscript>'
              . '<script>(function(){'
              . 'var u=' . json_encode($url) . ',n=' . $seconds . ',el=document.getElementById("sfy-cp-cd");'
              . 'function tick(){ if(el) el.textContent=String(n); }'
              . 'tick();'
              . 'var t=setInterval(function(){ n--; if(n<=0){ clearInterval(t); location.replace(u); return; } tick(); },1000);'
              . '})();</script>';
    } else {
        $out .= '<div class="hint">This step is confirmed. Reload this page to carry on.</div>';
    }

    return $out . '</div>';
}

function sfy_layout_row_default(string $type, string $id = ''): array {
    return [
        'id' => $id !== '' ? $id : sfy_layout_new_id(), 'type' => $type, 'enabled' => 1, 'width' => 'full',
        'title' => '', 'text' => '', 'html' => '', 'button_label' => '', 'button_url' => '',
        'ad' => 'banner', 'align' => 'left', 'tone' => '',
    ];
}

/**
 * The shipped landing page.
 *
 * Order matters: the premium block sits immediately under the token box so
 * the offer (and any ad in that slot) is the first thing a visitor reads,
 * before the how-it-works cards and the security panel. The public counters
 * ship disabled — re-enable them in Admin → Homepage whenever you want them.
 */
function sfy_layout_default_home(): array {
    return [
        ['id' => 's_hero',     'type' => 'hero',     'enabled' => 1, 'width' => 'full',      'title' => '',
         'text' => '', 'html' => '', 'button_label' => '', 'button_url' => '', 'ad' => 'banner', 'align' => 'left', 'tone' => ''],
        ['id' => 's_premium',  'type' => 'premium',  'enabled' => 1, 'width' => 'full',      'title' => 'Premium',
         'text' => '', 'html' => '', 'button_label' => '', 'button_url' => '', 'ad' => '', 'align' => 'left', 'tone' => 'gold'],
        ['id' => 's_banner',   'type' => 'ad',       'enabled' => 1, 'width' => 'full',      'title' => '',
         'text' => '', 'html' => '', 'button_label' => '', 'button_url' => '', 'ad' => 'banner', 'align' => 'left', 'tone' => ''],
        // The step-by-step explanation lives on /tutorial, and the anti-bypass
        // internals are nobody's business at the top of a landing page. Both
        // rows ship present-but-hidden so they can be switched back on in
        // Admin → Homepage at any time.
        ['id' => 's_tut',      'type' => 'tutorial', 'enabled' => 1, 'width' => 'full',      'title' => 'New here?',
         'text' => 'A step-by-step walkthrough of both routes: the script link and the token code.',
         'html' => '', 'button_label' => 'OPEN THE GUIDE', 'button_url' => '', 'ad' => '', 'align' => 'left', 'tone' => ''],
        ['id' => 's_howto',    'type' => 'howto',    'enabled' => 0, 'width' => 'full',      'title' => 'How it works',
         'text' => "Open your token link\nFinish every numbered task\nEach step needs a verified postback\nYour code appears instantly",
         'html' => '', 'button_label' => '', 'button_url' => '', 'ad' => '', 'align' => 'left', 'tone' => ''],
        ['id' => 's_status',   'type' => 'status',   'enabled' => 0, 'width' => 'half',      'title' => 'Security status',
         'text' => '', 'html' => '', 'button_label' => '', 'button_url' => '', 'ad' => '', 'align' => 'left', 'tone' => ''],
        ['id' => 's_stats',    'type' => 'stats',    'enabled' => 0, 'width' => 'full',      'title' => '',
         'text' => '', 'html' => '', 'button_label' => '', 'button_url' => '', 'ad' => '', 'align' => 'left', 'tone' => ''],
    ];
}

/**
 * One-time upgrade applied by migration 014 for installs that saved a layout
 * before the premium block moved to the top. Only ever moves the premium row
 * and switches the public counters off — every other customisation is kept.
 */
function sfy_layout_upgrade(array $rows): array {
    $heroIdx = null;
    $premIdx = null;
    foreach ($rows as $i => $r) {
        if (($r['type'] ?? '') === 'hero'   && $heroIdx === null) $heroIdx = $i;
        if (($r['type'] ?? '') === 'premium' && $premIdx === null) $premIdx = $i;
    }
    if ($heroIdx === null) return $rows;

    // Sections the landing page no longer leads with. They stay in the list so
    // the admin can switch them back on, but they do not render by default.
    foreach ($rows as $i => $r) {
        if (in_array($r['type'] ?? '', ['stats', 'howto', 'status'], true)) $rows[$i]['enabled'] = 0;
        if (($r['type'] ?? '') === 'tutorial' && ($r['width'] ?? '') !== 'full') $rows[$i]['width'] = 'full';
    }

    if ($premIdx === null) {
        $prem = sfy_layout_row_default('premium', 's_premium');
        $prem['width'] = 'full';
        $prem['tone']  = 'gold';
        array_splice($rows, $heroIdx + 1, 0, [$prem]);
        return $rows;
    }
    if ($premIdx === $heroIdx + 1) return $rows;

    $prem = $rows[$premIdx];
    $prem['width'] = 'full';
    array_splice($rows, $premIdx, 1);
    $heroIdx = null;
    foreach ($rows as $i => $r) if (($r['type'] ?? '') === 'hero') { $heroIdx = $i; break; }
    if ($heroIdx === null) return $rows;
    array_splice($rows, $heroIdx + 1, 0, [$prem]);
    return $rows;
}

/** The four ad slots the builder may reference. */
function sfy_layout_ad_slots(): array {
    return ['top' => 'Top bar', 'banner' => 'Banner', 'side' => 'Sidebar', 'bottom' => 'Bottom',
            'popup' => 'Popup', 'float' => 'Floating corner', 'sticky' => 'Sticky footer'];
}

function sfy_layout_normalize(array $rows): array {
    $types   = sfy_layout_types();
    $widths  = sfy_layout_widths();
    $slots   = sfy_layout_ad_slots();
    $seen    = [];
    $out     = [];

    foreach ($rows as $r) {
        if (!is_array($r)) continue;
        $type = (string)($r['type'] ?? '');
        if (!isset($types[$type])) continue;

        $id = (string)($r['id'] ?? '');
        if ($id === '' || !preg_match('/^[a-z0-9_]{2,32}$/i', $id) || isset($seen[$id])) $id = sfy_layout_new_id();
        $seen[$id] = true;

        $width = (string)($r['width'] ?? 'full');
        $ad    = (string)($r['ad'] ?? 'banner');
        $tone  = (string)($r['tone'] ?? '');
        if (!in_array($tone, ['', 'neon', 'gold', 'blue', 'violet', 'red'], true)) $tone = '';

        $out[] = [
            'id'           => $id,
            'type'         => $type,
            'enabled'      => !empty($r['enabled']) ? 1 : 0,
            'width'        => isset($widths[$width]) ? $width : 'full',
            'title'        => substr((string)($r['title'] ?? ''), 0, 120),
            'text'         => substr((string)($r['text'] ?? ''), 0, 2000),
            'html'         => substr((string)($r['html'] ?? ''), 0, 6000),
            'button_label' => substr((string)($r['button_label'] ?? ''), 0, 40),
            'button_url'   => substr((string)($r['button_url'] ?? ''), 0, 300),
            'ad'           => isset($slots[$ad]) ? $ad : 'banner',
            'align'        => ((string)($r['align'] ?? 'left')) === 'center' ? 'center' : 'left',
            'tone'         => $tone,
        ];
    }

    return $out;
}

/**
 * Live layout (draft-aware so the admin preview can show unsaved edits).
 * $refresh forces a re-read after a save in the same request.
 */
function sfy_layout(bool $draft = false, bool $refresh = false): array {
    static $cache = null;
    if ($cache !== null && !$draft && !$refresh) return $cache;

    $raw = (string)sfy_config_get('set_layout_home', '');
    $rows = [];
    if ($raw !== '') {
        $j = json_decode($raw, true);
        if (is_array($j)) $rows = isset($j['sections']) && is_array($j['sections']) ? $j['sections'] : $j;
    }
    if (!$rows) $rows = sfy_layout_default_home();

    $out = sfy_layout_normalize($rows);

    if ($draft && !empty($_SESSION['sfy_layout_draft']) && is_array($_SESSION['sfy_layout_draft'])) {
        $out = sfy_layout_normalize($_SESSION['sfy_layout_draft']);
    }

    if (!$draft) $cache = $out;
    return $out;
}

function sfy_layout_save(array $rows): array {
    $clean = sfy_layout_normalize($rows);
    sfy_config_set('set_layout_home', json_encode(['sections' => $clean], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    sfy_config_all(true);
    sfy_layout(false, true);
    return $clean;
}

/** Restore the shipped default layout. */
function sfy_layout_reset(): array {
    $rows = sfy_layout_default_home();
    sfy_config_set('set_layout_home', json_encode(['sections' => $rows], JSON_UNESCAPED_SLASHES));
    sfy_config_all(true);
    sfy_layout(false, true);
    return $rows;
}

/* ── rendering ─────────────────────────────────────────────────────── */
/**
 * Render the whole section stack.
 * @param array  $sections rows from sfy_layout()
 * @param string $page     page key for ad targeting
 */
function sfy_layout_render(array $sections, string $page = 'home'): string {
    $out  = '';
    $open = false;

    foreach ($sections as $s) {
        if (empty($s['enabled'])) continue;

        // Ad-at-page-edge sections sit outside the grid so their placement
        // keeps its edge meaning.
        if ($s['type'] === 'ad' && in_array($s['ad'], ['top', 'bottom', 'popup', 'float', 'sticky'], true)) {
            if ($open) { $out .= '</div>'; $open = false; }
            $out .= sfy_ad_slot($s['ad'], $page);
            continue;
        }

        if (!$open) { $out .= '<div class="sec-grid">'; $open = true; }

        $span = sfy_layout_span((string)$s['width']);
        $out .= '<section class="sec sec-' . sfy_esc((string)$s['type'])
              . ($s['align'] === 'center' ? ' sec-center' : '')
              . ($s['tone'] !== '' ? ' sec-tone-' . sfy_esc((string)$s['tone']) : '')
              . '" style="--span:' . $span . '" data-sec="' . sfy_esc((string)$s['id']) . '">'
              . sfy_layout_section_html($s, $page)
              . '</section>';
    }

    if ($open) $out .= '</div>';
    return $out;
}

/** One section's inner markup. Never throws: unknown types render nothing. */
function sfy_layout_section_html(array $s, string $page = 'home'): string {
    $type  = (string)$s['type'];
    $title = trim((string)$s['title']);
    $text  = trim((string)$s['text']);
    $html  = (string)$s['html'];
    $line  = static fn(string $t): string => $t;

    $head = static function (string $t, string $sub = '') use ($line): string {
        if ($t === '' && $sub === '') return '';
        return '<div class="card-head"><h2>&gt; ' . sfy_esc(strtoupper($t)) . '</h2></div>'
             . ($sub !== '' ? '<p class="dim small" style="margin:-4px 0 10px">' . sfy_esc($sub) . '</p>' : '');
    };

    $lines = static fn(string $t): array => array_values(array_filter(array_map('trim', preg_split('/\r?\n/', $t)), fn($l) => $l !== ''));

    switch ($type) {

        case 'hero': {
            $headline = $title !== '' ? $title : sfy_setting_text('site_headline', 'Complete the tasks, unlock the code.');
            $sub      = $text   !== '' ? $text   : sfy_setting_text('site_subtext', 'Two verified steps. No shortcuts, no bypassing.');
            $resume   = (string)($GLOBALS['SFY_RESUME_SESSION'] ?? '');
            $err      = (string)($GLOBALS['SFY_HOME_ERROR'] ?? '');
            /* The hero knows whether this visitor has a run in progress, so it
               registers that action for the pinned bar too: on a phone the bar
               then says exactly what the card's own button says. One label,
               one URL, rendered twice. */
            $resumeUrl   = $resume !== '' ? sfy_url('go/' . $resume) : '';
            $resumeLabel = 'RESUME MY TASK';
            if ($resumeUrl !== '') {
                sfy_pin_action(['url' => $resumeUrl, 'kind' => 'task', 'label' => $resumeLabel, 'icon' => '▶']);
            }
            return '<div class="card brk">'
                 . '<div class="card-head"><h1>&gt;' . sfy_esc(SFY_APP_NAME) . '</h1><span class="spacer"></span>'
                 . '<span class="badge g"><span class="dot static"></span> SYSTEM ONLINE</span></div>'
                 . '<p style="font-size:17px;color:var(--text);margin:2px 0 4px">' . sfy_esc($headline) . '</p>'
                 . '<p class="dim" style="margin:0 0 16px">' . sfy_esc($sub) . '</p>'
                 . ($err === 'expired' ? '<div class="msg warn">◆ Your previous session expired. Claim a new token below.</div>' : '')
                 . '<div class="label">Have a token? Paste it here</div>'
                 . '<div class="inline"><input class="grow mono" id="sfy-token-input" placeholder="--// paste your token //--"'
                 . ' autocomplete="off" spellcheck="false" inputmode="text">'
                 . '<button class="btn btn-primary" id="sfy-claim-btn">▶ CLAIM</button></div>'
                 . '<div class="hint">Paste the whole link too — the token is extracted automatically.</div>'
                 . ($resume !== ''
                     ? '<hr class="sep"><div class="msg info">◆ You have a verification session in progress on this device.</div>'
                       . '<a class="btn btn-gold btn-block" href="' . sfy_esc($resumeUrl) . '">'
                       . sfy_esc($resumeLabel) . '</a>'
                     : '')
                 . '</div>';
        }

        case 'stats': {
            $c = sfy_try(function (): array {
                $db = sfy_db();
                $out = [];

                /*
                 * "Codes unlocked" and "today" are token activity, so a token
                 * marked HIDDEN in Admin → Tokens is excluded from both. The
                 * join is only added when the column exists, so an install that
                 * has not run migration 022 still shows real numbers instead of
                 * zeroes.
                 */
                $hidden = sfy_column_exists('sfy_tokens', 'is_hidden');
                $join   = $hidden ? ' LEFT JOIN sfy_tokens t ON t.token = s.token ' : ' ';
                $hide   = $hidden ? ' AND COALESCE(t.is_hidden,0) = 0 ' : ' ';

                $sqls = [
                    'devices' => "SELECT COUNT(*) AS n FROM sfy_devices",
                    'success' => "SELECT COUNT(*) AS n FROM sfy_sessions s" . $join
                                 . "WHERE s.is_completed=1" . $hide,
                    'today'   => "SELECT COUNT(*) AS n FROM sfy_sessions s" . $join
                                 . "WHERE s.is_completed=1 AND s.completed_at >= CURDATE()" . $hide,
                ];
                foreach ($sqls as $k => $sql) {
                    $out[$k] = (int)($db->query($sql)->fetch()['n'] ?? 0);
                }
                return $out;
            }, ['devices' => 0, 'success' => 0, 'today' => 0]);
            $c = array_merge(['devices' => 0, 'success' => 0, 'today' => 0], is_array($c) ? $c : []);
            return '<div class="grid grid-3">'
                 . sfy_kpi('Codes unlocked', number_format($c['success']), '')
                 . sfy_kpi('Devices seen', number_format($c['devices']), 'blue')
                 . sfy_kpi('Unlocked today', number_format($c['today']), 'gold')
                 . '</div>';
        }

        case 'howto': {
            $items = $lines($text);
            if (!$items) $items = ['Open your token link', 'Complete every step', 'Copy your code'];
            $cells = '';
            foreach ($items as $i => $item) {
                $cells .= '<div class="card"><div class="card-head"><h2>&gt; ' . str_pad((string)($i + 1), 2, '0', STR_PAD_LEFT)
                        . ' ' . sfy_esc(strtoupper(sfy_short($item, 26))) . '</h2></div>'
                        . '<p class="small dim">' . sfy_esc($item) . '</p></div>';
            }
            return $head($title !== '' ? $title : 'How it works') . '<div class="grid auto">' . $cells . '</div>';
        }

        case 'features': {
            $rows = $lines($text);
            if (!$rows) return '';
            $cells = '';
            foreach ($rows as $r) {
                [$h, $b] = array_pad(explode('::', $r, 2), 2, '');
                $cells .= '<div class="card"><div class="card-head"><h2>&gt; ' . sfy_esc(strtoupper(trim($h))) . '</h2></div>'
                        . '<p class="small dim">' . sfy_esc(trim($b)) . '</p></div>';
            }
            return ($title !== '' ? '<div class="card-head" style="border:0;padding:0"><h2>&gt; ' . sfy_esc(strtoupper($title)) . '</h2></div>' : '')
                 . '<div class="grid auto">' . $cells . '</div>';
        }

        case 'faq': {
            $rows = $lines($text);
            if (!$rows) return '';
            $body = '';
            foreach ($rows as $r) {
                [$q, $ans] = array_pad(explode('::', $r, 2), 2, '');
                $body .= '<details class="faq"><summary>' . sfy_esc(trim($q)) . '</summary>'
                       . '<div class="small dim">' . sfy_esc(trim($ans)) . '</div></details>';
            }
            return '<div class="card">' . $head($title !== '' ? $title : 'FAQ') . $body . '</div>';
        }

        case 'premium':
            // The home section shows the real plan cards. The Settings copy is
            // still the headline/sub-line so a custom offer is never lost.
            return sfy_home_plans_block([
                'head' => $title,
                'text' => $text,
            ]);

        case 'tutorial': {
            $url   = trim((string)$s['button_url']);
            $label = trim((string)$s['button_label']) !== '' ? (string)$s['button_label'] : 'OPEN THE GUIDE';
            return '<div class="card">' . $head($title !== '' ? $title : 'New here?')
                 . ($text !== '' ? '<p class="dim" style="margin:0 0 12px">' . sfy_esc($text) . '</p>' : '')
                 . '<div class="tut-mini">'
                 . '<span class="n">01</span><span>Run the script, press <b>Copy link</b> or <b>Copy code</b></span>'
                 . '<span class="n">02</span><span>Open the link (or paste the code on the site)</span>'
                 . '<span class="n">03</span><span>Finish each task, then copy your unlock code</span>'
                 . '</div>'
                 . '<a class="btn btn-primary btn-block mt-2" href="' . sfy_esc($url !== '' ? sfy_footer_link_url($url) : sfy_url('tutorial')) . '">'
                 . '📖 ' . sfy_esc($label) . '</a></div>';
        }

        case 'status': {
            $need = function_exists('sfy_return_check_state')
                ? (bool)(sfy_return_check_state()['require_postback'] ?? true)
                : (bool)sfy_cfg('security.require_postback', true);
            $sig  = (bool)sfy_cfg('security.allow_unsigned_postback', false);
            $lock = (bool)sfy_cfg('security.enforce_fingerprint', true);
            return '<div class="card">' . $head($title !== '' ? $title : 'Security status')
                 . '<table class="tbl" style="min-width:0"><tbody>'
                 . '<tr><td class="dim small">Database</td><td>' . sfy_badge('ONLINE', 'g') . '</td></tr>'
                 . '<tr><td class="dim small">Anti-bypass</td><td>' . sfy_badge($need ? 'ENFORCED' : 'OFF', $need ? 'g' : 'y') . '</td></tr>'
                 . '<tr><td class="dim small">Signature</td><td>' . sfy_badge($sig ? 'OPTIONAL' : 'REQUIRED', $sig ? 'y' : 'g') . '</td></tr>'
                 . '<tr><td class="dim small">Device lock</td><td>' . sfy_badge($lock ? 'ON' : 'OFF', $lock ? 'g' : 'gr') . '</td></tr>'
                 . '</tbody></table>'
                 . ($text !== '' ? '<p class="small dim mt-2">' . sfy_esc($text) . '</p>' : '')
                 . '</div>';
        }

        case 'cta': {
            $label = trim((string)$s['button_label']) !== '' ? (string)$s['button_label'] : 'CONTINUE';
            $url   = trim((string)$s['button_url'])   !== '' ? sfy_footer_link_url((string)$s['button_url']) : sfy_url('');
            return '<div class="card">' . $head($title)
                 . ($text !== '' ? '<p class="dim" style="margin:0 0 12px">' . sfy_esc($text) . '</p>' : '')
                 . '<a class="btn btn-primary btn-lg" href="' . sfy_esc($url) . '">' . sfy_esc($label) . '</a></div>';
        }

        case 'heading':
            return ($title !== '' ? '<h2 class="sec-heading">&gt; ' . sfy_esc(strtoupper($title)) . '</h2>' : '')
                 . ($text !== '' ? '<p class="dim sec-sub">' . sfy_esc($text) . '</p>' : '');

        case 'custom':
            return $html !== '' ? $html : ($text !== '' ? $text : '');

        case 'divider':
            return '<hr class="sep sec-divider">' . ($title !== '' ? '<div class="hint center">' . sfy_esc($title) . '</div>' : '');

        case 'ad':
            return sfy_ad_slot((string)$s['ad'], $page);
    }

    return '';
}
