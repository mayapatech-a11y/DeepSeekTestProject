<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY ULTIMATE — DEVICE REGISTRY
 *  Every successful (and failed) attempt is attributed to a device:
 *  name, fingerprint, OS, browser, screen, timezone, language, IP, country
 *  plus running success / failure / bypass counters.
 * ═══════════════════════════════════════════════════════════════════════
 */

/** Stable device identity: browser fingerprint when available, else a hash. */
function sfy_device_key(string $fingerprint, string $ip = '', string $ua = ''): string {
    $fp = trim($fingerprint);
    if ($fp !== '' && preg_match('/^[a-zA-Z0-9_\-]{6,128}$/', $fp)) return substr($fp, 0, 128);
    return 'h_' . substr(hash_hmac('sha256', ($ip ?: sfy_client_ip()) . '|' . ($ua ?: sfy_user_agent()),
                                   (string)sfy_cfg('app.app_key')), 0, 40);
}

/**
 * Build a device profile from the current request (JSON body or form).
 * Client-supplied values are only ever *hints* — the server's UA/IP win
 * for the security-relevant fields.
 */
function sfy_device_profile(?array $client = null): array {
    $client = $client ?? $_POST;
    $ua     = sfy_user_agent();
    if (!empty($client['user_agent']) && is_string($client['user_agent'])) {
        $ua = substr(trim($client['user_agent']), 0, 512);
    }
    $parsed = sfy_parse_ua($ua);
    $ip     = sfy_client_ip();

    $fp = (string)($client['device_fingerprint'] ?? $client['fingerprint'] ?? '');
    if ($fp === '' && !empty($client['deviceId'])) $fp = (string)$client['deviceId'];

    $str = fn($v, $len) => substr(trim((string)$v), 0, $len);

    return [
        'device_key'        => sfy_device_key($fp, $ip, $ua),
        'device_name'       => $str($client['device_name'] ?? $parsed['device_name'], 191) ?: $parsed['device_name'],
        'device_type'       => $parsed['device_type'],
        'os'                => $str($client['os']       ?? '', 64) ?: $parsed['os'],
        'browser'           => $str($client['browser']  ?? '', 64) ?: $parsed['browser'],
        'browser_version'   => $str($client['browser_version'] ?? '', 32) ?: $parsed['browser_version'],
        'user_agent'        => $ua,
        'screen_resolution' => $str($client['screen_resolution'] ?? $client['screen'] ?? '', 50),
        'timezone'          => $str($client['timezone'] ?? '', 100),
        'language'          => $str($client['language'] ?? '', 32),
        'ip'                => $ip,
        'country'           => sfy_geo_country($ip),
    ];
}

function sfy_device_find(int $id): ?array {
    if ($id <= 0) return null;
    return sfy_try(function () use ($id) {
        $st = sfy_db()->prepare("SELECT * FROM sfy_devices WHERE id=? LIMIT 1");
        $st->execute([$id]);
        return $st->fetch() ?: null;
    }, null);
}

function sfy_device_find_by_key(string $key): ?array {
    return sfy_try(function () use ($key) {
        $st = sfy_db()->prepare("SELECT * FROM sfy_devices WHERE device_key=? LIMIT 1");
        $st->execute([substr($key, 0, 128)]);
        return $st->fetch() ?: null;
    }, null);
}

/**
 * Insert-or-refresh a device row. Bumps session_count only when $countSession.
 * @return array|null the device row (null when the registry rejects it)
 */
function sfy_device_upsert(array $p, bool $countSession = true): ?array {
    try {
        $db  = sfy_db();
        $row = sfy_device_find_by_key($p['device_key']);

        if ($row) {
            $db->prepare("UPDATE sfy_devices SET
                    device_name=COALESCE(NULLIF(?,''),device_name),
                    device_type=COALESCE(NULLIF(?,''),device_type),
                    os=COALESCE(NULLIF(?,''),os),
                    browser=COALESCE(NULLIF(?,''),browser),
                    browser_version=COALESCE(NULLIF(?,''),browser_version),
                    user_agent=?, screen_resolution=COALESCE(NULLIF(?,''),screen_resolution),
                    timezone=COALESCE(NULLIF(?,''),timezone), language=COALESCE(NULLIF(?,''),language),
                    ip=?, country=COALESCE(NULLIF(?,''),country),
                    last_seen=NOW(), session_count=session_count+?, updated_at=NOW()
                  WHERE id=?")
               ->execute([
                   $p['device_name'], $p['device_type'], $p['os'], $p['browser'], $p['browser_version'],
                   $p['user_agent'], $p['screen_resolution'], $p['timezone'], $p['language'],
                   $p['ip'], $p['country'], $countSession ? 1 : 0, (int)$row['id'],
               ]);
            return sfy_device_find((int)$row['id']);
        }

        $db->prepare("INSERT INTO sfy_devices
              (device_key, device_name, device_type, os, browser, browser_version, user_agent,
               screen_resolution, timezone, language, ip, country, first_seen, last_seen,
               session_count, success_count, fail_count, code_views, bypass_attempts, tokens_used,
               first_ip, created_at, updated_at)
              VALUES (?,?,?,?,?,?,?,?,?,?,?,?,NOW(),NOW(),?,0,0,0,0,0,?,NOW(),NOW())")
           ->execute([
               $p['device_key'], $p['device_name'], $p['device_type'], $p['os'], $p['browser'],
               $p['browser_version'], $p['user_agent'], $p['screen_resolution'], $p['timezone'],
               $p['language'], $p['ip'], $p['country'], $countSession ? 1 : 0,
               $p['ip'],
           ]);
        return sfy_device_find((int)$db->lastInsertId());
    } catch (Throwable $e) {
        error_log('[SFY] device upsert: ' . $e->getMessage());
        return null;
    }
}

/** Increment an arbitrary counter column on a device. */
function sfy_device_bump(int $deviceId, string $column, int $by = 1, array $snapshot = []): void {
    if ($deviceId <= 0) return;
    $allowed = ['success_count','fail_count','code_views','bypass_attempts','tokens_used','session_count'];
    if (!in_array($column, $allowed, true)) return;
    try {
        $set = "`$column` = `$column` + ?";
        if ($snapshot) $set .= ", last_seen = NOW(), updated_at = NOW()";
        else            $set .= ", updated_at = NOW()";
        $params = [$by];
        foreach (['last_token','last_game_id','last_session_id'] as $k) {
            if (isset($snapshot[$k])) { $set .= ", `$k` = ?"; $params[] = $snapshot[$k]; }
        }
        $params[] = $deviceId;
        sfy_db()->prepare("UPDATE sfy_devices SET $set WHERE id=?")->execute($params);
    } catch (Throwable $e) { error_log('[SFY] device bump: ' . $e->getMessage()); }
}

/** Attach the device to a session row (idempotent). */
function sfy_device_link_session(string $sessionId, int $deviceId): void {
    if ($deviceId <= 0) return;
    try {
        sfy_db()->prepare("UPDATE sfy_sessions SET device_id=? WHERE session_id=? AND (device_id IS NULL OR device_id<>?)")
                 ->execute([$deviceId, $sessionId, $deviceId]);
    } catch (Throwable $e) { error_log('[SFY] device link: ' . $e->getMessage()); }
}

/** Aggregate KPIs for the admin Devices dashboard. */
function sfy_device_stats(): array {
    return sfy_try(function (): array {
    $db = sfy_db();
    $one = fn(string $sql) => (int)$db->query($sql)->fetch()['n'];
    return [
        'total'        => $one("SELECT COUNT(*) AS n FROM sfy_devices"),
        'today'        => $one("SELECT COUNT(*) AS n FROM sfy_devices WHERE last_seen >= CURDATE()"),
        'week'         => $one("SELECT COUNT(*) AS n FROM sfy_devices WHERE last_seen >= DATE_SUB(NOW(), INTERVAL 7 DAY)"),
        'converters'   => $one("SELECT COUNT(*) AS n FROM sfy_devices WHERE success_count > 0"),
        'repeat'       => $one("SELECT COUNT(*) AS n FROM sfy_devices WHERE success_count > 1"),
        'mobile'       => $one("SELECT COUNT(*) AS n FROM sfy_devices WHERE device_type='mobile'"),
        'desktop'      => $one("SELECT COUNT(*) AS n FROM sfy_devices WHERE device_type='desktop'"),
        'blocked'      => $one("SELECT COUNT(*) AS n FROM sfy_devices WHERE is_blocked=1"),
        'suspicious'   => $one("SELECT COUNT(*) AS n FROM sfy_devices WHERE risk_score >= 50 OR bypass_attempts > 0"),
        'success_total'=> $one("SELECT COALESCE(SUM(success_count),0) AS n FROM sfy_devices"),
        'fail_total'   => $one("SELECT COALESCE(SUM(fail_count),0) AS n FROM sfy_devices"),
    ];
    }, ['total'=>0,'today'=>0,'week'=>0,'converters'=>0,'repeat'=>0,'mobile'=>0,'desktop'=>0,
        'blocked'=>0,'suspicious'=>0,'success_total'=>0,'fail_total'=>0]);
}

/** Paged / filtered list for the admin table. */
function sfy_devices_list(string $search = '', string $sort = 'last_seen', int $limit = 100, int $offset = 0, string $type = ''): array {
    $sortable = [
        'last_seen'     => 'last_seen DESC',
        'success'       => 'success_count DESC',
        'fail'          => 'fail_count DESC',
        'sessions'      => 'session_count DESC',
        'risk'          => 'risk_score DESC',
        'created'       => 'id DESC',
        'country'       => 'country ASC',
        'ip'            => 'ip ASC',
    ];
    $order = $sortable[$sort] ?? $sortable['last_seen'];

    $w = []; $p = [];
    if ($search !== '') {
        $w[] = "(device_name LIKE ? OR device_key LIKE ? OR ip LIKE ? OR country LIKE ? OR browser LIKE ?
                 OR os LIKE ? OR last_token LIKE ? OR last_session_id LIKE ? OR notes LIKE ?)";
        for ($i = 0; $i < 9; $i++) $p[] = '%' . $search . '%';
    }
    if ($type !== '') { $w[] = "device_type = ?"; $p[] = $type; }

    $sql = "SELECT * FROM sfy_devices" . ($w ? ' WHERE ' . implode(' AND ', $w) : '')
         . " ORDER BY $order LIMIT " . max(1, min(500, $limit)) . " OFFSET " . max(0, $offset);
    return sfy_try(function () use ($sql, $p): array {
        $st = sfy_db()->prepare($sql);
        $st->execute($p);
        return $st->fetchAll();
    }, []);
}

function sfy_devices_count(string $search = '', string $type = ''): int {
    $w = []; $p = [];
    if ($search !== '') {
        $w[] = "(device_name LIKE ? OR device_key LIKE ? OR ip LIKE ? OR country LIKE ? OR last_token LIKE ?)";
        for ($i = 0; $i < 5; $i++) $p[] = '%' . $search . '%';
    }
    if ($type !== '') { $w[] = "device_type = ?"; $p[] = $type; }
    return sfy_try(function () use ($w, $p): int {
        $st = sfy_db()->prepare("SELECT COUNT(*) AS n FROM sfy_devices" . ($w ? ' WHERE ' . implode(' AND ', $w) : ''));
        $st->execute($p);
        return (int)($st->fetch()['n'] ?? 0);
    }, 0);
}

/** Sessions recorded for one device (used by the admin detail drawer). */
function sfy_device_sessions(int $deviceId, int $limit = 25): array {
    return sfy_try(function () use ($deviceId, $limit): array {
        $st = sfy_db()->prepare("SELECT session_id, token, current_step, total_steps, is_completed, country,
                                        user_ip, created_at, expires_at, completed_at
                                 FROM sfy_sessions WHERE device_id=? ORDER BY created_at DESC LIMIT ?");
        $st->bindValue(1, $deviceId, PDO::PARAM_INT);
        $st->bindValue(2, $limit, PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll();
    }, []);
}

/** Leaderboard: devices with the most successful code unlocks. */
function sfy_device_leaderboard(int $limit = 15): array {
    return sfy_try(function () use ($limit): array {
        $st = sfy_db()->prepare("SELECT * FROM sfy_devices
                                 WHERE success_count > 0
                                 ORDER BY success_count DESC, tokens_used DESC, last_seen DESC LIMIT ?");
        $st->bindValue(1, $limit, PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll();
    }, []);
}

/** Breakdown by OS / browser / device type for the dashboard charts. */
function sfy_device_breakdown(string $field = 'browser', int $limit = 10): array {
    $map = ['browser' => 'browser', 'os' => 'os', 'device_type' => 'device_type', 'country' => 'country'];
    $col = $map[$field] ?? 'browser';
    return sfy_try(function () use ($col, $limit): array {
        $st = sfy_db()->prepare("SELECT COALESCE(NULLIF(`$col`,''),'Unknown') AS label, COUNT(*) AS n,
                                        COALESCE(SUM(success_count),0) AS ok
                                 FROM sfy_devices GROUP BY label ORDER BY n DESC LIMIT ?");
        $st->bindValue(1, $limit, PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll();
    }, []);
}

/** Daily unique devices + successes for the last N days. */
function sfy_device_daily(int $days = 14): array {
    return sfy_try(function () use ($days): array {
        $st = sfy_db()->prepare("SELECT DATE(last_seen) AS day, COUNT(*) AS devices,
                                        COALESCE(SUM(success_count),0) AS ok
                                 FROM sfy_devices
                                 WHERE last_seen >= " . sfy_sql_now_offset('DAY') . "
                                 GROUP BY DATE(last_seen) ORDER BY day DESC");
        $st->bindValue(1, -$days, PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll();
    }, []);
}

/** Devices sharing an IP with N or more peers — cheap multi-account signal. */
function sfy_device_ip_clusters(int $minPeers = 3, int $limit = 15): array {
    return sfy_try(function () use ($minPeers, $limit): array {
        $st = sfy_db()->prepare("SELECT ip, COUNT(*) AS devices, COALESCE(SUM(success_count),0) AS ok,
                                        COALESCE(SUM(fail_count),0) AS fails, MAX(last_seen) AS last_seen
                                 FROM sfy_devices WHERE ip IS NOT NULL AND ip<>''
                                 GROUP BY ip HAVING devices >= ? ORDER BY devices DESC LIMIT ?");
        $st->bindValue(1, $minPeers, PDO::PARAM_INT);
        $st->bindValue(2, $limit, PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll();
    }, []);
}

function sfy_device_block(int $id, bool $blocked): void {
    sfy_try(function () use ($id, $blocked) {
        sfy_db()->prepare("UPDATE sfy_devices SET is_blocked=?, updated_at=NOW() WHERE id=?")
                 ->execute([$blocked ? 1 : 0, $id]);
        return true;
    }, false);
}

function sfy_device_delete(int $id): void {
    sfy_try(function () use ($id) {
        sfy_db()->prepare("DELETE FROM sfy_devices WHERE id=?")->execute([$id]);
        return true;
    }, false);
}

/** Fresh browser fingerprint generated client side (returned to the page). */
function sfy_device_fingerprint_js(): string {
    return <<<'JS'
(function(){
  function fp(){
    var n = navigator, s = screen;
    var parts = [
      n.userAgent, n.language, (n.languages||[]).join(','),
      s.width + 'x' + s.height, s.colorDepth,
      (new Date()).getTimezoneOffset(),
      n.platform || '', n.hardwareConcurrency || 0,
      n.deviceMemory || 0, n.maxTouchPoints || 0,
      (n.plugins ? n.plugins.length : 0)
    ];
    var raw = parts.join('|'), h = 2166136261;
    for (var i = 0; i < raw.length; i++) { h ^= raw.charCodeAt(i); h = (h * 16777619) >>> 0; }
    return 'fp_' + h.toString(36) + '_' + raw.length.toString(36);
  }
  var key = 'sfy_dev_fp';
  var id = null;
  try { id = localStorage.getItem(key); } catch(e) {}
  if (!id) { id = fp(); try { localStorage.setItem(key, id); } catch(e) {} }
  window.SFY_DEVICE_FP = id;
})();
JS;
}

/** Shared payload builder so every page reports the same device shape. */
function sfy_device_client_js(): string {
    return <<<'JS'
window.SFY_device = function(){
  var n = navigator, s = screen;
  return {
    device_fingerprint: window.SFY_DEVICE_FP || '',
    device_name: (n.platform || 'Unknown') + ' · ' + (n.userAgentData && n.userAgentData.platform ? n.userAgentData.platform : ''),
    user_agent: n.userAgent,
    screen_resolution: s.width + 'x' + s.height,
    timezone: (function(){ try { return Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch(e){ return ''; } })(),
    language: n.language || '',
    touch: (n.maxTouchPoints || 0) > 0 ? 1 : 0
  };
};
JS;
}
