<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY ULTIMATE — SESSION FLOW
 *  Everything between "user clicked the Roblox menu link" and "user reads
 *  the code": session lookup/creation, device binding, bypass flagging and
 *  the code-release gate.
 * ═══════════════════════════════════════════════════════════════════════
 */

/* ── lookup ────────────────────────────────────────────────────────── */
function sfy_load_session(string $sid): ?array {
    if ($sid === '') return null;
    return sfy_try(function () use ($sid) {
        $st = sfy_db()->prepare("SELECT * FROM sfy_sessions WHERE session_id=? LIMIT 1");
        $st->execute([$sid]);
        return $st->fetch() ?: null;
    }, null);
}

/**
 * A live session for this address, restricted to sessions that could belong to
 * the caller.
 *
 * This is the last-resort resolver used where there is no cookie to go by (a
 * provider landing on /done that lost the session id, a fresh tab, the home
 * page). The address alone is *not* an identity — a household, a school, a
 * café, a mobile carrier or an office puts every one of their users behind one
 * address — and treating it as one is how a flow claimed on an iPhone showed up
 * as "in progress on this device" on the owner's Windows PC, and how a landing
 * on /done from that PC could attribute itself to the phone's unfinished step.
 *
 * So the rows are filtered through sfy_session_belongs_here(): same device id or
 * fingerprint when both sides know one, and — the part an IP cannot do — the
 * same coarse browser/platform identity (`mobile|ios|safari` is never
 * `desktop|windows 10/11|chrome`). Sessions that predate migration 021 carry no
 * identity, so a missing value is never a refusal.
 */
function sfy_find_session_by_ip(string $ip, string $token = '', int $deviceId = 0, string $fp = ''): ?array {
    return sfy_try(function () use ($ip, $token, $deviceId, $fp): ?array {
        if ($ip === '' || !sfy_table_exists('sfy_sessions')) return null;
        $have = sfy_sessions_have('is_completed', 'expires_at', 'token', 'user_ip', 'created_at', 'session_id');
        if (!in_array('user_ip', $have, true)) return null;

        $where = ['user_ip=?'];  $p = [$ip];
        if (in_array('is_completed', $have, true)) $where[] = 'is_completed=0';
        if (in_array('expires_at', $have, true))   $where[] = 'expires_at>NOW()';
        if ($token !== '' && in_array('token', $have, true)) { $where[] = 'token=?'; $p[] = $token; }

        $order = in_array('created_at', $have, true) ? 'created_at DESC' : 'session_id DESC';
        $st = sfy_db()->prepare('SELECT * FROM sfy_sessions WHERE ' . implode(' AND ', $where)
                             . ' ORDER BY ' . $order . ' LIMIT 20');
        $st->execute($p);
        foreach ($st->fetchAll() as $row) {
            if (sfy_session_belongs_here($row, $deviceId, $fp)) return $row;
        }
        return null;
    }, null);
}

/* ── schema-tolerant lookups ───────────────────────────────────────────
   The public claim flow is the first thing a real visitor touches, so none
   of these queries may ever depend on a column that an unfinished update has
   not created yet. Each WHERE clause is assembled from the columns that
   actually exist and the whole thing degrades to null instead of throwing. */

function sfy_sessions_have(string ...$cols): array {
    $out = [];
    foreach ($cols as $c) if (sfy_column_exists('sfy_sessions', $c)) $out[] = $c;
    return $out;
}

/** Live (unfinished, unexpired) session for this token bound to this user. */
function sfy_session_find_live(string $token, int $deviceId = 0, string $fp = '', string $ip = ''): ?array {
    return sfy_try(function () use ($token, $deviceId, $fp, $ip): ?array {
        if (!sfy_table_exists('sfy_sessions')) return null;
        $have = sfy_sessions_have('is_completed', 'expires_at', 'token', 'device_id', 'fingerprint', 'user_ip', 'created_at');
        if (!in_array('is_completed', $have, true)) return null;

        $where = ['is_completed=0'];
        $p     = [];
        if (in_array('expires_at', $have, true)) $where[] = 'expires_at>NOW()';
        if ($token !== '' && in_array('token', $have, true)) { $where[] = 'token=?'; $p[] = $token; }

        /*
         * Identity first, address last — and the address may only adopt a
         * session that cannot be attributed to anybody else.
         *
         * The three used to be OR-ed into one bracket, which meant two players
         * sharing a NAT (one household, one school, one mobile carrier) and one
         * shared token were handed the *same* session: the second player landed
         * in the first player's half-finished run. With reusable tokens that is
         * a normal situation, not an edge case.
         */
        $ident = [];
        if ($deviceId > 0 && in_array('device_id', $have, true)) { $ident[] = 'device_id=?'; $p[] = $deviceId; }
        if ($fp !== ''       && in_array('fingerprint', $have, true)) { $ident[] = 'fingerprint=?'; $p[] = $fp; }

        if ($ident) {
            $where[] = '(' . implode(' OR ', $ident) . ')';
        } elseif ($ip !== '' && in_array('user_ip', $have, true)) {
            /* Nothing identifies this caller, so fall back to the address — for
               a session that has no device recorded either. */
            $where[] = 'user_ip=?';
            $p[]     = $ip;
            if (in_array('device_id', $have, true))   $where[] = '(device_id IS NULL OR device_id=0)';
            if (in_array('fingerprint', $have, true)) $where[] = "(fingerprint IS NULL OR fingerprint='')";
        }

        $order = in_array('created_at', $have, true) ? 'created_at DESC' : 'session_id DESC';
        $st = sfy_db()->prepare('SELECT * FROM sfy_sessions WHERE ' . implode(' AND ', $where)
                             . ' ORDER BY ' . $order . ' LIMIT 1');
        $st->execute($p);
        return $st->fetch() ?: null;
    }, null);
}

/**
 * Is this token meant to be reused by everybody who holds the link?
 * Memoised per request: the claim path asks more than once.
 */
function sfy_token_is_multi(string $token): bool {
    if ($token === '') return false;
    static $memo = [];
    if (array_key_exists($token, $memo)) return $memo[$token];

    return $memo[$token] = (bool)sfy_try(function () use ($token): bool {
        if (!sfy_table_exists('sfy_tokens') || !sfy_column_exists('sfy_tokens', 'multi_use')) return false;
        $st = sfy_db()->prepare("SELECT multi_use FROM sfy_tokens WHERE token=? LIMIT 1");
        $st->execute([$token]);
        return (int)($st->fetch()['multi_use'] ?? 0) === 1;
    }, false);
}

/**
 * What happens when a token that is already marked used is claimed again?
 *
 *   open    (default) — the used flag is ignored completely. The link behaves
 *                       like a fresh one for everybody who holds it: the tasks
 *                       run, the code is delivered. Token duplication is the
 *                       token pool's job (the separate code system marks its
 *                       own rows used and never hands the same one out
 *                       twice), so refusing a claim here only produces dead
 *                       ends: a link that worked for one player refuses every
 *                       other one, and the admin has to reset rows by hand.
 *   handoff — a used token hands the code back while it is still inside the
 *             view window, and otherwise explains that it is finished.
 */
function sfy_token_reuse_mode(): string {
    $raw = strtolower(trim((string)sfy_config_get('set_token_reuse', '')));
    if ($raw === '') $raw = strtolower(trim((string)sfy_cfg('security.token_reuse', 'open')));
    return in_array($raw, ['open', 'handoff'], true) ? $raw : 'open';
}

/**
 * May anybody holding this link claim it, whatever its used flag says?
 * True under the OPEN policy, and true for a token explicitly marked reusable.
 * The per-token switch is what keeps a single "locked" token possible once the
 * install-wide policy is HANDOFF again.
 */
function sfy_token_reusable(array $tok): bool {
    if (sfy_token_reuse_mode() === 'open') return true;
    return sfy_token_is_multi((string)($tok['token'] ?? ''));
}

/**
 * The browser/platform signature this install can trust.
 *
 * Derived from the request alone — never from client-supplied JSON — and
 * deliberately coarse. Version numbers are dropped so a browser update, a new
 * OS patch or an emoji-flavoured UA string cannot look like a new browser, and
 * the IP is not part of it so a mobile handover is not either. What it *does*
 * notice is the thing that matters: a different browser family or platform.
 *
 * Examples: `desktop|windows 10/11|chrome`, `mobile|android|chrome`.
 */
function sfy_flow_identity(string $ua = ''): string {
    $ua = $ua !== '' ? $ua : sfy_user_agent();
    if (trim($ua) === '') return '';
    $p = sfy_parse_ua($ua);
    return strtolower(trim((string)($p['device_type'] ?? 'desktop')) . '|'
                    . trim((string)($p['os'] ?? '')) . '|'
                    . trim((string)($p['browser'] ?? '')));
}

/**
 * Could this session be *this* device's session — or does it belong to somebody
 * else on the same network?
 *
 * "Same IP" is a hint, never an identity: one household, school, café, mobile
 * carrier or office puts many people behind a single address, so a resolver that
 * trusts the address hands one person's half-finished flow to another. Three
 * signals are checked instead, and each one is only a refusal when *both* sides
 * know it:
 *
 *   1. the recorded `device_id`, when the caller can name one,
 *   2. the recorded device fingerprint, when the caller sends one,
 *   3. `flow_identity` — the coarse, request-derived browser/platform signature
 *      (`mobile|ios|safari` can never equal `desktop|windows 10/11|chrome`),
 *      which is the "a phone is not a PC" judgement an address cannot make.
 *
 * A value nobody recorded is never held against the caller: an install whose
 * sessions predate migration 021, a client that sends no User-Agent, or a
 * cookie-less first visit must all still work. Missing information means
 * "cannot judge", and "cannot judge" is not a refusal.
 */
function sfy_session_belongs_here(array $sess, int $deviceId = 0, string $fp = ''): bool {
    $storedDev = (int)($sess['device_id'] ?? 0);
    if ($deviceId > 0 && $storedDev > 0 && $storedDev !== $deviceId) return false;

    $storedFp = trim((string)($sess['fingerprint'] ?? ''));
    if ($fp !== '' && $storedFp !== '' && !hash_equals($storedFp, $fp)) return false;

    $storedIdent = trim((string)($sess['flow_identity'] ?? ''));
    $myIdent     = sfy_flow_identity();
    if ($storedIdent !== '' && $myIdent !== '' && $storedIdent !== $myIdent) return false;

    return true;
}

/**
 * Retire an unfinished session so it cannot be continued from anywhere.
 *
 * Deliberately **not** part of the device-change path any more: that path used
 * to call this, which meant a second device merely *opening* a task link threw
 * away the first device's progress mid-task. Ownership is per request now (see
 * sfy_session_belongs_here), so a device change only decides what *this*
 * request may continue — never what the other one loses. Kept as the explicit
 * "retire this session" primitive for admin/staff use.
 */
function sfy_session_close(string $sid, string $why = ''): void {
    sfy_try(function () use ($sid, $why): void {
        sfy_db()->prepare("UPDATE sfy_sessions SET expires_at = NOW()
                            WHERE session_id=? AND is_completed=0")->execute([$sid]);
        error_log('[SFY] session closed (' . $why . '): ' . $sid);
    }, null);
}

/** Is somebody on a different IP already running this token? (anti-sharing) */
function sfy_token_session_elsewhere(string $token, string $ip, int $deviceId = 0, string $fp = ''): ?array {
    return sfy_try(function () use ($token, $ip, $deviceId, $fp): ?array {
        if (!sfy_table_exists('sfy_sessions')) return null;
        $have = sfy_sessions_have('is_completed', 'expires_at', 'token', 'user_ip', 'device_id', 'fingerprint', 'created_at');
        if (!in_array('token', $have, true) || !in_array('user_ip', $have, true)) return null;

        $where = ['token=?'];  $p = [$token];
        if (in_array('is_completed', $have, true)) $where[] = 'is_completed=0';
        if (in_array('expires_at', $have, true))   $where[] = 'expires_at>NOW()';
        if ($ip !== '') { $where[] = 'user_ip<>?'; $p[] = $ip; }

        /*
         * The caller's own device is never "somebody else" — even when its IP
         * changed (mobile data handoff, VPN toggle, a new router lease). The
         * guard used to fire on the IP alone, so a player who re-claimed their
         * own token was answered with "Token already in use" while nothing was
         * actually wrong.
         */
        if ($deviceId > 0 && in_array('device_id', $have, true)) {
            $where[] = '(device_id IS NULL OR device_id<>?)';
            $p[]     = $deviceId;
        }
        if ($fp !== '' && in_array('fingerprint', $have, true)) {
            $where[] = '(fingerprint IS NULL OR fingerprint<>?)';
            $p[]     = $fp;
        }

        $order = in_array('created_at', $have, true) ? 'created_at DESC' : 'session_id DESC';
        $st = sfy_db()->prepare('SELECT session_id, user_ip FROM sfy_sessions WHERE ' . implode(' AND ', $where)
                             . ' ORDER BY ' . $order . ' LIMIT 1');
        $st->execute($p);
        return $st->fetch() ?: null;
    }, null);
}

/**
 * How far a *finished* token may be handed around.
 *
 *   any    — any device that still holds the link can re-open the code inside
 *            the view window. A fresh browser, a phone, a reinstall all work:
 *            the player finished the work, so they get their code back.
 *   device — only the device that completed the flow may display it.
 *
 * `any` is the default because it is what the site already did, and locking the
 * code away from the person who earned it is a support burden. The point of the
 * switch is that the *copy on the page now tells the truth* either way: the old
 * text promised "bound to this device and IP" while nothing enforced it.
 */
function sfy_code_handoff_mode(): string {
    $raw = strtolower(trim((string)sfy_config_get('set_code_handoff', '')));
    if ($raw === '') $raw = strtolower(trim((string)sfy_cfg('security.code_handoff', 'any')));
    return in_array($raw, ['any', 'device'], true) ? $raw : 'any';
}

/**
 * Is this the device the code was unlocked on?
 * Compares the stored device id first and the stored fingerprint second, so a
 * session whose id was never written still matches on the key. A session with
 * neither recorded answers "yes": an unfinished update must never lock a
 * legitimate player out of the code they earned.
 */
function sfy_code_device_matches(array $sess, ?array $device): bool {
    $sidDev = (int)($sess['device_id'] ?? 0);
    $fp     = trim((string)($sess['device_fingerprint'] ?? ''));
    if ($sidDev <= 0 && $fp === '') return true;
    if (!$device) return false;

    if ($sidDev > 0 && (int)($device['id'] ?? 0) === $sidDev) return true;
    $viewer = trim((string)($device['device_key'] ?? ''));
    return $viewer !== '' && $fp !== '' && hash_equals($fp, $viewer);
}

/**
 * May this device display the code? Only the policy decides — the same-device
 * question lives in sfy_code_device_matches() so the *page* can say "reopened
 * elsewhere" even in the mode where that is perfectly allowed.
 */
function sfy_code_handoff_allows(array $sess, ?array $device): bool {
    return sfy_code_handoff_mode() !== 'device' || sfy_code_device_matches($sess, $device);
}

/** Everything recorded about how a link was claimed, for the claim page. */
function sfy_token_completed_session(string $token, int $deviceId = 0): ?array {
    return sfy_try(function () use ($token, $deviceId): ?array {
        if (!sfy_table_exists('sfy_sessions')) return null;
        $have  = sfy_sessions_have('is_completed', 'token', 'device_id', 'completed_at');
        if (!in_array('token', $have, true)) return null;
        $where = ['token=?'];
        $p     = [$token];
        if (in_array('is_completed', $have, true)) $where[] = 'is_completed=1';

        if (in_array('device_id', $have, true)) {
            // Favour this device, then the most recent completion.
            $order = '(device_id = ?) DESC, ';
            $p[]   = $deviceId;
        } else {
            $order = '';
        }
        $order .= in_array('completed_at', $have, true) ? 'completed_at DESC' : 'session_id DESC';

        $st = sfy_db()->prepare('SELECT * FROM sfy_sessions WHERE ' . implode(' AND ', $where)
                             . ' ORDER BY ' . $order . ' LIMIT 1');
        $st->execute($p);
        return $st->fetch() ?: null;
    }, null);
}

/** Token row lookup that reports a missing table instead of exploding. */
function sfy_token_find(string $token): ?array {
    return sfy_try(function () use ($token): ?array {
        if (!sfy_table_exists('sfy_tokens')) return null;
        $st = sfy_db()->prepare("SELECT * FROM sfy_tokens WHERE token=? LIMIT 1");
        $st->execute([$token]);
        return $st->fetch() ?: null;
    }, null);
}

function sfy_session_cookie_name(): string { return 'sfy_sid'; }

function sfy_set_session_cookie(string $sid): void {
    if (headers_sent()) { $_SESSION['sfy_sid'] = $sid; return; }
    setcookie(sfy_session_cookie_name(), $sid, [
        'expires'  => time() + sfy_setting_int('session_ttl_minutes', 30) * 60,
        'path'     => '/',
        'secure'   => !empty($_SERVER['HTTPS']),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

function sfy_get_session_cookie(): ?string {
    return $_COOKIE[sfy_session_cookie_name()] ?? ($_SESSION['sfy_sid'] ?? null);
}

/*
 * Claim-page / landing-page resolution order: cookie → PHP session → ip+token.
 *
 * The cookie is first because it is the only signal that is actually bound to
 * the browser asking: it is set on the device that claimed the session. The
 * address fallback behind it is identity-checked (see sfy_session_belongs_here)
 * and exists for a provider landing that lost the session id, not to hand a
 * session to anybody who happens to share the network.
 */
/** Live = unfinished (or already finished) and, when known, not past its TTL. */
function sfy_session_is_live(array $s): bool {
    if ((int)($s['is_completed'] ?? 0) === 1) return true;
    $exp = (string)($s['expires_at'] ?? '');
    return $exp === '' ? true : strtotime($exp) > time();
}

function sfy_session_is_expired(array $s): bool {
    $exp = (string)($s['expires_at'] ?? '');
    return $exp !== '' && strtotime($exp) <= time();
}

function sfy_resolve_current_session(string $token = ''): ?array {
    $sid = sfy_get_session_cookie();
    if ($sid) {
        $s = sfy_load_session((string)$sid);
        /* A cookie that belongs to another browser/platform is not adopted
           either: a phone's session cookie pasted, restored or synced onto a
           different machine is still the phone's flow. */
        if ($s && sfy_session_is_live($s) && sfy_session_belongs_here($s)) return $s;
    }
    return sfy_find_session_by_ip(sfy_client_ip(), $token);
}

/* ── creation ──────────────────────────────────────────────────────── */
/**
 * Create the run's session row — or answer with something a player can act on.
 *
 * This is the first write of a whole run, which makes it the worst possible
 * place to fail: a throw here used to reach the crash handler *before* any
 * session existed, so the claim POST answered an opaque HTTP 500 to the player
 * and a bare `ref:` to the owner. Two things happen instead:
 *
 *   1. the column sweep (sfy_schema_repair_columns()) repairs the tables and
 *      the insert is retried once — the same self-healing the updater performs,
 *      applied exactly where a missing column bites. A database that is simply
 *      behind the code therefore recovers on the player's own request;
 *   2. if it still cannot be stored, the player gets a clear page with a retry
 *      and the admin's updater, and the raw error (message + file:line) goes to
 *      the error log, so the owner reads the real cause in Admin → Updater →
 *      ERROR_LOG instead of a ref they cannot look up from the web UI.
 *
 * The throw is never swallowed: whatever the cause, it is logged verbatim.
 */
function sfy_session_create(array $tokenRow, string $ip, string $ua, string $fingerprint, int $deviceId): string {
    try {
        return sfy_session_insert($tokenRow, $ip, $ua, $fingerprint, $deviceId);
    } catch (Throwable $e) {
        error_log('[SFY] session create failed: ' . $e->getMessage()
                . ' @ ' . basename($e->getFile()) . ':' . $e->getLine());

        $repaired = sfy_try(fn() => array_filter(sfy_schema_repair_columns()['notes'] ?? []), []);
        if ($repaired) {
            try {
                $sid = sfy_session_insert($tokenRow, $ip, $ua, $fingerprint, $deviceId);
                error_log('[SFY] session create recovered after repairing ' . implode(', ', $repaired));
                return $sid;
            } catch (Throwable $e2) {
                error_log('[SFY] session create still failing after repair: ' . $e2->getMessage());
            }
        }

        sfy_fatal('Could not start your run',
            'The server could not store a new verification just now. Nothing was lost — retry this link, and if it '
          . 'keeps happening the administrator can read the exact cause in Admin → Updater → ERROR_LOG.',
            503,
            ['retry' => (string)($_SERVER['REQUEST_URI'] ?? sfy_url('')), 'admin' => true]);
        throw $e;   // sfy_fatal() exits; kept so the return type holds for a static reader
    }
}

function sfy_session_insert(array $tokenRow, string $ip, string $ua, string $fingerprint, int $deviceId): string {
    $db    = sfy_db();
    $sid   = sfy_rand_id(24);
    $tasks = (int)($tokenRow['tasks_required'] ?? 0);
    if ($tasks < 1) $tasks = sfy_setting_int('default_tasks_required', 2);
    $ttl   = max(5, sfy_setting_int('session_ttl_minutes', 30));

    /*
     * Build the INSERT from the columns this install actually has. If the
     * updater has not been run yet the optional columns simply drop out, so a
     * visitor can never trigger a fatal error on a half-upgraded database.
     */
    $values = [
        'session_id'   => $sid,
        'token'        => (string)($tokenRow['token'] ?? ''),
        'game_id'      => $tokenRow['game_id'] ?? null,
        'current_step' => 1,
        'total_steps'  => $tasks,
        'user_ip'      => $ip,
        'user_agent'   => substr($ua, 0, 512),
        'fingerprint'  => substr($fingerprint, 0, 128),
        /* Stored so a *later* request can tell "same browser" from "another
           browser" using a value both requests can compute. */
        'flow_identity' => sfy_flow_identity($ua),
        'device_id'    => $deviceId,
        'country'      => sfy_geo_country($ip),
    ];

    $cols = []; $marks = []; $params = [];
    foreach ($values as $col => $val) {
        if (!sfy_column_exists('sfy_sessions', $col)) continue;
        $cols[] = "`$col`"; $marks[] = '?'; $params[] = $val;
    }
    if (!in_array('`session_id`', $cols, true)) {
        throw new RuntimeException('sfy_sessions is missing its session_id column — run the updater.');
    }
    foreach (['step_started_at', 'created_at'] as $col) {
        if (sfy_column_exists('sfy_sessions', $col)) { $cols[] = "`$col`"; $marks[] = 'NOW()'; }
    }
    foreach (['risk_score', 'bypass_flags'] as $col) {
        if (sfy_column_exists('sfy_sessions', $col)) { $cols[] = "`$col`"; $marks[] = '0'; }
    }
    if (sfy_column_exists('sfy_sessions', 'expires_at')) {
        $cols[] = '`expires_at`';
        /* TIMESTAMPADD(MINUTE, ?, NOW()) — a bound amount, because MySQL will not
           take a placeholder in the INTERVAL slot (see sfy_sql_now_offset()). */
        $marks[]  = sfy_sql_now_offset('MINUTE');
        $params[] = $ttl;
    }

    $sql = 'INSERT INTO sfy_sessions (' . implode(',', $cols) . ') VALUES (' . implode(',', $marks) . ')';
    $db->prepare($sql)->execute($params);

    return $sid;
}

function sfy_session_extend(string $sid, int $minutes = 0): void {
    $minutes = $minutes > 0 ? $minutes : sfy_setting_int('session_ttl_minutes', 30);
    sfy_try(function () use ($sid, $minutes) {
        sfy_db()->prepare('UPDATE sfy_sessions SET expires_at = ' . sfy_sql_now_offset('MINUTE') . ' WHERE session_id=?')
                 ->execute([$minutes, $sid]);
        return true;
    }, false);
}

/* ── flagging ──────────────────────────────────────────────────────── */
function sfy_session_flag(string $sid, string $reason, int $risk = 10, ?int $deviceId = null): void {
    try {
        sfy_db()->prepare("UPDATE sfy_sessions SET bypass_flags=bypass_flags+1, risk_score=risk_score+? WHERE session_id=?")
                 ->execute([$risk, $sid]);
        if ($deviceId === null) {
            $st = sfy_db()->prepare("SELECT device_id FROM sfy_sessions WHERE session_id=?");
            $st->execute([$sid]);
            $deviceId = (int)($st->fetch()['device_id'] ?? 0);
        }
        if ($deviceId > 0) sfy_device_bump((int)$deviceId, 'bypass_attempts', 1);
        error_log("[SFY] bypass signalled: $reason (session $sid)");
    } catch (Throwable $e) { error_log('[SFY] flag: ' . $e->getMessage()); }
}

/** A verified provider postback clears the flags; the provider vouched for it. */
function sfy_session_clear_flags(string $sid): void {
    if ($sid === '') return;
    sfy_try(function () use ($sid) {
        $db = sfy_db();

        /* If the strict waiting popup fired before a slow-but-real postback,
           that produced a false strict_landing row and one device attempt.
           The provider has now vouched for the session, so remove that false
           positive instead of letting it accumulate into a device block. */
        $dev = 0;
        $st = $db->prepare("SELECT device_id FROM sfy_sessions WHERE session_id=?");
        $st->execute([$sid]);
        $dev = (int)($st->fetch()['device_id'] ?? 0);

        $cnt = 0;
        if (function_exists('sfy_table_exists') && sfy_table_exists('sfy_postback_log')) {
            $q = $db->prepare("SELECT COUNT(*) AS n FROM sfy_postback_log
                               WHERE session_id=? AND reason='return_rejected'
                                 AND raw_query LIKE '%strict_landing%'");
            $q->execute([$sid]);
            $cnt = (int)($q->fetch()['n'] ?? 0);
            if ($cnt > 0) {
                $db->prepare("DELETE FROM sfy_postback_log
                              WHERE session_id=? AND reason='return_rejected'
                                AND raw_query LIKE '%strict_landing%'")->execute([$sid]);
            }
        }
        if ($cnt > 0 && $dev > 0) {
            $db->prepare('UPDATE sfy_devices SET bypass_attempts=GREATEST(0, bypass_attempts-?) WHERE id=?')
               ->execute([$cnt, $dev]);
        }

        $db->prepare("UPDATE sfy_sessions SET bypass_flags=0, risk_score=0 WHERE session_id=?")
           ->execute([$sid]);
        return null;
    }, null);
}

/* ══ the bypass warning (staged, 2026-10-24) ══════════════════════════

   A session is "flagged" when something that only a bypass attempt produces
   was recorded for it: a rejected postback (bad key, IP mismatch, no
   attribution), a ticket that did not match, a landing with no hand-off
   cookie, or a landing from a named link-skipping host. A normal reload that
   is merely refused as "typed_url" is deliberately NOT a flag.

   The warning is a policy notice, not a second gate: it never withholds a
   code. It ships OFF in config/config.php (production), ON in the staging
   copy, so it can be reviewed before the main site shows it.

   Enforcement is intentionally not automatic yet: an IP ban on a shared
   carrier NAT can hit innocent players. The attempts are already counted on
   the device (bypass_attempts) and in sfy_postback_log for an owner to act on.
   ═══════════════════════════════════════════════════════════════════ */

/** Boolean bypass option: panel (set_*) first, then config, then default. */
function sfy_bypass_opt_bool(string $key, bool $default): bool {
    $v = sfy_config_get('set_' . $key, null);
    if ($v === null || $v === '') return (bool)sfy_cfg('security.' . $key, $default);
    return !in_array(strtolower(trim((string)$v)), ['0', 'off', 'no', 'false'], true);
}

/** Integer bypass option: panel (set_*) first, then config, then default (min 1). */
function sfy_bypass_opt_int(string $key, int $default): int {
    $v = sfy_config_get('set_' . $key, null);
    if ($v === null || $v === '') return max(1, (int)sfy_cfg('security.' . $key, $default));
    return max(1, (int)$v);
}

function sfy_bypass_state(array $sess): array {
    /* The panel (Admin → Settings → Bypass response) overrides config; staging
       seeds both on, production seeds both off. */
    $staging = defined('STAGING_COPY');
    $enabled = sfy_bypass_opt_bool('show_bypass_warning', $staging);
    /* If the block key was never set, follow the notice rather than silently
       staying cosmetic. */
    $blockOn  = sfy_bypass_opt_bool('bypass_block', $enabled);
    $flags   = (int)($sess['bypass_flags'] ?? 0);
    $device  = 0;
    $ipHits  = 0;

    if ($enabled || $blockOn) {
        $devId = (int)($sess['device_id'] ?? 0);
        if ($devId > 0 && function_exists('sfy_device_find')) {
            $dev = sfy_device_find($devId);
            $device = (int)($dev['bypass_attempts'] ?? 0);
        }
        $ip = sfy_client_ip();
        if ($ip !== '' && function_exists('sfy_table_exists') && sfy_table_exists('sfy_postback_log')) {
            $ipWindow = max(1, min(168, sfy_bypass_opt_int('bypass_ip_window_hours', 24)));
            $ipHits = (int)sfy_try(function () use ($ip, $ipWindow): int {
                $st = sfy_db()->prepare("SELECT COUNT(*) AS n FROM sfy_postback_log
                    WHERE ip=? AND created_at > DATE_SUB(NOW(), INTERVAL {$ipWindow} HOUR)
                      AND ( reason IN ('bad_postback_key','ip_mismatch','unattributed_ip')
                            OR (reason='return_rejected' AND ( raw_query LIKE '%ticket_missing%'
                                 OR raw_query LIKE '%ticket_invalid%'
                                 OR raw_query LIKE '%no_handoff_cookie%'
                                 OR raw_query LIKE '%blocked_referrer%'
                                 OR raw_query LIKE '%strict_landing%' )) )");
                $st->execute([$ip]);
                return (int)($st->fetch()['n'] ?? 0);
            }, 0);
        }
    }

    $detected = $flags > 0 || $device > 0 || $ipHits > 0;
    $flagged  = $enabled && $detected;
    $limit    = max(2, (int)sfy_cfg('security.bypass_ban_after', 3));

    /* The popup and the block must agree on the number. The IP counter is
       opt-in (bypass_block_ip): on staging it is on so repeated attempts from
       the same connection are counted; production can leave it off so a shared
       carrier address does not lock a household. */
    $blockAfter = sfy_bypass_opt_int('bypass_block_after', 2);
    $blockIp    = sfy_bypass_opt_bool('bypass_block_ip', false);
    $ipWindow   = max(1, min(168, sfy_bypass_opt_int('bypass_ip_window_hours', 24)));
    $attempts   = $detected ? max(1, $flags, $device, $blockIp ? $ipHits : 0) : 0;
    $blocked    = $blockOn && $detected && $attempts >= $blockAfter;

    return ['enabled' => $enabled, 'flagged' => $flagged, 'detected' => $detected,
            'blocked' => $blocked, 'attempts' => $attempts, 'limit' => $limit,
            'flags' => $flags, 'device' => $device, 'ip_hits' => $ipHits,
            'block_after' => $blockAfter, 'ip_window' => $ipWindow];
}

/** The red notice shown on a flagged session. Empty for everybody else. */
function sfy_bypass_warning(array $sess): string {
    $st = sfy_bypass_state($sess);
    if (empty($st['enabled']) || empty($st['flagged'])) return '';

    $n = (int)$st['attempts'];
    $limit = (int)$st['limit'];
    $tail = $n >= $limit
        ? 'This connection has reached the flagged-attempt limit and is now subject to an IP ban.'
        : 'Repeated attempts are recorded and will lead to an IP ban.';

    $sid = (string)($sess['session_id'] ?? '');
    /* A completed session cannot go "back to the task" — /go would bounce it
       straight back to /out. Only offer the link while a step is still open. */
    $completed = (int)($sess['is_completed'] ?? 0) === 1;
    $go  = (!$completed && $sid !== '') ? sfy_url('go/' . rawurlencode($sid)) : '';
    $css = '#sfy-bw{position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;'
         . 'padding:18px;background:rgba(4,5,9,.86);-webkit-backdrop-filter:blur(3px);backdrop-filter:blur(3px);'
         . 'animation:sfyBwBg .9s steps(2,end) infinite}'
         . '@keyframes sfyBwBg{0%,100%{background:rgba(4,5,9,.86)}50%{background:rgba(78,0,12,.62)}}'
         . '#sfy-bw .sfy-bw-card{width:min(560px,100%);background:linear-gradient(180deg,#1a0b10,#12080c);'
         . 'border:1px solid #ff3b5c;border-radius:14px;padding:22px 22px 18px;color:#ffeef2;'
         . 'box-shadow:0 0 0 1px rgba(255,59,92,.6),0 0 30px rgba(255,0,51,.7),0 0 100px rgba(255,0,51,.35),'
         . 'inset 0 0 46px rgba(255,0,51,.10);animation:sfyBwFlash .8s steps(2,end) infinite}'
         . '@keyframes sfyBwFlash{0%,100%{border-color:#ff3b5c;box-shadow:0 0 0 1px rgba(255,59,92,.6),'
         . '0 0 26px rgba(255,0,51,.65),0 0 80px rgba(255,0,51,.3),inset 0 0 40px rgba(255,0,51,.08)}'
         . '50%{border-color:#fff;box-shadow:0 0 0 3px #ff0033,0 0 55px #ff0033,0 0 130px rgba(255,0,51,.75),'
         . 'inset 0 0 60px rgba(255,0,51,.18)}}'
         . '#sfy-bw .sfy-bw-siren{height:8px;border-radius:6px;margin:-6px 0 14px;'
         . 'background:repeating-linear-gradient(90deg,#ff0033 0 16px,#2a0008 16px 32px);'
         . 'background-size:32px 8px;animation:sfyBwSiren .5s linear infinite;box-shadow:0 0 20px #ff0033}'
         . '@keyframes sfyBwSiren{to{background-position:32px 0}}'
         . '#sfy-bw .sfy-bw-top{display:flex;gap:12px;align-items:center;margin:0 0 6px}'
         . '#sfy-bw .sfy-bw-icon{display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;'
         . 'border-radius:10px;background:#3a0008;border:1px solid #ff0033;color:#ff2d4b;font-size:22px;'
         . 'box-shadow:0 0 22px rgba(255,0,51,.8)}'
         . '#sfy-bw h2{margin:0;font-size:17px;letter-spacing:.12em;color:#ff2d4b;text-transform:uppercase;'
         . 'text-shadow:0 0 14px rgba(255,0,51,.85);animation:sfyBwTitle .8s steps(2,end) infinite}'
         . '@keyframes sfyBwTitle{0%,100%{opacity:1}50%{opacity:.45}}'
         . '#sfy-bw p{margin:10px 0 0;font-size:13px;line-height:1.55;color:#f3c9d2}'
         . '#sfy-bw .sfy-bw-count{margin-top:14px;padding:10px 12px;border:1px solid rgba(255,0,51,.55);'
         . 'border-radius:8px;background:rgba(255,0,51,.12);font-size:12px;letter-spacing:.08em;color:#ffb3c0}'
         . '#sfy-bw .sfy-bw-count b{color:#fff;font-size:16px}'
         . '#sfy-bw .sfy-bw-ban{color:#ff5a73;font-weight:800;text-shadow:0 0 8px rgba(255,0,51,.5)}'
         . '#sfy-bw .sfy-bw-note{color:#c9a6b0;font-size:12px}'
         . '#sfy-bw .sfy-bw-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:18px}'
         . '#sfy-bw .sfy-bw-btn{appearance:none;border:1px solid #ff0033;background:#ff0033;color:#14070b;'
         . 'font:inherit;font-weight:800;letter-spacing:.04em;padding:10px 14px;border-radius:8px;'
         . 'text-decoration:none;cursor:pointer;box-shadow:0 0 18px rgba(255,0,51,.5)}'
         . '#sfy-bw .sfy-bw-ghost{background:transparent;color:#ffb3c0;box-shadow:none}'
         . '#sfy-bw .sfy-bw-btn:hover{filter:brightness(1.12)}'
         . '@media (prefers-reduced-motion:reduce){#sfy-bw,#sfy-bw .sfy-bw-card,#sfy-bw .sfy-bw-siren,'
         . '#sfy-bw h2{animation:none}}';

    return '<style>' . $css . '</style>'
         . '<div id="sfy-bw" role="alertdialog" aria-modal="true" aria-labelledby="sfy-bw-t">'
         . '<div class="sfy-bw-card">'
         . '<div class="sfy-bw-siren" aria-hidden="true"></div>'
         . '<div class="sfy-bw-top"><span class="sfy-bw-icon" aria-hidden="true">⚠</span>'
         . '<h2 id="sfy-bw-t">⚠ Bypass detected</h2></div>'
         . '<p>This run is flagged — a link-skipping service, a replayed landing or a forged task report was seen.</p>'
         . '<div class="sfy-bw-count">ATTEMPT <b>' . $n . '</b> FROM THIS CONNECTION</div>'
         . '<p class="sfy-bw-ban">' . $tail . '</p>'
         . '<p class="sfy-bw-note">If you are a real player, go back to the task and finish it normally. '
         . 'This notice does not remove a code you already earned.</p>'
         . '<div class="sfy-bw-actions">'
         . ($go !== '' ? '<a class="sfy-bw-btn" href="' . sfy_esc($go) . '">BACK TO THE TASK</a>' : '')
         . '<button type="button" class="sfy-bw-btn sfy-bw-ghost" '
         . 'onclick="var m=document.getElementById(\'sfy-bw\');if(m){m.style.display=\'none\';}">I UNDERSTAND</button>'
         . '</div></div></div>'
         /* Fixed positioning must not be trapped by a transformed card
            ancestor: move the overlay to <body> before it is painted. */
         . '<script>(function(){var m=document.getElementById("sfy-bw");'
         . 'if(m&&m.parentNode!==document.body){document.body.appendChild(m);}})();</script>';
}


/**
 * Strict-mode landing check: after 10 s on /done with no provider postback,
 * show a flashing red popup. It does not claim an attempt number; it explains
 * that a bypass landing cannot complete and that the step is still waiting.
 * A flagged session already shows the red modal, so this returns '' there.
 */
function sfy_strict_wait_warning(array $sess): string {
    $rc = sfy_return_check_state();
    if (empty($rc['require_postback'])) return '';
    $st = sfy_bypass_state($sess);
    /* The warning switch controls this popup too, not just the detected modal. */
    if (empty($st['enabled'])) return '';
    if (!empty($st['flagged'])) return '';

    $sid = (string)($sess['session_id'] ?? '');
    $go  = $sid !== '' ? sfy_url('go/' . rawurlencode($sid)) : '';
    /* Grace period: a real postback can still be in flight. Configurable in
       Settings; default 10 s. */
    $delayMs = max(1, min(60, sfy_bypass_opt_int('bypass_warning_delay', 10))) * 1000;
    $warnUrl = $sid !== '' ? sfy_url('api/step.php') . '?a=warn&sid=' . rawurlencode($sid) : '';
    $css = '#sfy-sw{display:none;position:fixed;inset:0;z-index:99998;align-items:center;justify-content:center;'
         . 'padding:18px;background:rgba(4,5,9,.88);-webkit-backdrop-filter:blur(3px);backdrop-filter:blur(3px)}'
         . '#sfy-sw.on{display:flex;animation:sfySwBg .9s steps(2,end) infinite}'
         . '@keyframes sfySwBg{0%,100%{background:rgba(4,5,9,.88)}50%{background:rgba(78,0,12,.64)}}'
         . '#sfy-sw .sfy-sw-card{width:min(560px,100%);background:linear-gradient(180deg,#1a0b10,#12080c);'
         . 'border:1px solid #ff3b5c;border-radius:14px;padding:22px;color:#ffeef2;'
         . 'box-shadow:0 0 0 1px rgba(255,59,92,.6),0 0 30px rgba(255,0,51,.7),0 0 100px rgba(255,0,51,.35);'
         . 'animation:sfySwFlash .8s steps(2,end) infinite}'
         . '@keyframes sfySwFlash{0%,100%{border-color:#ff3b5c;box-shadow:0 0 0 1px rgba(255,59,92,.6),'
         . '0 0 26px rgba(255,0,51,.65),0 0 80px rgba(255,0,51,.3)}50%{border-color:#fff;'
         . 'box-shadow:0 0 0 3px #ff0033,0 0 55px #ff0033,0 0 130px rgba(255,0,51,.75)}}'
         . '#sfy-sw .sfy-sw-siren{height:8px;border-radius:6px;margin:-6px 0 14px;'
         . 'background:repeating-linear-gradient(90deg,#ff0033 0 16px,#2a0008 16px 32px);'
         . 'background-size:32px 8px;animation:sfySwSiren .5s linear infinite;box-shadow:0 0 20px #ff0033}'
         . '@keyframes sfySwSiren{to{background-position:32px 0}}'
         . '#sfy-sw h2{margin:0 0 6px;font-size:17px;letter-spacing:.12em;color:#ff2d4b;text-transform:uppercase;'
         . 'text-shadow:0 0 14px rgba(255,0,51,.85);animation:sfySwTitle .8s steps(2,end) infinite}'
         . '@keyframes sfySwTitle{0%,100%{opacity:1}50%{opacity:.45}}'
         . '#sfy-sw p{margin:10px 0 0;font-size:13px;line-height:1.55;color:#f3c9d2}'
         . '#sfy-sw .sfy-sw-count{margin-top:14px;padding:10px 12px;border:1px solid rgba(255,0,51,.55);'
         . 'border-radius:8px;background:rgba(255,0,51,.12);font-size:12px;letter-spacing:.08em;color:#ffb3c0}'
         . '#sfy-sw .sfy-sw-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:18px}'
         . '#sfy-sw .sfy-sw-btn{appearance:none;border:1px solid #ff0033;background:#ff0033;color:#14070b;'
         . 'font:inherit;font-weight:800;letter-spacing:.04em;padding:10px 14px;border-radius:8px;'
         . 'text-decoration:none;cursor:pointer;box-shadow:0 0 18px rgba(255,0,51,.5)}'
         . '#sfy-sw .sfy-sw-ghost{background:transparent;color:#ffb3c0;box-shadow:none;border-color:#ff3b5c}'
         . '@media (prefers-reduced-motion:reduce){#sfy-sw.on,#sfy-sw .sfy-sw-card,#sfy-sw .sfy-sw-siren,'
         . '#sfy-sw h2{animation:none}}';

    return '<style>' . $css . '</style>'
         . '<div id="sfy-sw" role="alertdialog" aria-modal="true" aria-labelledby="sfy-sw-t">'
         . '<div class="sfy-sw-card">'
         . '<div class="sfy-sw-siren" aria-hidden="true"></div>'
         . '<h2 id="sfy-sw-t">⚠ Bypass warning</h2>'
         . '<p>This verification was not completed normally. If you used a bypass, link-skipping or shortcut '
         . 'service, stop and go back to the task. This page will not release the code.</p>'
         . '<div class="sfy-sw-count">BYPASS ATTEMPT RECORDED</div>'
         . '<p>Repeated attempts are recorded and can lead to a temporary <b>IP ban</b>.</p>'
         . '<div class="sfy-sw-actions">'
         . ($go !== '' ? '<a class="sfy-sw-btn" href="' . sfy_esc($go) . '">BACK TO THE TASK</a>' : '')
         . '<button type="button" class="sfy-sw-btn sfy-sw-ghost" '
         . 'onclick="var m=document.getElementById(\'sfy-sw\');if(m){m.classList.remove(\'on\');document.body.style.overflow=\'\';}">I UNDERSTAND</button>'
         . '</div></div></div>'
         . '<script>(function(){var m=document.getElementById("sfy-sw");if(!m)return;'
         . 'var u=' . json_encode($warnUrl) . ';'
         . 'if(m.parentNode!==document.body){document.body.appendChild(m);}'
         . 'function show(){if(document.body.contains(m)){m.classList.add("on");document.body.style.overflow="hidden";}}'
         . 'setTimeout(function(){if(!document.body.contains(m))return;'
         . 'if(!u){show();return;}'
         . 'fetch(u,{credentials:"same-origin",cache:"no-store"}).catch(function(){}).finally(show);'
         . '},' . $delayMs . ');'
         . '})();</script>';
}

/**
 * Hard block: a flagged run gets no task, no advance and no code.
 *
 * Only called when sfy_bypass_state()['blocked'] is true, so a normal player
 * (or a first, recoverable flag) still sees the notice and can finish.
 */
function sfy_bypass_block_page(array $sess, string $page = 'task'): void {
    $st = sfy_bypass_state($sess);
    if (empty($st['blocked'])) return;

    $page    = $page === 'code' ? 'code' : 'task';
    $n       = (int)$st['attempts'];
    $ipHits  = (int)($st['ip_hits'] ?? 0);
    $ipAfter = max(1, (int)($st['block_after'] ?? 2));
    $ipWin   = max(1, (int)($st['ip_window'] ?? 24));
    $ipBan   = $ipHits >= $ipAfter;
    $lead    = $ipBan
        ? 'This connection has ' . $n . ' flagged attempts in the last ' . $ipWin . ' hours.'
        : 'A bypass attempt was detected on this verification. The code is withheld while this run is reviewed.';
    http_response_code(403);
    sfy_head(['title' => $ipBan ? 'Access cooldown' : 'Verification under review', 'page' => $page, 'noindex' => true]);
    ?>
    <div class="shell">
      <?= sfy_ad_slot('top', $page) ?>
      <div class="card brk" style="--accent:#FF5A73">
        <div class="card-head">
          <h1>&gt; <?= $ipBan ? 'ACCESS_COOLDOWN' : 'VERIFICATION_UNDER_REVIEW' ?></h1>
          <span class="spacer"></span>
          <span class="badge" style="background:#ff3b5c;color:#14070b">BLOCKED</span>
        </div>
        <div class="msg bad"><b>⚠ <?= sfy_esc($lead) ?></b>
          <?= $ipBan ? 'Try again after the cooldown, or contact support if you believe this is a mistake.' : 'The code is withheld while this run is reviewed.' ?></div>
        <div class="term" style="max-height:none">&gt; flagged attempts: <?= (int)$n ?>

&gt; ip cooldown: <?= (int)$ipWin ?>h

&gt; this request cannot advance</div>
        <p class="dim" style="margin:12px 0 0">If you are a real player and believe this is a mistake, contact
          support with the token below. Do not open the landing page directly — finish the task normally and
          return here.</p>
        <div class="hint">Token: <b><?= sfy_esc((string)($sess['token'] ?? '—')) ?></b></div>
        <div class="btn-row mt-2">
          <a class="btn" href="<?= sfy_esc(sfy_url('')) ?>">▶ START WITH A NEW TOKEN</a>
          <a class="btn" href="<?= sfy_esc(sfy_url('tutorial')) ?>">📖 HOW IT WORKS</a>
        </div>
      </div>
      <?= sfy_ad_slot('banner', $page) ?>
      <?= sfy_ad_slot('bottom', $page) ?>
    </div>
    <?= sfy_ad_slot('popup', $page) ?>
    <?php sfy_foot(['page' => $page]); ?>
    <?php exit;
}

/* ── gates ─────────────────────────────────────────────────────────── */
/**
 * Validate a session for a page.
 * @return array{0:?array,1:?array} [session, device]
 */
function sfy_session_gate(string $sid, string $page = 'task'): array {
    if ($sid === '' || !preg_match('/^[a-f0-9]{16,64}$/i', $sid)) {
        sfy_fatal('Invalid link', 'The verification link is malformed. Start again from the Roblox menu.', 400);
    }

    $sess = sfy_load_session($sid);
    if (!$sess) {
        sfy_fatal('Session expired', 'We could not find this verification session. Please start again from the Roblox menu.', 404);
    }

    $device = null;
    $deviceId = (int)($sess['device_id'] ?? 0);
    if ($deviceId > 0) $device = sfy_device_find($deviceId);

    if ($device && (int)$device['is_blocked'] === 1) {
        sfy_fatal('Access blocked', 'This device has been blocked by the administrator.', 403);
    }

    if ((int)($sess['is_completed'] ?? 0) === 1) {
        if ($page === 'task') sfy_redirect(sfy_url('out/' . $sid));
        return [$sess, $device];
    }

    if (sfy_session_is_expired($sess)) {
        sfy_fatal('Session expired',
            'This session timed out before all tasks were finished. Request a new link from the Roblox menu.',
            410, ['retry' => sfy_url('claim/' . urlencode((string)$sess['token']))]);
    }

    /*
     * ── is this the browser that claimed the session? ──────────────────
     *
     * This check was wrong in two ways at once, and together they made it
     * impossible to pass. It compared the raw User-Agent string *verbatim*, so
     * any UA nuance (a Chrome update, an in-app browser) read as "another
     * browser" and answered HTTP 403 "Link locked to another browser" — and
     * then flagged the player's device as a bypass attempt on top of it. And
     * the fingerprint it was meant to compare was computed from client-supplied
     * JSON on the claim page but from the bare request on /go, so those two
     * values could never match either.
     *
     * The identity is now derived from the request alone and is deliberately
     * coarse: browser family + platform, no version numbers, no IP. A mismatch
     * is a *device change*, not an attack — this browser is sent to start its
     * own flow at task 1, which is what a player switching device expects.
     * Nothing is flagged as bypass.
     *
     * ── and it is non-destructive ──────────────────────────────────────
     *
     * The session is **not** closed. It belongs to another device — a phone in
     * the same house, somebody who was sent the link, or the player's own
     * second machine — and that device's progress is not this request's to
     * throw away. Closing it here also meant that merely *opening* a task link
     * on a second device killed the flow running on the first one, mid-task.
     * Ownership decided per request (see sfy_session_belongs_here) is what
     * keeps them apart; nothing has to be destroyed for that.
     */
    if (sfy_cfg('security.enforce_fingerprint', true)) {
        $now  = sfy_flow_identity();
        $then = trim((string)($sess['flow_identity'] ?? ''));
        if ($then !== '' && $now !== '' && !hash_equals($then, $now)) {
            error_log('[SFY] device change on session ' . $sid . ': ' . $then . ' → ' . $now);
            sfy_redirect(sfy_url('claim/' . urlencode((string)$sess['token']) . '?restart=1'));
        }
    }

    return [$sess, $device];
}

/** Can this request read the finished code? (anti-sharing) */
function sfy_code_gate(array $sess): array {
    if ((int)($sess['is_completed'] ?? 0) !== 1) {
        return ['ok' => false, 'reason' => 'incomplete'];
    }

    $ttlMin = sfy_setting_int('code_view_ttl_minutes', 30);
    $doneAt = strtotime((string)($sess['completed_at'] ?? $sess['created_at']));
    if ($ttlMin > 0 && $doneAt && (time() - $doneAt) > $ttlMin * 60) {
        return ['ok' => false, 'reason' => 'expired'];
    }

    $max = sfy_setting_int('max_code_views', 4);
    if ($max > 0 && (int)($sess['code_views'] ?? 0) >= $max) {
        return ['ok' => false, 'reason' => 'too_many_views'];
    }
    return ['ok' => true, 'reason' => 'ok'];
}

function sfy_code_view_log(string $sid, int $deviceId = 0): void {
    try {
        sfy_db()->prepare("UPDATE sfy_sessions
                           SET code_views = code_views + 1,
                               first_seen_code_at = COALESCE(first_seen_code_at, NOW())
                           WHERE session_id=?")->execute([$sid]);
        if ($deviceId > 0) sfy_device_bump($deviceId, 'code_views', 1);
    } catch (Throwable $e) { error_log('[SFY] code view: ' . $e->getMessage()); }
}

/**
 * Record one code open: the token it belongs to, and *who* asked for it.
 *
 * `own_device` is 0 when the request did not come from the device that
 * completed the tasks — the difference between a player reopening their own
 * code and a link being handed around. It is recorded, never punished: the
 * counters are for the admin to read, they are not a gate.
 */
function sfy_code_open_record(array $sess, ?array $device = null, string $ip = ''): void {
    sfy_try(function () use ($sess, $device, $ip): void {
        if (!sfy_table_exists('sfy_code_opens')) return;
        $db   = sfy_db();
        $own  = sfy_code_device_matches($sess, $device) ? 1 : 0;
        $prof = $device ?: [];

        $db->prepare("INSERT INTO sfy_code_opens
                (token, session_id, device_id, device_name, device_type, os, browser, ip, country,
                 timezone, own_device, created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,NOW())")
           ->execute([
               substr((string)($sess['token'] ?? ''), 0, 64),
               substr((string)($sess['session_id'] ?? ''), 0, 64),
               (int)($prof['id'] ?? ($sess['device_id'] ?? 0)),
               substr((string)($prof['device_name'] ?? ($sess['device_name'] ?? '')), 0, 191),
               substr((string)($prof['device_type'] ?? ''), 0, 16),
               substr((string)($prof['os'] ?? ''), 0, 64),
               substr((string)($prof['browser'] ?? ''), 0, 64),
               substr($ip !== '' ? $ip : (string)($prof['ip'] ?? ($sess['user_ip'] ?? '')), 0, 64),
               substr((string)($prof['country'] ?? ($sess['country'] ?? '')), 0, 96),
               substr((string)($prof['timezone'] ?? ''), 0, 100),
               $own,
           ]);
    }, null);
}

/**
 * How much a token's code has actually been used.
 * @return array{opens:int,devices:int,foreign:int,last:?array,first_at:?string}
 */
function sfy_token_code_stats(string $token): array {
    $empty = ['opens' => 0, 'devices' => 0, 'foreign' => 0, 'last' => null, 'first_at' => null];
    if ($token === '') return $empty;

    return sfy_try(function () use ($token, $empty): array {
        if (!sfy_table_exists('sfy_code_opens')) return $empty;
        $db = sfy_db();
        $agg = $db->prepare("SELECT COUNT(*) AS opens,
                                    COUNT(DISTINCT NULLIF(device_id,0)) AS devices,
                                    COALESCE(SUM(own_device=0),0) AS `foreign`,
                                    MIN(created_at) AS first_at
                             FROM sfy_code_opens WHERE token=?");
        $agg->execute([$token]);
        $a = $agg->fetch() ?: [];

        $last = $db->prepare("SELECT * FROM sfy_code_opens WHERE token=? ORDER BY id DESC LIMIT 1");
        $last->execute([$token]);
        $row = $last->fetch() ?: null;

        return [
            'opens'    => (int)($a['opens'] ?? 0),
            'devices'  => (int)($a['devices'] ?? 0),
            'foreign'  => (int)($a['foreign'] ?? 0),
            'first_at' => ($a['first_at'] ?? null) ? (string)$a['first_at'] : null,
            'last'     => is_array($row) ? $row : null,
        ];
    }, $empty);
}

/**
 * The label the admin (and the player) reads for one open row:
 * "Chrome on Windows · Philippines".
 */
function sfy_code_open_where(array $row): string {
    $bits = [];
    $b = trim((string)($row['browser'] ?? ''));
    $o = trim((string)($row['os'] ?? ''));
    if ($b !== '') $bits[] = $b;
    if ($o !== '') $bits[] = $o;
    if (!$bits) $bits[] = trim((string)($row['device_name'] ?? '')) ?: 'unknown device';
    $loc = trim((string)($row['country'] ?? ''));
    return implode(' on ', $bits) . ($loc !== '' ? ' · ' . $loc : '');
}

/* ══════════════════════════════════════════════════════════════════════
   TASK RETURN CHECK
   
   A postback is the strongest possible proof that a task was completed,
   and it stays the primary gate. On a lot of real installs it is also the
   one thing that never arrives (a free host answering the provider with a
   browser challenge, a postback URL built from macros the provider does
   not expand, a delay longer than a human will wait), and the player then
   sits on /done forever while their task really was completed.

   The return check is the safety net: the player must have clicked into
   the task (beacon recorded server-side) and stayed away for at least
   `return_dwell_seconds` before the landing back on /done can stand in
   for the postback. It is recorded distinctly (`provider_return`), never
   counted as a verified postback, and switches itself off the moment a
   real postback starts arriving again — mode `auto`.

   ── who may confirm a return ────────────────────────────────────────

   A safety net is only worth having when it cannot be pulled from the
   outside. It used to be: /done confirmed the step for *any* request that
   arrived after the dwell, so the whole anti-bypass gate came down to
   pasting the landing URL into the address bar — or fetching it from the
   console — with the task page sitting open in the other tab.

   A landing is now only trusted when the request itself says it came from
   the provider: a cross-site *document* navigation (`Sec-Fetch-Site:
   cross-site`, where a typed URL reports `none` and a link on our own
   pages `same-origin`), from a host on the provider list. That verdict is
   recorded in `sfy_step_tokens.returned_at` by /done alone, and
   `sfy_step_advance_soft()` refuses to confirm a step without it — so a
   poll, a console fetch or a shared link can no longer stand in for the
   provider. See `sfy_return_landing_evidence()`.
   ═════════════════════════════════════════════════════════════════ */

/**
 * Hosts whose landing back on /done counts as a return from the provider.
 *
 * Providers move between domains, so the list is editable in
 * Admin → Settings (and `*` accepts any host that is not ours). Matching is
 * by suffix, so `links.lootlabs.gg` is covered by `lootlabs.gg`.
 */
function sfy_return_referrer_hosts(): array {
    $raw = trim((string)sfy_config_get('set_return_referrer_hosts', ''));
    if ($raw === '') {
        $raw = trim((string)sfy_cfg('security.return_referrer_hosts', 'lootlabs.gg,lootlabs.com,loot-link.com'));
    }

    $out = [];
    foreach (preg_split('/[\s,;]+/', strtolower($raw)) ?: [] as $h) {
        $h = trim($h);
        if ($h === '') continue;
        if (str_contains($h, '://')) {
            $p = parse_url($h, PHP_URL_HOST);
            $h = is_string($p) ? $p : '';
        }
        $h = trim(strtolower($h), "./");
        if ($h === '') continue;
        $out[] = $h;
    }

    /*
     * Every offerable task provider contributes its own domains, so adding a
     * provider (Work.ink, or anything pasted in the panel) is enough: its
     * landing page counts as a provider return without a second trip to the
     * security settings. A provider is a known host by definition — this can
     * only ever widen the list to *our* chosen providers.
     */
    if (function_exists('sfy_provider_return_hosts')) {
        foreach (sfy_provider_return_hosts() as $h) {
            $h = trim(strtolower((string)$h), "./");
            if ($h !== '') $out[] = $h;
        }
    }
    return array_values(array_unique($out));
}

/**
 * Hosts a landing is refused from, whatever else the request says.
 *
 * The ticket below is the real gate; this is the cheap, honest second layer.
 * A bypass service that does leak a referrer gets named instead of matching the
 * "cross-site navigation" pattern — and a service that strips it is stopped by
 * the ticket instead. Editable in Admin → Settings → Flow & anti-bypass.
 */
function sfy_return_referrer_blocklist(): array {
    $raw = trim((string)sfy_config_get('set_return_referrer_block', ''));
    if ($raw === '') {
        $raw = trim((string)sfy_cfg('security.return_referrer_block',
            'baconbypass.xyz,bypass.city,bypass.vip,rip.linkvertise.lol,bypass.link,bypass.tools,izen.lol'));
    }

    $out = [];
    foreach (preg_split('/[\s,;]+/', strtolower($raw)) ?: [] as $h) {
        $h = trim($h, " \t./");
        if ($h === '') continue;
        if (str_contains($h, '://')) {
            $p = parse_url($h, PHP_URL_HOST);
            $h = is_string($p) ? strtolower($p) : '';
        }
        if ($h !== '') $out[] = $h;
    }
    return array_values(array_unique($out));
}

/** Is this host on the refusal list? (matched by suffix, like the allow list) */
function sfy_return_host_blocked(string $host): bool {
    $host = strtolower(trim($host));
    if ($host === '') return false;
    foreach (sfy_return_referrer_blocklist() as $h) {
        if ($host === $h || str_ends_with($host, '.' . $h)) return true;
    }
    return false;
}

/** Is this referrer host one we accept a return from? (`*` = any host) */
function sfy_return_host_allowed(string $host): bool {
    $host = strtolower(trim($host));
    if ($host === '') return false;                       // nothing to match against
    $hosts = sfy_return_referrer_hosts();
    if (!$hosts) return true;                             // list cleared = accept any referrer
    foreach ($hosts as $h) {
        if ($h === '*') return true;
        if ($host === $h || str_ends_with($host, '.' . $h)) return true;
    }
    return false;
}

/** Host of a URL (or of a bare host string); '' when there is nothing usable. */
function sfy_return_host_of(string $url): string {
    $url = trim($url);
    if ($url === '' || $url === 'null') return '';
    if (!str_contains($url, '://')) $url = 'https://' . ltrim($url, '/');
    $p = parse_url($url, PHP_URL_HOST);
    return is_string($p) ? strtolower($p) : '';
}

/**
 * Did this request really arrive from the task provider?
 *
 * The browser answers that for us. A landing the provider performed is a
 * cross-site document navigation:
 *
 *   Sec-Fetch-Site: cross-site   ← the provider's page sent the player here
 *   Sec-Fetch-Mode: navigate     ← a document, not an image/fetch ping
 *   Sec-Fetch-Dest: document
 *
 * and neither a URL typed into the address bar (`Sec-Fetch-Site: none`) nor a
 * link or script on one of our own pages (`same-origin`/`same-site`) can
 * produce that. Browsers too old to send the headers fall back to the
 * referrer, which is also why a landing with no referrer at all is still
 * accepted when the navigation itself is cross-site (some providers send
 * `Referrer-Policy: no-referrer`, and privacy extensions strip it).
 *
 * @return array{ok:bool,why:string,source:string,site:string,referer_host:string}
 */
function sfy_return_landing_evidence(array $server = []): array {
    $s = $server ?: $_SERVER;

    $mk = fn(bool $ok, string $why, string $source, string $site, string $refHost): array =>
        ['ok' => $ok, 'why' => $why, 'source' => $source, 'site' => $site, 'referer_host' => $refHost];

    $site = strtolower(trim((string)($s['HTTP_SEC_FETCH_SITE'] ?? '')));
    $mode = strtolower(trim((string)($s['HTTP_SEC_FETCH_MODE'] ?? '')));
    $dest = strtolower(trim((string)($s['HTTP_SEC_FETCH_DEST'] ?? '')));

    $refHost  = sfy_return_host_of((string)($s['HTTP_REFERER'] ?? ''));
    $selfHost = sfy_return_host_of(sfy_url(''));

    /* Only a document navigation can be a landing. */
    if (($mode !== '' && $mode !== 'navigate') || ($dest !== '' && $dest !== 'document')) {
        return $mk(false, 'not_a_navigation', 'sec-fetch', $site, $refHost);
    }

    if ($site !== '') {
        if ($site === 'same-origin' || $site === 'same-site') {
            return $mk(false, 'same_site', 'sec-fetch', $site, $refHost);
        }
        if ($site !== 'cross-site') {
            /* `none` is a typed, pasted or bookmarked URL — the exact bypass
               this gate exists for. */
            return $mk(false, 'typed_url', 'sec-fetch', $site, $refHost);
        }
        if ($refHost !== '' && $selfHost !== '' && $refHost === $selfHost) {
            return $mk(false, 'self_referrer', 'sec-fetch', $site, $refHost);
        }
        if ($refHost !== '' && sfy_return_host_blocked($refHost)) {
            return $mk(false, 'blocked_referrer', 'sec-fetch', $site, $refHost);
        }
        if ($refHost !== '' && !sfy_return_host_allowed($refHost)) {
            return $mk(false, 'unlisted_referrer', 'sec-fetch', $site, $refHost);
        }
        /*
         * Strict mode (opt-in, security.return_require_referrer): refuse a
         * cross-site landing with no referrer at all. Some providers strip
         * the referrer legitimately — LootLabs sends `Referrer-Policy:
         * no-referrer` on its task pages — so this ships off. The return
         * ticket (migration 031) is the real proof: only LootLabs can decrypt
         * the &data= blob that carries it, so a landing with no ticket has
         * already been refused before this point.
         */
        if ($refHost === '' && sfy_return_require_referrer()) {
            return $mk(false, 'no_referrer_required', 'sec-fetch', $site, '');
        }
        return $mk(true, 'cross_site', 'sec-fetch', $site, $refHost);
    }

    /* No Sec-Fetch-* headers at all: the referrer is the only signal left. */
    if ($refHost === '') {
        return $mk(false, 'no_referrer', 'referer', $site, '');
    }
    if ($selfHost !== '' && $refHost === $selfHost) {
        return $mk(false, 'self_referrer', 'referer', $site, $refHost);
    }
    if (sfy_return_host_blocked($refHost)) {
        return $mk(false, 'blocked_referrer', 'referer', $site, $refHost);
    }
    if (!sfy_return_host_allowed($refHost)) {
        return $mk(false, 'unlisted_referrer', 'referer', $site, $refHost);
    }
    return $mk(true, 'referrer', 'referer', $site, $refHost);
}

/** Player-facing sentence for a refused landing (never a dead end). */
function sfy_return_landing_text(string $why): string {
    switch ($why) {
        case 'typed_url':
        case 'no_referrer':
            return 'This page only confirms a task when the task itself sends you here. Open the task with the '
                 . 'button below, finish it, and let it bring you back — do not reopen or type this link by hand.';
        case 'same_site':
            return 'We did not see you leave for the task. Open the task with the button below and come back '
                 . 'through it, not through a link on this site.';
        case 'unlisted_referrer':
            return 'You came back from a page this site does not recognise as the task provider. Open the task '
                 . 'with the button below and let it bring you back here.';
        case 'blocked_referrer':
            return 'This page was reached from a link-skipping service, so the task cannot be counted. Open the task '
                 . 'with the button below and finish it normally to get your code.';
        case 'no_handoff_cookie':
            return 'This page only confirms a task when the browser that opened it is the one that ran the task. '
                 . 'Open the task with the button below and let it bring you back.';
        case 'landing_ip_mismatch':
            return 'That confirmation came from a different connection than the one the task was opened on. '
                 . 'Open the task with the button below and finish it on this connection.';
        case 'ticket_missing':
        case 'ticket_invalid':
            return 'This page only confirms a task when the task itself sends you here. That link did not come from '
                 . 'your task, so nothing was counted — open the task with the button below and let it bring you back.';
        case 'ticket_used':
            return 'That confirmation has already been used. Open the task again with the button below and finish '
                 . 'it once more to get your code.';
        case 'not_a_navigation':
            return 'That request was not a visit to this page. Open the task with the button below and let it '
                 . 'bring you back here.';
        case 'no_provider_return':
            return 'We have no record of you coming back from the task yet. Open the task with the button below, '
                 . 'finish it, and let it send you here on its own.';
        default:
            return 'Confirmation is being retried automatically. You can also press CHECK AGAIN or go back to the task.';
    }
}

function sfy_return_check_state(bool $refresh = false): array {
    static $memo = null;
    if ($memo !== null && !$refresh) return $memo;

    $raw = strtolower(trim((string)sfy_config_get('set_postback_fallback', '')));
    if ($raw === '') $raw = strtolower(trim((string)sfy_cfg('security.postback_fallback', 'auto')));
    if (!in_array($raw, ['auto', 'on', 'off'], true)) $raw = 'auto';

    // When did a real (non-fallback) postback last verify anything?
    $lastOk = sfy_try(function (): int {
        $st = sfy_db()->prepare("SELECT MAX(created_at) AS t FROM sfy_postback_log
                                 WHERE accepted=1 AND (reason IS NULL OR reason<>'provider_return')");
        $st->execute();
        $t = (string)($st->fetch()['t'] ?? '');
        return $t !== '' ? (int)strtotime($t) : 0;
    }, 0);

    $staleH = max(1, (int)sfy_cfg('security.postback_stale_hours', 48));

    /*
     * P0-2 (2026-10-24). "Require a verified postback" used to be a checkbox
     * that only changed a badge on the overview. It is the operator's strongest
     * statement about this flow, so it now switches the return check off: a
     * step may only advance through a postback that passed sfy_postback_verify()
     * (authenticated by the per-account key from P0-1).
     *
     * The return check remains available for providers that have no postback
     * mechanism at all — the operator turns this box off for those.
     */
    $reqPbRaw  = trim((string)sfy_config_get('set_require_postback', ''));
    $requirePb = $reqPbRaw === ''
        ? (bool)sfy_cfg('security.require_postback', true)
        : ($reqPbRaw === '1');

    $active = $requirePb ? false
           : ($raw === 'on'
              || ($raw === 'auto' && ($lastOk === 0 || (time() - $lastOk) > $staleH * 3600)));

    $dwell = (int)sfy_setting('return_dwell_seconds', 45);
    if ($dwell < 15) $dwell = 15;

    /* The provider-landing gate. Only switch it off if the provider cannot be
       recognised at all (no referrer, no Sec-Fetch-* headers) — see
       sfy_return_landing_evidence(). It defaults to ON because a return check
       that any URL visit can satisfy is worth nothing. */
    $req = trim((string)sfy_config_get('set_return_require_provider', ''));
    if ($req === '') $req = sfy_cfg('security.return_require_provider', true) ? '1' : '0';

    /*
     * The per-run return ticket (migration 031).
     *
     * When a step was handed off through LootLabs' encrypted `&data=`
     * destination it carries a one-time ticket, and only a landing that presents
     * it may confirm the step — that is what makes `/done` unreachable by
     * guessing, by a bare redirect, or by replaying a URL somebody copied out of
     * a previous run. Steps handed off *without* a ticket (a plain link,
     * Work.ink, a custom provider) keep the ordinary gates: this switch cannot
     * strand a provider that has no `&data=` mechanism.
     */
    $tick = trim((string)sfy_config_get('set_return_ticket_required', ''));
    if ($tick === '') $tick = sfy_cfg('security.return_ticket_required', true) ? '1' : '0';

    return $memo = ['mode' => $raw, 'active' => $active, 'last_ok' => $lastOk, 'dwell' => $dwell,
                    'stale_h' => $staleH, 'require_provider' => $req === '1',
                    'require_ticket' => $tick === '1', 'require_postback' => $requirePb,
                    'redirect_api' => function_exists('sfy_redirect_api_mode') ? sfy_redirect_api_mode() : 'off'];
}

/* ══════════════════════════════════════════════════════════════════════
   ZERO-TAP FLOW — the next task opens itself

   `/done` never shows a "step confirmed, press to continue" card: a
   confirmed step forwards the player straight into their next task. The
   task page used to answer that with a card whose only affordance was
   OPEN TASK & RETURN, so every step in the chain cost one more press for
   no reason — the handoff it leads to is generated on the server anyway.

   With the zero-tap flow on, the forwarding link carries `zt=1` and the
   task page uses it to hand the player over immediately:

     * the one-time step nonce is still issued for *this* step only,
     * `sfy_step_begin()` stamps the click clock the button's beacon would
       have stamped (the return check refuses a step whose clock never
       started — that gate is untouched),
     * the handoff is logged as an auto-open so the Postback Doctor shows
       how the player arrived,
     * and only then is the browser sent to the provider.

   Nothing about the verification changes: a step still advances through
   the signed postback or the verified provider return, and a hand-typed
   `?zt=1` only skips the card — it cannot complete anything.

   Mode lives in **Admin → Settings → Flow & anti-bypass** (`set_zerotap`,
   shipped ON); `config/config.php` → `security.zerotap` is the fallback
   default. Turn it off to keep the press on every step.

   The hand-off is announced before the browser moves — the card naming the
   task that was just confirmed — and the pause it counts down is
   `set_zerotap_handoff_seconds` (2–15s, shipped 5) in the same card, so the
   player can be given more time to read "task n is done" without slowing the
   flow down harder than the admin asked for.
   ═════════════════════════════════════════════════════════════════ */

/** 'on' = the next task opens itself, 'off' = the player presses the button. */
function sfy_zerotap_mode(): string {
    $raw = strtolower(trim((string)sfy_config_get('set_zerotap', '')));
    if ($raw === '') $raw = strtolower(trim((string)sfy_cfg('security.zerotap', 'on')));
    return in_array($raw, ['0', 'off', 'no', 'false', ''], true) ? 'off' : 'on';
}

function sfy_zerotap_enabled(): bool { return sfy_zerotap_mode() === 'on'; }

/**
 * ═════════════════════════════════════════════════════════════════════
 *   THE HUB IS A DOOR, NOT A PAGE
 *
 *   `/go/<session>` is where the flow decides which network serves the step,
 *   mints the one-time nonce, logs the handoff and stamps the click clock.
 *   All of that has to happen on a request of its own — the whole anti-bypass
 *   chain is built on it — but none of it needs a *screen*: a player who has
 *   just pressed PROCEED on the claim page, or who the provider has just sent
 *   back, is shown a page whose only content is a button asking them to
 *   confirm what they already asked for.
 *
 *   With the pass-through on that page is never rendered. The handoff is
 *   issued exactly as before (same nonce, same log line, same click clock —
 *   `sfy_step_begin()` runs before the browser moves, because the return check
 *   refuses a step whose clock never started) and the browser is then handed
 *   straight to the provider. The page still exists and still does its work:
 *   a step that has already been opened, a choice that is still open, an
 *   exhausted budget, a reset or a direct visit all land on it and are served
 *   normally, and the browser's Back button reaches it too.
 *
 *   Mode lives in **Admin → Settings → Flow & anti-bypass** (`set_hub_pass`,
 *   shipped **ON**); `config/config.php` → `security.hub_pass` is the fallback.
 *   The three flow modes form a ladder, strongest first:
 *
 *     pass-through ON               → straight into the task, no page between
 *     pass-through OFF, zero-tap ON → the TASK COMPLETE card, then the task
 *     both OFF                      → the hand-off card and the task page,
 *                                     each pressed once
 * ═════════════════════════════════════════════════════════════════════
 */
function sfy_hub_pass_mode(): string {
    $raw = strtolower(trim((string)sfy_config_get('set_hub_pass', '')));
    if ($raw === '') $raw = strtolower(trim((string)sfy_cfg('security.hub_pass', 'on')));
    return in_array($raw, ['0', 'off', 'no', 'false', ''], true) ? 'off' : 'on';
}

function sfy_hub_pass(): bool { return sfy_hub_pass_mode() === 'on'; }

/**
 * How long the hand-off card counts down before it follows the next task.
 *
 * Clamped to the range the settings field offers (2–15s): the value only ever
 * delays a handoff that has already been issued, but an unclamped one could
 * either skip the "task n is done" message entirely or stall the chain for as
 * long as whoever posted the form wanted. Anything unreadable falls back to
 * the shipped 5s instead of reaching the card.
 */
function sfy_zerotap_handoff_seconds(): int {
    $raw = sfy_config_get('set_zerotap_handoff_seconds', '');
    if ($raw === null || $raw === '') $raw = sfy_cfg('security.zerotap_handoff_seconds', 5);
    $n = (int)trim((string)$raw);
    if ($n <= 0) $n = 5;
    return max(2, min(15, $n));
}

/**
 * Where a confirmed step sends the player: the next step's own page.
 *
 * From step 2 on, that page is the confirmation card ("mission accomplished"
 * plus the continuation — see sfy_reward_ready_card()), which is what the
 * player is meant to read between two tasks. So the landing page's only job is
 * to get them there; the continuation itself is the card's own button.
 */
function sfy_step_next_url(string $sid): string {
    return sfy_url('go/' . urlencode($sid));
}

/**
 * The continuation the confirmation card's button carries.
 *
 * Flagged with `zt=1` whenever a confirmed step is meant to carry straight on
 * — either the zero-tap flow or the pass-through hub, both of which issue the
 * hand-off and open the task itself instead of rendering another card to
 * press; with both off the same link renders the ordinary task card.
 * Either way it is a plain link, so a blocked script still gets through.
 */
function sfy_task_continue_url(string $sid): string {
    return sfy_step_next_url($sid) . ((sfy_zerotap_enabled() || sfy_hub_pass()) ? '?zt=1' : '');
}

/** The player really opened the task — remember the click moment. */
function sfy_step_mark_clicked(string $sid, string $nonce = ''): bool {
    return (bool)sfy_try(function () use ($sid, $nonce): bool {
        if (!sfy_column_exists('sfy_step_tokens', 'clicked_at')) return false;
        $db = sfy_db();
        if ($nonce !== '') {
            $st = $db->prepare("UPDATE sfy_step_tokens SET clicked_at=COALESCE(clicked_at, NOW())
                                WHERE session_id=? AND nonce=? AND consumed_at IS NULL");
            $st->execute([$sid, $nonce]);
            return $st->rowCount() >= 0;
        }
        $st = $db->prepare("UPDATE sfy_step_tokens SET clicked_at=COALESCE(clicked_at, NOW())
                            WHERE session_id=? AND consumed_at IS NULL ORDER BY step DESC LIMIT 1");
        $st->execute([$sid]);
        return $st->rowCount() >= 0;
    }, false);
}

/**
 * Start this step's clock: the moment the player went into the task.
 *
 * Two callers stamp it — the button's own beacon (`/api/step.php` a=start) and
 * the zero-tap handoff, which opens the task without a tap and therefore has to
 * stamp the same clock server-side. The return check refuses to confirm a step
 * whose clock never started, so the two must stay one implementation.
 */
function sfy_step_begin(string $sid, string $nonce = ''): bool {
    return (bool)sfy_try(function () use ($sid, $nonce): bool {
        if (sfy_column_exists('sfy_sessions', 'step_started_at')) {
            sfy_db()->prepare("UPDATE sfy_sessions SET step_started_at=NOW() WHERE session_id=?")->execute([$sid]);
        }
        return sfy_step_mark_clicked($sid, $nonce);
    }, false);
}

/** The player came back from the task provider. */
function sfy_step_mark_returned(string $sid, int $step): void {
    sfy_try(function () use ($sid, $step) {
        if (!sfy_column_exists('sfy_step_tokens', 'returned_at')) return null;
        sfy_db()->prepare("UPDATE sfy_step_tokens SET returned_at=COALESCE(returned_at, NOW())
                           WHERE session_id=? AND step=? AND consumed_at IS NULL")->execute([$sid, $step]);
        return null;
    }, null);
}

/**
 * Forget the click/return clocks of an open handoff (step 1+; 0 = every step).
 *
 * Called when a handoff is re-issued — after a reset, or for a step whose row
 * was already consumed. Those timestamps belong to the previous attempt, and a
 * stale `returned_at` is exactly what would let the next landing confirm a
 * step the player never went back to.
 */
function sfy_step_clear_clock(string $sid, int $step = 0): void {
    sfy_try(function () use ($sid, $step) {
        $sets = [];
        foreach ([['clicked_at', 'NULL'], ['returned_at', 'NULL'], ['soft_verified', '0'],
                  ['return_ticket', 'NULL'], ['return_ticket_at', 'NULL'],
                  ['return_ticket_used_at', 'NULL']] as [$c, $v]) {
            if (sfy_column_exists('sfy_step_tokens', $c)) $sets[] = $c . '=' . $v;
        }
        if (!$sets) return null;

        $sql    = 'UPDATE sfy_step_tokens SET ' . implode(', ', $sets) . ' WHERE session_id=? AND consumed_at IS NULL';
        $params = [$sid];
        if ($step > 0) { $sql .= ' AND step=?'; $params[] = $step; }
        sfy_db()->prepare($sql)->execute($params);
        return null;
    }, null);
}

/* ══ the per-run return ticket ════════════════════════════════════════

   The destination LootLabs sends the finished task to is not one fixed page
   any more. It is `/done?rt=<ticket>`, where the ticket was minted for this
   step alone and travels ONLY inside the encrypted `&data=` blob — the one
   thing in the whole chain that nobody but LootLabs (and this install) can
   read. So the landing page stops being guessable: a bypass service that used
   to just navigate the player to `/done` has nothing to present, and a URL
   copied out of somebody else's finished run is single-use and worthless.

   These helpers are deliberately narrow: they compare a ticket against the row
   the step already has, and they never mint one (minting happens once, at
   handoff, next to the nonce).
   ═══════════════════════════════════════════════════════════════════ */

/** Does this landing carry the ticket the handoff minted for this step? */
function sfy_return_ticket_ok(array $row, string $ticket): array {
    $stored = trim((string)($row['return_ticket'] ?? ''));
    $ticket = trim($ticket);

    /* Handed off with no ticket (plain link, another provider) — the ordinary
       gates decide, exactly as they did before migration 031. */
    if ($stored === '') return ['ok' => true, 'reason' => 'no_ticket'];

    if ($ticket === '')                       return ['ok' => false, 'reason' => 'ticket_missing'];
    if (!hash_equals($stored, $ticket))        return ['ok' => false, 'reason' => 'ticket_invalid'];
    if (!empty($row['return_ticket_used_at'])) return ['ok' => false, 'reason' => 'ticket_used'];

    return ['ok' => true, 'reason' => 'ticket'];
}

/** The open step a ticket belongs to, or null. Also used by /done to find the
 *  session when the landing arrives without the player's cookie. */
function sfy_return_ticket_step(string $ticket): ?array {
    $ticket = trim($ticket);
    if ($ticket === '' || preg_match('/^[A-Za-z0-9]{16,64}$/', $ticket) !== 1) return null;

    return sfy_try(function () use ($ticket): ?array {
        if (!sfy_column_exists('sfy_step_tokens', 'return_ticket')) return null;
        $st = sfy_db()->prepare("SELECT * FROM sfy_step_tokens WHERE return_ticket=? LIMIT 1");
        $st->execute([$ticket]);
        return $st->fetch() ?: null;
    }, null);
}

/** Burn a ticket: it confirmed a step, so it may never confirm another. */
function sfy_return_ticket_mark_used(int $rowId): void {
    if ($rowId <= 0) return;
    sfy_try(function () use ($rowId) {
        if (!sfy_column_exists('sfy_step_tokens', 'return_ticket_used_at')) return null;
        sfy_db()->prepare("UPDATE sfy_step_tokens SET return_ticket_used_at=NOW() WHERE id=?")->execute([$rowId]);
        return null;
    }, null);
}

/**
 * Present a ticket for this step: validate it AND burn it.
 *
 * Called by /done (and by a provider landing on the task page) at the moment the
 * landing is recorded. Burning it here rather than at confirmation is what lets
 * the dwell run out afterwards: the step remembers "the ticket WAS presented",
 * so the status poll that finishes the confirmation seconds later does not have
 * to carry it again — and a replay of the same URL cannot present it twice.
 *
 * @return array{ok:bool,reason:string}
 */
function sfy_return_ticket_present(array $row, string $ticket): array {
    $r = sfy_return_ticket_ok($row, $ticket);
    if (!empty($r['ok']) && ($r['reason'] ?? '') === 'ticket') {
        sfy_return_ticket_mark_used((int)($row['id'] ?? 0));
    }
    return $r;
}

/* ══ the hand-off cookie (P1-1, 2026-10-24) ═══════════════════════════

   The landing URL is handed to the provider, and a bypass service that resolves
   the destination can hold the same URL — but it cannot make the player's
   browser carry a cookie the player never had, and it cannot set one on this
   domain from its own server. So /go sets one short-lived, HttpOnly cookie for
   the step, and /done refuses a landing that does not present it.

   SameSite=Lax is deliberate: the provider's redirect is a top-level
   cross-site GET, which still sends Lax cookies. A background fetch does not.

   Only steps that carry a return ticket (the LootLabs &data= handoff) are held
   to it; Work.ink and custom providers keep their old gates.
   ═══════════════════════════════════════════════════════════════════ */

function sfy_step_cookie_name(string $sid, int $step): string {
    return 'sfy_rt_' . substr(hash_hmac('sha256', $sid . '|' . $step,
                                        (string)sfy_cfg('app.app_key')), 0, 10);
}

function sfy_step_cookie_set(string $sid, int $step, string $nonce): void {
    if (headers_sent() || $sid === '' || $nonce === '') return;
    $val = substr(hash_hmac('sha256', 'step-cookie|' . $sid . '|' . $step . '|' . $nonce,
                            (string)sfy_cfg('app.app_key')), 0, 40);
    setcookie(sfy_step_cookie_name($sid, $step), $val, [
        'expires'  => time() + 3600,
        'path'     => '/',
        'secure'   => !empty($_SERVER['HTTPS']),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

function sfy_step_cookie_ok(string $sid, int $step, string $nonce): bool {
    $got  = (string)($_COOKIE[sfy_step_cookie_name($sid, $step)] ?? '');
    $want = substr(hash_hmac('sha256', 'step-cookie|' . $sid . '|' . $step . '|' . $nonce,
                             (string)sfy_cfg('app.app_key')), 0, 40);
    return $got !== '' && hash_equals($want, $got);
}

/**
 * Throw a step's ticket away (0 = every step of the session).
 *
 * Called whenever a handoff is re-issued or could not carry the ticket — a
 * stale ticket is one a bypasser may already hold, and a step whose link never
 * delivered one must not be held to it.
 */
function sfy_step_ticket_clear(string $sid, int $step = 0): void {
    if (trim($sid) === '') return;
    sfy_try(function () use ($sid, $step) {
        if (!sfy_column_exists('sfy_step_tokens', 'return_ticket')) return null;
        $sql    = 'UPDATE sfy_step_tokens SET return_ticket=NULL, return_ticket_at=NULL, return_ticket_used_at=NULL'
                . ' WHERE session_id=?';
        $params = [$sid];
        if ($step > 0) { $sql .= ' AND step=?'; $params[] = $step; }
        sfy_db()->prepare($sql)->execute($params);
        return null;
    }, null);
}

/**
 * Admin → Accounts → TEST RETURN TICKET.
 *
 * Proves the mechanism without touching a live step: a ticket is minted, put
 * through the same destination builder a real handoff uses, and read back
 * through the same validator `/done` uses — plus the two answers an owner
 * actually needs ("is migration 031 applied?", "is the gate armed?"). Nothing
 * here writes a row, so it is safe to press at any time.
 *
 * @return array{ok:bool,steps:array<int,array{0:string,1:bool,2:string}>,error:string}
 */
function sfy_return_ticket_selftest(): array {
    $steps = [];
    $add   = function (string $label, bool $ok, string $note = '') use (&$steps): void {
        $steps[] = [$label, $ok, $note];
    };

    $hasCol = (bool)sfy_try(fn() => sfy_column_exists('sfy_step_tokens', 'return_ticket'), false);
    $add('the ticket column exists', $hasCol,
         $hasCol ? '' : 'run Admin → Updater to apply migration 031');

    $state = sfy_return_check_state(true);
    $add('the ticket gate is armed', !empty($state['require_ticket']),
         !empty($state['require_ticket']) ? '' : 'return_ticket_required is switched off');

    $ticket = sfy_nonce();
    $dest   = sfy_redirect_destination(['sid' => 'selftest', 'ticket' => $ticket]);
    $add('the destination carries the ticket', str_contains($dest, 'rt=' . rawurlencode($ticket)), $dest);

    $row = ['id' => 0, 'return_ticket' => $ticket, 'return_ticket_used_at' => null];

    $good = sfy_return_ticket_ok($row, $ticket);
    $add('the right ticket is accepted', !empty($good['ok']), (string)($good['reason'] ?? ''));

    $wrong = sfy_return_ticket_ok($row, sfy_nonce());
    $add('a wrong ticket is refused', empty($wrong['ok']), (string)($wrong['reason'] ?? ''));

    $burned = sfy_return_ticket_ok(
        array_replace($row, ['return_ticket_used_at' => date('c')]), $ticket);
    $add('a burned ticket cannot be replayed', empty($burned['ok']), (string)($burned['reason'] ?? ''));

    $api = function_exists('sfy_redirect_api_mode') ? sfy_redirect_api_mode() : 'off';
    $add('the LootLabs Redirect API is on', $api !== 'off',
         $api === 'off' ? 'the encrypted destination is what carries the ticket' : 'mode ' . $api);

    $ok = true;
    foreach ($steps as $s) if (empty($s[1])) $ok = false;

    return ['ok' => $ok, 'steps' => $steps, 'error' => ''];
}

/** When the player clicked into this step's task (0 = never). */
function sfy_step_click_time(array $row, array $sess): int {
    foreach ([$row['clicked_at'] ?? null, $sess['step_started_at'] ?? null] as $t) {
        $t = is_string($t) ? trim($t) : '';
        if ($t === '' || $t === '0000-00-00 00:00:00') continue;
        $ts = strtotime($t);
        if ($ts) return (int)$ts;
    }
    return 0;
}

/** Log a return-check verification so the admin can tell it apart. */
function sfy_log_return_check(array $row, array $sess, int $dwell, string $why): void {
    sfy_try(function () use ($row, $sess, $dwell, $why) {
        $db   = sfy_db();
        $cols = ['session_id','account_id','step','ip','unique_id','nonce','dwell',
                 'accepted','verified','reason','user_agent','raw_query','created_at'];
        $vals = [
            (string)($sess['session_id'] ?? ''), (int)($row['account_id'] ?? 0), (int)($row['step'] ?? 0),
            sfy_client_ip(), (string)($sess['session_id'] ?? ''), (string)($row['nonce'] ?? ''),
            $dwell, 1, 0, 'provider_return', sfy_user_agent(), 'return_check:' . substr($why, 0, 40),
        ];
        if (sfy_column_exists('sfy_postback_log', 'attribution')) { $cols[] = 'attribution'; $vals[] = 'return'; }
        $marks = [];
        foreach ($cols as $c) $marks[] = $c === 'created_at' ? 'NOW()' : '?';
        $db->prepare('INSERT INTO sfy_postback_log (' . implode(',', $cols) . ') VALUES (' . implode(',', $marks) . ')')
           ->execute($vals);
        return null;
    }, null);
}

/**
 * A landing we refused, so the admin can see it (and tune the host list)
 * instead of wondering why players report "it will not confirm".
 *
 * Deduped to one row a minute per session: a player reloading /done must not
 * be able to fill the log from the outside.
 */
function sfy_log_return_reject(string $sid, array $sess, string $why, string $detail = ''): void {
    sfy_try(function () use ($sid, $sess, $why, $detail) {
        $db = sfy_db();
        $st = $db->prepare("SELECT COUNT(*) AS n FROM sfy_postback_log
                            WHERE session_id=? AND reason='return_rejected'
                              AND created_at > DATE_SUB(NOW(), INTERVAL 60 SECOND)");
        $st->execute([$sid]);
        if ((int)($st->fetch()['n'] ?? 0) > 0) return null;

        $cols = ['session_id','account_id','step','ip','unique_id','dwell',
                 'accepted','verified','reason','user_agent','raw_query','created_at'];
        $vals = [
            $sid, 0, max(1, (int)($sess['current_step'] ?? 1)), sfy_client_ip(), $sid, 0,
            0, 0, 'return_rejected', sfy_user_agent(),
            'return:' . substr($why, 0, 40) . ($detail !== '' ? ':' . substr($detail, 0, 60) : ''),
        ];
        if (sfy_column_exists('sfy_postback_log', 'attribution')) { $cols[] = 'attribution'; $vals[] = 'return'; }
        $marks = [];
        foreach ($cols as $c) $marks[] = $c === 'created_at' ? 'NOW()' : '?';
        $db->prepare('INSERT INTO sfy_postback_log (' . implode(',', $cols) . ') VALUES (' . implode(',', $marks) . ')')
           ->execute($vals);
        return null;
    }, null);
}

/**
 * Credit a finished flow to the device that claimed it.
 * Shared by the postback receiver and the return check so the two paths can
 * never drift apart (or double-count).
 */
function sfy_completion_credit(array $sess, bool $completed): void {
    if (!$completed) return;
    $deviceId = (int)($sess['device_id'] ?? 0);
    if ($deviceId <= 0 && !empty($sess['fingerprint'])) {
        $dev = sfy_device_find_by_key((string)$sess['fingerprint']);
        if ($dev) {
            $deviceId = (int)$dev['id'];
            sfy_device_link_session((string)$sess['session_id'], $deviceId);
        }
    }
    if ($deviceId <= 0) return;

    sfy_device_bump($deviceId, 'success_count', 1, [
        'last_token'      => (string)($sess['token'] ?? ''),
        'last_game_id'    => (string)($sess['game_id'] ?? ''),
        'last_session_id' => (string)($sess['session_id'] ?? ''),
    ]);
    sfy_device_bump($deviceId, 'tokens_used', 1);
}

/**
 * Advance the current step because the player verifiably came back.
 * @return array{ok:bool,reason:string,...}
 */
function sfy_step_advance_soft(string $sid, string $why = 'return', string $ticket = ''): array {
    $state = sfy_return_check_state();
    /* A missing session is reported as such; the postback-only rule is the
       answer for a session that does exist. */
    if (empty($state['require_postback']) && !$state['active']) {
        return ['ok' => false, 'reason' => 'return_check_off'];
    }

    $sess = sfy_load_session($sid);
    if (!$sess) return ['ok' => false, 'reason' => 'not_found'];

    /* Hard block: a flagged run cannot advance through the return check. A
       genuine provider postback (api/hook.php) is the other path and clears the
       flags after it verifies. */
    $by = sfy_bypass_state($sess);
    if (!empty($by['blocked'])) {
        return ['ok' => false, 'reason' => 'bypass_blocked', 'attempts' => (int)$by['attempts']];
    }

    if (!empty($state['require_postback'])) return ['ok' => false, 'reason' => 'postback_required'];
    if (!$state['active']) return ['ok' => false, 'reason' => 'return_check_off'];

    $step  = max(1, (int)($sess['current_step'] ?? 1));
    $total = max(1, (int)($sess['total_steps'] ?? 1));
    if ((int)($sess['is_completed'] ?? 0) === 1 || $step > $total) {
        return ['ok' => true, 'reason' => 'already_done', 'completed' => true, 'new_step' => $step, 'total' => $total];
    }
    if (sfy_session_is_expired($sess)) return ['ok' => false, 'reason' => 'session_expired'];

    $row = sfy_step_open($sid, $step);
    if (!$row) return ['ok' => false, 'reason' => 'no_open_step'];
    if (!empty($row['consumed_at'])) return ['ok' => false, 'reason' => 'step_already_done'];

    /*
     * The per-run ticket, checked FIRST — it is the gate the bypass actually has
     * to beat. A step that was handed off through the encrypted `&data=`
     * destination can only be confirmed by a landing that presents the ticket
     * that handoff minted, and only once. A bare `/done`, a replayed URL and a
     * ticket from another run all stop here, before the landing is even
     * consulted.
     */
    if (!empty($state['require_ticket'])) {
        $stored = trim((string)($row['return_ticket'] ?? ''));
        if ($stored !== '') {
            $presented = !empty($row['return_ticket_used_at']);   // /done already validated + burned it
            $carried   = trim($ticket) !== '' && hash_equals($stored, trim($ticket));
            if (!$presented && !$carried) {
                return ['ok' => false, 'reason' => 'ticket_missing', 'step_token' => $row];
            }
        }
    }

    /*
     * The landing must have been recorded by /done, and /done only records it
     * when the request really is the provider's cross-site navigation (see
     * sfy_return_landing_evidence()). Without this, any later poll of this
     * endpoint — a page left open, a fetch typed into the console — would
     * confirm a step that was never returned from, which is exactly how the
     * gate used to be walked around.
     */
    if (sfy_column_exists('sfy_step_tokens', 'returned_at') && empty($row['returned_at'])) {
        return ['ok' => false, 'reason' => 'no_provider_return'];
    }

    $clicked = sfy_step_click_time($row, $sess);
    if ($clicked <= 0) return ['ok' => false, 'reason' => 'task_never_opened'];
    $waited = time() - $clicked;
    if ($waited < $state['dwell']) {
        return ['ok' => false, 'reason' => 'return_too_fast', 'wait' => $state['dwell'] - $waited, 'dwell' => $state['dwell']];
    }

    $account = sfy_account_find((int)($row['account_id'] ?? 0)) ?? [];
    $out     = sfy_postback_consume($row, $sess, $account, '', sfy_client_ip(), $waited);

    if (empty($out['advanced'])) {
        /* The write did not land. Report it instead of claiming success so the
           page keeps the player on the retry path. */
        sfy_log_return_check($row, $sess, $waited, 'write_failed');
        return ['ok' => false, 'reason' => 'write_failed', 'detail' => (string)($out['errors'][0] ?? '')];
    }

    sfy_try(function () use ($row) {
        if (sfy_column_exists('sfy_step_tokens', 'soft_verified')) {
            sfy_db()->prepare("UPDATE sfy_step_tokens SET soft_verified=1, returned_at=COALESCE(returned_at, NOW())
                               WHERE id=?")->execute([(int)$row['id']]);
        }
        return null;
    }, null);
    /* Single use: the ticket confirmed this step, so it can never confirm
       another — a copied `/done?rt=…` link is worthless after the first hit. */
    sfy_return_ticket_mark_used((int)($row['id'] ?? 0));

    sfy_log_return_check($row, $sess, $waited, $why);
    sfy_try(function () use ($sess, $out) { sfy_completion_credit($sess, (bool)$out['completed']); return null; }, null);

    return ['ok' => true, 'reason' => 'provider_return', 'new_step' => $out['new_step'],
            'total' => $out['total'], 'completed' => (bool)$out['completed'], 'waited' => $waited];
}

/**
 * What should the task / return page do with the next status answer?
 *
 * `$cur` is the step that page is currently *showing*. Reporting "advanced"
 * for a step the page already displays is what made /go/<sid> reload itself
 * forever from step 2 on: the poll saw current_step=2, redirected to /go/<sid>,
 * which rendered step 2 and polled again — a full page load every few seconds
 * with nothing whatsoever happening. A step is only "advanced" when it moved
 * *past* what the client is looking at, and an unknown `$cur` (0) can never
 * invent an advance.
 *
 * @return array{status:string,step:int,total:int,redirect:string}
 */
function sfy_step_status_decision(int $step, int $total, bool $completed, int $cur, string $sid): array {
    $step  = max(1, $step);
    $total = max(1, $total);

    if ($completed || $step > $total) {
        return ['status' => 'completed', 'step' => $step, 'total' => $total,
                'redirect' => sfy_url('out/' . $sid)];
    }
    if ($cur > 0 && $step > $cur) {
        /* The next step's own page — never a flagged continuation: from step 2
           on that page is the confirmation card, and *its* button carries the
           continuation. A flag here would skip the page the player is meant to
           read, which is the whole reason the poll reports an advance. */
        return ['status' => 'advanced', 'step_done' => $cur, 'step' => $step, 'total' => $total,
                'redirect' => sfy_step_next_url($sid)];
    }
    return ['status' => 'pending', 'step' => $step, 'total' => $total, 'redirect' => ''];
}

/**
 * Reset a stuck flow to step 1 without asking the player for a new token.
 * The verification counters are kept (never wiped) so abuse history survives
 * a reset — only the progress and the open handoffs are cleared.
 */
function sfy_session_reset_flow(string $sid): array {
    return sfy_try(function () use ($sid): array {
        $sess = sfy_load_session($sid);
        if (!$sess) return ['ok' => false, 'reason' => 'not_found'];
        if ((int)($sess['is_completed'] ?? 0) === 1) {
            /* Nothing to reset — say where the code is instead of leaving the
               player on a page that can only ever answer "completed". */
            return ['ok' => false, 'reason' => 'already_completed', 'redirect' => sfy_url('out/' . urlencode($sid))];
        }

        $db = sfy_db();
        $db->prepare("UPDATE sfy_step_tokens SET consumed_at=NOW()
                      WHERE session_id=? AND consumed_at IS NULL")->execute([$sid]);
        /* The next /go re-issues step 1; the clocks from this attempt must not
           survive it, or the fresh handoff would look like a provider return
           the player already made. */
        sfy_step_clear_clock($sid, 0);

        /*
         * A reset also hands back the provider budget: the handoffs of the
         * discarded attempt must not keep counting against a provider's
         * "tasks per run" limit, or a player who restarted at task 1 could
         * find the provider they just used no longer on offer.
         */
        sfy_try(function () use ($db, $sid) {
            if (sfy_column_exists('sfy_step_tokens', 'provider_id')) {
                $db->prepare('UPDATE sfy_step_tokens SET provider_id=0 WHERE session_id=?')->execute([$sid]);
            }
            if (sfy_column_exists('sfy_sessions', 'provider_id')) {
                $db->prepare('UPDATE sfy_sessions SET provider_id=0 WHERE session_id=?')->execute([$sid]);
            }
            return null;
        }, null);

        $sets   = ['current_step=1'];
        $params = [];
        if (sfy_column_exists('sfy_sessions', 'step_started_at')) $sets[] = 'step_started_at=NOW()';
        if (sfy_column_exists('sfy_sessions', 'expires_at')) {
            $sets[]   = 'expires_at=' . sfy_sql_now_offset('MINUTE');
            $params[] = max(5, sfy_setting_int('session_ttl_minutes', 30));
        }
        /* Keep bypass_flags across a reset: RESET & START OVER must not launder
           a detected attempt and unlock the run. The device counter also stays. */
        $params[] = $sid;
        $db->prepare('UPDATE sfy_sessions SET ' . implode(', ', $sets) . ' WHERE session_id=?')->execute($params);

        $db->prepare("INSERT INTO sfy_postback_log (session_id, step, accepted, verified, reason, user_agent, raw_query, created_at)
                      VALUES (?,1,0,0,'manual_reset',?,'reset',NOW())")
           ->execute([$sid, sfy_user_agent()]);

        return ['ok' => true, 'session_id' => $sid, 'redirect' => sfy_url('go/' . $sid)];
    }, ['ok' => false, 'reason' => 'error']);
}

/* ── maintenance ───────────────────────────────────────────────────── */
function sfy_purge_stale(): void {
    try {
        $db = sfy_db();
        $db->exec("DELETE FROM sfy_sessions WHERE is_completed=0 AND expires_at < DATE_SUB(NOW(), INTERVAL 3 DAY)");
        $db->exec("DELETE FROM sfy_step_tokens WHERE issued_at < DATE_SUB(NOW(), INTERVAL 7 DAY)");
        $db->exec("DELETE FROM sfy_postback_log WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)");
        $db->exec("DELETE FROM sfy_rate_limits WHERE window_start < DATE_SUB(NOW(), INTERVAL 1 HOUR)");
    } catch (Throwable $e) { error_log('[SFY] purge: ' . $e->getMessage()); }
}

/* ── reporting ─────────────────────────────────────────────────────── */
function sfy_funnel_stats(): array {
    return sfy_try(function (): array {
    $db  = sfy_db();
    $one = fn(string $sql) => (int)$db->query($sql)->fetch()['n'];
    $total     = $one("SELECT COUNT(*) AS n FROM sfy_sessions");
    $completed = $one("SELECT COUNT(*) AS n FROM sfy_sessions WHERE is_completed=1");
    $open      = $one("SELECT COUNT(*) AS n FROM sfy_sessions WHERE is_completed=0 AND expires_at>NOW()");
    $expired   = $one("SELECT COUNT(*) AS n FROM sfy_sessions WHERE is_completed=0 AND expires_at<=NOW()");
    $timedOut  = $one("SELECT COUNT(*) AS n FROM sfy_sessions WHERE bypass_flags > 0");
    $pbOk      = $one("SELECT COUNT(*) AS n FROM sfy_postback_log WHERE accepted=1");
    $pbBad     = $one("SELECT COUNT(*) AS n FROM sfy_postback_log WHERE accepted=0");
    return [
        'total'      => $total,
        'completed'  => $completed,
        'open'       => $open,
        'expired'    => $expired,
        'flagged'    => $timedOut,
        'postbacks'  => $pbOk,
        'postbacks_bad' => $pbBad,
        'rate'       => $total > 0 ? round($completed / $total * 100, 1) : 0.0,
        'drop'       => $total > 0 ? round(($total - $completed - $open) / $total * 100, 1) : 0.0,
    ];
    }, ['total'=>0,'completed'=>0,'open'=>0,'expired'=>0,'flagged'=>0,'postbacks'=>0,
        'postbacks_bad'=>0,'rate'=>0.0,'drop'=>0.0]);
}

function sfy_recent_postbacks(int $limit = 100): array {
    return sfy_try(function () use ($limit): array {
        $st = sfy_db()->prepare("SELECT * FROM sfy_postback_log ORDER BY id DESC LIMIT ?");
        $st->bindValue(1, $limit, PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll();
    }, []);
}

function sfy_sessions_filters(string $search = '', string $filter = '', int $provider = 0): array {
    $w = []; $p = [];
    if ($search !== '') {
        $w[] = "(session_id LIKE ? OR token LIKE ? OR user_ip LIKE ? OR device_name LIKE ? OR country LIKE ?)";
        for ($i = 0; $i < 5; $i++) $p[] = "%$search%";
    }
    switch ($filter) {
        case 'done':    $w[] = "is_completed=1"; break;
        case 'open':    $w[] = "is_completed=0 AND expires_at>NOW()"; break;
        case 'expired': $w[] = "is_completed=0 AND expires_at<=NOW()"; break;
        case 'flagged': $w[] = "bypass_flags>0"; break;
        case 'highrisk': $w[] = "risk_score>=50"; break;
    }
    if ($provider > 0) $w[] = "provider_id=" . (int)$provider;
    return [$w ? ' WHERE ' . implode(' AND ', $w) : '', $p];
}

function sfy_sessions_count(string $search = '', string $filter = '', int $provider = 0): int {
    return (int)sfy_try(function () use ($search, $filter, $provider): int {
        [$where, $p] = sfy_sessions_filters($search, $filter, $provider);
        $st = sfy_db()->prepare('SELECT COUNT(*) AS n FROM sfy_sessions' . $where);
        $st->execute($p);
        return (int)($st->fetch()['n'] ?? 0);
    }, 0);
}

function sfy_sessions_list(string $search = '', string $filter = '', int $limit = 100, int $offset = 0, string $sort = 'new', int $provider = 0): array {
    [$where, $p] = sfy_sessions_filters($search, $filter, $provider);
    $orders = [
        'new' => 'created_at DESC', 'old' => 'created_at ASC',
        'flags' => 'bypass_flags DESC, created_at DESC',
        'risk' => 'risk_score DESC, created_at DESC',
        'expires' => 'expires_at ASC', 'steps' => 'current_step DESC, created_at DESC',
    ];
    $order = $orders[$sort] ?? $orders['new'];
    $sql = 'SELECT * FROM sfy_sessions' . $where . ' ORDER BY ' . $order
         . ' LIMIT ' . max(1, min(200, $limit)) . ' OFFSET ' . max(0, $offset);
    return sfy_try(function () use ($sql, $p): array {
        $st = sfy_db()->prepare($sql);
        $st->execute($p);
        return $st->fetchAll();
    }, []);
}

function sfy_session_detail(string $sid): array {
    return sfy_try(function () use ($sid): array {
        $sess = sfy_load_session($sid);
        if (!$sess) return [];
        $st = sfy_db()->prepare("SELECT * FROM sfy_step_tokens WHERE session_id=? ORDER BY step");
        $st->execute([$sid]);
        $steps = $st->fetchAll();
        $st = sfy_db()->prepare("SELECT * FROM sfy_postback_log WHERE session_id=? ORDER BY id DESC LIMIT 25");
        $st->execute([$sid]);
        $pbs = $st->fetchAll();
        return ['session' => $sess, 'steps' => $steps, 'postbacks' => $pbs,
                'device' => (int)($sess['device_id'] ?? 0) > 0 ? sfy_device_find((int)$sess['device_id']) : null];
    }, []);
}

/**
 * Should a provider landing with no referrer be refused?
 *
 * Ships off. LootLabs sends `Referrer-Policy: no-referrer` on its task pages,
 * so a genuine landing from them arrives with an empty referrer. The return
 * ticket (migration 031) already proves the landing came through their
 * decryption, so the referrer is a secondary signal. Turn on for strict
 * behaviour when you would rather trust the ticket alone.
 */
function sfy_return_require_referrer(): bool {
    $raw = strtolower(trim((string)sfy_config_get('set_return_require_referrer', '')));
    if ($raw === '') return (bool)sfy_cfg('security.return_require_referrer', false);
    return !in_array($raw, ['0', 'off', 'no', 'false'], true);
}
