<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY ULTIMATE — ADVERTISEMENT ENGINE
 *  Ads are managed in the admin panel and rendered into named slots on the
 *  public pages: popup, interstitial, top, bottom, side, banner, float,
 *  sticky (mobile bar). Impressions / clicks / dismissals are tracked.
 * ═══════════════════════════════════════════════════════════════════════
 */

function sfy_ad_placements(): array {
    return [
        'popup'        => 'Popup modal (auto-opens, dismissible)',
        'interstitial' => 'Interstitial gate (must click through)',
        'top'          => 'Top bar (above content)',
        'bottom'       => 'Bottom bar (below content)',
        'side'         => 'Side panel (sticky on desktop, inline on mobile)',
        'banner'       => 'Inline banner card',
        'float'        => 'Floating corner card',
        'sticky'       => 'Mobile sticky bottom bar',
    ];
}

function sfy_ad_pages(): array {
    return [
        'all'      => 'Every page',
        'home'     => 'Landing / home',
        'claim'    => 'Claim page (token check)',
        'task'     => 'Task page',
        'code'     => 'Final code page',
        'tutorial' => 'Tutorial / guide page',
    ];
}

/**
 * Which columns this install actually has on sfy_ads. A half-finished
 * update must never be able to make every ad invisible or every ad save
 * fail — the queries below are built from this list.
 */
function sfy_ad_columns(bool $refresh = false): array {
    static $cols = null;
    if ($cols !== null && !$refresh) return $cols;

    $out = [];
    if (sfy_table_exists('sfy_ads')) {
        foreach (['title','body','image_url','target_url','button_text','placement','pages','theme_color',
                  'is_active','is_dismissible','sort_order','start_at','end_at','max_impressions',
                  'impressions','clicks','dismissals','created_at','updated_at','created_by'] as $c) {
            if (sfy_column_exists('sfy_ads', $c)) $out[] = $c;
        }
        // Only a *real* answer is worth caching: before the updater creates the
        // table the empty result is provisional, so don't memoise it.
        $cols = $out;
    }
    return $out;
}

function sfy_ad_has(string $col): bool { return in_array($col, sfy_ad_columns(), true); }

function sfy_ad_scope_match(array $ad, string $page): bool {
    $scope = trim((string)($ad['pages'] ?? 'all'));
    if ($scope === '' || $scope === 'all') return true;
    $parts = array_map('trim', explode(',', $scope));
    return in_array('all', $parts, true) || in_array($page, $parts, true);
}

function sfy_ad_active_clause(): string {
    $w = [];
    if (sfy_ad_has('is_active')) $w[] = 'is_active=1';
    if (sfy_ad_has('start_at'))  $w[] = '(start_at IS NULL OR start_at <= NOW())';
    if (sfy_ad_has('end_at'))    $w[] = '(end_at IS NULL OR end_at >= NOW())';
    if (sfy_ad_has('max_impressions') && sfy_ad_has('impressions'))
        $w[] = '(max_impressions = 0 OR impressions < max_impressions)';
    return $w ? implode(' AND ', $w) : '1=1';
}

function sfy_ad_find(int $id): ?array {
    return sfy_try(function () use ($id) {
        if (!sfy_table_exists('sfy_ads')) return null;
        $st = sfy_db()->prepare("SELECT * FROM sfy_ads WHERE id=? LIMIT 1");
        $st->execute([$id]);
        return $st->fetch() ?: null;
    }, null);
}

/** All rows, optionally filtered. Used by the admin list. */
function sfy_ads_all(string $search = '', string $placement = ''): array {
    $w = []; $p = [];
    if ($search !== '')   { $w[] = "(title LIKE ? OR body LIKE ? OR target_url LIKE ?)"; $p[] = "%$search%"; $p[] = "%$search%"; $p[] = "%$search%"; }
    if ($placement !== '') { $w[] = "placement=?"; $p[] = $placement; }
    $order = sfy_ad_has('sort_order') ? 'sort_order ASC, id DESC' : 'id DESC';
    $sql = "SELECT * FROM sfy_ads" . ($w ? ' WHERE ' . implode(' AND ', $w) : '')
         . " ORDER BY " . $order;
    return sfy_try(function () use ($sql, $p): array {
        $st = sfy_db()->prepare($sql);
        $st->execute($p);
        return $st->fetchAll();
    }, []);
}

/**
 * Ads to show in one slot on one page.
 * The page filter is applied *before* the per-slot cap, otherwise five ads
 * scoped to another page would silently hide a valid one further down.
 */
function sfy_ads_slot(string $placement, string $page, int $limit = 5): array {
    try {
        if (!sfy_table_exists('sfy_ads')) return [];
        $order = sfy_ad_has('sort_order') ? 'sort_order ASC, id DESC' : 'id DESC';
        $st = sfy_db()->prepare("SELECT * FROM sfy_ads WHERE placement=? AND " . sfy_ad_active_clause()
              . " ORDER BY " . $order . " LIMIT 60");
        $st->execute([$placement]);
        $out = [];
        foreach ($st->fetchAll() as $ad) {
            if (!sfy_ad_scope_match($ad, $page)) continue;
            $out[] = $ad;
            if (count($out) >= $limit) break;
        }
        return $out;
    } catch (Throwable $e) {
        error_log('[SFY] ads slot: ' . $e->getMessage());
        return [];
    }
}

function sfy_ad_track_url(int $id, string $kind): string {
    return sfy_url('api/ad.php?a=' . urlencode($kind) . '&id=' . $id);
}

/* ── markup ────────────────────────────────────────────────────────── */

function sfy_ad_media(array $ad): string {
    $img = trim((string)($ad['image_url'] ?? ''));
    if ($img === '') return '';
    return '<div class="ad-media"><img src="' . sfy_esc($img) . '" alt="" loading="lazy" referrerpolicy="no-referrer"></div>';
}

/**
 * Preview rendering for the admin panel: overlays stay inline so a popup or
 * interstitial ad is actually visible in the editor instead of rendering as
 * a hidden full-screen layer.
 */
function sfy_ad_render_preview(array $ad): string {
    $html = sfy_ad_render($ad, (string)($ad['placement'] ?? 'banner'));
    if (str_contains($html, 'ad-overlay')) {
        $html = str_replace(' hidden>', '>', $html);
        $html = str_replace('class="ad-overlay ', 'class="ad-overlay ad-overlay-inline ', $html);
    }
    return $html;
}

function sfy_ad_cta(array $ad): string {
    $url = trim((string)($ad['target_url'] ?? ''));
    $txt = trim((string)($ad['button_text'] ?? '')) ?: 'Open';
    if ($url === '') return '';
    return '<a class="ad-cta" href="' . sfy_esc($url) . '" target="_blank" rel="noopener nofollow sponsored"'
         . ' data-ad-click="' . (int)$ad['id'] . '">' . sfy_esc($txt) . '</a>';
}

/** One ad rendered for a given slot. */
function sfy_ad_render(array $ad, string $placement): string {
    $id     = (int)($ad['id'] ?? 0);
    $title  = trim((string)($ad['title'] ?? ''));
    $body   = trim((string)($ad['body'] ?? ''));
    $color  = preg_match('/^#[0-9a-fA-F]{3,8}$/', (string)($ad['theme_color'] ?? '')) ? (string)$ad['theme_color'] : '#3BF5D0';
    $dismiss= (int)($ad['is_dismissible'] ?? 0) === 1;
    $pid    = 'ad-' . $placement . '-' . $id;

    $inner = '<div class="ad-tag">SPONSORED</div>'
           . '<div class="ad-body">'
           . ($title !== '' ? '<div class="ad-title">' . sfy_esc($title) . '</div>' : '')
           . ($body  !== '' ? '<div class="ad-text">'  . nl2br(sfy_esc($body)) . '</div>' : '')
           . sfy_ad_cta($ad)
           . '</div>'
           . sfy_ad_media($ad)
           . ($dismiss ? '<button type="button" class="ad-x" data-ad-dismiss="' . $id . '" aria-label="Dismiss">&times;</button>' : '');

    $attrs = ' id="' . $pid . '" data-ad="' . $id . '" data-placement="' . sfy_esc($placement) . '"'
           . ' style="--ad-accent:' . sfy_esc($color) . '"';

    switch ($placement) {
        case 'popup':
            return '<div class="ad-overlay ad-overlay-popup" data-ad-overlay="' . $id . '" hidden>'
                 . '<div class="ad-modal"' . $attrs . '>' . $inner . '</div></div>';
        case 'interstitial':
            return '<div class="ad-overlay ad-overlay-gate" data-ad-gate="' . $id . '" hidden>'
                 . '<div class="ad-modal ad-modal-gate"' . $attrs . '>'
                 . '<div class="ad-gate-note">Continue after checking the sponsor below</div>'
                 . $inner
                 . '<button type="button" class="btn btn-primary ad-continue" data-ad-continue="' . $id . '">CONTINUE &rsaquo;</button>'
                 . '</div></div>';
        case 'top':    return '<div class="ad-bar ad-top"' . $attrs . '>' . $inner . '</div>';
        case 'bottom': return '<div class="ad-bar ad-bottom"' . $attrs . '>' . $inner . '</div>';
        case 'side':   return '<aside class="ad-side"' . $attrs . '>' . $inner . '</aside>';
        case 'float':  return '<div class="ad-float"' . $attrs . '>' . $inner . '</div>';
        case 'sticky': return '<div class="ad-sticky"' . $attrs . '>' . $inner . '</div>';
        case 'banner':
        default:       return '<div class="ad-card"' . $attrs . '>' . $inner . '</div>';
    }
}

/** Entire slot (0..n ads). Returns '' when the slot is empty. */
function sfy_ads_render(string $placement, string $page): string {
    $ads = sfy_ads_slot($placement, $page);
    if (!$ads) return '';
    $html = '';
    foreach ($ads as $ad) $html .= sfy_ad_render($ad, $placement);
    return $html;
}

/** Interaction script + tracker for whichever slots are present on the page. */
function sfy_ads_script(string $page, array $placements): string {
    $have = '';
    foreach ($placements as $p) $have .= "'" . $p . "',";
    return '<script>(function(){
  var PAGE=' . json_encode($page) . ', PLACEMENTS=[' . $have . '];
  function track(id,a){ try{
      var u="' . sfy_url('api/ad.php') . '?a="+a+"&id="+id+"&p="+encodeURIComponent(PAGE);
      if(navigator.sendBeacon){ navigator.sendBeacon(u); } else { fetch(u,{method:"POST",keepalive:true}).catch(function(){}); }
  }catch(e){} }
  function opened(key){ try{ return sessionStorage.getItem("sfy_ad_"+key)==="1"; }catch(e){ return false; } }
  function mark(key){ try{ sessionStorage.setItem("sfy_ad_"+key,"1"); }catch(e){} }

  // impressions
  PLACEMENTS.forEach(function(pl){
    document.querySelectorAll(".ad-card[data-ad],.ad-bar[data-ad],.ad-side[data-ad],.ad-float[data-ad],.ad-sticky[data-ad]").forEach(function(el){
      if(el.getAttribute("data-placement")!==pl) return;
      track(el.getAttribute("data-ad"),"imp");
    });
    document.querySelectorAll(".ad-modal[data-ad]").forEach(function(el){
      if(el.getAttribute("data-placement")===pl) track(el.getAttribute("data-ad"),"imp");
    });
  });

  // The scroll lock lives on <body>: .ad-locked{overflow:hidden} is a body
  // rule, so putting the class on <html> silently did nothing.
  function lock(on){ try{ document.body.classList[on ? "add" : "remove"]("ad-locked"); }catch(e){} }
  function anyOpen(){
    var n=0;
    document.querySelectorAll(".ad-overlay").forEach(function(ov){ if(!ov.hidden) n++; });
    return n>0;
  }

  // popup + interstitial overlays
  document.querySelectorAll(".ad-overlay").forEach(function(ov){
    var box=ov.querySelector(".ad-modal"); if(!box) return;
    var id=box.getAttribute("data-ad"), key=PAGE+"_"+id;
    if(ov.hasAttribute("data-ad-gate")){
      if(opened(key)) return;
      ov.hidden=false; lock(true);
    } else if(!opened(key)){
      setTimeout(function(){ if(!opened(key)){ ov.hidden=false; lock(true); } }, 1400);
    }
  });

  document.addEventListener("click", function(ev){
    var x=ev.target.closest("[data-ad-dismiss]");
    if(x){ var box=x.closest(".ad-modal, .ad-card, .ad-bar, .ad-side, .ad-float, .ad-sticky");
      if(box){ var ov=box.closest(".ad-overlay");
        track(box.getAttribute("data-ad"),"dis");
        if(ov){ mark(PAGE+"_"+box.getAttribute("data-ad")); ov.hidden=true; }
        else { box.style.display="none"; }
        if(!anyOpen()) lock(false);
      } }
    var c=ev.target.closest("[data-ad-continue]");
    if(c){ var box2=c.closest(".ad-modal"), ov2=c.closest(".ad-overlay");
      if(box2) mark(PAGE+"_"+box2.getAttribute("data-ad"));
      if(ov2){ ov2.hidden=true; } if(!anyOpen()) lock(false); }
    var k=ev.target.closest("[data-ad-click]");
    if(k) track(k.getAttribute("data-ad-click"),"click");
  }, true);

  // Escape closes any open overlay, and never leaves the page scroll-locked.
  document.addEventListener("keydown", function(ev){
    if(ev.key !== "Escape") return;
    document.querySelectorAll(".ad-overlay").forEach(function(ov){
      if(ov.hidden) return;
      if(ov.hasAttribute("data-ad-gate")) return;   // the gate must be acknowledged
      var b=ov.querySelector(".ad-modal");
      if(b) mark(PAGE+"_"+b.getAttribute("data-ad"));
      ov.hidden=true;
    });
    if(!anyOpen()) lock(false);
  });
})();</script>';
}

/* ── tracking + stats ──────────────────────────────────────────────── */
function sfy_ad_track(int $id, string $kind): void {
    $col = ['imp' => 'impressions', 'click' => 'clicks', 'dis' => 'dismissals'][$kind] ?? null;
    if ($col === null || !sfy_ad_has($col)) return;
    try {
        sfy_db()->prepare("UPDATE sfy_ads SET `$col` = `$col` + 1 WHERE id=?")->execute([$id]);
    } catch (Throwable $e) { error_log('[SFY] ad track: ' . $e->getMessage()); }
}

function sfy_ads_stats(): array {
    return sfy_try(function (): array {
    if (!sfy_table_exists('sfy_ads')) throw new RuntimeException('no ads table');
    $pick = fn(string $col, string $alias): string => sfy_ad_has($col)
        ? "COALESCE(SUM(`$col`),0) AS $alias" : "0 AS $alias";
    $active = sfy_ad_has('is_active') ? 'SUM(is_active=1)' : '0';
    $r = sfy_db()->query("SELECT COUNT(*) AS total,
                                 $active AS active,
                                 " . $pick('impressions', 'impressions') . ",
                                 " . $pick('clicks', 'clicks') . ",
                                 " . $pick('dismissals', 'dismissals') . "
                          FROM sfy_ads")->fetch() ?: [];
    $imp = (int)($r['impressions'] ?? 0);
    $clk = (int)($r['clicks'] ?? 0);
    return [
        'total'       => (int)($r['total'] ?? 0),
        'active'      => (int)($r['active'] ?? 0),
        'impressions' => $imp,
        'clicks'      => $clk,
        'dismissals'  => (int)($r['dismissals'] ?? 0),
        'ctr'         => $imp > 0 ? round(($clk / $imp) * 100, 2) : 0.0,
    ];
    }, ['total'=>0,'active'=>0,'impressions'=>0,'clicks'=>0,'dismissals'=>0,'ctr'=>0.0]);
}

function sfy_ads_by_placement(): array {
    return sfy_try(function (): array {
        $pick = fn(string $col, string $alias): string => sfy_ad_has($col)
            ? "COALESCE(SUM(`$col`),0) AS $alias" : "0 AS $alias";
        return sfy_db()->query("SELECT placement, COUNT(*) AS n,
                                       " . $pick('impressions', 'impressions') . ",
                                       " . $pick('clicks', 'clicks') . "
                                FROM sfy_ads GROUP BY placement ORDER BY n DESC")->fetchAll();
    }, []);
}
