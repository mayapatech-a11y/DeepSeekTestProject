<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY ULTIMATE — UTILITIES
 *  User-agent intelligence, geo lookup, formatting and settings access.
 * ═══════════════════════════════════════════════════════════════════════
 */

/** Parse a User-Agent into bush-league-but-useful device intelligence. */
function sfy_parse_ua(string $ua): array {
    $ua   = trim($ua);
    $low  = strtolower($ua);
    $os   = 'Unknown';
    $type = 'desktop';

    $osMap = [
        'windows nt 10' => 'Windows 10/11', 'windows nt 6.3' => 'Windows 8.1',
        'windows nt 6.2' => 'Windows 8',    'windows nt 6.1' => 'Windows 7',
        'windows nt 6.0' => 'Windows Vista', 'windows' => 'Windows',
        'iphone' => 'iOS', 'ipad' => 'iPadOS', 'ipod' => 'iOS',
        'android' => 'Android', 'mac os x' => 'macOS', 'macintosh' => 'macOS',
        'cros' => 'ChromeOS', 'linux' => 'Linux', 'ubuntu' => 'Ubuntu',
        'freebsd' => 'FreeBSD', 'x11' => 'Linux',
    ];
    foreach ($osMap as $needle => $label) {
        if (str_contains($low, $needle)) { $os = $label; break; }
    }

    $browser = 'Other';
    $version = '';
    $bMap = [
        'edg/'            => 'Edge',
        'edga/'           => 'Edge',
        'opr/'            => 'Opera',
        'opera'           => 'Opera',
        'samsungbrowser'  => 'Samsung Internet',
        'ucbrowser'       => 'UC Browser',
        'brave'           => 'Brave',
        'vivaldi'         => 'Vivaldi',
        'firefox/'        => 'Firefox',
        'fxios'           => 'Firefox iOS',
        'crios'           => 'Chrome iOS',
        'chrome/'         => 'Chrome',
        'safari/'         => 'Safari',
    ];
    foreach ($bMap as $needle => $label) {
        if (str_contains($low, $needle)) {
            $browser = $label;
            if (preg_match('~' . preg_quote($needle, '~') . '([0-9]+(?:\.[0-9]+){0,3})~i', $ua, $m)) $version = $m[1];
            break;
        }
    }
    // Safari's version lives after "Version/"
    if ($browser === 'Safari' && preg_match('~version/([0-9]+(?:\.[0-9]+){0,3})~i', $ua, $m)) $version = $m[1];

    if (preg_match('/mobile|iphone|ipod|android.*mobile|windows phone/i', $ua))      $type = 'mobile';
    elseif (preg_match('/ipad|tablet|kindle|silk|android(?!.*mobile)/i', $ua))      $type = 'tablet';
    if (preg_match('/bot|crawl|spider|slurp|bingpreview|headless/i', $ua))          $type = 'bot';

    $device = 'Unknown Device';
    if (preg_match('/\((?:[^;()]*;)?\s*([^;()]+?)\s*(?:Build|\)|;)/i', $ua, $m)) {
        $candidate = trim($m[1]);
        if ($candidate !== '' && strlen($candidate) < 60 && !preg_match('/^(linux|android|windows|wow64|u|x11)/i', $candidate)) {
            $device = $candidate;
        }
    }
    if ($device === 'Unknown Device') $device = ucfirst($type) . ' · ' . $os;

    return [
        'os'              => substr($os, 0, 64),
        'browser'         => substr($browser, 0, 64),
        'browser_version' => substr($version, 0, 32),
        'device_type'     => substr($type, 0, 16),
        'device_name'     => substr($device, 0, 128),
    ];
}

/** Country for an IP. Uses Cloudflare's header first, then a cached API call. */
function sfy_geo_country(string $ip, string $fallback = ''): string {
    static $memo = [];

    if (str_contains($ip, '.')) {
        $private = ['10.', '127.', '192.168.', '172.16.', '172.17.', '172.18.', '172.19.',
                    '172.2', '172.30.', '172.31.', '169.254.'];
        foreach ($private as $p) if (str_starts_with($ip, $p)) return $fallback !== '' ? $fallback : 'Local';
    }
    if (isset($memo[$ip])) return $memo[$ip];

    if (!empty($_SERVER['HTTP_CF_IPCOUNTRY'])) {
        $c = strtoupper(substr((string)$_SERVER['HTTP_CF_IPCOUNTRY'], 0, 2));
        if ($c !== 'XX' && $c !== '' && strlen($c) === 2) return $memo[$ip] = sfy_country_name($c);
    }
    if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
        return $memo[$ip] = ($fallback !== '' ? $fallback : 'Unknown');
    }
    if (!function_exists('curl_init')) return $memo[$ip] = ($fallback !== '' ? $fallback : 'Unknown');

    $ch = @curl_init('http://ip-api.com/json/' . rawurlencode($ip) . '?fields=status,countryCode,country');
    if ($ch) {
        @curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 3, CURLOPT_CONNECTTIMEOUT => 2]);
        $resp = @curl_exec($ch);
        @curl_close($ch);
        if ($resp) {
            $d = json_decode($resp, true);
            if (!empty($d['country'])) return $memo[$ip] = substr((string)$d['country'], 0, 96);
            if (!empty($d['countryCode'])) return $memo[$ip] = sfy_country_name((string)$d['countryCode']);
        }
    }
    return $memo[$ip] = ($fallback !== '' ? $fallback : 'Unknown');
}

/** ISO-3166 alpha-2 → readable name (fallback for when only a code is known). */
function sfy_country_name(string $code): string {
    $code = strtoupper($code);
    $map = [
        'US'=>'United States','PH'=>'Philippines','ID'=>'Indonesia','BR'=>'Brazil','IN'=>'India',
        'MX'=>'Mexico','VN'=>'Vietnam','TH'=>'Thailand','MY'=>'Malaysia','SG'=>'Singapore',
        'GB'=>'United Kingdom','CA'=>'Canada','AU'=>'Australia','DE'=>'Germany','FR'=>'France',
        'NL'=>'Netherlands','ES'=>'Spain','IT'=>'Italy','PL'=>'Poland','RO'=>'Romania',
        'TR'=>'Turkey','EG'=>'Egypt','SA'=>'Saudi Arabia','AE'=>'United Arab Emirates',
        'NG'=>'Nigeria','ZA'=>'South Africa','KE'=>'Kenya','AR'=>'Argentina','CL'=>'Chile',
        'CO'=>'Colombia','PE'=>'Peru','JP'=>'Japan','KR'=>'South Korea','CN'=>'China',
        'TW'=>'Taiwan','HK'=>'Hong Kong','RU'=>'Russia','UA'=>'Ukraine','PK'=>'Pakistan',
        'BD'=>'Bangladesh','LK'=>'Sri Lanka','NP'=>'Nepal','KH'=>'Cambodia','MM'=>'Myanmar',
        'JP'=>'Japan','NZ'=>'New Zealand','IE'=>'Ireland','PT'=>'Portugal','GR'=>'Greece',
        'SE'=>'Sweden','NO'=>'Norway','DK'=>'Denmark','FI'=>'Finland','CH'=>'Switzerland',
        'AT'=>'Austria','BE'=>'Belgium','CZ'=>'Czechia','HU'=>'Hungary','IL'=>'Israel',
        'IR'=>'Iran','IQ'=>'Iraq','JO'=>'Jordan','KW'=>'Kuwait','QA'=>'Qatar','OM'=>'Oman',
        'MA'=>'Morocco','DZ'=>'Algeria','TN'=>'Tunisia','GH'=>'Ghana','TZ'=>'Tanzania',
        'UG'=>'Uganda','ET'=>'Ethiopia','BY'=>'Belarus','KZ'=>'Kazakhstan','UZ'=>'Uzbekistan',
    ];
    return $map[$code] ?? ($code !== '' ? $code : 'Unknown');
}

/** Human friendly "3 min ago". */
function sfy_ago(?string $datetime): string {
    if (!$datetime) return '—';
    $ts = strtotime($datetime);
    if ($ts === false) return '—';
    $diff = time() - $ts;
    if ($diff < 0) {
        $fwd = abs($diff);
        if ($fwd < 60) return 'in ' . $fwd . 's';
        if ($fwd < 3600) return 'in ' . round($fwd / 60) . 'm';
        if ($fwd < 86400) return 'in ' . round($fwd / 3600) . 'h';
        return 'in ' . round($fwd / 86400) . 'd';
    }
    if ($diff < 60) return $diff . 's ago';
    if ($diff < 3600) return round($diff / 60) . 'm ago';
    if ($diff < 86400) return round($diff / 3600) . 'h ago';
    if ($diff < 2592000) return round($diff / 86400) . 'd ago';
    return date('M j, Y', $ts);
}

function sfy_short(string $s, int $len = 18): string {
    $s = (string)$s;
    return strlen($s) > $len ? substr($s, 0, $len) . '…' : $s;
}

function sfy_mask_ip(string $ip): string {
    if (str_contains($ip, ':')) {           // IPv6
        $parts = explode(':', $ip);
        return implode(':', array_slice($parts, 0, 3)) . '::/48';
    }
    $p = explode('.', $ip);
    return count($p) === 4 ? $p[0] . '.' . $p[1] . '.' . $p[2] . '.x' : $ip;
}

/* ── error log access (surfaced in Admin → Updater) ────────────────── */
function sfy_log_path(): string { return SFY_ROOT . '/storage/php-errors.log'; }

function sfy_log_tail(int $lines = 80): string {
    $file = sfy_log_path();
    if (!is_file($file) || !is_readable($file)) return '';
    $fh = @fopen($file, 'r');
    if (!$fh) return '';
    $size = (int)filesize($file);
    $read = min(16000, max(1, $size));
    @fseek($fh, max(0, $size - $read));
    $data = (string)fread($fh, $read);
    fclose($fh);
    $rows = array_values(array_filter(explode("\n", str_replace("\r", '', $data)), fn($l) => trim($l) !== ''));
    return implode("\n", array_slice($rows, -max(1, $lines)));
}

function sfy_log_size(): int {
    $file = sfy_log_path();
    return is_file($file) ? (int)filesize($file) : 0;
}

/**
 * Owner-only diagnostic bundle for the postback receiver's ping probe.
 *
 * "The receiver is reachable" is not much help when the flow itself is broken,
 * so the same URL — with ?sfy_key=<app.app_key> — also hands the owner (or the
 * developer they are working with) the server's own evidence:
 *
 *   • the tail of storage/php-errors.log, which holds every crash, every query
 *     a guard swallowed and every transport failure the host recorded;
 *   • the live DDL of the tables the player flow writes to, so the real schema
 *     can be compared with the declared one instead of guessed at;
 *   • @@sql_mode — whether MySQL rejects a bad row or quietly truncates it;
 *   • and, with &probe=1, a real INSERT through sfy_session_insert() (the first
 *     write of every run), followed by its own cleanup. That is the one
 *     statement that starts a verification, so it can be proven — or made to
 *     name its own error — on demand, with no player involved.
 *
 * Without the key this returns [] and nothing about the install is exposed.
 */
function sfy_diag_report(bool $probe = false): array {
    if (!function_exists('sfy_diag_active') || !sfy_diag_active()) return [];

    $out = [
        'error_log' => sfy_log_tail(60),
        'log_size'  => sfy_log_size(),
        'sql_mode'  => sfy_try(fn() => (string)sfy_db()->query('SELECT @@sql_mode')->fetchColumn(), ''),
    ];

    $out['schema'] = sfy_try(function (): array {
        $tables = [];
        foreach (['sfy_sessions', 'sfy_step_tokens', 'sfy_postback_log', 'sfy_devices', 'sfy_captcha_log'] as $t) {
            if (!sfy_table_exists($t)) { $tables[$t] = 'MISSING'; continue; }
            $row = sfy_db()->query('SHOW CREATE TABLE `' . $t . '`')->fetch();
            $tables[$t] = (string)($row['Create Table'] ?? '');
        }
        return $tables;
    }, []);

    if ($probe) {
        try {
            $sid = sfy_session_insert(['token' => 'sfy-diag-probe', 'tasks_required' => 2],
                                      '127.0.0.1', 'SFY diag probe', 'diag', 0);
            sfy_db()->prepare('DELETE FROM sfy_sessions WHERE session_id=?')->execute([$sid]);
            $out['session_insert'] = ['ok' => true, 'note' => 'a run can be created on this install (probe row removed)'];
        } catch (Throwable $e) {
            $out['session_insert'] = [
                'ok'      => false,
                'class'   => get_class($e),
                'message' => $e->getMessage(),
                'at'      => basename($e->getFile()) . ':' . $e->getLine(),
            ];
        }
    }

    return $out;
}

function sfy_log_clear(): void { @file_put_contents(sfy_log_path(), ''); }

/**
 * Run a query block that must never take the panel down: a missing table or
 * column (i.e. a not-yet-applied update) degrades to $default instead.
 */
function sfy_try(callable $fn, $default = null) {
    try {
        return $fn();
    } catch (Throwable $e) {
        error_log('[SFY] degraded query: ' . $e->getMessage());
        return $default;
    }
}

/** Runtime setting: DB value first, then config default, then hard default. */
function sfy_setting(string $key, $hardDefault = null) {
    $fromDb = sfy_config_get('set_' . $key, null);
    if ($fromDb !== null && $fromDb !== '') return $fromDb;
    return sfy_cfg('security.' . $key, $hardDefault);
}
function sfy_setting_int(string $key, int $hardDefault = 0): int {
    return (int)sfy_setting($key, (string)$hardDefault);
}

/** Build a URL on this install. */
function sfy_url(string $path = ''): string {
    return SFY_DOMAIN . ($path === '' ? '' : '/' . ltrim($path, '/'));
}

/** Absolute path for an entry-point include. */
function sfy_page(string $name): string { return SFY_ROOT . '/pages/' . $name . '.php'; }

/** Admin page URL (works whether or not pretty routing is active). */
function sfy_admin_url(array $query = []): string {
    $base = sfy_url('admin/');
    return $query ? $base . '?' . http_build_query($query) : $base;
}
