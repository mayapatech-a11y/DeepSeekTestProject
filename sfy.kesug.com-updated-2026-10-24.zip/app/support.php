<?php
declare(strict_types=1);
/** Support requests + threaded chat. */

function sfy_support_categories(): array {
    return ['game' => 'Game suggestion', 'support' => 'Support', 'bug' => 'Bug report', 'payment' => 'Payment', 'account' => 'Account', 'other' => 'Something else'];
}
function sfy_support_statuses(): array {
    return ['open' => 'Open', 'in_progress' => 'In progress', 'resolved' => 'Resolved', 'closed' => 'Closed'];
}
function sfy_support_status_label(string $s): string {
    return sfy_support_statuses()[$s] ?? ucfirst($s);
}

function sfy_support_ensure(): bool {
    static $done = false;
    if ($done) return true;
    try {
        $db = sfy_db();
        $db->exec("CREATE TABLE IF NOT EXISTS `sfy_support_requests` (
          `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
          `code` VARCHAR(32) NOT NULL,
          `name` VARCHAR(96) NULL,
          `email` VARCHAR(191) NOT NULL,
          `category` VARCHAR(32) NOT NULL DEFAULT 'other',
          `subject` VARCHAR(191) NULL,
          `status` VARCHAR(20) NOT NULL DEFAULT 'open',
          `unread` TINYINT(1) NOT NULL DEFAULT 1,
          `ip` VARCHAR(64) NULL,
          `user_agent` VARCHAR(512) NULL,
          `created_at` DATETIME NULL,
          `updated_at` DATETIME NULL,
          `last_message_at` DATETIME NULL,
          UNIQUE KEY `uniq_support_code` (`code`),
          KEY `idx_support_status` (`status`, `updated_at`),
          KEY `idx_support_email` (`email`),
          KEY `idx_support_unread` (`unread`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $db->exec("CREATE TABLE IF NOT EXISTS `sfy_support_messages` (
          `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
          `request_id` BIGINT NOT NULL,
          `sender` VARCHAR(10) NOT NULL DEFAULT 'user',
          `body` TEXT NOT NULL,
          `ip` VARCHAR(64) NULL,
          `created_at` DATETIME NULL,
          KEY `idx_support_msg_request` (`request_id`, `id`),
          KEY `idx_support_msg_ip` (`ip`, `created_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $done = true;
        return true;
    } catch (Throwable $e) {
        error_log('[SFY] support tables: ' . $e->getMessage());
        return false;
    }
}

function sfy_support_code(): string {
    $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $out = '';
    for ($i = 0; $i < 6; $i++) $out .= $alphabet[random_int(0, strlen($alphabet) - 1)];
    return 'SFY-R-' . $out;
}

/** @return array{ok:bool,code:string,error:string,request:?array} */
function sfy_support_create(array $in): array {
    if (!sfy_support_ensure()) return ['ok' => false, 'code' => '', 'error' => 'The request system is not available right now.', 'request' => null];
    $ip = sfy_client_ip();
    if (!sfy_rate_limit('support_new', 5, 3600, $ip)) {
        return ['ok' => false, 'code' => '', 'error' => 'Too many requests from this connection. Try again later.', 'request' => null];
    }
    $name = substr(trim((string)($in['name'] ?? '')), 0, 96);
    $email = substr(trim((string)($in['email'] ?? '')), 0, 191);
    $category = strtolower(trim((string)($in['category'] ?? 'other')));
    if (!isset(sfy_support_categories()[$category])) $category = 'other';
    $subject = substr(trim((string)($in['subject'] ?? '')), 0, 191);
    $body = substr(trim((string)($in['message'] ?? '')), 0, 3000);
    if ($name === '') return ['ok' => false, 'code' => '', 'error' => 'Tell us your name.', 'request' => null];
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) return ['ok' => false, 'code' => '', 'error' => 'Enter a valid email address so we can reply.', 'request' => null];
    if (strlen($body) < 2) return ['ok' => false, 'code' => '', 'error' => 'Write a little more about your request.', 'request' => null];

    try {
        $db = sfy_db();
        $code = sfy_support_code();
        for ($i = 0; $i < 8; $i++) {
            $st = $db->prepare('SELECT 1 FROM sfy_support_requests WHERE code=? LIMIT 1');
            $st->execute([$code]);
            if (!$st->fetchColumn()) break;
            $code = sfy_support_code();
        }
        $db->prepare("INSERT INTO sfy_support_requests
            (code,name,email,category,subject,status,unread,ip,user_agent,created_at,updated_at,last_message_at)
            VALUES (?,?,?,?,?, 'open',1,?,?,NOW(),NOW(),NOW())")
           ->execute([$code, $name, $email, $category, $subject, $ip, substr(sfy_user_agent(), 0, 512)]);
        $id = (int)$db->lastInsertId();
        $db->prepare('INSERT INTO sfy_support_messages (request_id,sender,body,ip,created_at) VALUES (?,?,?,?,NOW())')
           ->execute([$id, 'user', $body, $ip]);
        return ['ok' => true, 'code' => $code, 'error' => '', 'request' => sfy_support_find_id($id)];
    } catch (Throwable $e) {
        error_log('[SFY] support create: ' . $e->getMessage());
        return ['ok' => false, 'code' => '', 'error' => 'Could not save the request. Try again.', 'request' => null];
    }
}

function sfy_support_find(string $code, string $email): ?array {
    return sfy_try(function () use ($code, $email): ?array {
        $st = sfy_db()->prepare('SELECT * FROM sfy_support_requests WHERE code=? AND LOWER(email)=LOWER(?) LIMIT 1');
        $st->execute([strtoupper(trim($code)), trim($email)]);
        return $st->fetch() ?: null;
    }, null);
}
function sfy_support_find_code(string $code): ?array {
    return sfy_try(function () use ($code): ?array {
        $st = sfy_db()->prepare('SELECT * FROM sfy_support_requests WHERE code=? LIMIT 1');
        $st->execute([strtoupper(trim($code))]);
        return $st->fetch() ?: null;
    }, null);
}
function sfy_support_find_id(int $id): ?array {
    return sfy_try(function () use ($id): ?array {
        $st = sfy_db()->prepare('SELECT * FROM sfy_support_requests WHERE id=? LIMIT 1');
        $st->execute([$id]);
        return $st->fetch() ?: null;
    }, null);
}
function sfy_support_messages(int $id): array {
    return sfy_try(function () use ($id): array {
        $st = sfy_db()->prepare('SELECT * FROM sfy_support_messages WHERE request_id=? ORDER BY id ASC');
        $st->execute([$id]);
        return $st->fetchAll();
    }, []);
}

/** @return array{ok:bool,error:string,wait:int} */
function sfy_support_reply(int $id, string $sender, string $body, string $ip = ''): array {
    $sender = $sender === 'admin' ? 'admin' : 'user';
    $body = trim($body);
    if ($body === '') return ['ok' => false, 'error' => 'Write a message first.', 'wait' => 0];
    if (strlen($body) > 3000) return ['ok' => false, 'error' => 'Message is too long (max 3000 characters).', 'wait' => 0];
    $req = sfy_support_find_id($id);
    if (!$req) return ['ok' => false, 'error' => 'Request not found.', 'wait' => 0];
    $db = sfy_db();
    $ip = $ip !== '' ? $ip : sfy_client_ip();

    if ($sender === 'user') {
        $last = 0;
        $st = $db->prepare("SELECT created_at FROM sfy_support_messages WHERE request_id=? AND sender='user' ORDER BY id DESC LIMIT 1");
        $st->execute([$id]);
        if ($t = $st->fetchColumn()) $last = max($last, (int)strtotime((string)$t));
        if ($ip !== '') {
            $st = $db->prepare("SELECT created_at FROM sfy_support_messages WHERE sender='user' AND ip=? ORDER BY id DESC LIMIT 1");
            $st->execute([$ip]);
            if ($t = $st->fetchColumn()) $last = max($last, (int)strtotime((string)$t));
        }
        $wait = $last > 0 ? 5 - (time() - $last) : 0;
        if ($wait > 0) return ['ok' => false, 'error' => "Please wait {$wait}s before sending another message.", 'wait' => $wait];
        if (!sfy_rate_limit('support_chat', 30, 60, $ip)) return ['ok' => false, 'error' => 'Slow down for a moment.', 'wait' => 5];
    }

    try {
        $db->prepare('INSERT INTO sfy_support_messages (request_id,sender,body,ip,created_at) VALUES (?,?,?,?,NOW())')
           ->execute([$id, $sender, $body, $ip]);
        $db->prepare("UPDATE sfy_support_requests
                         SET last_message_at=NOW(), updated_at=NOW(),
                             unread=IF(?='user',1,0),
                             status=IF(?='user' AND status IN ('resolved','closed'),'open',status)
                       WHERE id=?")->execute([$sender, $sender, $id]);
        return ['ok' => true, 'error' => '', 'wait' => 0];
    } catch (Throwable $e) {
        error_log('[SFY] support reply: ' . $e->getMessage());
        return ['ok' => false, 'error' => 'Could not save the message.', 'wait' => 0];
    }
}

function sfy_support_mark_read(int $id): void {
    sfy_try(function () use ($id): void {
        sfy_db()->prepare('UPDATE sfy_support_requests SET unread=0 WHERE id=?')->execute([$id]);
    }, null);
}
/**
 * Import legacy Hub inbox messages into the main support queue.
 * Matches imported rows by HUB-<id>, so repeated Inbox loads never duplicate.
 */
function sfy_support_import_hub_messages(): int {
    if (!sfy_support_ensure() || !sfy_table_exists('sfy_hub_messages')) return 0;
    $made = 0;
    try {
        $db = sfy_db();
        $rows = $db->query('SELECT * FROM sfy_hub_messages ORDER BY id ASC')->fetchAll();
        $catMap = ['suggestion' => 'game', 'support' => 'support', 'bug' => 'bug', 'other' => 'other'];
        $stMap  = ['new' => 'open', 'read' => 'open', 'replied' => 'in_progress', 'closed' => 'closed'];
        foreach ($rows as $m) {
            $code = 'HUB-' . str_pad((string)(int)$m['id'], 6, '0', STR_PAD_LEFT);
            $st = $db->prepare('SELECT 1 FROM sfy_support_requests WHERE code=? LIMIT 1');
            $st->execute([$code]);
            if ($st->fetchColumn()) continue;

            $kind = (string)($m['kind'] ?? 'other');
            $cat  = $catMap[$kind] ?? 'other';
            $status = $stMap[(string)($m['status'] ?? 'new')] ?? 'open';
            $contact = trim((string)($m['contact'] ?? ''));
            $name = trim((string)($m['name'] ?? ''));
            if ($name === '') $name = 'Hub guest';
            $subject = trim((string)($m['subject'] ?? ''));
            if ($subject === '') $subject = trim((string)($m['game_name'] ?? ''));
            if ($subject === '') $subject = 'Imported Hub message';
            $created = (string)($m['created_at'] ?? '') ?: date('Y-m-d H:i:s');

            $db->prepare("INSERT INTO sfy_support_requests
                (code,name,email,category,subject,status,unread,ip,user_agent,created_at,updated_at,last_message_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)")
               ->execute([$code, substr($name, 0, 96), substr($contact, 0, 191), $cat, substr($subject, 0, 191),
                          $status, ((string)($m['status'] ?? '') === 'new' ? 1 : 0), (string)($m['ip'] ?? ''),
                          (string)($m['user_agent'] ?? ''), $created, (string)($m['updated_at'] ?? $created), $created]);
            $rid = (int)$db->lastInsertId();
            $body = trim((string)($m['message'] ?? ''));
            if ($body === '') $body = '(empty legacy message)';
            $db->prepare('INSERT INTO sfy_support_messages (request_id,sender,body,ip,created_at) VALUES (?,?,?,?,?)')
               ->execute([$rid, 'user', $body, (string)($m['ip'] ?? ''), $created]);
            $made++;
        }
    } catch (Throwable $e) {
        error_log('[SFY] hub inbox import: ' . $e->getMessage());
    }
    return $made;
}

function sfy_support_unread_count(): int {
    return (int)sfy_try(function (): int {
        if (!sfy_table_exists('sfy_support_requests')) return 0;
        return (int)sfy_db()->query('SELECT COUNT(*) AS n FROM sfy_support_requests WHERE unread=1')->fetch()['n'];
    }, 0);
}
function sfy_support_list(array $f = [], int $page = 1, int $per = 20): array {
    return sfy_try(function () use ($f, $page, $per): array {
        $w = []; $p = [];
        if (($f['q'] ?? '') !== '') {
            $w[] = '(code LIKE ? OR name LIKE ? OR email LIKE ? OR subject LIKE ?)';
            for ($i = 0; $i < 4; $i++) $p[] = '%' . $f['q'] . '%';
        }
        if (($f['status'] ?? '') !== '' && isset(sfy_support_statuses()[$f['status']])) { $w[] = 'status=?'; $p[] = $f['status']; }
        if (($f['category'] ?? '') !== '' && isset(sfy_support_categories()[$f['category']])) { $w[] = 'category=?'; $p[] = $f['category']; }
        $orders = ['new' => 'updated_at DESC', 'old' => 'updated_at ASC', 'unread' => 'unread DESC, updated_at DESC', 'code' => 'code ASC'];
        $order = $orders[$f['sort'] ?? 'new'] ?? $orders['new'];
        $where = $w ? ' WHERE ' . implode(' AND ', $w) : '';
        $st = sfy_db()->prepare('SELECT * FROM sfy_support_requests' . $where . ' ORDER BY ' . $order . ' LIMIT ' . max(1, min(100, $per)) . ' OFFSET ' . max(0, ($page - 1) * $per));
        $st->execute($p);
        return $st->fetchAll();
    }, []);
}
function sfy_support_count(array $f = []): int {
    return (int)sfy_try(function () use ($f): int {
        $w = []; $p = [];
        if (($f['q'] ?? '') !== '') {
            $w[] = '(code LIKE ? OR name LIKE ? OR email LIKE ? OR subject LIKE ?)';
            for ($i = 0; $i < 4; $i++) $p[] = '%' . $f['q'] . '%';
        }
        if (($f['status'] ?? '') !== '' && isset(sfy_support_statuses()[$f['status']])) { $w[] = 'status=?'; $p[] = $f['status']; }
        if (($f['category'] ?? '') !== '' && isset(sfy_support_categories()[$f['category']])) { $w[] = 'category=?'; $p[] = $f['category']; }
        $st = sfy_db()->prepare('SELECT COUNT(*) AS n FROM sfy_support_requests' . ($w ? ' WHERE ' . implode(' AND ', $w) : ''));
        $st->execute($p);
        return (int)($st->fetch()['n'] ?? 0);
    }, 0);
}
function sfy_support_stats(): array {
    return (array)sfy_try(function (): array {
        $out = ['total' => 0, 'open' => 0, 'unread' => 0, 'resolved' => 0];
        foreach (sfy_db()->query('SELECT status, COUNT(*) AS n, SUM(unread=1) AS u FROM sfy_support_requests GROUP BY status')->fetchAll() as $r) {
            $out['total'] += (int)$r['n'];
            $out[$r['status']] = (int)$r['n'];
            $out['unread'] += (int)$r['u'];
        }
        return $out;
    }, ['total' => 0, 'open' => 0, 'unread' => 0, 'resolved' => 0]);
}
function sfy_support_update_status(int $id, string $status): bool {
    if (!isset(sfy_support_statuses()[$status])) return false;
    return (bool)sfy_try(function () use ($id, $status): bool {
        sfy_db()->prepare('UPDATE sfy_support_requests SET status=?, unread=0, updated_at=NOW() WHERE id=?')->execute([$status, $id]);
        return true;
    }, false);
}
function sfy_support_delete(int $id): void {
    sfy_try(function () use ($id): void {
        $db = sfy_db();
        $db->prepare('DELETE FROM sfy_support_messages WHERE request_id=?')->execute([$id]);
        $db->prepare('DELETE FROM sfy_support_requests WHERE id=?')->execute([$id]);
    }, null);
}
