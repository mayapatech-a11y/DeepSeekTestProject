<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY ULTIMATE — LAYOUT / PARTIALS
 *  One header, one footer, one ad pipeline for every public page.
 * ═══════════════════════════════════════════════════════════════════════
 */

function sfy_asset(string $path): string {
    $file = SFY_ROOT . '/' . ltrim($path, '/');
    $v    = is_file($file) ? substr((string)filemtime($file), -6) : SFY_VERSION;
    return sfy_url($path) . '?v=' . $v;
}

function sfy_page_title(string $title = ''): string {
    return $title === '' ? SFY_APP_NAME : $title . ' — ' . SFY_APP_NAME;
}

/* ── hub module bridge ────────────────────────────────────────────────
   SFY HUB — the scripts / games / premium-keys module — is a self-contained
   add-on: it has its own folder, its own tables and its own control panel.
   All the main site owes it is a *link*, which is what these helpers build.

   The link is conditional on the folder really being there, so a site that
   never installs the hub (or removes it later) shows no dead entry, and
   nothing else in this file depends on the module existing. The hub's own
   pages load this file through app/core.php, which is why sfy_hub_url() is
   defined here rather than there: one definition, both sides.
   ──────────────────────────────────────────────────────────────────── */

/** Is the hub module present in this install? */
function sfy_hub_live(): bool {
    static $live = null;
    if ($live === null) {
        $live = is_file(SFY_ROOT . '/hub/index.php') && is_dir(SFY_ROOT . '/hub/lib');
    }
    return $live;
}

/** A URL inside the hub. `$page` is the hub route, e.g. 'offers' | 'contact'. */
function sfy_hub_url(string $page = '', array $q = []): string {
    $url = sfy_url('hub/');
    if ($page !== '') $q = array_merge(['p' => $page], $q);
    return $q ? $url . '?' . http_build_query($q) : $url;
}

/** The hub's own control panel (same staff sign-in as the main panel). */
function sfy_hub_admin_url(array $q = []): string {
    $url = sfy_url('hub/admin/');
    return $q ? $url . '?' . http_build_query($q) : $url;
}

/** Extra footer entries the hub contributes ([] when it is not installed). */
function sfy_hub_footer_links(): array {
    if (!sfy_hub_live()) return [];
    return [
        ['label' => 'Scripts', 'url' => sfy_hub_url()],
        ['label' => 'Premium', 'url' => sfy_url('pricing')],
    ];
}

/**
 * Live-preview mode: an admin views a page with *unsaved* design / layout /
 * footer drafts applied. Never available to the public.
 */
function sfy_is_preview(): bool {
    if (sfy_param('preview') !== '1') return false;
    return !empty($_SESSION['sfy_admin']);
}

/** The appearance array a page should render with (draft in preview mode). */
function sfy_active_appearance(): array {
    if (sfy_is_preview()) {
        $d = sfy_appearance_draft();
        if ($d !== null) return $d;
    }
    return sfy_appearance();
}

/** Render an ad slot and remember that the placement was used. */
function sfy_ad_slot(string $placement, string $page): string {
    $html = sfy_ads_render($placement, $page);
    if ($html !== '') $GLOBALS['SFY_AD_USED'][$placement] = true;
    return $html;
}
function sfy_ad_used_slots(): array { return array_keys($GLOBALS['SFY_AD_USED'] ?? []); }

/**
 * <head> + opening chrome.
 * @param array $o title, page, wide, body_class, noindex, head, status, minimal
 */
function sfy_head(array $o = []): void {
    $page    = (string)($o['page'] ?? 'home');
    $wide    = !empty($o['wide']);
    $minimal = !empty($o['minimal']);
    $status  = $o['status'] ?? 'ONLINE';
    $app     = sfy_active_appearance();
    $scheme  = (string)(sfy_design_presets()[$app['preset']]['scheme'] ?? 'dark');
    $appCls  = 'appearance' . (sfy_is_preview() ? ' preview-mode' : '');
    $bodyCls = trim($appCls . ' ' . sfy_appearance_classes($app) . ' page page-' . $page . ' '
                     . (string)($o['body_class'] ?? '') . ($wide ? ' wide' : ''));
    ?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="color-scheme" content="<?= $scheme === 'light' ? 'light' : 'dark' ?>">
<meta name="theme-color" content="<?= sfy_esc((string)(sfy_design_presets()[$app['preset']]['swatch'][0] ?? '#171e2e')) ?>">
<?php if (!empty($o['noindex'])): ?><meta name="robots" content="noindex,nofollow"><?php endif; ?>
<title><?= sfy_esc(sfy_page_title((string)($o['title'] ?? ''))) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<?php
$sfyFonts  = sfy_design_fonts();
$sfyFamily = 'family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;600;700';
if (!empty($sfyFonts[$app['font_ui']]['google'])) $sfyFamily .= '&family=' . $sfyFonts[$app['font_ui']]['google'];
?>
<link href="https://fonts.googleapis.com/css2?<?= $sfyFamily ?>&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= sfy_esc(sfy_asset('assets/theme.css')) ?>">
<style id="sfy-appearance"><?= sfy_appearance_css($app) ?></style>
<?php if (sfy_is_preview()): ?><base target="_self"><?php endif; ?>
<link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='%2338D9B0'/><stop offset='0.55' stop-color='%237BA2F0'/><stop offset='1' stop-color='%23A08CFF'/></linearGradient></defs><rect width='32' height='32' rx='8' fill='%23171e2e'/><path d='M8 20h16M8 12h16' stroke='url(%23g)' stroke-width='3.4' stroke-linecap='round'/></svg>">
<?= (string)($o['head'] ?? '') ?>
</head>
<body class="<?= sfy_esc($bodyCls) ?>">
<div class="fx-grid" aria-hidden="true"></div>
<div class="fx-scan" aria-hidden="true"></div>
<?php if (sfy_is_preview()): ?>
  <div class="preview-flag">◉ LIVE PREVIEW — draft settings, nothing saved yet</div>
<?php endif; ?>
<?php if (!$minimal): ?>
<header class="site-head">
  <div class="inner">
    <a class="brand" href="<?= sfy_esc(sfy_url('')) ?>">
      <span>&gt;<?= sfy_esc(strtoupper(str_replace(' ', '_', SFY_APP_NAME))) ?></span><span class="v">v<?= sfy_esc(SFY_VERSION) ?></span>
    </a>
    <div class="head-right">
      <?php if (sfy_hub_live()): ?>
        <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_hub_url()) ?>">⌗ Scripts</a>
        <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_url('pricing')) ?>">⚡ Premium</a>
      <?php endif; ?>
      <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_url('support')) ?>">✉ Support</a>
      <span class="dot"></span>
      <span class="mono"><?= sfy_esc($status) ?></span>
      <?php if (!empty($o['user'])): ?>
        <span class="mono"><?= sfy_esc((string)$o['user']) ?></span>
        <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_admin_url(['logout' => 1])) ?>">Logout</a>
      <?php endif; ?>
    </div>
  </div>
</header>
<?php endif;
}

/**
 * The footer is database-driven: the admin can rename, re-point, hide,
 * reorder or delete every link, drop the Admin entry entirely, or switch
 * the whole footer off.
 */
function sfy_footer_html(): string {
    $f = sfy_footer_config(sfy_is_preview());
    if (empty($f['enabled'])) return '';

    $links = '';
    foreach ($f['links'] as $l) {
        if (empty($l['enabled'])) continue;
        if (empty($l['new_tab']) && $l['url'] === '@discord'
            && (string)sfy_config_get('set_support_discord', '') === '') continue;
        // The Admin entry is governed by the dedicated switch as well as its
        // own enabled flag — hiding it in Settings is enough.
        if (str_starts_with(ltrim((string)$l['url'], '/'), 'admin')
            && empty($f['show_admin'])) continue;
        if (ltrim((string)$l['url'], '/') === 'tutorial'
            && (string)sfy_config_get('set_tutorial_enabled', '1') !== '1') continue;
        $url = sfy_footer_link_url((string)$l['url']);
        if ($url === '') continue;
        $links .= '<a href="' . sfy_esc($url) . '"'
                . (!empty($l['new_tab']) ? ' target="_blank" rel="noopener"' : '') . '>'
                . sfy_esc((string)$l['label']) . '</a>';
    }

    /* The hub module contributes its own two entries. They are appended — not
       stored in the footer settings — so a site that installs or removes the
       hub gets the right footer without anyone editing a link list. */
    foreach (sfy_hub_footer_links() as $hl) {
        $links .= '<a href="' . sfy_esc((string)$hl['url']) . '">' . sfy_esc((string)$hl['label']) . '</a>';
    }

    $copy = trim((string)$f['copyright']);
    if ($copy !== '') {
        $copy = str_replace(['{year}', '{site}'], [date('Y'), SFY_APP_NAME], $copy);
        $copy = sfy_esc($copy);
    } else {
        $copy = '&copy; ' . date('Y') . ' ' . sfy_esc(SFY_APP_NAME);
    }
    if (trim((string)$f['tagline']) !== '') $copy .= ' // ' . sfy_esc((string)$f['tagline']);

    return '<footer class="site-foot">'
         . ($links !== '' ? '<nav class="foot-links">' . $links . '</nav>' : '')
         . '<div class="foot-copy">' . $copy . '</div>'
         . '</footer>';
}

function sfy_foot(array $o = []): void {
    $page = (string)($o['page'] ?? 'home');
    /* A page inside the flow hands the bar its own next action (see
       sfy_pinned_fab): the task page passes the very handoff link its button
       uses, so "continue" is the same button in two places rather than two
       different answers. Pages with nothing to declare pass nothing. */
    $pinned = is_array($o['pinned'] ?? null) ? $o['pinned'] : null;
    $slots = sfy_ad_used_slots();
    if ($slots) echo sfy_ads_script($page, $slots);
    /* The admin shell has its own chrome and must not inherit the public
       footer, pinned bar or shop links. */
    $isAdmin = str_starts_with($page, 'admin');
    ?>
<script><?= sfy_device_fingerprint_js(); ?></script>
<script><?= sfy_device_client_js(); ?></script>
<?php if (!$isAdmin): ?>
<?= sfy_pinned_fab($page, $pinned) ?>
<?= sfy_footer_html() ?>
<?php endif; ?>
<?= (string)($o['foot'] ?? '') ?>
</body>
</html>
<?php
}

/**
 * The visitor's own verification — unfinished, or finished with the code still
 * open — or null.
 *
 * Deliberately cheap and strict. The pinned button is on *every* page, so this
 * reads the session cookie (or the PHP session behind it) only — no address
 * fallback, because "somebody on this network has a session" is exactly the
 * confusion the resolver stopped making. And it must belong to this device, so
 * a cookie restored or synced onto another machine cannot put a flow that is
 * not ours behind the button. Anything unexpected degrades to null, i.e. to
 * the guide link, never to a fatal on a public page.
 *
 * A *finished* session is kept: "show me my code again" is the one action left
 * once the tasks are done. Only an unfinished one has an expiry to respect —
 * the code keeps its own window instead (see sfy_code_offer).
 */
function sfy_pinned_session(): ?array {
    if (!function_exists('sfy_get_session_cookie') || !function_exists('sfy_load_session')) return null;
    try {
        $sid = sfy_get_session_cookie();
        if (!$sid) return null;
        $s = sfy_load_session((string)$sid);
        if (!$s) return null;
        if ((int)($s['is_completed'] ?? 0) !== 1
            && function_exists('sfy_session_is_expired') && sfy_session_is_expired($s)) return null;
        if (function_exists('sfy_session_belongs_here') && !sfy_session_belongs_here($s)) return null;
        return $s;
    } catch (Throwable $e) {
        return null;
    }
}

/**
 * Is the finished code still available to this device, and how much of it is
 * left? Null when there is nothing to offer.
 *
 * This mirrors the gate the code page itself applies — completed, inside the
 * view window, under the view cap (`sfy_code_gate()`) — so the pinned button
 * can never point at a page whose only answer is "code expired" or "view limit
 * reached". The note is what the visitor gets to see before tapping: how many
 * displays are left and how long the window has to run, either part dropped
 * when that limit is off (a `0` window or cap means unlimited).
 */
function sfy_code_offer(array $sess, int $now = 0): ?array {
    if ((int)($sess['is_completed'] ?? 0) !== 1) return null;
    if (!function_exists('sfy_code_gate')) return null;

    $gate = sfy_code_gate($sess);
    if (empty($gate['ok'])) return null;

    $now = $now ?: time();
    $ttl = sfy_setting_int('code_view_ttl_minutes', 30);
    $max = sfy_setting_int('max_code_views', 4);
    $bits = [];
    $words = [];

    if ($max > 0) {
        $left    = max(0, $max - (int)($sess['code_views'] ?? 0));
        $bits[]  = $left . ' LEFT';
        $words[] = $left . ' view' . ($left === 1 ? '' : 's') . ' left';
    }
    if ($ttl > 0) {
        $doneAt  = strtotime((string)($sess['completed_at'] ?? $sess['created_at'] ?? '')) ?: $now;
        $mins    = max(0, (int)ceil((($doneAt + $ttl * 60) - $now) / 60));
        $bits[]  = $mins . ' MIN';
        $words[] = $mins . ' minute' . ($mins === 1 ? '' : 's') . ' left';
    }

    return ['note' => implode(' · ', $bits), 'said' => implode(', ', $words)];
}

/**
 * The shipped wording of the pinned button, one entry per state.
 *
 * Editable in Admin → Settings → GUIDE_AND_PREMIUM (`pinned_label_*`). These
 * are what a blank field falls back to, and what a fresh install seeds.
 */
function sfy_pinned_labels(): array {
    return [
        'continue' => 'CONTINUE TASK {step}/{total}',
        'code'     => 'SHOW MY CODE',
        'guide'    => 'HOW TO GET TOKEN',
    ];
}

/**
 * Collapse a label to one line and cut it at 48 characters, UTF-8 safely.
 *
 * mbstring is not guaranteed on shared hosting (this project never leans on
 * it), so the cut is done with a UTF-8 pattern rather than mb_substr. Called on
 * everything that reaches the bar, including a label a page supplies itself.
 */
function sfy_pinned_clean(string $label): string {
    $label = trim((string)preg_replace('/\s+/u', ' ', $label));
    if (preg_match('//u', $label) === 1) {
        $label = (string)preg_replace('/^(.{0,48}).*$/us', '$1', $label);
    } else {
        $label = substr($label, 0, 48);
    }
    return trim($label);
}

/**
 * One pinned-button label, read from Settings and rendered for a step.
 *
 * `{step}` and `{total}` are substituted *after* the setting is read, so the
 * numbers can sit wherever the site owner wants them — or be left out — in
 * their own words. The result is collapsed to a single line and clamped to 48
 * characters: this is a fixed bar pinned over the bottom of a phone screen, and
 * a paste with newlines in it would eat the page it is pinned over. A blank
 * setting means "use the shipped wording".
 */
function sfy_pinned_label(string $state, int $step = 1, int $total = 1): string {
    $labels  = sfy_pinned_labels();
    $default = (string)($labels[$state] ?? '');
    $label   = function_exists('sfy_setting_text')
             ? sfy_setting_text('pinned_label_' . $state, $default)
             : (string)sfy_config_get('set_pinned_label_' . $state, $default);

    $label = sfy_pinned_clean(str_replace(['{step}', '{total}'], [(string)$step, (string)$total], $label));
    return $label !== '' ? $label : $default;
}

/**
 * Where the pinned button points, for a given session (a decision, not markup:
 * the caller escapes the label on the way out).
 *
 * The button is the visitor's *next action*, in priority order:
 *
 *   1. a flow still running on this device → **▶ CONTINUE TASK n/N**, straight
 *      back into /go/<session>, the same action the card asks for, reachable
 *      with a thumb without scrolling to it;
 *   2. a flow that finished and whose code is still open → **📄 SHOW MY CODE**
 *      back to /out/<session>, with what is left of the window and the view cap
 *      spelled out ("3 LEFT · 24 MIN") — the code used to be reachable only
 *      while that tab stayed open, so a player who closed it had to find the
 *      link again;
 *   3. otherwise → the guide link, because with nothing to continue — outside
 *      the flow — "how do I get a token" is the only useful thing left to offer.
 *
 * `$codeIsHere` says the request *is* the code page: linking there from there
 * would only spend another display of the view cap, so the offer is skipped and
 * the guide link takes its place (an unfinished session still continues).
 *
 * `$pinned` is a page that knows its own next action — the task page hands over
 * the very handoff link its card renders — and it wins over everything above.
 * That is the "linked copy of the continue button" case: inside the flow the bar
 * carries the same URL as the page's own button, which also covers a task link
 * opened where no claim cookie exists (an in-app browser, a second device), by
 * far the most common place the bar used to fall back to the guide.
 */
function sfy_pinned_target(?array $sess, int $now = 0, bool $codeIsHere = false, ?array $pinned = null): array {
    $now = $now ?: time();
    $sid = $sess ? (string)($sess['session_id'] ?? '') : '';

    if ($pinned !== null && trim((string)($pinned['url'] ?? '')) !== '') {
        $kindRaw = (string)($pinned['kind'] ?? 'task');
        $kind    = in_array($kindRaw, ['task', 'code', 'guide'], true) ? $kindRaw : 'task';
        $step  = max(1, (int)($pinned['step'] ?? 1));
        $total = max(1, (int)($pinned['total'] ?? $step));
        $own   = trim((string)($pinned['label'] ?? ''));
        /* `kind` is the *variant* (what the bar is doing), the setting keys are
           named per state: a task bar borrows the continue wording. */
        $state = $kind === 'guide' ? 'guide' : ($kind === 'code' ? 'code' : 'continue');
        return [
            'kind'   => $kind,
            'url'    => trim((string)$pinned['url']),
            'icon'   => (string)($pinned['icon'] ?? '▶'),
            'note'   => '',
            'aria'   => (string)($pinned['aria'] ?? ('Continue task ' . $step . ' of ' . $total)),
            'label'  => $own !== '' ? sfy_pinned_clean($own)
                                    : sfy_pinned_label($state, $step, $total),
            'beacon' => ['sid' => (string)($pinned['sid'] ?? ''), 'nonce' => (string)($pinned['nonce'] ?? '')],
        ];
    }

    if ($sid !== '' && (int)($sess['is_completed'] ?? 0) !== 1) {
        $step  = max(1, (int)($sess['current_step'] ?? 1));
        $total = max(1, (int)($sess['total_steps'] ?? $step));
        return ['kind' => 'task', 'url' => sfy_url('go/' . $sid), 'icon' => '▶', 'note' => '',
                'aria' => 'Continue task ' . $step . ' of ' . $total,
                'label' => sfy_pinned_label('continue', $step, $total)];
    }

    $offer = ($sid !== '' && !$codeIsHere) ? sfy_code_offer((array)$sess, $now) : null;
    if ($offer !== null) {
        return ['kind' => 'code', 'url' => sfy_url('out/' . $sid), 'icon' => '📄',
                'note' => (string)$offer['note'],
                'aria' => 'Show my access code' . ((string)$offer['said'] !== '' ? ' — ' . $offer['said'] : ''),
                'label' => sfy_pinned_label('code')];
    }

    return ['kind' => 'guide', 'url' => sfy_url('tutorial'), 'icon' => '📖', 'note' => '',
            'aria' => 'Open the step-by-step guide', 'label' => sfy_pinned_label('guide')];
}

/**
 * Register the page's primary action for the pinned bar.
 *
 * A page whose own button says OPEN TASK & RETURN must not have a bar that says
 * something else — two answers to "what do I do next" is how a player opens the
 * wrong thing. So the page declares the action it renders and the *same* string
 * and URL are used for the button and for the bar: one label, defined once,
 * rendered twice. The first declaration in a request wins, which is what makes
 * it safe to call from a partial (the homepage hero) as well as from a page.
 *
 * The label is deliberately optional: without one the bar falls back to its own
 * wording from Settings (`pinned_label_*`), which is what the states the bar
 * derives by itself — a cookie-known flow, an open code — keep using.
 */
function sfy_pin_action(?array $action = null): ?array {
    static $cur = null;
    if (is_array($action) && $cur === null && trim((string)($action['url'] ?? '')) !== '') {
        $cur = $action;
    }
    return $cur;
}

/**
 * The mobile-only button pinned to the bottom of the screen.
 *
 * It never appears inside the admin panel or on the guide page itself, and the
 * whole button is switched off in Admin → GUIDE_AND_PREMIUM (a sticky ad is
 * lifted above it there so the two never overlap).
 */
function sfy_pinned_fab(string $page, ?array $pinned = null): string {
    if ($page === 'tutorial' || $page === 'admin') return '';
    if ((string)sfy_config_get('set_tutorial_fab', '1') !== '1') return '';

    /* An action handed in by sfy_foot() wins, then whatever the page registered
       with sfy_pin_action(), then the states derived from the session. */
    if ($pinned === null) $pinned = sfy_pin_action();

    $t = sfy_pinned_target(sfy_pinned_session(), 0, $page === 'code', $pinned);

    /* The guide link additionally needs the guide page to exist; the task and
       code links do not — a live flow and an open code are both worth getting
       back to even with the guide off. */
    if ($t['kind'] === 'guide' && (string)sfy_config_get('set_tutorial_enabled', '1') !== '1') return '';

    $note   = (string)($t['note'] ?? '');
    $beacon = (array)($t['beacon'] ?? []);

    /* When the bar is a copy of the task page's own button it has to stamp the
       same click clock that button stamps — a return that never had a clock
       started is refused by the return check. The id and the data-* pair are
       what the task page's delegated listener looks for. */
    $attrs = (string)($beacon['nonce'] ?? '') !== ''
           ? ' id="sfy-open-task-fab" data-sid="' . sfy_esc((string)($beacon['sid'] ?? '')) . '"'
             . ' data-nonce="' . sfy_esc((string)$beacon['nonce']) . '"'
           : '';

    return '<a class="tut-fab tut-fab-' . $t['kind'] . '" href="' . sfy_esc((string)$t['url']) . '"' . $attrs
         . ' aria-label="' . sfy_esc((string)$t['aria']) . '" title="' . sfy_esc((string)$t['aria']) . '">'
         . '<span class="ic">' . $t['icon'] . '</span> ' . sfy_esc((string)$t['label'])
         . ($note !== '' ? ' <span class="sub">' . sfy_esc($note) . '</span>' : '')
         . '</a>';
}

/* ── small components ──────────────────────────────────────────────── */
function sfy_badge(string $text, string $class = 'gr'): string {
    return '<span class="badge ' . sfy_esc($class) . '">' . sfy_esc($text) . '</span>';
}

function sfy_kpi(string $label, $value, string $class = '', string $sub = ''): string {
    return '<div class="kpi ' . sfy_esc($class) . '"><div class="lbl">' . sfy_esc($label) . '</div>'
         . '<div class="val">' . sfy_esc((string)$value) . '</div>'
         . ($sub !== '' ? '<div class="sub">' . sfy_esc($sub) . '</div>' : '') . '</div>';
}

function sfy_progress(int $step, int $total, string $label = ''): string {
    $total = max(1, $total);
    $pct   = min(100, (int)round(($step - 1) / $total * 100));
    return '<div class="bar-wrap"><div class="bar grow"><i style="width:' . $pct . '%"></i></div>'
         . '<span class="pct">' . $pct . '%</span></div>'
         . ($label !== '' ? '<div class="hint">' . sfy_esc($label) . '</div>' : '');
}

/**
 * The 1..N step strip.
 *
 * No player-facing page prints it any more: the strip spelled out the task
 * count on the page a run starts from, and the count is the one number that
 * makes somebody weighing a task stop and leave. The flow says *what* is
 * happening (“mission accomplished”, “your task”) and never *how much of it is
 * left*; see the flow section of the README. It stays here — and stays tested —
 * because the admin panel and a site owner's custom HTML may still want it.
 */
function sfy_steps(int $current, int $total, string $sid = ''): string {
    $out = '<div class="steps">';
    for ($i = 1; $i <= max(1, $total); $i++) {
        $cls = $i < $current ? 'done' : ($i === $current ? 'active' : '');
        $out .= '<div class="step ' . $cls . '">'
              . '<div class="n">STEP ' . $i . '/' . $total . '</div>'
              . '<div class="t">' . ($i < $current ? '✓ verified' : ($i === $current ? '› in progress' : 'pending')) . '</div>'
              . '</div>';
    }
    return $out . '</div>';
}

/** Colored percentage bar row used in the admin tables. */
function sfy_mini_bar(int $value, int $max, string $tone = ''): string {
    $max = max(1, $max);
    $w   = max(2, min(100, (int)round($value / $max * 100)));
    return '<span class="bar ' . sfy_esc($tone) . '" style="display:inline-block;width:120px;vertical-align:middle">'
         . '<i style="width:' . $w . '%"></i></span>';
}
