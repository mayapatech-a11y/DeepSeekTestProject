<?php
declare(strict_types=1);
/** Save the pricing editor payload. Returns [ok, message]. */
function sfy_pricing_save_post(array $post): array {
    $plans = [];
    foreach ((array)($post['plan_name'] ?? []) as $i => $name) {
        $name = trim((string)$name);
        if ($name === '' || !empty($post['plan_delete'][$i])) continue;
        $id = preg_replace('/[^a-z0-9_-]/', '', strtolower(trim((string)($post['plan_id'][$i] ?? ''))));
        if ($id === '') $id = 'plan-' . substr(sha1($name . microtime()), 0, 8);
        $period = strtolower(trim((string)($post['plan_period'][$i] ?? 'instant')));
        if (!isset(sfy_pricing_periods()[$period])) $period = 'instant';
        $plans[] = [
            'id' => $id,
            'period' => $period,
            'name' => substr($name, 0, 60),
            'days' => max(0, min(3650, (int)($post['plan_days'][$i] ?? 0))),
            'price' => is_numeric($post['plan_price'][$i] ?? '') ? (string)(float)$post['plan_price'][$i] : '0',
            'savings' => is_numeric($post['plan_savings'][$i] ?? '') ? (string)(float)$post['plan_savings'][$i] : '',
            'note' => substr(trim((string)($post['plan_note'][$i] ?? '')), 0, 180),
            'featured' => !empty($post['plan_featured'][$i]) ? 1 : 0,
            'enabled' => !empty($post['plan_enabled'][$i]) ? 1 : 0,
        ];
    }
    $payments = [];
    foreach ((array)($post['pay_label'] ?? []) as $i => $label) {
        $label = trim((string)$label);
        if ($label === '') continue;
        $id = preg_replace('/[^a-z0-9_-]/', '', strtolower(trim((string)($post['pay_id'][$i] ?? ''))));
        if ($id === '') $id = 'pay-' . substr(sha1($label . microtime()), 0, 8);
        $payments[] = [
            'id' => $id,
            'label' => substr($label, 0, 50),
            'url' => trim((string)($post['pay_url'][$i] ?? '')),
            'note' => substr(trim((string)($post['pay_note'][$i] ?? '')), 0, 140),
        ];
    }

    $title = substr(trim((string)($post['pricing_title'] ?? 'Choose your access')), 0, 80);
    $intro = substr(trim((string)($post['pricing_intro'] ?? '')), 0, 200);

    try {
        $db = sfy_db();

        /* Plans: one row each. Replace the set so deletes and hides stick. */
        if (sfy_table_exists('sfy_pricing_plans')) {
            $keep = [];
            $order = 0;
            $up = $db->prepare('REPLACE INTO sfy_pricing_plans
                (id,period,name,days,price,savings,note,featured,enabled,sort_order,updated_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,NOW())');
            foreach ($plans as $p) {
                $up->execute([
                    $p['id'], $p['period'], $p['name'], (int)$p['days'],
                    (float)$p['price'], ($p['savings'] === '' ? null : (float)$p['savings']),
                    $p['note'], (int)$p['featured'], (int)$p['enabled'], $order++,
                ]);
                $keep[$p['id']] = true;
            }
            $existing = $db->query('SELECT id FROM sfy_pricing_plans')->fetchAll();
            $del = $db->prepare('DELETE FROM sfy_pricing_plans WHERE id=?');
            foreach ($existing as $row) {
                if (!isset($keep[(string)$row['id']])) $del->execute([(string)$row['id']]);
            }
            if ($keep === []) {
                $db->exec('DELETE FROM sfy_pricing_plans');
            }
        }

        /* Title, intro and payment methods stay in the small JSON blob. */
        $meta = json_encode([
            'version' => 3,
            'title' => $title,
            'intro' => $intro,
            'payments' => $payments,
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if ($meta === false) return [false, 'Could not encode the settings: ' . json_last_error_msg()];
        sfy_config_set('set_pricing_json', $meta);

        sfy_config_set('set_pricing_enabled', !empty($post['pricing_enabled']) ? '1' : '0');
    } catch (Throwable $e) {
        error_log('[SFY] pricing save: ' . $e->getMessage());
        return [false, 'Database error while saving plans: ' . $e->getMessage()];
    }

    return [true, 'Plans and payment methods saved.'];
}
