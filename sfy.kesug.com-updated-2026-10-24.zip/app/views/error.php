<?php
/**
 * Themed error page. Rendered from inside sfy_fatal():
 *   $title, $detail, $code, $opts (optional 'retry', 'hint')
 */
$code   = (int)($code ?? 500);
$title  = (string)($title ?? 'Something went wrong');
$detail = (string)($detail ?? '');
$opts   = is_array($opts ?? null) ? $opts : [];

$tone = $code >= 500 ? 'red' : ($code >= 400 ? 'gold' : 'neon');
$page = 'error';

if (!function_exists('sfy_head')) {   // ultra-early failure safety net
    header('Content-Type: text/html; charset=utf-8');
    echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>' . htmlspecialchars($title) . '</title></head>'
       . '<body style="background:#202a68;color:#FFFFFF;font-family:monospace;padding:40px">'
       . '<h1 style="color:#FF7D8F">' . htmlspecialchars($title) . '</h1><p>' . htmlspecialchars($detail) . '</p></body></html>';
    return;
}

sfy_head(['title' => $title, 'page' => $page, 'noindex' => true]);
?>
<div class="shell">
  <?= sfy_ad_slot('top', $page) ?>
  <div class="card brk" style="--accent:<?= $tone === 'red' ? '#FF7D8F' : ($tone === 'gold' ? '#FFCB3D' : '#3BF5D0') ?>">
    <div class="card-head">
      <h1>&gt; <?= sfy_esc(strtoupper($title)) ?></h1>
      <span class="spacer"></span>
      <span class="badge <?= $code >= 500 ? 'r' : 'y' ?>">HTTP <?= $code ?></span>
    </div>
    <div class="term mono" style="max-height:none">
<div class="line">request halted</div>
<div class="line">reason: <?= sfy_esc($title) ?></div>
<?php if ($detail !== ''): ?><div class="line">detail: <?= sfy_esc($detail) ?></div><?php endif; ?>
<?php if (!empty($opts['ref'])): ?><div class="line">ref: <span class="mono"><?= sfy_esc((string)$opts['ref']) ?><?= !empty($opts['cls']) ? ' &middot; ' . sfy_esc((string)$opts['cls']) : '' ?></span> &mdash; send this to support</div><?php endif; ?>
<div class="line warn">action: restart the flow from the Roblox menu</div>
    </div>

    <div class="btn-row mt-2">
      <?php if (!empty($opts['retry'])): ?>
        <a class="btn btn-primary" href="<?= sfy_esc((string)$opts['retry']) ?>">↻ RETRY THIS STEP</a>
      <?php endif; ?>
      <?php if (!empty($opts['admin'])): ?>
        <a class="btn btn-gold" href="<?= sfy_esc(sfy_admin_url(['tab' => 'updater'])) ?>">⚙ OPEN UPDATER</a>
      <?php endif; ?>
      <a class="btn" href="<?= sfy_esc(sfy_url('')) ?>">← HOME</a>
      <?php if ($d = (string)sfy_config_get('set_support_discord', '')): ?>
        <a class="btn btn-gold" href="<?= sfy_esc($d) ?>" target="_blank" rel="noopener">GET HELP</a>
      <?php endif; ?>
    </div>

    <?php if (!empty($opts['hint'])): ?>
      <div class="hint mt-2"><?= sfy_esc((string)$opts['hint']) ?></div>
    <?php endif; ?>
  </div>
  <?= sfy_ad_slot('banner', $page) ?>
  <?= sfy_ad_slot('bottom', $page) ?>
</div>
<?php sfy_foot(['page' => $page]); ?>
