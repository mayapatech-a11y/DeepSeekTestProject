<?php
declare(strict_types=1);
/**
 * Postback relay pull (2026-10-24).
 *
 * InfinityFree answers an external server-to-server GET with a JavaScript
 * challenge, so LootLabs' postback cannot reach api/hook.php directly. A small
 * public relay (Cloudflare Worker) receives it instead; this file pulls the
 * stored events outbound and replays each query through the site's own
 * /api/hook.php. The loopback comes from the server's own IP, which the host
 * does not challenge (the installer's "server-to-server callback" self-test
 * proves this).
 *
 * Config:
 *   security.relay_pull_url  full URL incl. the pull secret, e.g.
 *                            https://sfy-relay.example.workers.dev/pull?secret=...
 *                            Empty = relay disabled.
 *   security.relay_timeout   seconds (default 4).
 *
 * The relay's /hook URL goes into the LootLabs account's postback URL; the app
 * appends &key=... to it exactly like a normal postback.
 */

/** Resolve a host over DoH JSON; returns an IPv4 or '' when the host still
 *  cannot be resolved. Used only for the relay pull host, never the loopback. */
function sfy_relay_doh_ip(string $host, int $timeout = 4): string {
    $doh = trim((string)sfy_cfg('security.relay_doh_url', 'https://cloudflare-dns.com/dns-query'));
    if ($host === '' || $doh === '') return '';
    $url = $doh . (str_contains($doh, '?') ? '&' : '?') . 'name=' . rawurlencode($host) . '&type=A';
    $body = false;

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => max(2, min(8, $timeout)),
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_HTTPHEADER     => ['accept: application/dns-json'],
            CURLOPT_USERAGENT      => 'SFY-relay-doh/1.0',
        ]);
        $body = curl_exec($ch);
        curl_close($ch);
    } else {
        $ctx = stream_context_create(['http' => [
            'timeout' => max(2, min(8, $timeout)), 'ignore_errors' => true,
            'header' => "accept: application/dns-json\r\n", 'user_agent' => 'SFY-relay-doh/1.0',
        ]]);
        $body = @file_get_contents($url, false, $ctx);
    }

    if (!is_string($body) || $body === '') return '';
    $j = json_decode($body, true);
    if (!is_array($j) || empty($j['Answer']) || !is_array($j['Answer'])) return '';
    foreach ($j['Answer'] as $a) {
        $ip = (string)($a['data'] ?? '');
        if ((int)($a['type'] ?? 0) === 1 && filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            return $ip;
        }
    }
    return '';
}

function sfy_relay_http(string $url, int $timeout = 4, bool $doh = false): array {
    $timeout = max(1, min(15, $timeout));
    $body = false;
    $code = 0;
    $err  = '';

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_CONNECTTIMEOUT => min(8, $timeout),
            CURLOPT_USERAGENT      => 'SFY-relay/1.0',
        ]);
        /* Some free hosts cannot resolve workers.dev even though the rest of
           the internet can. Resolve the pull host over DoH and pin it with
           CURLOPT_RESOLVE; the site's own loopback does not need this. */
        if ($doh) {
            $host = (string)parse_url($url, PHP_URL_HOST);
            if ($host !== '' && !filter_var($host, FILTER_VALIDATE_IP)) {
                $sys = @gethostbyname($host);
                if ($sys === $host) {
                    $ip = sfy_relay_doh_ip($host, $timeout);
                    $port = (int)(parse_url($url, PHP_URL_PORT) ?: 443);
                    if ($ip !== '') {
                        curl_setopt($ch, CURLOPT_RESOLVE, [$host . ':' . $port . ':' . $ip]);
                    } elseif (defined('CURLOPT_DOH_URL')) {
                        $dohUrl = trim((string)sfy_cfg('security.relay_doh_url', 'https://cloudflare-dns.com/dns-query'));
                        if ($dohUrl !== '') curl_setopt($ch, CURLOPT_DOH_URL, $dohUrl);
                    }
                }
            }
        }
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($body === false) $err = (string)curl_error($ch);
        curl_close($ch);
    } else {
        $ctx = stream_context_create(['http' => [
            'timeout' => $timeout, 'ignore_errors' => true, 'user_agent' => 'SFY-relay/1.0',
        ]]);
        $body = @file_get_contents($url, false, $ctx);
        if ($body === false) $err = 'request failed';
        if (!empty($http_response_header[0]) && preg_match('~\s(\d{3})\s~', (string)$http_response_header[0], $m)) {
            $code = (int)$m[1];
        }
    }

    return ['ok' => $body !== false, 'body' => is_string($body) ? $body : '', 'code' => $code, 'error' => $err];
}

/** Relay option: panel (set_*) first, then config, then default. */
function sfy_relay_opt(string $key, string $default = ''): string {
    $v = sfy_config_get('set_' . $key, null);
    if ($v === null) return (string)sfy_cfg('security.' . $key, $default);
    /* An explicitly saved empty pull URL must disable the relay, not fall back
       to a config value. Other keys keep the config fallback. */
    if ($key === 'relay_pull_url') return trim((string)$v);
    if ($v === '') return (string)sfy_cfg('security.' . $key, $default);
    return (string)$v;
}

/**
 * Pull pending relay events and replay each through /api/hook.php.
 * Throttled to one network pull every 2 seconds; safe to call from the
 * /done and /api/step pollers.
 *
 * @return array{ok:bool,reason?:string,pulled?:int,processed?:int,results?:array}
 */
function sfy_relay_pull(int $limit = 20): array {
    $url = trim(sfy_relay_opt('relay_pull_url', ''));
    if ($url === '') return ['ok' => false, 'reason' => 'relay_off'];
    $timeout = max(2, min(15, (int)sfy_relay_opt('relay_timeout', '4')));

    $lock = SFY_ROOT . '/storage/relay-pull.lock';
    $last = @filemtime($lock);
    if ($last !== false && (time() - $last) < 2) return ['ok' => true, 'reason' => 'throttled'];
    @touch($lock);

    $sep = str_contains($url, '?') ? '&' : '?';
    $res = sfy_relay_http($url . $sep . 'limit=' . max(1, min(50, $limit)), $timeout, true);
    if (empty($res['ok'])) {
        error_log('[SFY] relay pull failed: ' . $res['error']);
        return ['ok' => false, 'reason' => 'pull_failed', 'error' => $res['error']];
    }

    $json = json_decode((string)$res['body'], true);
    if (!is_array($json) || !isset($json['events']) || !is_array($json['events'])) {
        error_log('[SFY] relay pull: bad payload (' . substr((string)$res['body'], 0, 120) . ')');
        return ['ok' => false, 'reason' => 'bad_payload'];
    }

    $hook = sfy_url('api/hook.php');
    $results = [];
    foreach ($json['events'] as $ev) {
        $q = is_string($ev) ? $ev : (is_array($ev) ? (string)($ev['query'] ?? '') : '');
        $q = ltrim(trim($q), '?&');
        if ($q === '') continue;

        /* The relay strips its own token; the query still carries key/ip/
           click_id/unique_id/acct exactly as LootLabs sent them. */
        $target = $hook . (str_contains($hook, '?') ? '&' : '?') . $q;
        $one = sfy_relay_http($target, $timeout);
        $results[] = [
            'code' => $one['code'],
            'ok'   => $one['ok'] && $one['code'] >= 200 && $one['code'] < 300,
            'body' => substr((string)$one['body'], 0, 160),
        ];
    }

    return ['ok' => true, 'pulled' => count($json['events']), 'processed' => count($results), 'results' => $results];
}
