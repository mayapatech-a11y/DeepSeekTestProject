<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY ULTIMATE — LOOTLABS INTEGRATION (anti-bypass)
 *
 *  Handoff : task page → signed step nonce → LootLabs link (optionally via
 *            the Redirect API) → user finishes → LootLabs postback →
 *            api/hook.php verifies the signature, the dwell time and the
 *            one-time nonce before the step is allowed to advance.
 * ═══════════════════════════════════════════════════════════════════════
 */

/* ── accounts ──────────────────────────────────────────────────────── */
/**
 * The active account pool.
 *
 * `$providerId > 0` narrows it to one task provider's accounts, which is how
 * each provider keeps its own rotation: two LootLabs accounts rotate between
 * LootLabs steps, two Work.ink accounts between Work.ink steps, and the two
 * pools never borrow from each other.
 */
function sfy_accounts_active(int $providerId = 0): array {
    try {
        if ($providerId > 0 && function_exists('sfy_provider_accounts')) {
            return sfy_provider_accounts($providerId, true);
        }
        return sfy_db()->query("SELECT * FROM lootlabs_accounts WHERE is_active=1 ORDER BY id ASC")->fetchAll();
    } catch (Throwable $e) { return []; }
}

function sfy_account_find(int $id): ?array {
    return sfy_try(function () use ($id): ?array {
        $st = sfy_db()->prepare("SELECT * FROM lootlabs_accounts WHERE id=? LIMIT 1");
        $st->execute([$id]);
        $row = $st->fetch();
        return $row === false ? null : $row;
    }, null);
}

/**
 * Pick the account for a step.
 *
 * Explicit chain ids are honoured, but unknown / disabled ids fall back to the
 * pool of active accounts so an empty or stale chain can never dead-end the
 * flow with "No active account for this step".
 *
 * `provider_ids` is how a merged network's rotation works: hand it every live
 * link of the network and the step index walks the *pooled* list, so task 1
 * opens on the first link and task 2 on the second one — instead of the same
 * link being reused while a second one sits idle.
 */
function sfy_resolve_account(string $chain, int $step, array $opts = []): ?array {
    $providerId  = (int)($opts['provider_id'] ?? 0);
    $providerIds = array_values(array_unique(array_filter(
        array_map('intval', (array)($opts['provider_ids'] ?? [])), fn($i) => $i > 0)));
    if (!$providerIds && $providerId > 0) $providerIds = [$providerId];

    $pool = count($providerIds) > 1 && function_exists('sfy_provider_accounts_multi')
          ? sfy_provider_accounts_multi($providerIds)
          : sfy_accounts_active($providerId);
    /*
     * A provider whose accounts all went inactive must never dead-end a step
     * that was already handed to it: fall back to the whole active pool, the
     * same way a stale account chain does below.
     */
    if (!$pool && $providerIds) $pool = sfy_accounts_active();
    if (!$pool) return null;

    $byId = [];
    foreach ($pool as $a) $byId[(int)$a['id']] = $a;

    $ids = [];
    foreach (array_map('intval', preg_split('/[,\s]+/', $chain, -1, PREG_SPLIT_NO_EMPTY) ?: []) as $id) {
        if ($id > 0) $ids[] = $id;
    }

    $candidates = [];
    foreach ($ids as $id) if (isset($byId[$id])) $candidates[] = $byId[$id];
    if (!$candidates) $candidates = array_values($pool);          // graceful fallback

    // Honour per-account daily caps when we can.
    $usable = array_values(array_filter($candidates, function ($a) {
        $cap = (int)($a['daily_cap'] ?? 0);
        if ($cap <= 0) return true;
        $usedDate = $a['used_date'] ?? null;
        $today    = date('Y-m-d');
        return $usedDate !== $today || (int)($a['used_today'] ?? 0) < $cap;
    }));
    if ($usable) $candidates = $usable;

    // Weighted rotation, then step-based index as a stable tiebreaker.
    $weighted = [];
    foreach ($candidates as $a) {
        $w = max(1, (int)($a['weight'] ?? 1));
        for ($i = 0; $i < $w; $i++) $weighted[] = $a;
    }
    if (!$weighted) return null;

    $idx = (($step - 1) % count($weighted) + count($weighted)) % count($weighted);
    return $weighted[$idx];
}

function sfy_account_touch(int $id): void {
    try {
        sfy_db()->prepare("UPDATE lootlabs_accounts
                           SET last_used_at=NOW(),
                               used_today = IF(used_date <=> CURDATE(), used_today + 1, 1),
                               used_date  = CURDATE()
                           WHERE id=?")->execute([$id]);
    } catch (Throwable $e) { /* non fatal */ }
}

/* ══════════════════════════════════════════════════════════════════════
   REDIRECT API — LOOTLABS ANTI-BYPASS HANDOFF
   https://help.lootlabs.gg/en/article/lootlabs-redirect-api-anti-bypass-9o0tky/

   How it works, in the provider's own terms:

     POST https://creators.lootlabs.gg/api/public/url_encryptor
       { "destination_url": "https://your.site/done",
         "api_token":      "<64-char hex>" }
     → { "type": "created", "request_time": 377,
         "message": "oUxJ2u2ePCkLdIsE80YCcg%3D%3D" }

   That `message` is an AES-256 blob encrypted with the API key, and it is
   appended to one of *your own* LootLabs links as `&data=<message>`:

     https://loot-link.com/s?qo0f&data=oUxJ2u2ePCkLdIsE80YCcg%3D%3D

   The visitor follows the link normally, finishes the task, and LootLabs then
   sends them to `destination_url` instead of whatever destination the link was
   created with. Because the blob can only be produced (or read) with the key,
   the final destination is decided by this server at click time rather than
   baked into a shareable URL — the “anti-bypass” part. GET is supported too
   (`?destination_url=…&api_token=…`), which is handy on hosts that mangle
   outgoing POST bodies.

   Everything below is admin-configurable: global mode (auto / on / off) plus a
   per-account override, POST or GET, and a cache so one API call can serve
   every visitor.
   ═════════════════════════════════════════════════════════════════════ */

/** Global mode: auto (use it when it works) | on (require it) | off (plain). */
function sfy_redirect_api_mode(): string {
    $m = strtolower(trim((string)sfy_config_get('set_redirect_api', '')));
    if (!in_array($m, ['auto', 'on', 'off'], true)) {
        $m = sfy_cfg('lootlabs.redirect_api', true) ? 'auto' : 'off';
    }
    return $m;
}

/** Per-account override; blank means "inherit the global mode". */
function sfy_redirect_api_account_mode(array $account): string {
    $own = strtolower(trim((string)($account['redirect_api'] ?? '')));
    return in_array($own, ['auto', 'on', 'off'], true) ? $own : sfy_redirect_api_mode();
}

function sfy_encrypt_method(): string {
    $m = strtolower(trim((string)sfy_config_get('set_encrypt_method', '')));
    if (!in_array($m, ['post', 'get'], true)) $m = strtolower((string)sfy_cfg('lootlabs.encrypt_method', 'post'));
    return $m === 'get' ? 'get' : 'post';
}

function sfy_redirect_cache_hours(): int {
    $h = (int)sfy_config_get('set_redirect_cache_hours', (string)(int)sfy_cfg('lootlabs.encrypt_cache_hours', 12));
    return max(0, min(168, $h));
}

/**
 * Our post-task landing page: the destination the encrypted handoff points at.
 * Leave the `{SESSION_ID}` macro out of it and every visitor shares the same
 * destination — which is what makes the encryption cacheable (and keeps the
 * account well inside LootLabs' API rate limits).
 */
function sfy_redirect_destination(array $ctx = []): string {
    $tpl = trim((string)sfy_config_get('set_return_url', ''));
    if ($tpl === '') $tpl = trim((string)sfy_config_get('return_url', ''));
    if ($tpl === '') $tpl = sfy_url('done');

    $ctx += ['sid' => $ctx['sid'] ?? '', 'unique_id' => $ctx['sid'] ?? ''];
    $url  = sfy_expand_macros($tpl, $ctx);

    /*
     * Put the per-run return ticket *inside the encrypted destination*.
     *
     * This is the whole anti-bypass point: the landing page stops being one
     * fixed, guessable address (`/done`) that any bypass service can navigate a
     * player to, and becomes `/done?rt=<ticket>` where the ticket is minted for
     * this step alone. Only LootLabs can hand it back, because only LootLabs can
     * decrypt the `&data=` blob it travels in — and it is single-use, so a
     * replayed or copied landing URL confirms nothing.
     *
     * It is deliberately NOT added to the plain task URL: that query string is
     * visible to the player and to whatever they paste it into.
     *
     * An owner who places `{RETURN_TICKET}` in the landing page themselves (or
     * writes an `rt=` by hand) keeps control — the ticket is not appended twice.
     */
    $ticket = trim((string)($ctx['ticket'] ?? ''));
    if ($ticket !== '') {
        $hasMacro = (bool)preg_match('/\{RETURN_TICKET\}|__RETURN_TICKET__|\{return_ticket\}/i', $tpl);
        if (!$hasMacro && !preg_match('/(?:^|[?&])rt=/', $url)) {
            $url .= (str_contains($url, '?') ? '&' : '?') . 'rt=' . rawurlencode($ticket);
        }
    }
    return $url;
}

/**
 * The `&data=` value must reach LootLabs percent-encoded exactly once.
 *
 * The API is inconsistent: the POST example returns `…%3D%3D` (already
 * encoded) while the GET example returns `TvgGcq/b%2Bttv1snxr8o6MA%3D%3D`
 * (base64 with a `/` in it). Decode-then-encode is the only normalisation that
 * is correct for both — calling urlencode() straight on the encoded form sent
 * `%253D` and the redirect silently failed.
 */
function sfy_lootlabs_normalize_data(string $message): string {
    $m = trim($message);
    if ($m === '') return '';
    return rawurlencode(rawurldecode($m));
}

/**
 * Interpret one encryptor response. Pure (no HTTP) so it is unit tested.
 * @return array{ok:bool,data:string,type:string,error:string}
 */
function sfy_lootlabs_parse_response(int $http, string $raw): array {
    $body = trim($raw);
    $j    = json_decode($body, true);
    $type = '';
    $msg  = '';
    $err  = '';
    $fail = fn(string $e): array => ['ok' => false, 'data' => '', 'type' => $type, 'error' => $e];

    if (is_array($j)) {
        $type = strtolower(trim((string)($j['type'] ?? '')));
        $msg  = trim((string)($j['message'] ?? ($j['data'] ?? ($j['url'] ?? ''))));
    }

    // 1. The API's own error envelope ("type": "error", "message": "…").
    if ($type === 'error') return $fail($msg !== '' ? $msg : 'the API reported an error');
    // 2. Transport level.
    if ($http !== 200) {
        return $fail('HTTP ' . $http . ($body !== '' ? ' — ' . substr(trim(strip_tags($body)), 0, 120) : ''));
    }
    if ($msg === '') {
        return $fail($body !== '' ? 'unexpected response: ' . substr($body, 0, 120) : 'empty response');
    }
    /*
     * 3. The only thing that is actually usable is a ciphertext. Failures show
     * up as prose in `message` ("Internal Server Error", "Invalid api token",
     * "Not Found"), sometimes with a success-looking type, so the payload itself
     * is validated instead of trusting `type`. After normalisation an encrypted
     * value is alphanumerics plus %XX escapes and nothing else, and AES-256
     * base64 for any real URL is well past 16 characters.
     */
    $plain = strtolower($msg);
    if (in_array($plain, ['internal server error', 'not found', 'unauthorized', 'forbidden',
                          'invalid api token', 'error', 'bad request'], true)) {
        return $fail($msg);
    }
    $data = sfy_lootlabs_normalize_data($msg);
    $bare = (string)preg_replace('/%[0-9A-Fa-f]{2}/', '', $data);
    if ($data === '' || preg_match('/^[A-Za-z0-9]+$/', $bare) !== 1 || strlen($bare) < 16) {
        return $fail('the API did not return an encrypted value (' . substr($msg, 0, 120) . ')');
    }

    return ['ok' => true, 'data' => $data, 'type' => $type !== '' ? $type : 'created', 'error' => ''];
}

/* ── encryption cache (one API call can serve every visitor) ─────────── */
function sfy_lootlabs_cache_key(string $dest, int $accountId): string {
    return 'lle_' . $accountId . '_' . substr(sha1($dest), 0, 12);
}

function sfy_lootlabs_cache_get(string $dest, int $accountId): ?string {
    $hours = sfy_redirect_cache_hours();
    if ($hours <= 0) return null;
    $j = json_decode((string)sfy_config_get(sfy_lootlabs_cache_key($dest, $accountId), ''), true);
    if (!is_array($j)) return null;
    $at = (int)($j['at'] ?? 0);
    $data = (string)($j['data'] ?? '');
    if ($data === '' || $at <= 0 || (time() - $at) > $hours * 3600) return null;
    return $data;
}

function sfy_lootlabs_cache_put(string $dest, int $accountId, string $data): void {
    if ($data === '' || sfy_redirect_cache_hours() <= 0) return;
    sfy_try(function () use ($dest, $accountId, $data) {
        sfy_config_set(sfy_lootlabs_cache_key($dest, $accountId), json_encode(['at' => time(), 'data' => $data]));
        sfy_lootlabs_cache_prune();
        return null;
    }, null);
}

/**
 * Keep the handoff cache bounded.
 *
 * This existed so one API call could serve every visitor — which worked
 * because the destination was the same `/done` for all of them, so the whole
 * cache was one row per account. Now the destination carries the per-run return
 * ticket, so it is one row per STEP, and `sfy_config` is read in full on every
 * single request (`sfy_config_all()`): unbounded growth there is a site-wide
 * slowdown, not a cosmetic leak.
 *
 * So the cache is dropped wholesale now and then. It only ever costs one
 * encryptor call for the steps still in flight — and each of those re-encrypts
 * to the *same* destination, because the destination is derived from the ticket,
 * not from the blob — so nothing in the flow notices.
 */
function sfy_lootlabs_cache_prune(): void {
    /* Expected steady state is well under the cap: one cheap DELETE every ~150
       handoffs, instead of a counter write on every one of them. */
    if (mt_rand(1, 150) !== 1) return;
    sfy_try(function () {
        sfy_db()->prepare("DELETE FROM sfy_config WHERE config_key LIKE 'lle\\_%'")->execute();
        return null;
    }, null);
}

/**
 * Ask LootLabs for the encrypted `&data=` value of a destination URL.
 * @param array{account_id?:int,method?:string,no_cache?:bool} $opts
 * @return array{ok:bool,data:string,type:string,cached:bool,ms:int,http:int,error:string,destination:string}
 */
function sfy_lootlabs_encrypt(string $destinationUrl, string $apiToken, array $opts = []): array {
    $accountId = (int)($opts['account_id'] ?? 0);
    $noCache   = !empty($opts['no_cache']);
    $mk = fn(bool $ok, string $data, string $type, bool $cached, int $ms, int $http, string $err): array =>
        ['ok' => $ok, 'data' => $data, 'type' => $type, 'cached' => $cached,
         'ms' => $ms, 'http' => $http, 'error' => $err, 'destination' => $destinationUrl];

    if ($destinationUrl === '') return $mk(false, '', '', false, 0, 0, 'no destination URL');
    if (trim($apiToken) === '')  return $mk(false, '', '', false, 0, 0, 'this account has no API key');
    if (!function_exists('curl_init')) return $mk(false, '', '', false, 0, 0, 'the curl extension is not enabled on this host');

    if (!$noCache) {
        $cached = sfy_lootlabs_cache_get($destinationUrl, $accountId);
        if ($cached !== null) return $mk(true, $cached, 'cache', true, 0, 0, '');
    }

    $method  = strtolower((string)($opts['method'] ?? sfy_encrypt_method()));
    $base    = (string)sfy_cfg('lootlabs.encrypt_url', 'https://creators.lootlabs.gg/api/public/url_encryptor');
    $timeout = max(3, (int)sfy_cfg('lootlabs.timeout', 8));

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => $timeout,
        CURLOPT_CONNECTTIMEOUT => min(5, $timeout),
        CURLOPT_SSL_VERIFYPEER => true,
        // The docs send the token in the body; the code samples send a Bearer
        // header. We send both so neither variant of their API can miss it.
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Accept: application/json',
                                   'Authorization: Bearer ' . $apiToken],
    ]);
    if ($method === 'get') {
        curl_setopt($ch, CURLOPT_URL, $base . '?' . http_build_query([
            'destination_url' => $destinationUrl, 'api_token' => $apiToken,
        ]));
    } else {
        curl_setopt($ch, CURLOPT_URL, $base);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['destination_url' => $destinationUrl, 'api_token' => $apiToken]));
    }

    $start  = microtime(true);
    $raw    = curl_exec($ch);
    $http   = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr = curl_error($ch);
    curl_close($ch);
    $ms = (int)round((microtime(true) - $start) * 1000);

    if ($raw === false) {
        error_log('[SFY] LootLabs encrypt transport error: ' . $curlErr);
        return $mk(false, '', '', false, $ms, $http, $curlErr !== '' ? $curlErr : 'no response from the API');
    }

    $parsed = sfy_lootlabs_parse_response($http, (string)$raw);
    if (empty($parsed['ok'])) {
        error_log('[SFY] LootLabs encrypt refused (HTTP ' . $http . '): ' . $parsed['error']);
        return $mk(false, '', (string)$parsed['type'], false, $ms, $http, (string)$parsed['error']);
    }

    if (!$noCache) sfy_lootlabs_cache_put($destinationUrl, $accountId, (string)$parsed['data']);
    return $mk(true, (string)$parsed['data'], (string)$parsed['type'], false, $ms, $http, '');
}

/**
 * Self-test for Admin → LootLabs → TEST ANTI-BYPASS.
 * Always hits the API (never the cache) and always encrypts the real return
 * URL, so it exercises exactly what a real handoff will do.
 * @return array{ok:bool,data:string,type:string,error:string,ms:int,http:int,destination:string}
 */
function sfy_lootlabs_test(string $apiToken, string $destination = ''): array {
    $dest = $destination !== '' ? $destination : sfy_redirect_destination();
    return sfy_lootlabs_encrypt($dest, $apiToken, ['no_cache' => true, 'method' => sfy_encrypt_method()]);
}

/**
 * Persist the result of an anti-bypass test on the account row.
 * Stored as `ok|<type>|<ms>` or `fail|<error>` so the accounts table can show
 * the state (and when it was last checked) without another API call.
 */
function sfy_account_store_encrypt_status(int $accountId, array $r): bool {
    if ($accountId <= 0) return false;

    $status = !empty($r['ok'])
        ? 'ok|' . (string)($r['type'] ?? '') . '|' . (int)($r['ms'] ?? 0)
        : 'fail|' . substr((string)($r['error'] ?? 'unknown error'), 0, 180);
    $now = date('c');

    /*
     * Always keep a copy in the config table — that write needs no ALTER, so
     * the panel can still show the truth on an install whose updater has not
     * finished. (A test that passes but leaves "NOT TESTED" on screen is worse
     * than no status at all.)
     */
    sfy_try(function () use ($accountId, $status, $now) {
        sfy_config_set('set_lle_last_test', json_encode(['account' => $accountId, 'status' => $status, 'at' => $now]));
        return true;
    }, false);

    return (bool)sfy_try(function () use ($accountId, $status): bool {
        if (!sfy_column_exists('lootlabs_accounts', 'encrypt_status')) return false;
        $sets = ['encrypt_status=?'];
        if (sfy_column_exists('lootlabs_accounts', 'encrypt_checked_at')) $sets[] = 'encrypt_checked_at=NOW()';
        $sets[] = 'updated_at=NOW()';
        sfy_db()->prepare('UPDATE lootlabs_accounts SET ' . implode(', ', $sets) . ' WHERE id=?')
               ->execute([$status, $accountId]);
        return true;
    }, false);
}

/**
 * The last anti-bypass test result for an account: the account row when the
 * schema has it, otherwise the config copy.
 * @return array{status:string,at:string,from:string}
 */
function sfy_redirect_api_last_test(array $account): array {
    $status = trim((string)($account['encrypt_status'] ?? ''));
    if ($status !== '') return ['status' => $status, 'at' => trim((string)($account['encrypt_checked_at'] ?? '')), 'from' => 'account'];

    $j = json_decode((string)sfy_config_get('set_lle_last_test', ''), true);
    if (is_array($j) && (int)($j['account'] ?? 0) === (int)($account['id'] ?? 0) && trim((string)($j['status'] ?? '')) !== '') {
        return ['status' => trim((string)$j['status']), 'at' => (string)($j['at'] ?? ''), 'from' => 'config'];
    }
    return ['status' => '', 'at' => '', 'from' => ''];
}

/**
 * Columns the anti-bypass panels and the return check need.
 * Empty means the upload and the updater agree; anything listed needs
 * Admin → Updater.
 */
function sfy_redirect_api_requirements(): array {
    $missing = [];
    foreach ([['lootlabs_accounts', 'redirect_api'],
              ['lootlabs_accounts', 'encrypt_status'],
              ['lootlabs_accounts', 'encrypt_checked_at'],
              ['sfy_step_tokens', 'clicked_at'],
              ['sfy_step_tokens', 'return_ticket']] as [$t, $c]) {
        if (!sfy_try(fn() => sfy_column_exists($t, $c), false)) $missing[] = $t . '.' . $c;
    }
    return $missing;
}

/** Human label for a test/handoff result, used by the admin panels. */
function sfy_redirect_api_status_label(array $account): array {
    $mode = sfy_redirect_api_account_mode($account);
    if ($mode === 'off') return ['PLAIN LINK', 'gr', 'anti-bypass off for this account'];
    if (trim((string)($account['api_key'] ?? '')) === '') return ['NO API KEY', 'r', 'this account has no API key'];

    $last   = sfy_redirect_api_last_test($account);
    $status = $last['status'];
    if ($status === '') return ['NOT TESTED', 'y', 'run TEST ANTI-BYPASS to check the key'];
    if (str_starts_with($status, 'ok')) {
        return ['API OK', 'g', $last['at'] !== '' ? 'checked ' . sfy_ago($last['at']) : ''];
    }
    return ['API FAILED', 'r', substr($status, 0, 80)];
}

/* ── signed step nonces ────────────────────────────────────────────── */
function sfy_step_signature(string $sessionId, int $step, string $nonce, int $accountId): string {
    return hash_hmac('sha256', 'pb|' . $sessionId . '|' . $step . '|' . $nonce . '|' . $accountId,
                     (string)sfy_cfg('app.app_key'));
}

/**
 * The postback URL's own password (P0-1, 2026-10-24).
 *
 * The step nonce and the per-step signature are printed in the player's task
 * URL, so neither of them can prove that a call came from the provider. This
 * value is derived from the app key, is written ONLY into the postback URL
 * configured in the provider's dashboard, and is never sent to a browser — so
 * a forged call cannot present it.
 *
 * It is per account so a leaked URL only exposes that one account; rotating
 * app.app_key rotates every key, and the dashboard URL has to be re-pasted.
 */
function sfy_postback_key(int $accountId): string {
    return substr(hash_hmac('sha256', 'postback-key|' . $accountId,
                            (string)sfy_cfg('app.app_key')), 0, 40);
}

/** Issue (or re-issue) the one-time nonce for the session's current step. */
function sfy_step_issue(string $sessionId, int $step, int $accountId, int $providerId = 0): array {
    $db    = sfy_db();
    $nonce = sfy_nonce();
    /* Which provider serves this step — recorded on the handoff itself, so the
       per-provider task budget and the admin's Sessions view both read the
       truth from the row that actually went out. */
    $hasProvider = (bool)sfy_try(fn() => sfy_column_exists('sfy_step_tokens', 'provider_id'), false);
    /* Migration 031. While it is missing the step simply carries no ticket and
       the ordinary gates apply — never a fatal on the hot path. */
    $hasTicket   = (bool)sfy_try(fn() => sfy_column_exists('sfy_step_tokens', 'return_ticket'), false);
    $ticket      = '';

    try {
        $st = $db->prepare("SELECT * FROM sfy_step_tokens WHERE session_id=? AND step=? LIMIT 1");
        $st->execute([$sessionId, $step]);
        $row = $st->fetch();

        if ($row && empty($row['consumed_at'])) {
            $nonce = (string)$row['nonce'];          // reuse the open nonce (retries / refresh)
            /*
             * Reuse the open ticket too. A retry or a refresh must produce the
             * SAME destination, or the encryption cache misses on every reload
             * and the ticket the player is already holding stops matching.
             */
            $ticket = $hasTicket ? trim((string)($row['return_ticket'] ?? '')) : '';
            /* Already presented but the step never confirmed (the player landed
               and left before the dwell ran out): hand out a fresh one, or the
               re-issued link would carry a burned ticket and confirm nothing. */
            $rePresent = $hasTicket && !empty($row['return_ticket_used_at']);
            $sets  = ['account_id=?', 'issued_at=NOW()', 'issued_ip=?', 'issued_ua=?'];
            $args  = [$accountId, sfy_client_ip(), sfy_user_agent()];
            if ($hasProvider && $providerId > 0) { $sets[] = 'provider_id=?'; $args[] = $providerId; }
            if ($hasTicket) {
                if ($ticket === '' || $rePresent) $ticket = sfy_nonce();
                $sets[] = 'return_ticket=?';      $args[] = $ticket;
                $sets[] = 'return_ticket_at=NOW()';
                if ($rePresent) $sets[] = 'return_ticket_used_at=NULL';
            }
            $args[] = (int)$row['id'];
            $db->prepare('UPDATE sfy_step_tokens SET ' . implode(', ', $sets) . ' WHERE id=?')->execute($args);
        } elseif ($row) {
            /*
             * This handoff starts over. Clock columns and the old ticket belong
             * to the previous attempt: a stale `returned_at` is exactly what
             * would let the next landing confirm a step nobody went back to,
             * and a stale ticket is one a bypasser may already hold. Clear both
             * before the fresh row is written.
             */
            sfy_step_clear_clock($sessionId, $step);
            $sets = ['nonce=?', 'account_id=?', 'issued_at=NOW()', 'consumed_at=NULL',
                     'issued_ip=?', 'issued_ua=?', 'attempts=0'];
            $args = [$nonce, $accountId, sfy_client_ip(), sfy_user_agent()];
            if ($hasProvider && $providerId > 0) { $sets[] = 'provider_id=?'; $args[] = $providerId; }
            if ($hasTicket) {
                $ticket = sfy_nonce();
                $sets[] = 'return_ticket=?';          $args[] = $ticket;
                $sets[] = 'return_ticket_at=NOW()';
                $sets[] = 'return_ticket_used_at=NULL';
            }
            $args[] = (int)$row['id'];
            $db->prepare('UPDATE sfy_step_tokens SET ' . implode(', ', $sets) . ' WHERE id=?')->execute($args);
        } else {
            $cols = ['session_id', 'step', 'nonce', 'account_id', 'issued_ip', 'issued_ua', 'issued_at'];
            $marks = ['?', '?', '?', '?', '?', '?', 'NOW()'];
            $args  = [$sessionId, $step, $nonce, $accountId, sfy_client_ip(), sfy_user_agent()];
            if ($hasProvider) { $cols[] = 'provider_id'; $marks[] = '?'; $args[] = $providerId; }
            if ($hasTicket) {
                $ticket = sfy_nonce();
                $cols[] = 'return_ticket';    $marks[] = '?';
                $cols[] = 'return_ticket_at'; $marks[] = 'NOW()';
                $args[] = $ticket;
            }
            $sql = 'INSERT INTO sfy_step_tokens (' . implode(', ', $cols) . ')'
                 . ' VALUES (' . implode(', ', $marks) . ')';
            $db->prepare($sql)->execute($args);
        }
    } catch (Throwable $e) {
        // Either a concurrent request already issued one (reuse it) or the
        // step-token table is not installed yet. Neither may take the page
        // down: the updater will finish the job on the next request.
        error_log('[SFY] step issue: ' . $e->getMessage());
        $row = sfy_try(function () use ($sessionId, $step) {
            $st = sfy_db()->prepare("SELECT * FROM sfy_step_tokens WHERE session_id=? AND step=? LIMIT 1");
            $st->execute([$sessionId, $step]);
            return $st->fetch() ?: null;
        }, null);
        if ($row) {
            $nonce     = (string)$row['nonce'];
            $accountId = (int)$row['account_id'];
            $ticket    = trim((string)($row['return_ticket'] ?? ''));
        }
    }

    return [
        'nonce'         => $nonce,
        'signature'     => sfy_step_signature($sessionId, $step, $nonce, $accountId),
        'step'          => $step,
        'account_id'    => $accountId,
        'provider_id'   => $providerId,
        'return_ticket' => $ticket,
    ];
}

function sfy_step_open(string $sessionId, int $step): ?array {
    return sfy_try(function () use ($sessionId, $step) {
        $st = sfy_db()->prepare("SELECT * FROM sfy_step_tokens WHERE session_id=? AND step=? LIMIT 1");
        $st->execute([$sessionId, $step]);
        return $st->fetch() ?: null;
    }, null);
}

/**
 * Locate an open step handoff by nonce, session id or (last resort) IP.
 *
 * The returned row carries `_attr`, which records *how* it was matched:
 *   'nonce'   — the single-use nonce we handed to the provider (strong)
 *   'session' — the session id we sent as unique_id          (strong)
 *   'ip'      — same IP inside the nonce window              (weak)
 * Attribution decides whether a missing signature is tolerated, so it must
 * never be guessed: it is the whole point of the anti-bypass gate.
 */
function sfy_step_locate(string $nonce, string $sessionHint, string $ip): ?array {
    return sfy_try(fn() => sfy_step_locate_raw($nonce, $sessionHint, $ip), null);
}

function sfy_step_locate_raw(string $nonce, string $sessionHint, string $ip): ?array {
    $db  = sfy_db();
    $age = (int)sfy_cfg('security.max_step_nonce_age', 900);

    if ($nonce !== '') {
        $st = $db->prepare("SELECT * FROM sfy_step_tokens WHERE nonce=? ORDER BY id DESC LIMIT 1");
        $st->execute([$nonce]);
        if ($r = $st->fetch()) { $r['_attr'] = 'nonce'; return $r; }
    }
    if ($sessionHint !== '') {
        $st = $db->prepare("SELECT * FROM sfy_step_tokens WHERE session_id=? AND consumed_at IS NULL
                            ORDER BY step DESC LIMIT 1");
        $st->execute([$sessionHint]);
        if ($r = $st->fetch()) { $r['_attr'] = 'session'; return $r; }
    }
    if ($ip !== '') {
        $st = $db->prepare("SELECT * FROM sfy_step_tokens WHERE consumed_at IS NULL AND issued_ip=?
                              AND issued_at > " . sfy_sql_now_offset('SECOND') . "
                            ORDER BY issued_at DESC LIMIT 1");
        $st->execute([$ip, -$age]);
        if ($r = $st->fetch()) { $r['_attr'] = 'ip'; return $r; }
    }
    return null;
}

/* ── url building + macro expansion ────────────────────────────────── */
/**
 * Macro table. A macro with no value in the context is left AS the
 * placeholder, so a postback template generated in the admin panel still
 * shows {CLICK_ID} etc. for the provider to fill in at click time.
 */
function sfy_postback_macros(array $ctx): array {
    $map = [
        'CLICK_ID'   => $ctx['click_id']  ?? '',
        'IP'         => $ctx['ip']        ?? '',
        'USER_ID'    => $ctx['unique_id'] ?? '',
        'UNIQUE_ID'  => $ctx['unique_id'] ?? '',
        'SUB_ID'     => $ctx['nonce']     ?? '',
        'NONCE'      => $ctx['nonce']     ?? '',
        'SIG'        => $ctx['sig']       ?? '',
        'SIGNATURE'  => $ctx['sig']       ?? '',
        'ACCOUNT'    => (string)($ctx['account_id'] ?? ''),
        'ACCOUNT_ID' => (string)($ctx['account_id'] ?? ''),   // the macro legend lists this name
        'STEP'       => (string)($ctx['step'] ?? ''),
        'TOKEN'      => (string)($ctx['token'] ?? ''),
        'GAME_ID'    => (string)($ctx['game_id'] ?? ''),
        'SESSION_ID' => (string)($ctx['sid'] ?? ($ctx['unique_id'] ?? '')),
        /* The per-run return ticket. Only ever put this somewhere only we and
           LootLabs can read it — the encrypted `&data=` destination. */
        'RETURN_TICKET' => (string)($ctx['ticket'] ?? ''),
        'DOMAIN'     => SFY_DOMAIN,
    ];
    $macros = [];
    foreach ($map as $macro => $value) {
        $value = (string)$value;
        if ($value === '') $value = '{' . $macro . '}';     // keep the placeholder
        $macros['{' . $macro . '}']               = $value;
        $macros['{' . strtolower($macro) . '}']   = $value;
        $macros['__' . $macro . '__']             = $value;
    }
    return $macros;
}

function sfy_expand_macros(string $template, array $ctx): string {
    return strtr($template, sfy_postback_macros($ctx));
}

/**
 * Postback URL shown in the admin (LootLabs / Work.ink dashboard value).
 * A provider may define the template once for all of its accounts; an account
 * that has its own template still wins.
 *
 * The built-in template is written for the network that will receive it.
 * LootLabs' Postback API documents exactly three macros — `{CLICK_ID}`, `{IP}`
 * and `{UNIQUE_ID}` — and no sub-id or signature macro of any kind; a
 * placeholder the network does not know is not dropped, it arrives as literal
 * text, which lands in the log as a bogus nonce. A LootLabs provider therefore
 * gets only the documented three, and the step nonce rides on `click_id` (the
 * value of the `&puid` this install puts on the task link — see
 * sfy_build_task_url()). Every other kind keeps the wider alias set.
 */
function sfy_postback_url(array $account, array $ctx = [], ?array $provider = null): string {
    $id  = (int)($account['id'] ?? 0);
    $key = sfy_postback_key($id);
    $tpl = trim((string)($account['postback_url'] ?? ''));
    if ($tpl === '' && is_array($provider)) $tpl = trim((string)($provider['postback_url'] ?? ''));
    if ($tpl === '') {
        $kind = strtolower((string)($provider['kind'] ?? $account['provider_kind'] ?? ''));
        $q    = 'click_id={CLICK_ID}&ip={IP}&unique_id={UNIQUE_ID}';
        if ($kind !== 'lootlabs') $q .= '&sub_id={SUB_ID}';
        $tpl = sfy_url('api/hook.php') . '?' . $q . '&acct=' . $id . '&key=' . $key;
    }
    $url = sfy_expand_macros($tpl, $ctx + ['account_id' => $id]);
    /* Always use THIS account's key. A postback URL copied from another
       account (or from staging) can still carry its old key=...; keeping it
       would make the app reject every real postback as bad_postback_key. */
    if (preg_match('/([?&])key=[^&]*/', $url)) {
        $url = preg_replace_callback(
            '/([?&])key=[^&]*/',
            static fn(array $m): string => $m[1] . 'key=' . rawurlencode($key),
            $url,
            1
        );
    } else {
        $url .= (str_contains($url, '?') ? '&' : '?') . 'key=' . $key;
    }
    return $url;
}

/**
 * Build the clickable task URL for a step.
 * @return array{url:string, mode:string, encrypted:?string}
 */
function sfy_build_task_url(array $account, array $token, array $hand) : array {
    $base = trim((string)($account['task_url'] ?? ''));

    /*
     * Several aliases for the same two values: whichever macro the provider
     * forwards back (`unique_id`, `sub_id`, `s1`, `custom`…) the postback
     * receiver can still attribute the call to this exact step.
     */
    $sep = str_contains($base, '?') ? '&' : '?';
    $q   = http_build_query([
        'unique_id' => $hand['sid'],
        'uid'       => $hand['sid'],
        's1'        => $hand['sid'],
        'sub_id'    => $hand['nonce'],
        's2'        => $hand['nonce'],
        /* LootLabs' documented attachment parameter: whatever `&puid` carries
           comes back in the postback as `click_id`, and it is the only value
           the network is documented to hand back. It carries the single-use
           step nonce, so a LootLabs postback names the exact step even though
           the link's other parameters are for other networks. */
        'puid'      => $hand['nonce'],
        /* P0-3, 2026-10-24: the per-step HMAC used to be printed here. It is a
           valid signature, so publishing it handed the player a postback they
           could replay. The provider does not expand {SIG} in its postback URL
           anyway; the key (P0-1) is what authenticates the call now. */
        'acct'      => (int)$account['id'],
    ]);
    $url = $base . $sep . $q;

    /*
     * Anti-bypass handoff. `off` skips the API entirely; `auto` uses it when it
     * answers and degrades to a plain link when it does not; `on` refuses the
     * handoff rather than silently downgrading the protection.
     */
    $apiMode = sfy_redirect_api_account_mode($account);
    /*
     * The destination carries this step's return ticket (`…/done?rt=<ticket>`),
     * and from here it is encrypted — the ticket is never added to the plain
     * task URL above, so the only way it can come back is through LootLabs'
     * own decryption of the `&data=` blob.
     */
    $dest    = sfy_redirect_destination([
        'sid'    => (string)($hand['sid'] ?? ''),
        'ticket' => (string)($hand['return_ticket'] ?? ''),
    ]);
    $enc     = ['ok' => false, 'data' => '', 'type' => '', 'cached' => false, 'ms' => 0, 'http' => 0,
                'error' => 'anti-bypass is switched off for this account', 'destination' => $dest];
    $handoff = 'plain';

    if ($apiMode !== 'off') {
        $enc = sfy_lootlabs_encrypt($dest, (string)($account['api_key'] ?? ''), ['account_id' => (int)($account['id'] ?? 0)]);
        if (!empty($enc['ok'])) $handoff = 'redirect_api';
    }

    if ($handoff === 'redirect_api') {
        $url .= '&data=' . $enc['data'];          // already percent-encoded once
    } else {
        /*
         * No encrypted destination reached the player, so this step must not be
         * held to a ticket it can never present — that would strand the player
         * on a link that is working exactly as configured. Clear it here (and
         * again for any provider that has no `&data=` mechanism at all, in
         * sfy_provider_build_handoff): the step falls back to the ordinary
         * postback / verified-return gates.
         */
        if (function_exists('sfy_step_ticket_clear')) {
            sfy_step_ticket_clear((string)($hand['sid'] ?? ''), (int)($hand['step'] ?? 0));
        }
        /*
         * Fail closed only when the API was *supposed* to be used:
         *   on   -> the operator requires it, always refuse a downgrade;
         *   auto -> refuse when fallback_plain is off (the 2026-10-24 default);
         *   off  -> the operator deliberately chose plain links, so allow it.
         * The old test also blocked 'off', which made turning the API off
         * impossible once fallback_plain was false.
         */
        if ($apiMode === 'on' || ($apiMode !== 'off' && !sfy_cfg('lootlabs.fallback_plain', true))) {
            return ['url' => '', 'mode' => 'unavailable', 'handoff' => 'blocked',
                    'destination' => $dest, 'encrypt' => $enc, 'anti_bypass_mode' => $apiMode];
        }
    }

    return [
        'url'             => $url,
        'mode'            => $handoff,
        'handoff'         => $handoff,
        'destination'     => $dest,
        'encrypt'         => $enc,
        'anti_bypass_mode'=> $apiMode,
        'encrypted'       => $handoff === 'redirect_api' ? $enc['data'] : null,
    ];
}

/* ── postback verification ─────────────────────────────────────────── */
/**
 * Is this postback call actually a browser navigation?
 *
 * The postback URL is a machine-to-machine endpoint, but the values it needs
 * are right there in the player's own task URL (the step nonce is sent to the
 * provider as `sub_id`), so pasting that URL into the address bar used to look
 * exactly like the provider calling it. The browser gives it away:
 *
 *   Sec-Fetch-Mode: navigate + Sec-Fetch-Dest: document + Sec-Fetch-Site: none
 *
 * is a URL typed or pasted into a tab. A real callback — LootLabs' server, a
 * client-side XHR or image ping — never sends `navigate` with `none`, and a
 * server-to-server call sends no Sec-Fetch-* headers at all. `same-origin` and
 * `cross-site` navigations are left alone: a redirect-based postback still
 * works, only the address bar is refused.
 */
function sfy_postback_browser_navigation(array $server = []): bool {
    if ((bool)sfy_cfg('security.allow_browser_postback', false)) return false;

    $s    = $server ?: $_SERVER;
    $mode = strtolower(trim((string)($s['HTTP_SEC_FETCH_MODE'] ?? '')));
    $site = strtolower(trim((string)($s['HTTP_SEC_FETCH_SITE'] ?? '')));
    $dest = strtolower(trim((string)($s['HTTP_SEC_FETCH_DEST'] ?? '')));

    if ($mode !== 'navigate') return false;
    if ($dest !== '' && $dest !== 'document') return false;
    return $site === '' || $site === 'none';
}

/**
 * Legacy HMAC-from-params check used when an account ships a LootLabs signed
 * hash. The signed step nonce is the primary gate; this is defence in depth.
 */
function sfy_verify_postback(array $params, string $secret): bool {
    if (empty($secret)) return (bool)sfy_cfg('security.allow_unsigned_postback', false);
    $received = (string)($params['hash'] ?? '');
    if ($received === '') return false;
    unset($params['hash']);
    ksort($params);
    $pairs = [];
    foreach ($params as $k => $v) {
        if (is_scalar($v)) $pairs[] = $k . '=' . $v;
    }
    $expected = hash_hmac('sha256', implode('|', $pairs), $secret);
    return hash_equals($expected, $received);
}

/**
 * Is a postback provably ours even without a signature?
 *
 * `$attr` comes from how the open step was located:
 *   'nonce'   — the single-use step nonce we handed to the provider
 *   'session' — the session id we sent as unique_id
 *   'ip'      — same IP inside the nonce window (weak, needs a signature)
 */
function sfy_postback_attribution_ok(string $attr, bool $sigOk, bool $hashOk): bool {
    if ($sigOk || $hashOk) return true;
    if (in_array($attr, ['signature', 'hash'], true)) return true;
    if (!in_array($attr, ['nonce', 'session', 'ip'], true)) return false;

    /*
     * Strict mode (opt-in, security.postback_require_nonce): an unsigned call
     * must be attributed by the nonce (or the session id) we handed the
     * provider. The IP-only match, the weakest accepted level, is refused —
     * a residential proxy can satisfy it, but it cannot know the 128-bit
     * single-use nonce that travelled inside the task URL. Ships off so the
     * existing trust_provider_attribution behaviour is unchanged.
     */
    if (sfy_postback_require_nonce()) {
        return $attr === 'nonce' || $attr === 'session';
    }

    /*
     * 'ip' is the weakest of the three, but it is still a real signal: the
     * postback came from the exact IP the handoff was issued to, inside the
     * nonce window, while that step was open, from an unfinished session. It
     * used to be rejected outright (`unattributed_ip`) — which silently
     * flagged real completions as bypass whenever a provider forwarded the
     * player's IP but not one of our own parameters. It now passes as
     * `ip_attributed`, which the admin and the log show as distinctly weaker
     * than a signed postback.
     */
    return (bool)sfy_cfg('security.trust_provider_attribution', true);
}

/* ── postback IP binding ───────────────────────────────────────────── */
/**
 * Are two addresses on the same network?
 *
 * IPv4 is compared on its /24 and IPv6 on its /48: a mobile handover, a new
 * router lease or a carrier moving an egress address stays inside that, while a
 * different network does not. The comparison is never *looser* than the address
 * itself — equal addresses always match, and an unparseable one never does.
 */
function sfy_ip_same_net(string $a, string $b, int $v4Bits = 24, int $v6Bits = 48): bool {
    $a = trim($a); $b = trim($b);
    if ($a === '' || $b === '') return false;
    if ($a === $b) return true;

    $ba = @inet_pton($a);
    $bb = @inet_pton($b);
    if ($ba === false || $bb === false || strlen($ba) !== strlen($bb)) return false;

    $bits  = strlen($ba) === 4 ? max(0, min(32, $v4Bits)) : max(0, min(128, $v6Bits));
    $bytes = intdiv($bits, 8);
    $rem   = $bits % 8;

    if ($bytes > 0 && substr($ba, 0, $bytes) !== substr($bb, 0, $bytes)) return false;
    if ($rem === 0) return true;

    $mask = (0xFF << (8 - $rem)) & 0xFF;
    return (ord($ba[$bytes]) & $mask) === (ord($bb[$bytes]) & $mask);
}

/** Is postback IP binding on? `set_postback_ip_enforce` (Admin → Settings). */
function sfy_postback_ip_enforced(): bool {
    $raw = strtolower(trim((string)sfy_config_get('set_postback_ip_enforce', '')));
    if ($raw === '') return (bool)sfy_cfg('security.postback_ip_enforce', true);
    return !in_array($raw, ['0', 'off', 'no', 'false'], true);
}

/**
 * Addresses (or ranges) whose `{IP}` is accepted even when it does not match
 * the handoff — for a provider that reports its own egress address rather than
 * the visitor's. Empty by default: nothing is trusted beyond the player's own
 * network until an owner puts something here and says so.
 */
function sfy_postback_ip_allowlist(): array {
    $raw = trim((string)sfy_config_get('set_postback_ip_allowlist', ''));
    if ($raw === '') $raw = trim((string)sfy_cfg('security.postback_ip_allowlist', ''));
    $out = [];
    foreach (preg_split('/[\s,;]+/', $raw) ?: [] as $h) {
        $h = trim($h);
        if ($h !== '') $out[] = $h;
    }
    return $out;
}

function sfy_postback_ip_allowlisted(string $ip): bool {
    foreach (sfy_postback_ip_allowlist() as $h) {
        if ($h === '*') return true;
        if (sfy_ip_same_net($ip, $h, 32, 128)) return true;
    }
    return false;
}

/**
 * May this postback's IP belong to the handoff this step issued?
 *
 * A value we never recorded (or an empty call) is not a refusal: the gate can
 * only judge what it was given, and "cannot judge" is never "guilty".
 */
function sfy_postback_ip_ok(string $issued, string $ip): bool {
    if (trim($issued) === '' || trim($ip) === '') return true;
    if (sfy_ip_same_net($issued, $ip)) return true;
    return sfy_postback_ip_allowlisted($ip);
}

/**
 * Full postback verification.
 * @return array{ok:bool, reason:string, step_token:?array, session:?array, account:?array, level:string}
 */
function sfy_postback_verify(string $sid, string $nonce, string $acctHint, string $sig,
                             string $ip, string $hashParam, string $key = ''): array {
    $db  = sfy_db();
    $row = sfy_step_locate($nonce, $sid, $ip);

    if (!$row) {
        return ['ok' => false, 'reason' => 'no_open_step', 'step_token' => null, 'session' => null, 'account' => null, 'level' => 'reject'];
    }

    $sid        = (string)$row['session_id'];
    $step       = (int)$row['step'];
    $nonce      = (string)$row['nonce'];
    $accountId  = (int)$row['account_id'];

    $session = sfy_load_session($sid);
    if (!$session) return ['ok' => false, 'reason' => 'session_missing', 'step_token' => $row, 'session' => null, 'account' => null, 'level' => 'reject'];
    if ((int)$session['is_completed'] === 1)
        return ['ok' => false, 'reason' => 'already_completed', 'step_token' => $row, 'session' => $session, 'account' => null, 'level' => 'ignore'];
    if (strtotime((string)$session['expires_at']) < time())
        return ['ok' => false, 'reason' => 'session_expired', 'step_token' => $row, 'session' => $session, 'account' => null, 'level' => 'reject'];
    if (!empty($row['consumed_at'])) {
        /*
         * The return check may have advanced this step already (returned_at +
         * soft_verified). A postback that arrives afterwards is then perfectly
         * normal traffic and must never be charged as a bypass attempt.
         */
        $soft = !empty($row['soft_verified']);
        return ['ok' => false, 'reason' => $soft ? 'already_advanced' : 'nonce_already_used',
                'step_token' => $row, 'session' => $session, 'account' => null,
                'level' => $soft ? 'ignore' : 'bypass',
                'attribution' => (string)($row['_attr'] ?? '')];
    }
    if ($step !== (int)$session['current_step'])
        return ['ok' => false, 'reason' => 'step_out_of_sync', 'step_token' => $row, 'session' => $session, 'account' => null, 'level' => 'bypass'];

    /*
     * The `acct` parameter is a routing *hint*, never proof.
     *
     * One LootLabs dashboard holds ONE postback URL for the whole account, so
     * with account rotation most postbacks necessarily carry an id that does
     * not match the account that served the step — and a stale value typed in
     * months ago (e.g. `acct=1` while the only account is #2) looks exactly the
     * same. The identity of the step is already proven by the single-use nonce
     * or by the session id we handed the provider, so a mismatched hint must
     * not throw a genuine completion away — and must certainly never be
     * recorded as a bypass attempt. It only decides anything when nothing else
     * identified the step.
     */
    $acctTolerated = false;
    if ($acctHint !== '' && (int)$acctHint > 0 && (int)$acctHint !== $accountId) {
        if (!in_array((string)($row['_attr'] ?? ''), ['nonce', 'session'], true)) {
            return ['ok' => false, 'reason' => 'account_mismatch', 'step_token' => $row,
                    'session' => $session, 'account' => null, 'level' => 'bypass'];
        }
        $acctTolerated = true;
    }

    $account = sfy_account_find($accountId) ?? [];

    /*
     * Authentication first (P0-1, 2026-10-24).
     *
     * The step nonce, the session id and the sig all travel in the player's
     * task URL, so none of them proves the caller is the provider. The key
     * below only ever lives in the postback URL configured in the provider's
     * dashboard. A call that cannot present it is refused before the dwell,
     * the attribution and the IP checks are even consulted.
     */
    if ((bool)sfy_cfg('security.postback_key_required', true)
        && !hash_equals(sfy_postback_key($accountId), $key)) {
        return ['ok' => false, 'reason' => 'bad_postback_key', 'step_token' => $row,
                'session' => $session, 'account' => $account, 'level' => 'bypass',
                'attribution' => (string)($row['_attr'] ?? '')];
    }

    // Dwell-time gate — blocks "click and instantly call the postback" bypassing.
    $minSeconds = (int)sfy_setting('min_task_seconds', 4);
    $started    = strtotime((string)($session['step_started_at'] ?? $session['created_at'] ?? 'now'));
    $dwell      = max(0, time() - $started);
    if ($minSeconds > 0 && $dwell < $minSeconds) {
        return ['ok' => false, 'reason' => 'too_fast', 'step_token' => $row, 'session' => $session, 'account' => $account,
                'level' => 'bypass', 'dwell' => $dwell];
    }

    // Signature gate — our own per-step HMAC, or the account's LootLabs hash.
    $expected = sfy_step_signature($sid, $step, $nonce, $accountId);
    $sigOk    = $sig !== '' && (hash_equals($expected, $sig) || hash_equals(substr($expected, 0, 48), $sig));

    $hashOk = false;
    if (!$sigOk && $hashParam !== '' && !empty($account['postback_secret'])) {
        $params = $_GET;
        unset($params['acct'], $params['sub_id'], $params['nonce'], $params['sig']);
        $hashOk = sfy_verify_postback($params, (string)$account['postback_secret']);
    }

    /*
     * Provider attribution.
     *
     * Real LootLabs postbacks only carry the macros configured in their
     * dashboard, so demanding our own `sig` on every call rejected perfectly
     * legitimate completions ("task never verifies"). The step nonce is a
     * 128-bit single-use secret that only the provider ever saw, and the
     * session id is a 192-bit random — a postback carrying either of them is
     * proof the handoff was ours, and the single-use + dwell + step-sync gates
     * below still apply. The IP-only match stays weak and still needs a
     * signature.
     */
    $attr    = (string)($row['_attr'] ?? 'ip');
    $trusted = sfy_postback_attribution_ok($attr, $sigOk, $hashOk);
    $lenient = (bool)sfy_cfg('security.allow_unsigned_postback', false);

    if (!$trusted && !$lenient) {
        return ['ok' => false, 'reason' => $attr === 'ip' ? 'unattributed_ip' : 'bad_signature',
                'step_token' => $row, 'session' => $session, 'account' => $account,
                'level' => 'bypass', 'dwell' => $dwell, 'attribution' => $attr];
    }

    /*
     * IP binding.
     *
     * `{IP}` in a LootLabs postback is the address that did the task, so a
     * genuine call from the player lands on the network the handoff was issued
     * to. A caller who only *has* the step nonce — which travels in the player's
     * own task URL — does not know that address, which is exactly what makes
     * this the one signal a server-side forgery cannot fake. A mismatch is
     * refused (and charged as a bypass attempt) rather than accepted with a
     * different label, which is what it used to do.
     */
    $ipOk  = sfy_postback_ip_ok((string)($row['issued_ip'] ?? ''), (string)$ip);
    if (!$ipOk && sfy_postback_ip_enforced()) {
        return ['ok' => false, 'reason' => 'ip_mismatch', 'step_token' => $row, 'session' => $session,
                'account' => $account, 'level' => 'bypass', 'dwell' => $dwell, 'attribution' => $attr,
                'issued_ip' => (string)($row['issued_ip'] ?? ''), 'postback_ip' => $ip];
    }

    $lvl   = !$trusted ? 'unsigned'
           : ($attr === 'ip' ? 'ip_attributed' : ($ipOk ? 'verified' : 'ip_changed'));

    $attribution = $sigOk ? 'signature' : ($hashOk ? 'hash' : $attr);
    if (!empty($acctTolerated)) $attribution .= '+acct';

    return ['ok' => true, 'reason' => 'ok', 'step_token' => $row, 'session' => $session, 'account' => $account,
            'level' => $lvl, 'dwell' => $dwell, 'signature_ok' => $sigOk, 'hash_ok' => $hashOk,
            'acct_hint_tolerated' => $acctTolerated, 'attribution' => $attribution];
}

/**
 * Advance the session and close the nonce.
 *
 * Ordered and guarded on purpose. The old version consumed the nonce FIRST and
 * ran every statement raw, so a single rejected write threw a 500 at the
 * player *after* the nonce was already spent — stranding the step forever with
 * no way to retry. Now:
 *   1. the session advances (a failure here leaves the nonce open for a retry),
 *   2. the nonce is closed,
 *   3. the token is marked used on the final step.
 * Steps 2 and 3 are logged but never fatal: the player's progress is already
 * safe by then.
 */
function sfy_postback_consume(array $row, array $session, array $account, string $clickId, string $ip, int $dwell): array {
    $sid      = (string)($session['session_id'] ?? '');
    $step     = (int)($session['current_step'] ?? 1);
    $total    = max(1, (int)($session['total_steps'] ?? 1));

    $newStep  = $step + 1;
    $complete = $newStep > $total ? 1 : 0;

    $fail = fn(string $why): array => ['new_step' => $step, 'total' => $total, 'completed' => false,
                                       'advanced' => false, 'errors' => [$why]];

    try {
        $db = sfy_db();
    } catch (Throwable $e) {
        error_log('[SFY] advance aborted: ' . $e->getMessage());
        return $fail('connect: ' . $e->getMessage());
    }

    /* Build the UPDATE defensively: optional columns drop out when the
       updater has not been run on this install yet. */
    $sets   = ['current_step=?', 'is_completed=?'];
    $params = [$newStep, $complete];
    if (sfy_column_exists('sfy_sessions', 'lootlabs_click_id')) {
        $sets[] = "lootlabs_click_id=COALESCE(NULLIF(?,''), lootlabs_click_id)";
        $params[] = $clickId;
    }
    if (sfy_column_exists('sfy_sessions', 'postback_count'))   $sets[] = 'postback_count=postback_count+1';
    if (sfy_column_exists('sfy_sessions', 'last_postback_at')) $sets[] = 'last_postback_at=NOW()';
    if (sfy_column_exists('sfy_sessions', 'step_started_at'))  $sets[] = 'step_started_at=NOW()';
    if (sfy_column_exists('sfy_sessions', 'completed_at')) {
        $sets[] = 'completed_at = IF(?, NOW(), completed_at)';
        $params[] = $complete;
    }
    $params[] = $sid;

    try {
        $db->prepare('UPDATE sfy_sessions SET ' . implode(', ', $sets) . ' WHERE session_id=?')->execute($params);
    } catch (Throwable $e) {
        /* Nothing moved: the nonce stays open so the player can retry the
           step instead of being stuck behind a spent handoff. */
        error_log('[SFY] advance failed for session ' . $sid . ': ' . $e->getMessage());
        return ['new_step' => $step, 'total' => $total, 'completed' => false,
                'advanced' => false, 'errors' => [$e->getMessage()]];
    }

    $errors = [];

    try {
        $db->prepare("UPDATE sfy_step_tokens SET consumed_at=NOW(), attempts=attempts+1 WHERE id=?")->execute([(int)($row['id'] ?? 0)]);
    } catch (Throwable $e) {
        $errors[] = 'nonce: ' . $e->getMessage();
        error_log('[SFY] nonce close failed: ' . $e->getMessage());
    }

    if ($complete) {
        try {
            /*
             * A reusable token is never marked used — the next player must get
             * exactly the same experience as the first. run_count still climbs,
             * so the admin can see how heavily it is being used.
             */
            $tSets = sfy_token_is_multi((string)($session['token'] ?? '')) ? [] : ['is_used=1'];
            $tP    = [];
            if (sfy_column_exists('sfy_tokens', 'used_at'))       $tSets[] = 'used_at=NOW()';
            if (sfy_column_exists('sfy_tokens', 'run_count'))     $tSets[] = 'run_count=run_count+1';
            if (sfy_column_exists('sfy_tokens', 'used_ip'))       { $tSets[] = 'used_ip=?';       $tP[] = $ip; }
            if (sfy_column_exists('sfy_tokens', 'used_device_id')){ $tSets[] = 'used_device_id=?'; $tP[] = (int)($session['device_id'] ?? 0); }
            $tP[] = (string)($session['token'] ?? '');
            if ($tSets) {
                $db->prepare('UPDATE sfy_tokens SET ' . implode(', ', $tSets) . ' WHERE token=?')->execute($tP);
            }
        } catch (Throwable $e) {
            $errors[] = 'token: ' . $e->getMessage();
            error_log('[SFY] token close failed: ' . $e->getMessage());
        }
    }

    return ['new_step' => $newStep, 'total' => $total, 'completed' => $complete === 1,
            'advanced' => true, 'errors' => $errors];
}

/* ── postback diagnostics ──────────────────────────────────────────── */
/**
 * Everything the admin needs to answer "is the provider even calling us?".
 * A postback that never arrives and a postback that arrives but is rejected
 * look identical from the player's side — this tells them apart.
 */
function sfy_postback_health(int $limit = 10): array {
    $empty = ['total' => 0, 'accepted' => 0, 'soft' => 0, 'rejected' => 0,
              'last_at' => null, 'last_ok' => null, 'recent' => [], 'error' => true];

    return sfy_try(function () use ($limit): array {
        $db  = sfy_db();
        $one = $db->query("SELECT COUNT(*) AS total,
                                  COALESCE(SUM(accepted=1),0) AS accepted,
                                  COALESCE(SUM(reason='provider_return'),0) AS soft,
                                  MAX(created_at) AS last_at
                           FROM sfy_postback_log")->fetch() ?: [];
        $ok  = $db->query("SELECT MAX(created_at) AS t FROM sfy_postback_log
                           WHERE accepted=1 AND (reason IS NULL OR reason<>'provider_return')")->fetch() ?: [];

        $attr = sfy_column_exists('sfy_postback_log', 'attribution') ? "COALESCE(attribution,'') AS attribution" : "'' AS attribution";
        $st   = $db->prepare("SELECT session_id, step, ip, nonce, dwell, accepted, verified, reason,
                                     $attr, raw_query, created_at
                              FROM sfy_postback_log
                              WHERE reason IS NULL OR reason NOT LIKE 'task_handoff%'
                              ORDER BY id DESC LIMIT ?");
        $st->bindValue(1, max(1, $limit), PDO::PARAM_INT);
        $st->execute();

        return [
            'total'    => (int)($one['total'] ?? 0),
            'accepted' => (int)($one['accepted'] ?? 0),
            'soft'     => (int)($one['soft'] ?? 0),
            'rejected' => max(0, (int)($one['total'] ?? 0) - (int)($one['accepted'] ?? 0)),
            'last_at'  => $one['last_at'] ?? null,
            'last_ok'  => $ok['t'] ?? null,
            'recent'   => $st->fetchAll(),
            'error'    => false,
        ];
    }, $empty);
}

/** Force the nonce for a step closed (admin action / expiry sweeper). */
function sfy_step_close(string $sid, int $step): void {
    sfy_db()->prepare("UPDATE sfy_step_tokens SET consumed_at=NOW() WHERE session_id=? AND step=? AND consumed_at IS NULL")
             ->execute([$sid, $step]);
}

/**
 * Should an unsigned postback be required to carry the single-use step nonce?
 *
 * Ships off. When on, a postback that arrives without a signature must be
 * attributed by the nonce (or the session id) we handed the provider — the
 * IP-only match, which is the weakest accepted level and satisfiable by a
 * residential proxy, is refused. Turn on only after confirming the LootLabs
 * dashboard's postback URL carries {CLICK_ID} (the value of the &puid on the
 * task link, which is where the nonce rides).
 */
function sfy_postback_require_nonce(): bool {
    $raw = strtolower(trim((string)sfy_config_get('set_postback_require_nonce', '')));
    if ($raw === '') return (bool)sfy_cfg('security.postback_require_nonce', false);
    return !in_array($raw, ['0', 'off', 'no', 'false'], true);
}
