<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY ULTIMATE — HUMAN CHECK (Cloudflare Turnstile)
 *
 *  A bot must not be able to *start* a verification.
 *
 *  Everything after the start is already signed, single-use and dwell
 *  gated: the step nonce is one-time, the postback must carry it, and a
 *  return only counts when the provider's own domain performed it. The one
 *  request in the whole flow that costs nothing and produces a session row
 *  is the claim link — and that is exactly the request a script can hammer.
 *  This module puts a challenge in front of *that* moment and nowhere else.
 *
 *  ── what the gate protects ──────────────────────────────────────────
 *   `claim`  before a verification session is created (shipped default)
 *   `admin`  before a staff sign-in is even attempted
 *
 *  Both are checkboxes in Admin → Settings → BOT CHECK, both are off until
 *  an owner switches them on, and neither touches the anti-bypass chain —
 *  a solved challenge opens a door, it never confirms a step. The code
 *  hand-off for an already finished token is deliberately *not* gated: the
 *  player who finished the work must get their code back without solving
 *  anything a second time.
 *
 *  ── why this can never brick the site ───────────────────────────────
 *  A challenge is only ever *demanded* when the install can actually check
 *  it: the toggle is on, both keys are filled in, and this host can make an
 *  outbound HTTPS request (curl, or allow_url_fopen). A half-configured
 *  toggle therefore blocks nobody — it reports itself in Admin → Security
 *  → BOT CHECKS instead, which is the failure mode an owner wants: a bot
 *  gate that is misconfigured must not lock real players out of a page they
 *  cannot pass.
 *
 *  A refused verification is then a separate decision from a *broken* one:
 *    • Cloudflare answered and said no       → refuse this request;
 *    • Cloudflare answered "wrong secret"    → that is the owner's
 *      configuration, not the player's problem, so nobody is refused and
 *      the panel says so in plain words;
 *    • Cloudflare could not be reached at all → the **fail mode** decides.
 *      It ships as *stay open* (no player is punished for the check's own
 *      provider being down) and switches to *strict* in the panel.
 *
 *  ── what a pass is worth ────────────────────────────────────────────
 *  One challenge per *verification run*, not per request. The pass lands on
 *  the session row (`sfy_sessions.captcha_passed_at`) so the claim page
 *  never asks twice for the same run, and a staff sign-in remembers the
 *  browser for the session it just opened. When that column is missing
 *  (the updater has not been run yet) the pass falls back to the PHP
 *  session, so the player is never asked in a loop while the install is
 *  half-upgraded.
 *
 *  ── everything in one place ─────────────────────────────────────────
 *  Settings, the outbound call, the widget markup, the pass memory, the
 *  refusal copy and the log all live here, so a page only ever says
 *  "is a challenge needed, and did this one pass?" — see
 *  sfy_captcha_needed() and sfy_captcha_check().
 * ═══════════════════════════════════════════════════════════════════════
 */

/** Where a challenge can stand. Adding one here is a checkbox + a caller. */
function sfy_captcha_contexts(): array { return ['claim', 'admin']; }

/** How an owner reads that context in the panel. */
function sfy_captcha_context_label(string $ctx): string {
    return [
        'claim' => 'before a verification starts (the claim link)',
        'admin' => 'before a staff sign-in',
    ][$ctx] ?? $ctx;
}

/** One stored truthy value ('1', 'on', 'yes', 'true'). */
function sfy_captcha_on($v): bool {
    return in_array(strtolower(trim((string)$v)), ['1', 'on', 'yes', 'true'], true);
}

/* ── configuration ─────────────────────────────────────────────────────
   Database value first, then `config/config.php`, then the shipped
   default — the same order every other runtime switch in this install
   uses. An install that configured Turnstile in config.php keeps working
   untouched: the panel simply shows its values and can override them. */

function sfy_captcha_enabled(): bool {
    $v = sfy_config_get('set_turnstile_enabled', null);
    if ($v === null || $v === '') return (bool)sfy_cfg('turnstile.enabled', false);
    return sfy_captcha_on($v);
}

function sfy_captcha_site_key(): string {
    $v = trim((string)sfy_config_get('set_turnstile_site_key', ''));
    return $v !== '' ? $v : trim((string)sfy_cfg('turnstile.site_key', ''));
}

function sfy_captcha_secret(): string {
    $v = trim((string)sfy_config_get('set_turnstile_secret', ''));
    return $v !== '' ? $v : trim((string)sfy_cfg('turnstile.secret', ''));
}

/** dark (default) | light | auto — the widget's own appearance, not the site's. */
function sfy_captcha_theme(): string {
    $v = strtolower(trim((string)sfy_config_get('set_turnstile_theme', '')));
    return in_array($v, ['dark', 'light', 'auto'], true) ? $v : 'dark';
}

/**
 * Stay open (shipped) or strict when Cloudflare cannot be reached.
 *
 * Not a checkbox: `open` is "keep the site usable", `strict` is "refuse
 * anybody we could not check". Both are legitimate — a site under an active
 * bot flood may want strict — so it is spelled out as a choice with the
 * consequence written next to it.
 */
function sfy_captcha_fail_open(): bool {
    $v = strtolower(trim((string)sfy_config_get('set_turnstile_fail_mode', '')));
    if (!in_array($v, ['open', 'strict'], true)) $v = 'open';
    return $v === 'open';
}

/**
 * Is this context gated at all? Not stored = the shipped answer, which is
 * "the claim page, and nothing else" — so flipping only `turnstile.enabled`
 * in config.php behaves exactly like it did before the panel existed.
 */
function sfy_captcha_at(string $ctx): bool {
    $v = sfy_config_get('set_turnstile_at_' . $ctx, null);
    if ($v === null || $v === '') return $ctx === 'claim';
    return sfy_captcha_on($v);
}

/** How this host can post to Cloudflare: curl | stream | none. */
function sfy_captcha_transport(): string {
    if (function_exists('curl_init')) return 'curl';
    if (sfy_captcha_on(ini_get('allow_url_fopen'))) return 'stream';
    return 'none';
}

/**
 * Can a challenge actually be checked right now?
 *
 * This — not `enabled` — is what a page asks before it refuses anybody. A
 * missing key, a disabled toggle or a host that cannot open an outbound
 * connection all answer "no", which means the gate steps aside and the
 * panel reports why.
 */
function sfy_captcha_ready(): bool {
    return sfy_captcha_enabled()
        && sfy_captcha_site_key() !== ''
        && sfy_captcha_secret() !== ''
        && sfy_captcha_transport() !== 'none';
}

/** Why the check cannot run, in plain words (empty list = it can). */
function sfy_captcha_problems(): array {
    if (!sfy_captcha_enabled()) return [];
    $out = [];
    if (sfy_captcha_site_key() === '') $out[] = 'the site key is empty';
    if (sfy_captcha_secret() === '')  $out[] = 'the secret key is empty';
    if (sfy_captcha_transport() === 'none') {
        $out[] = 'this host cannot make outbound HTTPS requests (no curl and allow_url_fopen is off)';
    }
    return $out;
}

/** The gate is on for this context *and* this install can enforce it. */
function sfy_captcha_wanted(string $ctx): bool {
    return sfy_captcha_ready() && sfy_captcha_at($ctx);
}

/* ── pass memory ─────────────────────────────────────────────────────── */

/**
 * The browser-level mark, for a context that has no session row of its own
 * (the staff sign-in) or as the fallback while the session column is still
 * missing. Bounded, so a stale mark cannot stand in for a fresh check.
 */
function sfy_captcha_browser_mark(string $ctx): void {
    $_SESSION['sfy_captcha'][$ctx] = time();
}

function sfy_captcha_browser_passed(string $ctx): bool {
    $t = (int)($_SESSION['sfy_captcha'][$ctx] ?? 0);
    if ($t <= 0) return false;
    if (time() - $t > 1800) {                 // half an hour
        unset($_SESSION['sfy_captcha'][$ctx]);
        return false;
    }
    return true;
}

/** Has *this verification run* already passed the challenge? */
function sfy_captcha_run_passed(?array $sess): bool {
    if (!$sess) return false;
    if (!sfy_column_exists('sfy_sessions', 'captcha_passed_at')) {
        return sfy_captcha_browser_passed('claim');
    }
    $t = trim((string)($sess['captcha_passed_at'] ?? ''));
    return $t !== '' && $t !== '0000-00-00 00:00:00';
}

/** Remember that this run is checked, so it is never asked twice. */
function sfy_captcha_mark_run(string $sid): void {
    sfy_captcha_browser_mark('claim');
    if ($sid === '') return;
    sfy_try(function () use ($sid) {
        if (!sfy_column_exists('sfy_sessions', 'captcha_passed_at')) return null;
        sfy_db()->prepare('UPDATE sfy_sessions SET captcha_passed_at=NOW() WHERE session_id=?')->execute([$sid]);
        return null;
    }, null);
}

/**
 * Forget every pass — used by the reset paths (a session that starts over
 * earns its challenge again) and by the admin when a run looks automated.
 */
function sfy_captcha_reset(?string $sid = null, string $ctx = ''): void {
    if ($ctx === '') unset($_SESSION['sfy_captcha']);
    else            unset($_SESSION['sfy_captcha'][$ctx]);

    if ($sid === null || $sid === '') return;
    sfy_try(function () use ($sid) {
        if (!sfy_column_exists('sfy_sessions', 'captcha_passed_at')) return null;
        sfy_db()->prepare('UPDATE sfy_sessions SET captcha_passed_at=NULL WHERE session_id=?')->execute([$sid]);
        return null;
    }, null);
}

/**
 * Does this request have to solve a challenge before it may proceed?
 *
 * $sess is the run being resumed (null when nothing has started yet).
 */
function sfy_captcha_needed(string $ctx, ?array $sess = null): bool {
    if (!sfy_captcha_wanted($ctx)) return false;
    if ($ctx === 'claim') return !sfy_captcha_run_passed($sess);
    return !sfy_captcha_browser_passed($ctx);
}

/* ── the outbound call ───────────────────────────────────────────────── */

/**
 * POST to Cloudflare, with the answer as a string (null = we never heard
 * back, which is a *transport* failure and not a verdict about the player).
 *
 * `$GLOBALS['SFY_CAPTCHA_HTTP']` may be a callable returning a canned
 * response; the tests use it so the verdict logic is exercised without a
 * network. It is not a configuration hook — nothing in the panel or the
 * request can set it.
 */
function sfy_captcha_http(string $url, array $fields): ?string {
    $override = $GLOBALS['SFY_CAPTCHA_HTTP'] ?? null;
    if (is_callable($override)) {
        $r = $override($url, $fields);
        return is_string($r) && $r !== '' ? $r : null;
    }

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => http_build_query($fields),
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_CONNECTTIMEOUT => 6,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $body = curl_exec($ch);
        $err  = curl_error($ch);
        curl_close($ch);
        if (!is_string($body) || $body === '') {
            error_log('[SFY] captcha transport: ' . ($err !== '' ? $err : 'empty response'));
            return null;
        }
        return $body;
    }

    if (!sfy_captcha_on(ini_get('allow_url_fopen'))) return null;

    $ctx = stream_context_create(['http' => [
        'method'        => 'POST',
        'header'        => "Content-Type: application/x-www-form-urlencoded\r\n",
        'content'       => http_build_query($fields),
        'timeout'       => 10,
        'ignore_errors' => true,
        'user_agent'    => 'SFY-Ultimate/' . (defined('SFY_VERSION') ? SFY_VERSION : '0'),
    ]]);
    $body = @file_get_contents($url, false, $ctx);
    return is_string($body) && $body !== '' ? $body : null;
}

function sfy_captcha_siteverify_url(): string {
    return 'https://challenges.cloudflare.com/turnstile/v0/siteverify';
}

/**
 * Ask Cloudflare about one response token.
 *
 * @return array{ok:bool,why:string,codes:string}
 *   why: ok | disabled | unconfigured | missing_response | rejected |
 *        expired | misconfigured | unreachable | bad_response
 */
function sfy_captcha_verify(string $response, string $ip = ''): array {
    $no = fn(string $why, string $codes = '', string $detail = ''): array =>
        ['ok' => false, 'why' => $why, 'codes' => $codes, 'detail' => $detail];

    if (!sfy_captcha_enabled())                                  return ['ok' => true, 'why' => 'disabled', 'codes' => '', 'detail' => ''];
    if (sfy_captcha_site_key() === '' || sfy_captcha_secret() === '') return $no('unconfigured');
    if (sfy_captcha_transport() === 'none')                      return $no('unreachable', '', 'no transport');

    $response = trim($response);
    if ($response === '') return $no('missing_response');
    if (strlen($response) > 4096) $response = substr($response, 0, 4096);   // sanity, not security

    $body = sfy_captcha_http(sfy_captcha_siteverify_url(), [
        'secret'   => sfy_captcha_secret(),
        'response' => $response,
        'remoteip' => $ip,
    ]);
    if ($body === null) return $no('unreachable', '', 'no answer');

    $j = json_decode($body, true);
    if (!is_array($j)) return $no('bad_response', '', substr($body, 0, 120));
    if (!empty($j['success'])) return ['ok' => true, 'why' => 'ok', 'codes' => '', 'detail' => ''];

    $codes = is_array($j['error-codes'] ?? null)
        ? implode(',', array_map(static fn($c) => (string)$c, $j['error-codes']))
        : (string)($j['error-codes'] ?? '');

    /*
     * Which refusal is this?
     *
     *   invalid-input-secret / missing-input-secret — *our* secret is wrong.
     *     Nobody is refused for that: the panel shows it and the gate steps
     *     aside, otherwise a typo in a key would take the whole flow down.
     *   timeout-or-duplicate — the player took too long or the token was
     *     already spent (a page reload with an old token lands here).
     *     Solvable by the player: "tick it again".
     *   internal-error — Cloudflare's own problem, treated like an
     *     unreachable service so the fail mode decides.
     */
    $why = 'rejected';
    if (str_contains($codes, 'invalid-input-secret') || str_contains($codes, 'missing-input-secret')) {
        $why = 'misconfigured';
    } elseif (str_contains($codes, 'timeout-or-duplicate')) {
        $why = 'expired';
    } elseif (str_contains($codes, 'internal-error')) {
        $why = 'unreachable';
    }
    return ['ok' => false, 'why' => $why, 'codes' => $codes, 'detail' => ''];
}

/** The player-facing sentence for a verdict (never a dead end). */
function sfy_captcha_error_text(string $why): string {
    switch ($why) {
        case '':
        case 'ok':
            return '';
        case 'missing_response':
            return 'Complete the human check below, then press the button again.';
        case 'expired':
            return 'That human check expired or was already used. Tick the box again and continue.';
        case 'rejected':
            return 'The human check could not verify this browser. Reload the page, tick the box again and continue.';
        case 'misconfigured':
            return 'This site has not finished configuring its human check, so it is not being enforced. You can continue.';
        case 'unreachable':
            return 'The human check service could not be reached from this site. Please try again in a moment.';
        case 'unconfigured':
            return 'This site has not configured its human check yet, so it is not being enforced. You can continue.';
        default:
            return 'Human verification failed. Complete the challenge and try again.';
    }
}

/**
 * Verify one submitted response and record what happened.
 *
 * This is the only entry point a page needs after the challenge: it decides
 * the verdict (including the fail mode), writes the log row and — when the
 * run is allowed — remembers the pass so the same run is never asked twice.
 *
 * @return array{ok:bool,why:string,codes:string,fail_open:bool,message:string}
 */
function sfy_captcha_check(string $ctx, string $sid, string $response, string $ip = ''): array {
    $v        = sfy_captcha_verify($response, $ip);
    $ok       = (bool)$v['ok'];
    $failOpen = false;

    /*
     * The verdicts that are *our* problem rather than the player's — a wrong
     * secret, an unfinished configuration, an unreachable service, a reply we
     * could not parse — honour the fail mode. A verdict Cloudflare actually
     * made about this token (`rejected`, `expired`, `missing_response`) never
     * does: that is the answer the gate exists to get, and switching the fail
     * mode on must never turn it into a pass.
     *
     * One context is exempt from the fail mode entirely: the staff sign-in.
     * A gate that can lock the owner out of the panel that switches the gate
     * off is a trap, not a gate — so a sign-in is never refused for a failure
     * on our side (the password, the lockout and every attempt being logged
     * all still apply). Cloudflare's own refusal still refuses.
     */
    $ourFailure = in_array((string)$v['why'], ['misconfigured', 'unreachable', 'bad_response', 'unconfigured'], true);
    if (!$ok && $ourFailure && ($ctx === 'admin' || sfy_captcha_fail_open())) {
        $ok = true;
        $failOpen = true;
    }

    $outcome = $ok ? ($failOpen ? 'open' : 'passed') : (string)$v['why'];
    sfy_captcha_log($ctx, $outcome, (string)$v['why'], (string)$v['codes'], $sid, $ip);

    if ($ok) {
        sfy_captcha_browser_mark($ctx);
        if ($ctx === 'claim') sfy_captcha_mark_run($sid);
    }

    return [
        'ok'        => $ok,
        'why'       => (string)$v['why'],
        'codes'     => (string)$v['codes'],
        'fail_open' => $failOpen,
        'message'   => $ok ? '' : sfy_captcha_error_text((string)$v['why']),
    ];
}

/* ── the widget ──────────────────────────────────────────────────────── */

/** The visitor's language, so the challenge speaks to them (never a URL). */
function sfy_captcha_language(): string {
    $raw = strtolower(trim((string)($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '')));
    if ($raw === '') return 'auto';
    $first = trim(explode(',', $raw)[0]);
    $first = trim(explode(';', $first)[0]);
    /* 2–3 letter primary tag ("fil", "en"), optional region ("pt-br"). */
    return preg_match('/^[a-z]{2,3}(-[a-z]{2,4})?$/', $first) === 1 ? $first : 'auto';
}

/**
 * The challenge itself: Cloudflare's own markup, plus its script exactly
 * once per page.
 *
 * Renders nothing when the install cannot enforce the check, so a page can
 * call it unconditionally and still not print a broken widget on a site
 * that has no keys yet.
 */
function sfy_captcha_widget(array $opts = []): string {
    if (!sfy_captcha_ready()) return '';

    static $scripted = false;
    $out = '<div class="cf-turnstile" data-sitekey="' . sfy_esc(sfy_captcha_site_key()) . '"'
         . ' data-theme="' . sfy_esc(sfy_captcha_theme()) . '"'
         . ' data-language="' . sfy_esc(sfy_captcha_language()) . '"'
         . (empty($opts['compact']) ? '' : ' data-size="compact"')
         . (empty($opts['callback']) ? '' : ' data-callback="' . sfy_esc((string)$opts['callback']) . '"')
         . '></div>';

    if (!$scripted) {
        $scripted = true;
        $out .= '<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>';
    }
    return $out;
}

/* ── the log ─────────────────────────────────────────────────────────── */

/**
 * One row per decided challenge. Only *decisions* are written — never a
 * plain page view — so the table answers "did the gate let people in, and
 * what did it turn away?" without drowning in first visits.
 */
function sfy_captcha_log(string $ctx, string $outcome, string $why, string $codes, string $sid, string $ip): void {
    sfy_try(function () use ($ctx, $outcome, $why, $codes, $sid, $ip) {
        if (!sfy_table_exists('sfy_captcha_log')) return null;
        sfy_db()->prepare("INSERT INTO sfy_captcha_log
                (context, outcome, reason, codes, session_id, ip, user_agent, created_at)
                VALUES (?,?,?,?,?,?,?,NOW())")
           ->execute([
               substr($ctx, 0, 16),
               substr($outcome, 0, 24),
               substr($why, 0, 32),
               substr($codes, 0, 191),
               substr($sid, 0, 64),
               substr($ip !== '' ? $ip : sfy_client_ip(), 0, 64),
               substr(sfy_user_agent(), 0, 512),
           ]);
        return null;
    }, null);
}

function sfy_captcha_recent(int $limit = 40): array {
    return (array)sfy_try(function () use ($limit): array {
        if (!sfy_table_exists('sfy_captcha_log')) return [];
        $st = sfy_db()->prepare("SELECT * FROM sfy_captcha_log ORDER BY id DESC LIMIT ?");
        $st->bindValue(1, max(1, $limit), PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll();
    }, []);
}

/**
 * How the gate behaved in the window.
 * passed = a real player (or a patient bot) solved it,
 * open   = we could not check and let the request through anyway,
 * refused = a challenge was demanded and not solved.
 */
function sfy_captcha_stats(int $hours = 24): array {
    $empty = ['passed' => 0, 'open' => 0, 'refused' => 0, 'total' => 0];
    return (array)sfy_try(function () use ($hours, $empty): array {
        if (!sfy_table_exists('sfy_captcha_log')) return $empty;
        $st = sfy_db()->prepare("SELECT
                SUM(outcome='passed') AS passed,
                SUM(outcome='open')   AS open,
                SUM(outcome NOT IN ('passed','open')) AS refused,
                COUNT(*)              AS total
              FROM sfy_captcha_log WHERE created_at > " . sfy_sql_now_offset('HOUR'));
        $st->execute([-max(1, $hours)]);
        $r = $st->fetch() ?: [];
        return [
            'passed'  => (int)($r['passed'] ?? 0),
            'open'    => (int)($r['open'] ?? 0),
            'refused' => (int)($r['refused'] ?? 0),
            'total'   => (int)($r['total'] ?? 0),
        ];
    }, $empty);
}

/** Verification runs that passed the challenge (i.e. how many were gated). */
function sfy_captcha_gated_runs(int $hours = 24): int {
    return (int)sfy_try(function () use ($hours): int {
        if (!sfy_column_exists('sfy_sessions', 'captcha_passed_at')) return 0;
        $st = sfy_db()->prepare("SELECT COUNT(*) AS n FROM sfy_sessions
                                  WHERE captcha_passed_at IS NOT NULL
                                    AND captcha_passed_at > " . sfy_sql_now_offset('HOUR'));
        $st->execute([-max(1, $hours)]);
        return (int)($st->fetch()['n'] ?? 0);
    }, 0);
}

function sfy_captcha_clear_log(): int {
    return (int)sfy_try(function (): int {
        if (!sfy_table_exists('sfy_captcha_log')) return 0;
        return (int)sfy_db()->exec("DELETE FROM sfy_captcha_log");
    }, 0);
}

/** The wording the admin panel shows for one log row. */
function sfy_captcha_outcome_badge(string $outcome): array {
    return [
        'passed'        => ['PASSED',  'g'],
        'open'          => ['OPEN',    'y'],
        'rejected'      => ['REFUSED', 'r'],
        'expired'       => ['EXPIRED', 'y'],
        'missing_response' => ['NO TOKEN', 'gr'],
        'misconfigured' => ['BAD KEYS', 'r'],
        'unreachable'   => ['UNREACHABLE', 'r'],
        'bad_response'  => ['BAD REPLY', 'r'],
        'unconfigured'  => ['UNSET', 'gr'],
    ][$outcome] ?? [strtoupper($outcome), 'gr'];
}

/* ── diagnostics ─────────────────────────────────────────────────────── */

/**
 * One-click key check for the panel.
 *
 * Cloudflare is asked to verify a deliberately bogus token. That separates
 * the two failures an owner actually hits:
 *
 *   invalid-input-response → the *secret* is right and only our dummy token
 *                            was rejected. Keys work.
 *   invalid-input-secret   → the secret itself is wrong (copied from another
 *                            widget, or the key was rotated). Nothing would
 *                            ever pass, and with the fail mode on `open` the
 *                            gate would silently stop enforcing anything.
 *
 * @return array{ok:bool,why:string,text:string,codes:string}
 */
function sfy_captcha_selftest(): array {
    if (!sfy_captcha_enabled()) {
        return ['ok' => false, 'why' => 'disabled', 'text' => 'The human check is switched off, so nothing is enforced.', 'codes' => ''];
    }
    if (sfy_captcha_site_key() === '' || sfy_captcha_secret() === '') {
        return ['ok' => false, 'why' => 'unconfigured', 'text' => 'Both the site key and the secret key are required before the check can run.', 'codes' => ''];
    }
    if (sfy_captcha_transport() === 'none') {
        return ['ok' => false, 'why' => 'unreachable', 'codes' => '',
                'text' => 'This host cannot make outbound HTTPS requests (no curl, allow_url_fopen off), so no challenge could ever be verified.'];
    }

    $body = sfy_captcha_http(sfy_captcha_siteverify_url(), [
        'secret'   => sfy_captcha_secret(),
        'response' => 'sfy-selftest-' . bin2hex(random_bytes(8)),
    ]);
    if ($body === null) {
        return ['ok' => false, 'why' => 'unreachable', 'codes' => '',
                'text' => 'Cloudflare could not be reached from this host. With the fail mode on "stay open" players still get through; on "strict" they would not.'];
    }

    $j     = json_decode($body, true);
    $codes = is_array($j['error-codes'] ?? null) ? implode(',', array_map('strval', $j['error-codes'])) : '';
    if (!is_array($j)) {
        return ['ok' => false, 'why' => 'bad_response', 'codes' => '', 'text' => 'Cloudflare answered something unexpected: ' . substr($body, 0, 160)];
    }
    if (str_contains($codes, 'invalid-input-secret') || str_contains($codes, 'missing-input-secret')) {
        return ['ok' => false, 'why' => 'misconfigured', 'codes' => $codes,
                'text' => 'Cloudflare rejected the SECRET KEY (' . $codes . '). Copy the secret from the Turnstile widget that owns this site key — with this key nothing can ever pass.'];
    }
    if (str_contains($codes, 'invalid-input-response') || str_contains($codes, 'missing-input-response')) {
        return ['ok' => true, 'why' => 'ok', 'codes' => $codes,
                'text' => 'Both keys are accepted: Cloudflare rejected the throwaway token, which is exactly what a working install looks like.'];
    }
    return ['ok' => true, 'why' => 'ok', 'codes' => $codes, 'text' => 'Cloudflare answered without an error for the throwaway token (codes: ' . ($codes !== '' ? $codes : 'none') . ').'];
}
