<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY ULTIMATE — CORE BOOTSTRAP
 *  Loads config, opens the database, exposes shared helpers and then
 *  pulls in every other module. Include this (or the legacy `sfy_core.php`
 *  shim) from any entry point.
 * ═══════════════════════════════════════════════════════════════════════
 */

if (defined('SFY_CORE_LOADED')) return;
define('SFY_CORE_LOADED', true);

define('SFY_ROOT', dirname(__DIR__));
define('SFY_APP', SFY_ROOT . '/app');

/* ── config ────────────────────────────────────────────────────────── */
$SFY = require SFY_ROOT . '/config/config.php';
if (is_file(SFY_ROOT . '/config/config.local.php')) {
    $local = require SFY_ROOT . '/config/config.local.php';
    if (is_array($local)) $SFY = array_replace_recursive($SFY, $local);
}
$GLOBALS['SFY_CFG'] = $SFY;

function sfy_cfg(string $path, $default = null) {
    $node = $GLOBALS['SFY_CFG'] ?? [];
    foreach (explode('.', $path) as $k) {
        if (!is_array($node) || !array_key_exists($k, $node)) return $default;
        $node = $node[$k];
    }
    return $node;
}

/* ── legacy constants (kept so every old include path still works) ── */
define('SFY_DB_HOST', (string)sfy_cfg('db.host'));
define('SFY_DB_USER', (string)sfy_cfg('db.user'));
define('SFY_DB_PASS', (string)sfy_cfg('db.pass'));
define('SFY_DB_NAME', (string)sfy_cfg('db.name'));
define('SFY_DOMAIN', rtrim((string)sfy_cfg('app.domain'), '/'));
define('SFY_APP_NAME', (string)sfy_cfg('app.name', 'SFY ULTIMATE'));
define('SFY_VERSION', (string)sfy_cfg('app.version', '6.0.0'));
define('SFY_POSTBACK_SECRET', (string)sfy_cfg('security.postback_secret'));
define('SFY_SESSION_TTL', (int)sfy_cfg('security.session_ttl_minutes', 30));
define('SFY_ADMIN_TTL', (int)sfy_cfg('security.admin_ttl_minutes', 90));
define('SFY_DEBUG', (bool)sfy_cfg('app.debug', false));
/*
 * There used to be SFY_TURNSTILE_SITE_KEY / SFY_TURNSTILE_SECRET constants
 * here, read straight from config.php. They are gone on purpose: the keys are
 * editable in Admin → Settings now, and a constant that only ever saw the
 * file would have kept a *second* source of truth — an install whose owner
 * pasted new keys into the panel would still have served the old widget, with
 * no way to see why. Use sfy_captcha_site_key() / sfy_captcha_secret().
 */

/* ── error handling ────────────────────────────────────────────────── */
error_reporting(SFY_DEBUG ? E_ALL : (E_ALL & ~E_DEPRECATED & ~E_NOTICE));
@ini_set('display_errors', SFY_DEBUG ? '1' : '0');
@ini_set('log_errors', '1');
@ini_set('error_log', SFY_ROOT . '/storage/php-errors.log');
if (!is_dir(SFY_ROOT . '/storage')) @mkdir(SFY_ROOT . '/storage', 0755, true);

date_default_timezone_set((string)sfy_cfg('app.timezone', 'UTC'));

if (session_status() === PHP_SESSION_NONE) {
    @session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => !empty($_SERVER['HTTPS']),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    @session_start();
}

/* ── crash handling ───────────────────────────────────────────────────
   A fatal error must never produce the host's blank "This page isn't
   working" screen: log the detail and show the themed error page instead.
   The technical message is shown to admins (or in debug mode) only. */
function sfy_crash_detail(): bool {
    return SFY_DEBUG || !empty($_SESSION['sfy_admin']) || sfy_diag_active();
}

/*
 * Owner diagnostics gate.
 *
 * Hiding the technical cause from players is right, but it used to leave the
 * owner with nothing to act on: "Something broke" with no way to learn *what*
 * broke short of a staff sign-in on the same browser. Opening the claim link
 * with ?sfy_key=<app.app_key> — the install's own signing secret, the one that
 * already signs every step handoff — reveals the cause on the page for that
 * browser for an hour, so a broken flow can be reproduced and read directly.
 *
 * The key is compared in constant time, never echoed, and never logged; without
 * it nothing about the failure is exposed. See also the receiver's ping probe
 * (/api/hook.php?ping=1&sfy_key=…), which returns the server's own log tail and
 * a live session-insert probe so an owner can hand a developer real evidence.
 */
function sfy_diag_key_ok(): bool {
    $given = (string)sfy_param('sfy_key', '');
    if ($given === '') return false;
    $key = (string)sfy_cfg('app.app_key', '');
    return $key !== '' && hash_equals($key, $given);
}

/**
 * A fingerprint of the code this install is actually running.
 *
 * Every deployment here is a hand-made upload (a File Manager drag, an FTP
 * client, a zip whose extraction half-finished), so "I uploaded it" and "the
 * server runs it" are different claims — and a stale file leaves no trace on a
 * page: it just keeps answering with the error the *old* code raised. The
 * receiver's ping already says whether an upload landed; this makes it exact.
 *
 * Compute the same value locally with:
 *
 *   php -r 'require "app/core.php"; echo sfy_app_fingerprint(), "\n";'
 *
 * If the two do not match, the upload is not what you think it is — before
 * debugging anything else. The hash covers only our own PHP sources (never
 * config/config.php, which holds the keys, and never storage/).
 */
function sfy_app_fingerprint(): string {
    /* Memoised in a global (like the schema cache) so a caller can force a
       recount after touching a file — and so a test can prove the stamp moves. */
    if (isset($GLOBALS['SFY_BUILD_FP'])) return (string)$GLOBALS['SFY_BUILD_FP'];

    $parts = [];
    $walk  = function (string $dir) use (&$walk, &$parts): void {
        $base = SFY_ROOT . '/' . $dir;
        if (!is_dir($base)) return;
        foreach ((array)scandir($base) as $entry) {
            if ($entry === '.' || $entry === '..') continue;
            $path = $base . '/' . $entry;
            if (is_dir($path)) { $walk($dir . '/' . $entry); continue; }
            if (!str_ends_with($entry, '.php')) continue;
            $parts[$dir . '/' . $entry] = (string)@hash_file('md5', $path);
        }
        ksort($parts);
    };
    foreach (['app', 'pages', 'api', 'admin'] as $dir) $walk($dir);

    return $GLOBALS['SFY_BUILD_FP'] = substr(sha1(implode('|', array_map(
        static fn($k) => $k . ':' . $parts[$k], array_keys($parts)
    ))), 0, 12);
}

/** Is this browser a diagnostics viewer (key just given, or given < 1 h ago)? */
function sfy_diag_active(): bool {
    if (sfy_diag_key_ok()) { $_SESSION['sfy_dbg'] = time(); return true; }
    $t = (int)($_SESSION['sfy_dbg'] ?? 0);
    return $t > 0 && (time() - $t) < 3600;
}

/**
 * Turn a raw throwable into a plain-English cause a visitor can act on.
 * Only fixed, safe text is exposed — never the raw message.
 * @return array{0:string,1:string} [public reason, staff-only detail]
 */
function sfy_crash_explain(Throwable $e): array {
    $raw = $e->getMessage();
    $low = strtolower($raw);

    // Missing table / column → the database updater has not finished.
    if (str_contains($low, 'unknown column') || str_contains($low, "doesn't exist")
        || str_contains($low, 'base table or view not found') || str_contains($low, 'unknown table')) {
        return [
            'The database is missing part of its structure, so verification cannot start. An administrator needs to run Admin → Updater → RUN UPDATER once.',
            'schema error: ' . $raw,
        ];
    }
    if (str_contains($low, 'access denied') || str_contains($low, '1045')) {
        return ['The database rejected the stored credentials. Check config/config.php.', 'database credentials: ' . $raw];
    }
    if (str_contains($low, 'could not find driver')) {
        return ['The PHP MySQL driver (pdo_mysql) is not enabled on this host.', 'missing driver: ' . $raw];
    }
    if (str_contains($low, 'connection refused') || str_contains($low, 'timed out')
        || str_contains($low, 'server has gone away') || str_contains($low, 'too many connections')) {
        return ['The database server is unreachable right now. Please retry in a moment.', 'database unreachable: ' . $raw];
    }
    if (str_contains($low, 'too many connections')) {
        return ['The database is at its connection limit. Please retry in a moment.', $raw];
    }

    return [
        'Something unexpected broke on the server. The details have been logged for the administrator.',
        $raw,
    ];
}


function sfy_render_crash(Throwable $e): void {
    $where = basename($e->getFile()) . ':' . $e->getLine();
    $raw   = $e->getMessage();

    /* A short, stable reference ties the screen a *player* is looking at to the
       exact line in the admin error log — without leaking file paths or SQL to
       the public. The same ref is printed on the page, so "it broke" becomes
       something the owner can look up in one paste. */
    $ref = strtoupper(substr(sha1($where . '|' . $raw), 0, 8));
    /* The class is logged and shown next to the ref: it costs nothing, leaks no
       path or SQL, and immediately separates "the database said no" from "our
       own code threw" when an owner reports a ref. */
    $cls = get_class($e);
    error_log('[SFY] crash [ref ' . $ref . '] ' . $cls . ': ' . $raw . ' @ ' . $where);

    if (!headers_sent()) http_response_code(500);

    try {
        [$reason, $tech] = sfy_crash_explain($e);
        $show   = sfy_crash_detail();
        $title  = 'Something broke';
        $code   = 500;
        $schema = str_starts_with($tech, 'schema error:');
        $opts   = ['retry' => sfy_url(''), 'admin' => $schema, 'reason' => $reason, 'ref' => $ref, 'cls' => $cls];
        if (!$show) {
            /* Tell the owner how to unmask this page instead of making them
               guess — a ref with no cause is what turned one broken statement
               into a week of "still the same error". */
            $opts['hint'] = 'Owner? Add &sfy_key=<app.app_key from config/config.php> to this URL and reload: the exact '
                          . 'cause (class, message, file:line) will be shown on the page, and /api/hook.php?ping=1&sfy_key=… '
                          . 'returns the server log tail.';
        }
        $detail = $show ? $tech . '  (' . $where . ')' : $reason;

        // A schema-shaped crash means our own health flag lied: drop it so the
        // next request re-verifies every column and repairs what it can.
        if ($schema && function_exists('sfy_schema_flag')) {
            sfy_schema_flag(false);
        }

        if (!defined('SFY_FATAL_SHOWN')) {
            define('SFY_FATAL_SHOWN', true);
            if (function_exists('sfy_wants_json') && sfy_wants_json()) {
                sfy_json(['status' => 'error', 'reason' => 'server_error', 'ref' => $ref, 'detail' => $detail], 500);
            }
            $view = SFY_APP . '/views/error.php';
            if (is_file($view) && function_exists('sfy_head')) { require $view; return; }
        }
    } catch (Throwable $nested) {
        error_log('[SFY] crash handler failed: ' . $nested->getMessage());
    }

    echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Server error</title></head>'
       . '<body style="background:#202a68;color:#FFFFFF;font-family:monospace;padding:40px">'
       . '<h1 style="color:#FF7D8F">SERVER ERROR</h1>'
       . '<p>' . htmlspecialchars($raw, ENT_QUOTES) . '</p>'
       . '<p style="color:#B0BCEF">' . htmlspecialchars($where, ENT_QUOTES) . '</p></body></html>';
}

set_exception_handler(function (Throwable $e): void { sfy_render_crash($e); });

register_shutdown_function(function (): void {
    $err = error_get_last();
    if (!$err || !in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR], true)) return;
    sfy_render_crash(new ErrorException($err['message'], 0, $err['type'], (string)$err['file'], (int)$err['line']));
});

/* ── database ──────────────────────────────────────────────────────── */
function sfy_db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
        (string)sfy_cfg('db.host'), (int)sfy_cfg('db.port', 3306), (string)sfy_cfg('db.name'));

    try {
        $pdo = new PDO($dsn, (string)sfy_cfg('db.user'), (string)sfy_cfg('db.pass'), [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_TIMEOUT            => 8,
        ]);
        $pdo->exec("SET NAMES utf8mb4");
        return $pdo;
    } catch (PDOException $e) {
        error_log('[SFY] DB error: ' . $e->getMessage());
        // If we are already rendering an error page, throw instead of
        // recursing into sfy_fatal() a second time.
        if (defined('SFY_FATAL_SHOWN')) {
            throw new RuntimeException('Database unavailable: ' . $e->getMessage());
        }
        sfy_fatal('Database offline',
            'The verification database is temporarily unavailable. Please try again in a moment.', 503);
    }
}

/* ── time math that survives REAL prepared statements ────────────────
   MySQL refuses a placeholder in the INTERVAL slot of DATE_ADD()/DATE_SUB():
   `INTERVAL ? MINUTE` is a syntax error (1064) the moment the connection stops
   emulating prepares — and sfy_db() connects with ATTR_EMULATE_PREPARES=false
   on purpose, because the flow's queries are worth preparing for real. The trap
   is invisible on a host that emulates and fatal on one that does not, which is
   exactly how it took the whole player flow down in production: the claim POST
   blew up inside sfy_session_create() *before* the session row existed, so
   /claim answered 500 for every token, and every guarded use of the same shape
   (rate limiting, the login lockout, session extension, the captcha and device
   counters) had been failing silently behind a catch that swallowed it.

   TIMESTAMPADD() takes the amount as an ordinary function argument, so a bound
   parameter is legal there. Every "n units ago / n units ahead" in this codebase
   goes through this helper, and the amount is bound *signed*: pass a negative
   number for "ago", a positive one for "in n units".

     DATE_SUB(NOW(), INTERVAL ? MINUTE)  →  sfy_sql_now_offset('MINUTE') with -n
     DATE_ADD(NOW(), INTERVAL ? MINUTE)  →  sfy_sql_now_offset('MINUTE') with +n

   The unit is whitelisted rather than interpolated raw, so the helper can never
   become a way to smuggle SQL into a statement. */
function sfy_sql_now_offset(string $unit): string {
    static $units = ['MICROSECOND', 'SECOND', 'MINUTE', 'HOUR', 'DAY', 'WEEK', 'MONTH', 'QUARTER', 'YEAR'];
    $u = strtoupper(trim($unit));
    if (!in_array($u, $units, true)) $u = 'SECOND';
    return 'TIMESTAMPADD(' . $u . ', ?, NOW())';
}

/* ── output helpers ────────────────────────────────────────────────── */
function sfy_esc($s): string { return htmlspecialchars((string)$s, ENT_QUOTES | ENT_HTML5, 'UTF-8'); }

function sfy_json(array $d, int $c = 200): void {
    if (!headers_sent()) {
        http_response_code($c);
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store');
    }
    echo json_encode($d);
    exit;
}

function sfy_redirect(string $url): void {
    if (headers_sent()) { echo '<script>location.replace(' . json_encode($url) . ');</script>'; exit; }
    while (ob_get_level() > 0) @ob_end_clean();
    header('Location: ' . $url, true, 302);
    exit;
}

/** Terminal-styled fatal page instead of a bare `die('...')`. */
function sfy_fatal(string $title, string $detail = '', int $code = 500, array $opts = []): void {
    // Guard against re-entrant fatals (e.g. DB helper called from the error view).
    if (defined('SFY_FATAL_SHOWN')) {
        if (!headers_sent()) http_response_code($code);
        echo '<p style="font-family:monospace;color:#FF7D8F">' . sfy_esc($title) . ' — ' . sfy_esc($detail) . '</p>';
        exit;
    }
    define('SFY_FATAL_SHOWN', true);

    if (!headers_sent()) http_response_code($code);
    if (sfy_wants_json()) sfy_json(['status' => 'error', 'reason' => $title, 'detail' => $detail], $code);
    require SFY_APP . '/views/error.php';
    exit;
}

function sfy_wants_json(): bool {
    $accept = $_SERVER['HTTP_ACCEPT'] ?? '';
    $xhr    = $_SERVER['HTTP_X_REQUESTED_WITH'] ?? '';
    $uri    = $_SERVER['REQUEST_URI'] ?? '';
    return stripos($accept, 'application/json') !== false
        || strcasecmp($xhr, 'XMLHttpRequest') === 0
        || str_contains($uri, '/api/');
}

/* ── request helpers ───────────────────────────────────────────────── */
function sfy_client_ip(): string {
    /*
     * P1-3 (2026-10-24). Forwarding headers are client input unless a proxy in
     * front of the site overwrites them. Trusting them by default made every
     * "address" in the flow (rate limits, handoff issued_ip, postback binding)
     * attacker-chosen on a host that does not strip them. Opt in with
     * security.trust_proxy_headers only when Cloudflare (or equivalent) sits
     * in front and sets them.
     */
    if ((bool)sfy_cfg('security.trust_proxy_headers', false)) {
        foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR'] as $k) {
            if (!empty($_SERVER[$k])) return trim(explode(',', (string)$_SERVER[$k])[0]);
        }
    }
    return (string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
}

function sfy_user_agent(): string { return substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 512); }

/*
 * A request parameter, as trimmed text.
 *
 * `$default` deliberately accepts *any scalar*, not only a string. It used to
 * be `string $default = ''` while call sites wrote the natural thing —
 * `(int)sfy_param('pick', 0)` — and under declare(strict_types=1) that is a
 * TypeError: the task page answered HTTP 500 for every player, before a single
 * line of its own logic ran. A helper whose whole job is reading untrusted
 * input must not be able to take a page down because of the *shape* of the
 * value it is asked to fall back to; a numeric default is normalised to text
 * here and cast by the caller, exactly as if it had been written '0'.
 */
function sfy_param(string $key, string|int|float|bool|null $default = ''): string {
    $v = $_POST[$key] ?? $_GET[$key] ?? $default;
    if (is_scalar($v)) return trim((string)$v);
    return $default === null ? '' : (is_scalar($default) ? trim((string)$default) : '');
}

function sfy_int(string $key, int $default = 0): int { return (int)sfy_param($key, (string)$default); }

/** First non-empty value from a list of aliases (LootLabs uses several names). */
function sfy_param_any(array $keys, string|int|float|bool|null $default = ''): string {
    foreach ($keys as $k) {
        $v = sfy_param($k, '');
        if ($v !== '') return $v;
    }
    return is_scalar($default) ? trim((string)$default) : '';
}

/* ── csrf ──────────────────────────────────────────────────────────── */
function sfy_csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return (string)$_SESSION['csrf'];
}
function sfy_csrf_check(?string $t): bool {
    return !empty($_SESSION['csrf']) && hash_equals((string)$_SESSION['csrf'], (string)$t);
}
function sfy_csrf_field(): string {
    return '<input type="hidden" name="csrf" value="' . sfy_esc(sfy_csrf_token()) . '">';
}

/* ── runtime config kv (stored in sfy_config) ──────────────────────── */
function sfy_config_all(bool $refresh = false): array {
    static $cache = null;
    if ($cache === null || $refresh) {
        $cache = [];
        try {
            foreach (sfy_db()->query("SELECT config_key, config_value FROM sfy_config")->fetchAll() as $r) {
                $cache[$r['config_key']] = $r['config_value'];
            }
        } catch (Throwable $e) { error_log('[SFY] config load: ' . $e->getMessage()); }
    }
    return $cache;
}
function sfy_config_get(string $key, $default = null) {
    $all = sfy_config_all();
    return $all[$key] ?? $default;
}
function sfy_config_set(string $key, $value): void {
    sfy_db()->prepare("INSERT INTO sfy_config (config_key, config_value) VALUES (?,?)
                       ON DUPLICATE KEY UPDATE config_value=VALUES(config_value)")
             ->execute([$key, (string)$value]);
    sfy_config_all(true);
}

/* ── ids / tokens ──────────────────────────────────────────────────── */
function sfy_rand_id(int $bytes = 24): string { return bin2hex(random_bytes($bytes)); }
function sfy_nonce(): string { return bin2hex(random_bytes(16)); }

function sfy_validate_token(string $t): bool {
    $t = trim($t);
    return strlen($t) >= 5 && strlen($t) <= 64 && preg_match('/^[A-Za-z0-9\-]+$/', $t) === 1;
}

function sfy_sign(array $parts, string $scope = ''): string {
    return hash_hmac('sha256', $scope . '|' . implode('|', array_map('strval', $parts)), (string)sfy_cfg('app.app_key'));
}

/* ── modules ───────────────────────────────────────────────────────── */
require_once SFY_APP . '/util.php';
require_once SFY_APP . '/security.php';
require_once SFY_APP . '/schema.php';
require_once SFY_APP . '/captcha.php';    // human check (Turnstile) before a run starts
require_once SFY_APP . '/devices.php';
require_once SFY_APP . '/ads.php';
require_once SFY_APP . '/providers.php';   // task providers (LootLabs, Work.ink, …)
require_once SFY_APP . '/lootlabs.php';
require_once SFY_APP . '/relay.php';      // outbound pull for postbacks a challenged host cannot receive
require_once SFY_APP . '/workink.php';    // Work.ink: its own kind, its own setup, its own key check
require_once SFY_APP . '/flow.php';
require_once SFY_APP . '/appearance.php';
require_once SFY_APP . '/support.php';   // email requests + threaded chat
require_once SFY_APP . '/layout.php';
require_once SFY_APP . '/pricing_save.php'; // pricing editor save (standalone endpoint + action)
require_once SFY_APP . '/theme.php';
