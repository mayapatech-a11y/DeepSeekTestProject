<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY ULTIMATE — TASK PROVIDERS
 *
 *  A *provider* is one place a player can earn their task: LootLabs,
 *  Work.ink, or anything else an administrator adds in the panel. Each
 *  provider owns
 *
 *    • its own pool of accounts (the LootLabs rotation applies unchanged —
 *      two accounts on one provider rotate between steps, and two providers
 *      never share an account), and
 *    • its own task budget for one verification: `tasks_allowed`, i.e. "you
 *      may do up to 2 tasks here for this token" (0 = as many as the token
 *      needs).
 *
 *  The player is asked *where* to earn when there is more than one provider
 *  to choose from; the choice is remembered on the session until that
 *  provider's budget is used up, and then they are asked again. With a
 *  single offerable provider no question is asked at all and the budget is
 *  ignored — an install that never adds a second provider behaves exactly
 *  as it did before providers existed.
 *
 *  Nothing here is hard-coded per provider: the task URL is a template with
 *  macros (including free-form `{setting:key}` values defined in the panel),
 *  so a new earning task can be added from the admin without touching code.
 * ═══════════════════════════════════════════════════════════════════════
 */

/* ── kinds ─────────────────────────────────────────────────────────── */
/**
 * Provider kinds decide how a handoff is built.
 *
 *   lootlabs — the account link plus the Redirect API anti-bypass (`&data=`)
 *              when the account has a working key.
 *   workink  — a plain Work.ink link; the finished task lands on the
 *              destination configured in the Work.ink dashboard and the
 *              return check confirms the step.
 *   custom   — any other network: a URL template with macros.
 *
 * All three share the same postback receiver, the same account rotation and
 * the same anti-bypass return check.
 */
function sfy_provider_kinds(): array {
    return [
        'lootlabs' => [
            'label'  => 'LootLabs',
            'blurb'  => 'Link + Redirect API anti-bypass, signed postbacks.',
            'anti'   => true,
        ],
        'workink'  => [
            'label'  => 'Work.ink',
            'blurb'  => 'Work.ink link; set its destination to /done in their dashboard.',
            'anti'   => false,
        ],
        'custom'   => [
            'label'  => 'Custom / other network',
            'blurb'  => 'Any link you can paste, with {SESSION_ID} style macros.',
            'anti'   => false,
        ],
    ];
}

function sfy_provider_kinds_list(): array {
    $out = [];
    foreach (sfy_provider_kinds() as $k => $v) $out[$k] = $v['label'];
    return $out;
}

function sfy_provider_kind(string $kind): string {
    $kind = strtolower(trim($kind));
    return isset(sfy_provider_kinds()[$kind]) ? $kind : 'custom';
}

function sfy_provider_kind_label(string $kind): string {
    return sfy_provider_kinds()[sfy_provider_kind($kind)]['label'] ?? 'Custom';
}

/* ── types: what the editor asks, and what the owner is told ─────────
   Adding a provider is two questions, in this order:

     1. which network is this? — `kind`, which decides how the handoff is
        built *and* which of the fields below are shown; and
     2. that network's own settings.

   The type is not a cosmetic label: LootLabs and Work.ink are set up in
   different dashboards, need different keys and are confirmed by different
   things (LootLabs: a Redirect-API handoff plus signed postbacks; Work.ink:
   a plain link whose landing back on /done is the proof). Showing one generic
   form for both is how an owner ends up pasting a Key System key into a
   Redirect-API field — so each type carries its own field list, its own
   wording and its own dashboard instructions, and the editor renders exactly
   those.
   ─────────────────────────────────────────────────────────────────── */

/**
 * Every editable field, once, keyed by the provider column it writes.
 * A type lists the ones it wants (see sfy_provider_types()); anything it
 * does not list is simply never offered, and — because the save only writes
 * the fields it received — never blanked either.
 *
 * @return array<string,array<string,mixed>>
 */
function sfy_provider_field_defs(): array {
    return [
        'name' => [
            'label'   => 'Name (shown to players)',
            'input'   => 'text', 'attr' => 'required', 'placeholder' => 'Work.ink',
            'hint'    => 'What the player reads on the chooser and in the status line.',
        ],
        'slug' => [
            'label'   => 'Slug (internal, unique)',
            'input'   => 'text', 'placeholder' => 'workink',
            'hint'    => 'Blank = built from the name. It names the provider in logs, in the admin URL and in {PROVIDER_SLUG}.',
        ],
        'tasks_allowed' => [
            'label'   => 'Tasks per run (0 = unlimited)',
            'input'   => 'number', 'min' => 0, 'max' => 50,
            'hint'    => 'How many tasks ONE verification may do here. <b>1</b> = the player is asked again for the next task; '
                       . '<b>2</b> = a two-task token finishes here. Only enforced while more than one provider is ready.',
        ],
        'sort_order' => [
            'label'   => 'Sort order (chooser order)',
            'input'   => 'number', 'min' => 0, 'max' => 999,
            'hint'    => 'Lower numbers are offered first.',
        ],
        'api_key' => [
            'label'   => 'API key (optional)',
            'input'   => 'text', 'placeholder' => 'inherited by accounts with no key of their own',
            'hint'    => 'An account that has no key of its own uses this one.',
        ],
        'api_mode' => [
            'label'   => 'Anti-bypass handoff',
            'input'   => 'select',
            'hint'    => 'Decides how the handoff is built. Every setting below shares the postback receiver, the account '
                       . 'rotation and the verified return check.',
            'options' => [
                ''     => 'INHERIT — the global mode (Admin → Accounts)',
                'auto' => 'AUTO — use the API, fall back to a plain link',
                'on'   => 'ON — require it, block the step if it fails',
                'off'  => 'OFF — plain links from this provider',
            ],
        ],
        'description' => [
            'label'   => 'Short line shown on the chooser',
            'input'   => 'text', 'placeholder' => 'Quick task — one click to finish.',
            'hint'    => 'Optional. One calm sentence; nothing here is counted out loud to the player.',
        ],
        'task_url' => [
            'label'   => 'Task URL / template',
            'input'   => 'text', 'mono' => true,
            'placeholder' => 'https://ads.example.com/go?u={SESSION_ID}',
            'hint'    => 'Blank = use each account’s own link.',
        ],
        'url_params' => [
            'label'   => 'Extra query parameters',
            'input'   => 'text', 'mono' => true, 'placeholder' => 'zone=web&type=ppl',
            'hint'    => 'Appended after the link, macros allowed — a fixed network parameter without touching the accounts.',
        ],
        'return_hosts' => [
            'label'   => 'Accepted return hosts',
            'input'   => 'text', 'mono' => true, 'placeholder' => 'work.ink,workink.com',
            'hint'    => 'Where the finished task sends the player back from. Added to the global list, so a landing from them '
                       . 'counts as a provider return.',
        ],
        'postback_url' => [
            'label'   => 'Postback URL template (optional)',
            'input'   => 'text', 'mono' => true,
            'placeholder' => 'https://example.test/api/hook.php?unique_id={UNIQUE_ID}&sub_id={SUB_ID}',
            'hint'    => 'Paste this into the network’s dashboard. Blank = the built-in receiver URL shown per account.',
        ],
        'postback_secret' => [
            'label'   => 'Postback secret (optional)',
            'input'   => 'text',
            'hint'    => 'Only if the network signs its callbacks and you want the signature checked.',
        ],
        'pass_params' => [
            'label'   => 'Append step parameters to the link',
            'input'   => 'check',
            'hint'    => 'Adds <code>unique_id</code> / <code>sub_id</code> (and the signature) to the handoff — harmless for a '
                       . 'network that ignores them, and it is what lets a postback name the exact step.',
        ],
        'settings' => [
            'label'   => 'Custom values — one <code>key = value</code> per line',
            'input'   => 'textarea', 'placeholder' => "key = value",
            'hint'    => 'Usable in any template above as <code>{setting:key}</code>.',
        ],
        'notes' => [
            'label'   => 'Internal notes',
            'input'   => 'text',
            'hint'    => 'Never shown to players.',
        ],
        'is_active' => [
            'label'   => 'Active — may be offered to players',
            'input'   => 'check',
        ],
        'is_maintenance' => [
            'label'   => 'Under maintenance — shown to players, greyed, never offered',
            'input'   => 'check',
            'hint'    => 'The network keeps its place on the chooser with <b>UNDER MAINTENANCE</b> over it instead of '
                       . 'silently disappearing, and no step is handed to it while this is on. Use it while you fix or '
                       . 'replace its links — <b>Active</b> above is the switch that hides a provider completely.',
        ],
    ];
}

/**
 * The three types, each with everything the editor needs to set it up alone.
 *
 *   tagline   one line for the type chooser
 *   confirmed how a step is proven when this provider serves it
 *   needs     what the owner must have before starting (shown before any field)
 *   steps     the dashboard walkthrough for this type, in order
 *   fields    the field order the editor renders (keys of sfy_provider_field_defs())
 *   overrides per-field label/hint/placeholder for this type
 *   starter   what a brand-new provider of this type starts with
 *   docs      where the network documents it (linked, never fetched)
 *
 * @return array<string,array<string,mixed>>
 */
function sfy_provider_types(): array {
    return [

        'lootlabs' => [
            'label'     => 'LootLabs',
            'tagline'   => 'A LootLabs task link plus the Redirect API anti-bypass handoff.',
            'tone'      => 'g',
            'anti'      => true,
            'confirmed' => 'a LootLabs postback whose click_id carries our step nonce (the &puid put on the task link), or the provider landing when LootLabs sends the player back to /done',
            'needs'     => [
                'A LootLabs creator account with at least one task link',
                'The <b>Redirect API token</b> from that account (creator panel → Advanced → API key)',
                'The postback URL this panel generates, pasted into the account’s <b>Advanced → Postback</b> section',
            ],
            'steps'     => [
                'name it, then set Tasks per run: how much of ONE token may be earned here',
                'paste the Redirect API key (provider-level is enough — accounts inherit it)',
                'open Admin → Accounts and add one account per LootLabs link (name + task URL)',
                'set the landing page under Admin → Accounts → Anti-bypass to this install’s /done',
                'in the LootLabs panel open Advanced → Postback, switch it on, and paste the postback URL below',
                'leave the macros as they are — LootLabs replaces only {CLICK_ID}, {IP} and {UNIQUE_ID}',
            ],
            'fields'    => ['name', 'slug', 'tasks_allowed', 'sort_order', 'api_key', 'api_mode', 'description',
                            'task_url', 'url_params', 'return_hosts', 'postback_url', 'postback_secret',
                            'pass_params', 'settings', 'notes', 'is_active', 'is_maintenance'],
            'overrides' => [
                'api_key' => [
                    'label'       => 'Redirect API key (optional here)',
                    'placeholder' => '64-char token from the LootLabs creator panel',
                    'hint'        => 'A LootLabs <b>Redirect API</b> token. An account with no key of its own inherits this one, '
                                     . 'and its handoffs then carry <code>&amp;data=</code> — the encrypted landing that makes a '
                                     . 'bypass impossible.',
                ],
                'api_mode' => [
                    'hint' => 'Decides this provider’s handoff: INHERIT follows Admin → Accounts, AUTO uses the Redirect API '
                              . 'and quietly falls back to a plain link when it refuses, ON blocks the step instead of '
                              . 'downgrading, OFF always sends a plain link.',
                ],
                'task_url' => [
                    'label'       => 'Task URL / template (usually blank)',
                    'placeholder' => 'https://loot-link.com/s?xxxx  or  https://lootlabs.gg/xxxx',
                    'hint'        => 'Blank = each account’s own LootLabs link, which is how the rotation works. A template here '
                                     . 'replaces every account link.',
                ],
                'return_hosts' => [
                    'hint' => 'A landing from these hosts counts as a provider return. Prefilled with LootLabs’ own domains; '
                              . 'they are added to the global list automatically.',
                ],
                'postback_url' => [
                    'hint' => 'Paste this into the LootLabs panel → <b>Advanced → Postback</b> for <b>each</b> account '
                              . '(LootLabs keeps one postback per account). Blank = the built-in receiver URL shown per account. '
                              . 'LootLabs replaces exactly <code>{CLICK_ID}</code>, <code>{IP}</code> and <code>{UNIQUE_ID}</code> '
                              . '— nothing else — and <code>{CLICK_ID}</code> is the <code>&amp;puid</code> this install puts on the '
                              . 'task link, i.e. the step nonce, which is how a postback names the exact step.',
                ],
            ],
            'starter'   => [
                'name' => 'LootLabs', 'slug' => 'lootlabs', 'sort_order' => 1,
                'description'   => 'Quick task — one click to finish.',
                'return_hosts'  => 'lootlabs.gg,lootlabs.com,loot-link.com',
                'pass_params'   => 1,
            ],
            'docs' => 'https://help.lootlabs.gg/en/article/lootlabs-redirect-api-anti-bypass-9o0tky/',
        ],

        'workink' => [
            'label'     => 'Work.ink',
            'tagline'   => 'A Work.ink link whose landing back on /done confirms the task.',
            'tone'      => 'b',
            'anti'      => false,
            'confirmed' => 'the provider landing — Work.ink sends the finished task to the destination you set, and that landing '
                           . 'on /done from a work.ink host is the proof (Work.ink has no postback to configure)',
            'needs'     => [
                'A Work.ink account with a link you can send players to',
                'That link’s <b>destination</b> set to this install’s /done page (shown below)',
                'The <b>Key System</b> API key from the Work.ink creator panel, so the TEST KEY button can check it',
            ],
            'steps'     => [
                'create the link in Work.ink and point its destination at the URL shown below',
                'switch on pass parameters below, so the step is identifiable in the log',
                'add the link as an account in Admin → Accounts (several links rotate between steps)',
                'paste the Key System key here and press TEST KEY',
                'leave Tasks per run at 1 to ask again after each task, or raise it to finish a token here',
            ],
            'fields'    => ['name', 'slug', 'tasks_allowed', 'sort_order', 'task_url', 'api_key', 'description',
                            'url_params', 'return_hosts', 'postback_url', 'pass_params', 'settings', 'notes', 'is_active',
                            'is_maintenance'],
            'overrides' => [
                'task_url' => [
                    'label'       => 'Work.ink link (or template)',
                    'placeholder' => 'https://work.ink/xxxx/sfy-script',
                    'hint'        => 'Optional. One Work.ink link for every step; blank = each account’s own link, which is '
                                     . 'how a pool of links rotates. Macros such as <code>{SESSION_ID}</code> work here too.',
                ],
                'api_key' => [
                    'label'       => 'Work.ink API key — Key System (optional)',
                    'placeholder' => 'Key System key from the Work.ink creator panel',
                    'hint'        => 'Used by <b>TEST KEY</b> below. It calls Work.ink’s token endpoint '
                                     . '(<code>work.ink/_api/v2/token/verify/{TOKEN}</code>) with this Key System key and asks '
                                     . 'about a token this install invented, so the answer is about the key: HTTP 401 means the '
                                     . 'key is wrong, 200 or 403 mean Work.ink accepts it. Work.ink also serves a public '
                                     . '<code>work.ink/_api/v2/token/isValid/{TOKEN}</code> for a token a player actually '
                                     . 'earned, which needs no key at all. Accounts with no key of their own inherit it.',
                ],
                'return_hosts' => [
                    'hint' => 'Work.ink sends the finished task to your destination, so the landing host has to be listed. '
                              . 'Prefilled with work.ink and workink.com.',
                ],
                'postback_url' => [
                    'label'       => 'Postback / webhook URL (optional)',
                    'hint'        => 'Leave this empty: Work.ink has no postback or webhook to configure, and a postback is never '
                                     . 'how one of its tasks is confirmed. Its keys are checked with the Key System API instead, '
                                     . 'below. Paste a URL here only for a network that really calls back.',
                ],
                'pass_params' => [
                    'hint' => 'Recommended on: it puts the session and step on the Work.ink link, so the log names the exact task '
                              . 'the player opened.',
                ],
            ],
            'starter'   => [
                'name' => 'Work.ink', 'slug' => 'workink', 'sort_order' => 2,
                'description'  => 'Quick task — one click to finish.',
                'return_hosts' => 'work.ink,workink.com',
                'pass_params'  => 1,
            ],
            'docs' => 'https://work.ink/',
        ],

        'custom' => [
            'label'     => 'Custom / other network',
            'tagline'   => 'Any network you can paste a link or a template for.',
            'tone'      => 'p',
            'anti'      => false,
            'confirmed' => 'whatever that network calls back — a postback to the receiver below, or the landing from one of '
                           . 'its own hosts',
            'needs'     => [
                'The link (or link template) that starts one task there',
                'The hosts a finished task returns from — or a postback URL it can call',
                'Nothing else: no key is required to be offered',
            ],
            'steps'     => [
                'paste the task URL template (macros such as {SESSION_ID} and {SUB_ID} are expanded per handoff)',
                'or leave it blank and give every account its own link under Admin → Accounts',
                'list the hosts the network returns from, so a landing counts',
                'if it supports postbacks, paste the postback URL below into its dashboard',
            ],
            'fields'    => ['name', 'slug', 'tasks_allowed', 'sort_order', 'description', 'task_url', 'url_params',
                            'return_hosts', 'postback_url', 'postback_secret', 'pass_params', 'settings', 'notes',
                            'is_active', 'is_maintenance'],
            'overrides' => [
                'task_url' => [
                    'hint' => 'A template with macros, e.g. '
                              . '<code>https://ads.example.com/start?u={SESSION_ID}&amp;t={SUB_ID}</code>. Blank = use each '
                              . 'account’s own link.',
                ],
            ],
            'starter'   => [
                'name' => 'Task provider', 'slug' => '', 'sort_order' => 0,
                'description' => 'Quick task — one click to finish.',
                'pass_params' => 1,
            ],
            'docs' => '',
        ],
    ];
}

/** One type's setup, normalised (an unknown kind reads as `custom`). */
function sfy_provider_type_meta(string $kind): array {
    $types = sfy_provider_types();
    return $types[sfy_provider_kind($kind)] ?? [];
}

/** The field order this type's editor renders. */
function sfy_provider_type_fields(string $kind): array {
    $meta = sfy_provider_type_meta($kind);
    $all  = sfy_provider_field_defs();
    $out  = [];
    foreach ((array)($meta['fields'] ?? array_keys($all)) as $key) {
        if (isset($all[$key])) $out[] = $key;
    }
    return $out;
}

/** One field's descriptor, with this type's own wording applied. */
function sfy_provider_field(string $key, string $kind): array {
    $def  = sfy_provider_field_defs()[$key] ?? [];
    $meta = sfy_provider_type_meta($kind);
    $over = (array)($meta['overrides'][$key] ?? []);
    return array_replace($def, $over);
}

/** What a new provider of this type starts with (the owner can change any of it). */
function sfy_provider_starter(string $kind): array {
    $meta = sfy_provider_type_meta($kind);
    $base = sfy_provider_normalize([]);
    $base['kind'] = sfy_provider_kind($kind);
    return array_replace($base, (array)($meta['starter'] ?? []));
}

/* ── storage ───────────────────────────────────────────────────────── */
function sfy_providers_ready(): bool {
    return (bool)sfy_try(fn() => sfy_table_exists('sfy_providers'), false);
}

/** Every provider row this install has (empty pre-migration). */
function sfy_providers_all(bool $activeOnly = false): array {
    return (array)sfy_try(function () use ($activeOnly): array {
        if (!sfy_table_exists('sfy_providers')) return [];
        $sql = 'SELECT * FROM sfy_providers' . ($activeOnly ? ' WHERE is_active=1' : '')
             . ' ORDER BY sort_order ASC, id ASC';
        return sfy_db()->query($sql)->fetchAll() ?: [];
    }, []);
}

function sfy_provider_find(int $id): ?array {
    if ($id <= 0) return null;
    return sfy_try(function () use ($id): ?array {
        if (!sfy_table_exists('sfy_providers')) return null;
        $st = sfy_db()->prepare('SELECT * FROM sfy_providers WHERE id=? LIMIT 1');
        $st->execute([$id]);
        return $st->fetch() ?: null;
    }, null);
}

function sfy_provider_by_slug(string $slug): ?array {
    if ($slug === '') return null;
    return sfy_try(function () use ($slug): ?array {
        if (!sfy_table_exists('sfy_providers')) return null;
        $st = sfy_db()->prepare('SELECT * FROM sfy_providers WHERE slug=? LIMIT 1');
        $st->execute([$slug]);
        return $st->fetch() ?: null;
    }, null);
}

/** Defensive defaults, so a row from a half-finished migration still works. */
function sfy_provider_normalize(?array $p): array {
    $p = is_array($p) ? $p : [];
    return $p + [
        'id' => 0, 'slug' => '', 'name' => 'Task provider', 'kind' => 'custom',
        'description' => '', 'is_active' => 1, 'sort_order' => 0, 'tasks_allowed' => 0,
        'task_url' => '', 'url_params' => '', 'pass_params' => 1, 'return_hosts' => '',
        'postback_url' => '', 'postback_secret' => '', 'api_key' => '', 'api_mode' => '',
        'settings' => '', 'notes' => '', 'is_maintenance' => 0,
    ];
}

function sfy_provider_label(array $p): string {
    $n = trim((string)($p['name'] ?? ''));
    return $n !== '' ? $n : sfy_provider_kind_label((string)($p['kind'] ?? 'custom'));
}

/**
 * A provider the owner parked for maintenance.
 *
 * Parked means *shown, never offered*. Hiding a provider completely (switching
 * it to inactive) is the wrong tool for "this network is broken for an hour":
 * the chooser silently loses an option, and a player who had already picked it
 * is bounced somewhere else with no explanation at all, which reads as a bug.
 * A parked provider therefore keeps its place on the chooser — greyed, with
 * UNDER MAINTENANCE over it — while no step is handed to it.
 */
function sfy_provider_maintenance(array $p): bool {
    return (int)($p['is_maintenance'] ?? 0) === 1;
}

/**
 * The providers that may actually serve a step right now: offerable and not
 * parked. This — not the offered list — is what decides whether a task budget
 * is enforced, because a parked network cannot pick up the slack.
 */
function sfy_provider_live(): array {
    return array_values(array_filter(sfy_provider_offerable(), fn($p) => !sfy_provider_maintenance($p)));
}

/**
 * The state badge one chooser box carries: [label, tone].
 *
 * Both choosers (the claim page's picker, and the hub's own card when the
 * choice is still open) read this, so a player is told the same thing in the
 * same words wherever the question is asked.
 *
 * @return array{0:string,1:string}
 */
function sfy_provider_state_badge(array $row): array {
    if (!empty($row['maintenance'])) return ['UNDER MAINTENANCE', 'y'];
    if (!empty($row['available']))  return ['READY', 'g'];
    return ['USED', 'gr'];
}

/**
 * Why a box cannot be pressed — '' when it can.
 *
 * Never an empty dead end: a player who is told nothing about a box they
 * cannot press has to guess whether the site is broken or their own link is.
 */
function sfy_provider_unavailable_note(array $row): string {
    if (!empty($row['maintenance'])) {
        return 'Under maintenance — this network is paused right now. Pick the other one, or come back in a few minutes.';
    }
    if (empty($row['available'])) {
        return 'This one has already done its part for your link. The other one will open instead.';
    }
    return '';
}

/** Free-form `key = value` settings, exposed to templates as {setting:key}. */
function sfy_provider_settings(array $p): array {
    $raw = trim((string)($p['settings'] ?? ''));
    if ($raw === '') return [];
    $j = json_decode($raw, true);
    if (is_array($j)) {
        $out = [];
        foreach ($j as $k => $v) {
            if (is_scalar($v)) $out[strtolower(trim((string)$k))] = (string)$v;
        }
        return $out;
    }
    /* Tolerate the panel's line format too, in case it was written by hand. */
    return sfy_provider_parse_settings($raw);
}

/** "key = value" lines (what the admin panel edits) → array. */
function sfy_provider_parse_settings(string $raw): array {
    $out = [];
    foreach (preg_split('/\r\n|\r|\n/', $raw) ?: [] as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#')) continue;
        $parts = preg_split('/[=:]/', $line, 2) ?: [];
        $k = strtolower(trim((string)($parts[0] ?? '')));
        if ($k === '' || !preg_match('/^[a-z0-9_\.\-]{1,40}$/', $k)) continue;
        $out[$k] = trim((string)($parts[1] ?? ''));
    }
    return $out;
}

function sfy_provider_settings_text(array $p): string {
    $s = sfy_provider_settings($p);
    if (!$s) return '';
    $lines = [];
    foreach ($s as $k => $v) $lines[] = $k . ' = ' . $v;
    return implode("\n", $lines);
}

/* ── accounts ──────────────────────────────────────────────────────── */
/**
 * Active accounts of one provider — the rotation pool.
 * Falls back to the whole active pool when the provider cannot be resolved,
 * because an empty pool is the "No active task provider" dead end.
 */
function sfy_provider_accounts(int $providerId, bool $activeOnly = true): array {
    return (array)sfy_try(function () use ($providerId, $activeOnly): array {
        if (!sfy_table_exists('lootlabs_accounts')) return [];
        $sql  = 'SELECT * FROM lootlabs_accounts';
        $w    = [];
        $p    = [];
        if ($activeOnly) $w[] = 'is_active=1';
        if ($providerId > 0 && sfy_column_exists('lootlabs_accounts', 'provider_id')) {
            $w[] = 'provider_id=?';
            $p[] = $providerId;
        }
        if ($w) $sql .= ' WHERE ' . implode(' AND ', $w);
        $sql .= ' ORDER BY id ASC';
        $st = sfy_db()->prepare($sql);
        $st->execute($p);
        return $st->fetchAll() ?: [];
    }, []);
}

/** provider id → number of active accounts, in one query. */
function sfy_provider_account_counts(): array {
    return (array)sfy_try(function (): array {
        if (!sfy_table_exists('lootlabs_accounts') || !sfy_column_exists('lootlabs_accounts', 'provider_id')) return [];
        $out = [];
        foreach (sfy_db()->query("SELECT provider_id, COUNT(*) AS n FROM lootlabs_accounts
                                  WHERE is_active=1 GROUP BY provider_id")->fetchAll() as $r) {
            $out[(int)$r['provider_id']] = (int)$r['n'];
        }
        return $out;
    }, []);
}

/** Provider id → how many step handoffs it has served (all time, consumed or not). */
function sfy_provider_served_counts(): array {
    return (array)sfy_try(function (): array {
        if (!sfy_table_exists('sfy_step_tokens') || !sfy_column_exists('sfy_step_tokens', 'provider_id')) return [];
        $out = [];
        foreach (sfy_db()->query("SELECT provider_id, COUNT(*) AS n FROM sfy_step_tokens
                                  WHERE provider_id>0 GROUP BY provider_id")->fetchAll() as $r) {
            $out[(int)$r['provider_id']] = (int)$r['n'];
        }
        return $out;
    }, []);
}

/** Provider id → accounts still unassigned (provider_id = 0). */
function sfy_provider_unassigned_accounts(): array {
    return (array)sfy_try(function (): array {
        if (!sfy_table_exists('lootlabs_accounts') || !sfy_column_exists('lootlabs_accounts', 'provider_id')) return [];
        return sfy_db()->query("SELECT * FROM lootlabs_accounts WHERE provider_id=0 OR provider_id IS NULL ORDER BY id")->fetchAll() ?: [];
    }, []);
}

/* ── budgets ───────────────────────────────────────────────────────── */
/** How many tasks one verification may run on this provider (0 = no limit). */
function sfy_provider_tasks_allowed(array $p): int {
    return max(0, min(50, (int)($p['tasks_allowed'] ?? 0)));
}

function sfy_provider_unlimited(array $p): bool { return sfy_provider_tasks_allowed($p) === 0; }

/**
 * How many tasks this session has already spent on each provider.
 *
 * Read from the step handoffs themselves (sfy_step_tokens.provider_id), which
 * is what the admin sees in Sessions — a step that was handed off *and*
 * closed counts, the step in progress counts once, and a step whose handoff
 * was re-issued after a provider change is recounted under the new provider
 * because sfy_step_issue rewrites the row.
 *
 * @return array<int,int> provider id → tasks used
 */
function sfy_provider_usage(string $sid, int $step = 0): array {
    return (array)sfy_try(function () use ($sid, $step): array {
        if ($sid === '' || !sfy_table_exists('sfy_step_tokens')
            || !sfy_column_exists('sfy_step_tokens', 'provider_id')) return [];
        $st = sfy_db()->prepare('SELECT step, provider_id FROM sfy_step_tokens WHERE session_id=? ORDER BY step ASC');
        $st->execute([$sid]);
        $used = [];
        foreach ($st->fetchAll() as $r) {
            $pid = (int)($r['provider_id'] ?? 0);
            if ($pid <= 0) continue;
            $s = (int)($r['step'] ?? 0);
            if ($step > 0 && $s > $step) continue;     // steps not reached yet
            $used[$pid] = (int)($used[$pid] ?? 0) + 1;
        }
        return $used;
    }, []);
}

/** Tasks left for this provider in this session (-1 = unlimited). */
function sfy_provider_remaining(array $p, int $used): int {
    if (sfy_provider_unlimited($p)) return -1;
    return max(0, sfy_provider_tasks_allowed($p) - max(0, $used));
}

/* ── who may be chosen ─────────────────────────────────────────────── */
/**
 * The candidate set the flow decides from: active, with at least one active
 * account. A provider with no accounts would dead-end the flow, so it is
 * never offered.
 *
 * A provider parked for maintenance is still listed here on purpose — the
 * chooser shows it, greyed — so "offerable" is not the same as "may serve this
 * step": that narrower set is sfy_provider_live(), and the decision itself is
 * sfy_provider_plan().
 */
function sfy_provider_offerable(): array {
    $out = [];
    foreach (sfy_providers_all(true) as $p) {
        $p     = sfy_provider_normalize($p);
        $count = count(sfy_provider_accounts((int)$p['id']));
        if ($count <= 0) continue;
        $p['accounts'] = $count;
        $out[] = $p;
    }
    return $out;
}

/**
 * Active accounts of several providers, pooled into one rotation.
 *
 * This is what makes a merged network rotate the way a single download used to:
 * the pool is ordered by account id, so `(step - 1) % count(pool)` hands task 1
 * the first link of the network and task 2 the second one — no assignment by
 * hand, and never the same link twice in a row while another one is waiting.
 *
 * Accounts are fetched per provider (not with one `IN (...)` query) because
 * that is the same query sfy_provider_accounts() makes, so an install with the
 * provider column missing still behaves.
 */
function sfy_provider_accounts_multi(array $providerIds): array {
    $out = [];
    foreach (array_unique(array_filter(array_map('intval', $providerIds), fn($i) => $i > 0)) as $id) {
        foreach (sfy_provider_accounts((int)$id) as $a) $out[(int)($a['id'] ?? 0)] = $a;
    }
    ksort($out);
    return array_values($out);
}

/**
 * Are two providers of this kind the same network?
 *
 * LootLabs and Work.ink are *networks*, not links: a second provider row of the
 * same kind is a second link on the same network, so it belongs in the same
 * rotation. A "custom" provider is its own network — its name, template and
 * keys are its own — so it is never merged with anything, not even another
 * custom row.
 */
function sfy_provider_kind_merges(string $kind): bool {
    return sfy_provider_kind($kind) !== 'custom';
}

/**
 * The networks a player is choosing between, in one place.
 *
 * This is the shape the flow really works with: same-kind providers collapsed
 * into a single network, the live members' accounts pooled into one rotation,
 * and their task budgets added up. So "LootLabs" plus a second LootLabs row is
 * **one** box on the chooser, and task 1 opens on the first link while task 2
 * opens on the second — instead of asking a player to pick between two rows
 * that are the same place to earn. Work.ink (or anything else) keeps its own
 * box, which is still a real choice.
 *
 * A parked member leaves the group's account pool but does not take the network
 * down: parking one link of a network leaves the other serving, which is the
 * only useful meaning of "pause this row". Only when *every* member is parked
 * is the whole network parked (and then it is still shown, greyed).
 *
 * @param array<int,array>|null $offerable
 * @return array<int,array{key:string,kind:string,provider:array,members:array<int,array>,
 *                        accounts:array<int,array>,live_ids:array<int,int>,
 *                        accounts_count:int,maintenance:bool}>
 */
function sfy_provider_networks(?array $offerable = null): array {
    $offerable = $offerable ?? sfy_provider_offerable();
    $groups    = [];

    foreach ($offerable as $p) {
        $p    = sfy_provider_normalize($p);
        $kind = sfy_provider_kind((string)$p['kind']);
        $key  = sfy_provider_kind_merges($kind) ? 'kind:' . $kind : 'provider:' . (int)$p['id'];
        if (!isset($groups[$key])) {
            $groups[$key] = [
                'key' => $key, 'kind' => $kind, 'provider' => $p, 'members' => [],
                'accounts' => [], 'live_ids' => [], 'maintenance' => true,
            ];
        }
        $groups[$key]['members'][] = $p;
    }

    foreach ($groups as $key => $g) {
        $unlimited = 0;
        $budget    = 0;
        foreach ($g['members'] as $m) {
            if (sfy_provider_maintenance($m)) continue;
            $g['maintenance'] = false;
            $g['live_ids'][]  = (int)$m['id'];
            $allowed = sfy_provider_tasks_allowed($m);
            if ($allowed === 0) $unlimited++; else $budget += $allowed;
        }

        /* Accounts come from the live members only: a parked link must never be
           handed a step just because its sibling is running. */
        $accounts = $g['live_ids'] ? sfy_provider_accounts_multi($g['live_ids']) : [];

        /* A network's budget is what its links add up to, and one unlimited
           member makes the whole network unlimited (`0` keeps that meaning).
           The primary row carries it so every existing budget helper works
           unchanged against a network. */
        $g['provider']['tasks_allowed'] = $unlimited > 0 ? 0 : min(50, $budget);
        $g['accounts']       = $accounts;
        $g['accounts_count'] = count($accounts);
        $groups[$key]        = $g;
    }

    return array_values($groups);
}

/**
 * The whole decision the task page needs.
 *
 * Two sets, and the difference matters:
 *
 *   • the *listed* set (`providers`) is everything a player is shown — parked
 *     networks included, because the chooser has to say "this one is under
 *     maintenance" rather than quietly drop an option;
 *   • the *live* set is what may actually serve a step. A budget is only
 *     enforced while more than one live provider exists, or a parked network
 *     could exhaust a two-task budget and leave the player on a chooser with
 *     nothing clickable.
 *
 * With nothing live at all the plan is not ok and says `maintenance`, so the
 * pages can tell the player what is going on instead of "no active task
 * provider" — which is what a broken install says.
 *
 * `providers` is one row per **network** (same-kind providers merged) — that is
 * the list the chooser renders and the pick is validated against. Each row
 * carries its members and their live account ids, so the handoff can pool the
 * rotation and put the step on the link that owns the resolved account.
 *
 * @return array{
 *   ok:bool, needs_choice:bool, reason:string, single:bool,
 *   providers:array<int,array{provider:array,members:array,live_ids:array,used:int,allowed:int,remaining:int,maintenance:bool,available:bool}>,
 *   current:?array, used:array<int,int>
 * }
 */
function sfy_provider_plan(array $sess): array {
    $networks = sfy_provider_networks();
    $live     = array_values(array_filter($networks, fn($n) => empty($n['maintenance'])));
    $plan     = ['ok' => (bool)$live, 'needs_choice' => false,
                 'reason' => $live ? 'unset' : ($networks ? 'maintenance' : 'no_providers'),
                 'single' => count($networks) === 1, 'providers' => [], 'current' => null, 'used' => []];
    if (!$live) return $plan;

    $sid  = (string)($sess['session_id'] ?? '');
    $step = max(1, (int)($sess['current_step'] ?? 1));
    $used = sfy_provider_usage($sid, $step);
    $plan['used'] = $used;

    /*
     * A budget only means something when there is somewhere else to go, and
     * "somewhere else" has to be a network that can really run: counting a
     * parked one would cap a two-task token at one task and then show the
     * player a chooser where nothing is pressable.
     */
    $enforce = count($live) > 1;

    foreach ($networks as $n) {
        $maintenance = !empty($n['maintenance']);
        /* Tasks spent is the sum over the network's links: one step is one
           handoff, and the handoff names the link that served it. */
        $spent = 0;
        foreach ($n['members'] as $m) $spent += (int)($used[(int)$m['id']] ?? 0);
        $left  = ($enforce && !$maintenance) ? sfy_provider_remaining($n['provider'], $spent) : -1;
        $plan['providers'][] = [
            'provider'    => $n['provider'],
            'members'     => $n['members'],
            'live_ids'    => $n['live_ids'],
            'accounts'    => (int)$n['accounts_count'],
            'used'        => $spent,
            'allowed'     => sfy_provider_tasks_allowed($n['provider']),
            'remaining'   => $left,
            'maintenance' => $maintenance,
            'available'   => !$maintenance && $left !== 0,
        ];
    }

    /*
     * One candidate: there is nowhere else to go, so it serves every step and
     * no budget is enforced. Nothing is asked. It is live by definition — the
     * parked-only case never reaches this line.
     */
    if (count($networks) === 1) {
        $plan['current'] = $plan['providers'][0] ?? null;
        $plan['reason']  = 'single_provider';
        return $plan;
    }

    $pick = (int)($sess['provider_id'] ?? 0);
    foreach ($plan['providers'] as $row) {
        if ((int)$row['provider']['id'] === $pick && !empty($row['available'])) { $plan['current'] = $row; break; }
    }

    if ($plan['current']) {
        $plan['reason'] = 'chosen';
    } else {
        $plan['needs_choice'] = true;
        /* Was the pick *parked* rather than spent? The chooser says which. */
        $parked = false;
        foreach ($plan['providers'] as $row) {
            if ((int)$row['provider']['id'] === $pick && !empty($row['maintenance'])) { $parked = true; break; }
        }
        $plan['reason'] = $parked ? 'maintenance' : ($pick > 0 ? 'exhausted' : 'unset');
    }

    return $plan;
}

/** Remember the player's choice for this session. */
function sfy_session_set_provider(string $sid, int $providerId): bool {
    return (bool)sfy_try(function () use ($sid, $providerId): bool {
        if ($sid === '' || !sfy_column_exists('sfy_sessions', 'provider_id')) return false;
        sfy_db()->prepare('UPDATE sfy_sessions SET provider_id=? WHERE session_id=?')->execute([$providerId, $sid]);
        return true;
    }, false);
}

function sfy_session_clear_provider(string $sid): bool { return sfy_session_set_provider($sid, 0); }

/** The provider row this session is currently earning on (0 = none picked). */
function sfy_session_provider_id(array $sess): int { return (int)($sess['provider_id'] ?? 0); }

/* ── templates ─────────────────────────────────────────────────────── */
/**
 * Macro context for a provider handoff. Everything the step handoff knows,
 * plus the provider's own free-form settings (`{setting:key}`), so a task the
 * admin added in the panel can carry whatever the network needs without a
 * code change.
 */
function sfy_provider_context(array $provider, array $account, array $token, array $hand): array {
    $ctx = [
        'sid'        => (string)($hand['sid'] ?? ''),
        'nonce'      => (string)($hand['nonce'] ?? ''),
        'sig'        => (string)($hand['signature'] ?? ''),
        'step'       => (int)($hand['step'] ?? 0),
        'account_id' => (int)($account['id'] ?? 0),
        'token'      => (string)($token['token'] ?? ''),
        'game_id'    => (string)($token['game_id'] ?? ''),
        'ip'         => sfy_client_ip(),
        'destination'=> sfy_redirect_destination(['sid' => (string)($hand['sid'] ?? '')]),
    ];
    $extra = [
        'ACCOUNT_ID' => (string)($account['id'] ?? 0),
        'PROVIDER'   => sfy_provider_label($provider),
        'PROVIDER_SLUG' => (string)($provider['slug'] ?? ''),
        'PROVIDER_ID'   => (string)($provider['id'] ?? 0),
        'DESCRIPTION'   => (string)($provider['description'] ?? ''),
        'DESTINATION'   => (string)$ctx['destination'],
    ];
    foreach (sfy_provider_settings($provider) as $k => $v) $extra['setting:' . $k] = $v;
    return [$ctx, $extra];
}

/** Expand a provider template (task URL, params, postback URL). */
function sfy_provider_expand(string $tpl, array $provider, array $account, array $token = [], array $hand = []): string {
    if (trim($tpl) === '') return '';
    [$ctx, $extra] = sfy_provider_context($provider, $account, $token, $hand);

    $out = sfy_expand_macros($tpl, $ctx + ['account_id' => (int)$ctx['account_id']]);
    $map = [];
    foreach ($extra as $macro => $value) {
        $value = (string)$value;
        if ($value === '') $value = '{' . $macro . '}';       // keep the placeholder
        $map['{' . $macro . '}']             = $value;
        $map['{' . strtolower($macro) . '}'] = $value;
        $map['__' . strtoupper($macro) . '__'] = $value;
    }
    return strtr($out, $map);
}

/** Append an already-built query string to a URL. */
function sfy_provider_append_query(string $url, string $query): string {
    $query = trim($query, "?& \t");
    if ($query === '' || $url === '') return $url;
    return $url . (str_contains($url, '?') ? '&' : '?') . $query;
}

/** Does this provider want the step aliases appended to its link? */
function sfy_provider_passes_params(array $p): bool {
    $v = $p['pass_params'] ?? 1;
    return (string)$v !== '0' && (string)$v !== '' && (string)$v !== 'off';
}

/** The aliases the postback receiver can attribute a step by. */
function sfy_provider_step_params(array $hand, array $account, int $accountId = 0, bool $withSig = true): array {
    $q = [
        'unique_id' => (string)($hand['sid'] ?? ''),
        'uid'       => (string)($hand['sid'] ?? ''),
        's1'        => (string)($hand['sid'] ?? ''),
        'sub_id'    => (string)($hand['nonce'] ?? ''),
        's2'        => (string)($hand['nonce'] ?? ''),
        'acct'      => $accountId > 0 ? $accountId : (int)($account['id'] ?? 0),
    ];
    if ($withSig && !empty($hand['signature'])) $q['sig'] = substr((string)$hand['signature'], 0, 48);
    return $q;
}

/* ── handoff ───────────────────────────────────────────────────────── */
/**
 * Build the clickable task URL for a step.
 *
 * Same return shape as sfy_build_task_url() so the task page does not have to
 * care which provider answered: url, mode (redirect_api | plain |
 * unavailable) and the anti-bypass notes.
 *
 * @return array{url:string,mode:string,handoff:string,destination:string,encrypt:mixed,anti_bypass_mode:string,provider_id:int,provider_name:string}
 */
function sfy_provider_build_handoff(array $provider, array $account, array $token, array $hand): array {
    $provider = sfy_provider_normalize($provider);
    $kind     = sfy_provider_kind((string)$provider['kind']);
    $dest     = sfy_redirect_destination(['sid' => (string)($hand['sid'] ?? '')]);

    $blocked = fn(string $why): array => [
        'url' => '', 'mode' => 'unavailable', 'handoff' => 'blocked', 'destination' => $dest,
        'encrypt' => ['ok' => false, 'data' => '', 'error' => $why, 'destination' => $dest, 'ms' => 0, 'http' => 0],
        'anti_bypass_mode' => (string)$provider['api_mode'], 'provider_id' => (int)$provider['id'],
        'provider_name' => sfy_provider_label($provider), 'kind' => $kind, 'error' => $why,
    ];

    /*
     * An account with no key of its own inherits the provider's, and the same
     * for the anti-bypass mode — that is what lets the owner paste one Work.ink
     * or LootLabs key at the provider level instead of on every account.
     */
    if (trim((string)($account['api_key'] ?? '')) === '' && trim((string)$provider['api_key']) !== '') {
        $account['api_key'] = (string)$provider['api_key'];
    }
    if (trim((string)($account['redirect_api'] ?? '')) === '' && trim((string)$provider['api_mode']) !== '') {
        $account['redirect_api'] = (string)$provider['api_mode'];
    }

    if ($kind === 'lootlabs' && function_exists('sfy_build_task_url')) {
        $out = sfy_build_task_url($account, $token, $hand);
        $out['kind']          = 'lootlabs';
        $out['provider_id']   = (int)$provider['id'];
        $out['provider_name'] = sfy_provider_label($provider);
        if (($out['url'] ?? '') !== '' && trim((string)$provider['url_params']) !== '') {
            $out['url'] = sfy_provider_append_query((string)$out['url'],
                sfy_provider_expand((string)$provider['url_params'], $provider, $account, $token, $hand));
        }
        return $out;
    }

    /*
     * Only the LootLabs branch above can carry a return ticket: it is the only
     * one with an encrypted `&data=` destination, and the only place a ticket
     * could reach the player unread. Clear whatever this step's handoff minted
     * so a provider with no such mechanism is never held to a ticket it cannot
     * deliver — it falls back to the ordinary postback / verified-return gates.
     */
    if (function_exists('sfy_step_ticket_clear')) {
        sfy_step_ticket_clear((string)($hand['sid'] ?? ''), (int)($hand['step'] ?? 0));
    }

    /* ── generic handoff (Work.ink and anything else) ───────────────── */
    $base = trim((string)$provider['task_url']);
    if ($base === '') $base = trim((string)($account['task_url'] ?? ''));
    if ($base === '') {
        return $blocked('this provider has no task URL — add one in Admin → Task providers');
    }

    $url = sfy_provider_expand($base, $provider, $account, $token, $hand);
    if ($url === '') return $blocked('the task URL template expanded to nothing');

    if (sfy_provider_passes_params($provider)) {
        $url = sfy_provider_append_query($url, http_build_query(sfy_provider_step_params($hand, $account)));
    }
    if (trim((string)$provider['url_params']) !== '') {
        $url = sfy_provider_append_query($url,
            sfy_provider_expand((string)$provider['url_params'], $provider, $account, $token, $hand));
    }

    return [
        'url'              => $url,
        'mode'             => 'provider_link',
        'handoff'          => 'provider_link',
        'destination'      => $dest,
        'encrypt'          => ['ok' => false, 'data' => '', 'error' => '', 'destination' => $dest, 'ms' => 0, 'http' => 0],
        'anti_bypass_mode' => (string)$provider['api_mode'],
        'provider_id'      => (int)$provider['id'],
        'provider_name'    => sfy_provider_label($provider),
        'kind'             => $kind,
    ];
}

/** Human badge for the handoff the player is about to follow. */
function sfy_provider_handoff_badge(array $built): array {
    $mode = (string)($built['handoff'] ?? $built['mode'] ?? 'plain');
    if ($mode === 'redirect_api') {
        return ['ANTI-BYPASS ON', 'g', 'the finished task is sent to our encrypted landing page'];
    }
    if ($mode === 'blocked') {
        return ['BLOCKED', 'r', 'the handoff could not be built'];
    }
    if (($built['kind'] ?? '') === 'lootlabs') {
        return ['PLAIN LINK', 'y', 'plain LootLabs link — no working anti-bypass key on this account'];
    }
    return ['PROVIDER LINK', 'b', 'plain provider link; the step is confirmed by the verified return'];
}

/* ── return hosts ──────────────────────────────────────────────────── */
/**
 * Hosts a provider lands the player back from.
 *
 * A provider's own domains are added to the accepted return-referrer list, so
 * adding Work.ink (or anything else) in the panel does not require editing the
 * security settings as well.
 */
function sfy_provider_return_hosts(): array {
    $out = [];
    foreach (sfy_provider_offerable() as $p) {
        foreach (preg_split('/[\s,;]+/', strtolower((string)$p['return_hosts'])) ?: [] as $h) {
            $h = trim($h, " \t./");
            if ($h === '') continue;
            if (str_contains($h, '://')) {
                $parsed = parse_url($h, PHP_URL_HOST);
                $h = is_string($parsed) ? strtolower($parsed) : '';
            }
            if ($h !== '') $out[] = $h;
        }
    }
    return array_values(array_unique($out));
}

/* ── admin helpers ─────────────────────────────────────────────────── */
/**
 * Sanity warnings for the panel: an install whose budgets cannot be met, a
 * provider with no accounts, an inactive provider holding the only link.
 * @return array<int,array{level:string,text:string}>
 */
function sfy_provider_warnings(): array {
    $warn = [];
    $all  = sfy_providers_all();
    if (!$all) return $warn;

    $offerable = sfy_provider_offerable();
    $live      = array_values(array_filter($offerable, fn($p) => !sfy_provider_maintenance($p)));
    $parked    = array_values(array_filter($offerable, fn($p) => sfy_provider_maintenance($p)));
    $active    = array_filter($all, fn($p) => (int)$p['is_active'] === 1);

    if (!$offerable) {
        $warn[] = ['r', 'No active provider has an account, so the task page cannot hand anybody off. '
                     . 'Add an account to at least one provider.'];
    }

    /*
     * Parked networks are never an error on their own — that is what the flag
     * is for. What *is* worth saying is when every network that could serve a
     * step is parked, because then no player can start or continue a run at
     * all, and the claim page will say so out loud.
     */
    if ($parked) {
        $names = implode(', ', array_map(fn($p) => sfy_provider_label($p), $parked));
        if (!$live) {
            $warn[] = ['r', 'Every provider that could serve a step is parked for maintenance (' . $names . '), so no '
                         . 'player can start or continue a run. Press RESUME on one to accept them again.'];
        } else {
            $warn[] = ['y', $names . ' is parked for maintenance: players still see it on the chooser, greyed, and every '
                         . 'step goes to the network(s) that are running.'];
        }
    }
    foreach ($all as $p) {
        $p = sfy_provider_normalize($p);
        if ((int)$p['is_active'] !== 1) continue;
        if (count(sfy_provider_accounts((int)$p['id'])) === 0) {
            $warn[] = ['y', sfy_provider_label($p) . ' is active but has no accounts, so players can never be sent to it.'];
        }
        if (sfy_provider_kind((string)$p['kind']) === 'custom' && trim((string)$p['task_url']) === '') {
            $warn[] = ['y', sfy_provider_label($p) . ' has no task URL template and no account link — every handoff would fail.'];
        }
    }

    /*
     * The budgets are only enforced while more than one provider is offerable,
     * and the flow always needs `default_tasks_required` steps. If the budget
     * total is below that, the extra steps simply fall back to the last
     * provider — which is worth saying out loud, because the owner may have
     * meant the opposite.
     */
    if (count($live) > 1) {
        $total = 0; $budgeted = 0; $unlimited = 0;
        foreach ($live as $p) {
            $allowed = sfy_provider_tasks_allowed($p);
            if ($allowed > 0) { $total += $allowed; $budgeted++; } else { $unlimited++; }
        }
        $needed = max(1, sfy_setting_int('default_tasks_required', 2));
        /* An unlimited provider can always finish the flow, so the total only
           matters when every provider has a finite budget. */
        if ($unlimited === 0 && $budgeted > 0 && $total < $needed) {
            $warn[] = ['y', 'The task budgets across your providers add up to ' . $total . ' task(s) but a token asks for '
                        . $needed . '. Players will be offered a provider again once one runs out, so raise a budget (or lower '
                        . 'the token requirement) if you meant to cap the whole flow.'];
        }
    }
    unset($active);
    return $warn;
}
