<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY ULTIMATE — SCHEMA / UPDATER ENGINE
 *  Every schema change ships as a numbered, idempotent migration that the
 *  admin panel installs with one click (Admin → Updater).
 *  Nothing here ever drops data.
 * ═══════════════════════════════════════════════════════════════════════
 */

/* ── introspection helpers ───────────────────────────────────────────
   Schema introspection is memoised per request and the helpers can flush it.

   The flushed value MUST keep the canonical shape. It used to be reset to a
   bare `[]`, `sfy_schema_cache()` handed that straight back, and the very next
   `sfy_column_exists()` / `sfy_table_exists()` / `sfy_index_exists()` called
   array_key_exists() on null — a TypeError on PHP 8. The migration runner
   caught it per column and recorded it as a failed column, so ONE successful
   ALTER broke every remaining column in that migration and in the ones after
   it. That is precisely how "SCHEMA OK" and a batch of missing columns could
   coexist, and why the anti-bypass test result was never stored.
   ───────────────────────────────────────────────────────────────────── */
function sfy_schema_cache_shape(): array { return ['tables' => [], 'cols' => [], 'idx' => []]; }

function sfy_schema_flush_cache(): void { $GLOBALS['SFY_SCHEMA_CACHE'] = sfy_schema_cache_shape(); }

function sfy_schema_cache(): array {
    $cache = $GLOBALS['SFY_SCHEMA_CACHE'] ?? null;
    if (!is_array($cache)) $cache = [];
    // Repair anything malformed rather than throwing at the call sites.
    foreach (['tables', 'cols', 'idx'] as $part) {
        if (!isset($cache[$part]) || !is_array($cache[$part])) $cache[$part] = [];
    }
    return $GLOBALS['SFY_SCHEMA_CACHE'] = $cache;
}

/**
 * Write one memoised answer back to the shared cache.
 *
 * The helpers below used to do "$cache = &sfy_schema_cache()", which is not
 * legal PHP: a function return cannot be taken by reference, so PHP 8.4
 * emitted "Only variables should be assigned by reference" and the write went
 * to a local copy. A value plus an explicit write-back is correct.
 */
function sfy_schema_cache_set(string $part, string $key, bool $value): bool {
    $cache = sfy_schema_cache();
    $cache[$part][$key] = $value;
    $GLOBALS['SFY_SCHEMA_CACHE'] = $cache;
    return $value;
}

function sfy_table_exists(string $table, ?PDO $db = null): bool {
    $cache = sfy_schema_cache();
    if (array_key_exists($table, $cache['tables'])) return (bool)$cache['tables'][$table];
    $st = ($db ?? sfy_db())->prepare("SELECT 1 FROM information_schema.TABLES
                                      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? LIMIT 1");
    $st->execute([$table]);
    return sfy_schema_cache_set('tables', $table, (bool)$st->fetchColumn());
}

function sfy_column_exists(string $table, string $column, ?PDO $db = null): bool {
    $cache = sfy_schema_cache();
    $k = $table . '.' . $column;
    if (array_key_exists($k, $cache['cols'])) return (bool)$cache['cols'][$k];
    $st = ($db ?? sfy_db())->prepare("SELECT 1 FROM information_schema.COLUMNS
                                      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ? LIMIT 1");
    $st->execute([$table, $column]);
    return sfy_schema_cache_set('cols', $k, (bool)$st->fetchColumn());
}

function sfy_index_exists(string $table, string $index, ?PDO $db = null): bool {
    $cache = sfy_schema_cache();
    $k = $table . '.' . $index;
    if (array_key_exists($k, $cache['idx'])) return (bool)$cache['idx'][$k];
    $st = ($db ?? sfy_db())->prepare("SELECT 1 FROM information_schema.STATISTICS
                                      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ? LIMIT 1");
    $st->execute([$table, $index]);
    return sfy_schema_cache_set('idx', $k, (bool)$st->fetchColumn());
}

/** Add a column only when missing. Returns true when it actually ran. */
function sfy_add_column(string $table, string $column, string $definition, ?PDO $db = null): bool {
    $db = $db ?? sfy_db();
    if (!sfy_table_exists($table, $db) || sfy_column_exists($table, $column, $db)) return false;
    try {
        $db->exec("ALTER TABLE `$table` ADD COLUMN `$column` $definition");
    } catch (Throwable $e) {
        sfy_schema_flush_cache();
        // Another request added it first, or the ALTER was replayed. The column
        // existing is the outcome we wanted — reporting a failure here would
        // keep the migration 'partial' and re-ALTERed forever.
        if (str_contains(strtolower($e->getMessage()), 'duplicate column')) {
            error_log("[SFY] $table.$column already present: " . $e->getMessage());
            return false;
        }
        throw $e;
    }
    sfy_schema_flush_cache();   // the memoised column list is now stale
    return true;
}

/** Add an index only when missing. Duplicate-row errors are swallowed + logged. */
function sfy_add_index(string $table, string $index, string $columns, bool $unique = false, ?PDO $db = null): bool {
    $db = $db ?? sfy_db();
    if (!sfy_table_exists($table, $db) || sfy_index_exists($table, $index, $db)) return false;
    try {
        $db->exec("ALTER TABLE `$table` ADD " . ($unique ? 'UNIQUE ' : '') . "INDEX `$index` ($columns)");
        sfy_schema_flush_cache();
        return true;
    } catch (Throwable $e) {
        error_log("[SFY] index $index on $table skipped: " . $e->getMessage());
        sfy_schema_flush_cache();
        return false;
    }
}

/* ── table definitions ─────────────────────────────────────────────── */
function sfy_definitions(): array {
    return [

'sfy_config' => "CREATE TABLE IF NOT EXISTS `sfy_config` (
  `config_key`   VARCHAR(96)  NOT NULL,
  `config_value` TEXT         NULL,
  `updated_at`   DATETIME     NULL,
  PRIMARY KEY (`config_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

'lootlabs_accounts' => "CREATE TABLE IF NOT EXISTS `lootlabs_accounts` (
  `id`               INT AUTO_INCREMENT PRIMARY KEY,
  `name`             VARCHAR(191) NOT NULL DEFAULT 'LootLabs',
  -- Which task provider this account belongs to (see sfy_providers).
  -- Every account of one provider rotates together; providers never share.
  `provider_id`      INT          NOT NULL DEFAULT 0,
  `api_key`          VARCHAR(255) NOT NULL DEFAULT '',
  -- '' = inherit the global Redirect API mode; otherwise auto | on | off
  `redirect_api`     VARCHAR(8)   NULL,
  `encrypt_status`   VARCHAR(191) NULL,
  `encrypt_checked_at` DATETIME   NULL,
  `postback_secret`  VARCHAR(255) NULL,
  `task_url`         TEXT         NULL,
  `postback_url`     TEXT         NULL,
  `postback_format`  TEXT         NULL,
  `is_active`        TINYINT(1)   NOT NULL DEFAULT 1,
  `weight`           INT          NOT NULL DEFAULT 1,
  `daily_cap`        INT          NOT NULL DEFAULT 0,
  `used_today`       INT          NOT NULL DEFAULT 0,
  `used_date`        DATE         NULL,
  `last_used_at`     DATETIME     NULL,
  `timeout_seconds`  INT          NOT NULL DEFAULT 8,
  `notes`            TEXT         NULL,
  `created_at`       DATETIME     NULL,
  `updated_at`       DATETIME     NULL,
  KEY `idx_acct_provider` (`provider_id`, `is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

/*
 * TASK PROVIDERS — where a player may earn their task.
 *
 * LootLabs shipped first and is seeded here as provider #1; Work.ink is
 * seeded ready-to-use and anything else can be added from the admin panel
 * without touching code. Each provider owns its own accounts, its own task
 * URL (template), its own return hosts and its own budget of how many tasks
 * one verification may run on it.
 */
'sfy_providers' => "CREATE TABLE IF NOT EXISTS `sfy_providers` (
  `id`             INT AUTO_INCREMENT PRIMARY KEY,
  `slug`           VARCHAR(48)  NOT NULL DEFAULT '',
  `name`           VARCHAR(191) NOT NULL DEFAULT 'Task provider',
  `kind`           VARCHAR(24)  NOT NULL DEFAULT 'custom',
  `description`    VARCHAR(255) NULL,
  `is_active`      TINYINT(1)   NOT NULL DEFAULT 1,
  -- Parked by the owner: the chooser still LISTS it (greyed, labelled UNDER
  -- MAINTENANCE), because a network that silently vanishes looks like a bug to
  -- the player, but no step is ever handed to it while this is 1.
  `is_maintenance` TINYINT(1)   NOT NULL DEFAULT 0,
  `sort_order`     INT          NOT NULL DEFAULT 0,
  -- How many tasks ONE verification may run here. 0 = as many as the token
  -- needs (i.e. unlimited). Only enforced while more than one provider is
  -- offerable — with a single provider there is nowhere else to go.
  `tasks_allowed`  INT          NOT NULL DEFAULT 0,
  `task_url`       TEXT         NULL,
  `url_params`     TEXT         NULL,
  `pass_params`    TINYINT(1)   NOT NULL DEFAULT 1,
  `return_hosts`   VARCHAR(255) NULL,
  `postback_url`   TEXT         NULL,
  `postback_secret` VARCHAR(255) NULL,
  `api_key`        VARCHAR(255) NULL,
  `api_mode`       VARCHAR(8)   NULL,
  `settings`       TEXT         NULL,
  `notes`          TEXT         NULL,
  `created_at`     DATETIME     NULL,
  `updated_at`     DATETIME     NULL,
  UNIQUE KEY `uniq_provider_slug` (`slug`),
  KEY `idx_provider_active` (`is_active`, `sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

'sfy_games' => "CREATE TABLE IF NOT EXISTS `sfy_games` (
  `game_id`        VARCHAR(64)  NOT NULL,
  `game_name`      VARCHAR(191) NOT NULL DEFAULT 'Unknown Game',
  `script_url`     TEXT         NULL,
  `script_version` INT          NOT NULL DEFAULT 1,
  `is_active`      TINYINT(1)   NOT NULL DEFAULT 1,
  `max_runs`       INT          NOT NULL DEFAULT 50,
  `notes`          TEXT         NULL,
  `created_at`     DATETIME     NULL,
  `updated_at`     DATETIME     NULL,
  PRIMARY KEY (`game_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

'sfy_tokens' => "CREATE TABLE IF NOT EXISTS `sfy_tokens` (
  `token`           VARCHAR(64)  NOT NULL,
  `code`            VARCHAR(64)  NULL,
  `game_id`         VARCHAR(64)  NULL,
  `game_name`       VARCHAR(191) NULL,
  `tasks_required`  INT          NOT NULL DEFAULT 2,
  `account_chain`   VARCHAR(191) NULL,
  `is_used`         TINYINT(1)   NOT NULL DEFAULT 0,
  `used_at`         DATETIME     NULL,
  `used_ip`         VARCHAR(64)  NULL,
  `used_device_id`  INT          NOT NULL DEFAULT 0,
  `run_count`       INT          NOT NULL DEFAULT 0,
  `max_runs`        INT          NOT NULL DEFAULT 50,
  `max_devices`     INT          NOT NULL DEFAULT 1,
  `multi_use`       TINYINT(1)   NOT NULL DEFAULT 0,
  `is_hidden`       TINYINT(1)   NOT NULL DEFAULT 0,
  `expires_at`      DATETIME     NULL,
  `notes`           TEXT         NULL,
  `created_by`      VARCHAR(64)  NULL,
  `created_at`      DATETIME     NULL,
  PRIMARY KEY (`token`),
  KEY `idx_tokens_used` (`is_used`),
  KEY `idx_tokens_game` (`game_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

'sfy_sessions' => "CREATE TABLE IF NOT EXISTS `sfy_sessions` (
  `session_id`        VARCHAR(64)  NOT NULL,
  `token`             VARCHAR(64)  NULL,
  `game_id`           VARCHAR(64)  NULL,
  `current_step`      INT          NOT NULL DEFAULT 1,
  `total_steps`       INT          NOT NULL DEFAULT 2,
  `is_completed`      TINYINT(1)   NOT NULL DEFAULT 0,
  `user_ip`           VARCHAR(64)  NULL,
  `user_agent`        VARCHAR(512) NULL,
  `fingerprint`       VARCHAR(128) NULL,
  `flow_identity`     VARCHAR(64)  NULL,
  `device_id`         INT          NOT NULL DEFAULT 0,
  -- The provider the player chose to earn on for this run (0 = not asked yet).
  `provider_id`       INT          NOT NULL DEFAULT 0,
  `lootlabs_click_id` VARCHAR(128) NULL,
  `postback_count`    INT          NOT NULL DEFAULT 0,
  `last_postback_at`  DATETIME     NULL,
  `step_started_at`   DATETIME     NULL,
  `risk_score`        INT          NOT NULL DEFAULT 0,
  `bypass_flags`      INT          NOT NULL DEFAULT 0,
  `code_views`        INT          NOT NULL DEFAULT 0,
  `first_seen_code_at` DATETIME    NULL,
  `device_name`       VARCHAR(191) NULL,
  `device_fingerprint` VARCHAR(128) NULL,
  `screen_resolution` VARCHAR(50)  NULL,
  `timezone`          VARCHAR(100) NULL,
  `language`          VARCHAR(32)  NULL,
  `country`           VARCHAR(96)  NULL,
  `created_at`        DATETIME     NULL,
  `expires_at`        DATETIME     NULL,
  `completed_at`      DATETIME     NULL,
  -- When this run solved the human check, if one was demanded (NULL = never).
  `captcha_passed_at` DATETIME     NULL,
  PRIMARY KEY (`session_id`),
  KEY `idx_sessions_ip` (`user_ip`),
  KEY `idx_sessions_token` (`token`),
  KEY `idx_sessions_done` (`is_completed`),
  KEY `idx_sessions_device` (`device_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

'sfy_step_tokens' => "CREATE TABLE IF NOT EXISTS `sfy_step_tokens` (
  `id`           BIGINT AUTO_INCREMENT PRIMARY KEY,
  `session_id`   VARCHAR(64) NOT NULL,
  `step`         INT         NOT NULL,
  `nonce`        VARCHAR(64) NOT NULL,
  `account_id`   INT         NOT NULL DEFAULT 0,
  `provider_id`  INT         NOT NULL DEFAULT 0,
  `issued_ip`    VARCHAR(64) NULL,
  `issued_ua`    VARCHAR(512) NULL,
  `issued_at`    DATETIME    NOT NULL,
  `consumed_at`  DATETIME    NULL,
  `clicked_at`   DATETIME    NULL,
  `returned_at`  DATETIME    NULL,
  `soft_verified` TINYINT(1) NOT NULL DEFAULT 0,
  -- Migration 031: the per-run return ticket that only the encrypted `&data=`
  -- destination can reveal. A step that was handed off with one may only be
  -- confirmed by a landing that presents it.
  `return_ticket` VARCHAR(64) NULL,
  `return_ticket_at` DATETIME NULL,
  `return_ticket_used_at` DATETIME NULL,
  `attempts`     INT         NOT NULL DEFAULT 0,
  UNIQUE KEY `uniq_step` (`session_id`, `step`),
  KEY `idx_step_nonce` (`nonce`),
  KEY `idx_step_ticket` (`return_ticket`),
  KEY `idx_step_open` (`consumed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

'sfy_postback_log' => "CREATE TABLE IF NOT EXISTS `sfy_postback_log` (
  `id`          BIGINT AUTO_INCREMENT PRIMARY KEY,
  `session_id`  VARCHAR(64)  NULL,
  `account_id`  INT          NULL,
  `step`        INT          NULL,
  `click_id`    VARCHAR(128) NULL,
  `ip`          VARCHAR(64)  NULL,
  `unique_id`   VARCHAR(128) NULL,
  `nonce`       VARCHAR(64)  NULL,
  `dwell`       INT          NULL,
  `accepted`    TINYINT(1)   NOT NULL DEFAULT 0,
  `verified`    TINYINT(1)   NOT NULL DEFAULT 0,
  `reason`      VARCHAR(64)  NULL,
  -- How the call was matched to a step: nonce | session | ip (migration 012).
  `attribution` VARCHAR(24)  NULL,
  `user_agent`  VARCHAR(512) NULL,
  `raw_query`   TEXT         NULL,
  `created_at`  DATETIME     NULL,
  KEY `idx_pb_session` (`session_id`),
  KEY `idx_pb_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

'sfy_devices' => "CREATE TABLE IF NOT EXISTS `sfy_devices` (
  `id`               BIGINT AUTO_INCREMENT PRIMARY KEY,
  `device_key`       VARCHAR(128) NOT NULL,
  `device_name`      VARCHAR(191) NULL,
  `device_type`      VARCHAR(16)  NULL,
  `os`               VARCHAR(64)  NULL,
  `browser`          VARCHAR(64)  NULL,
  `browser_version`  VARCHAR(32)  NULL,
  `user_agent`       VARCHAR(512) NULL,
  `screen_resolution` VARCHAR(50) NULL,
  `timezone`         VARCHAR(100) NULL,
  `language`         VARCHAR(32)  NULL,
  `ip`               VARCHAR(64)  NULL,
  `country`          VARCHAR(96)  NULL,
  `first_seen`       DATETIME     NULL,
  `last_seen`        DATETIME     NULL,
  `session_count`    INT NOT NULL DEFAULT 0,
  `success_count`    INT NOT NULL DEFAULT 0,
  `fail_count`       INT NOT NULL DEFAULT 0,
  `code_views`       INT NOT NULL DEFAULT 0,
  `bypass_attempts`  INT NOT NULL DEFAULT 0,
  `tokens_used`      INT NOT NULL DEFAULT 0,
  `last_token`       VARCHAR(64)  NULL,
  `last_game_id`     VARCHAR(64)  NULL,
  `last_session_id`  VARCHAR(64)  NULL,
  `first_ip`         VARCHAR(64)  NULL,
  `risk_score`       INT NOT NULL DEFAULT 0,
  `is_blocked`       TINYINT(1) NOT NULL DEFAULT 0,
  `is_trusted`       TINYINT(1) NOT NULL DEFAULT 0,
  `notes`            TEXT NULL,
  `created_at`       DATETIME NULL,
  `updated_at`       DATETIME NULL,
  UNIQUE KEY `uniq_device_key` (`device_key`),
  KEY `idx_dev_ip` (`ip`),
  KEY `idx_dev_success` (`success_count`),
  KEY `idx_dev_seen` (`last_seen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

'sfy_ads' => "CREATE TABLE IF NOT EXISTS `sfy_ads` (
  `id`            INT AUTO_INCREMENT PRIMARY KEY,
  `title`         VARCHAR(191) NOT NULL,
  `body`          TEXT         NULL,
  `image_url`     TEXT         NULL,
  `target_url`    TEXT         NULL,
  `button_text`   VARCHAR(64)  NULL,
  `placement`     VARCHAR(24)  NOT NULL DEFAULT 'banner',
  `pages`         VARCHAR(96)  NOT NULL DEFAULT 'all',
  `theme_color`   VARCHAR(16)  NOT NULL DEFAULT '#3BF5D0',
  `is_active`     TINYINT(1)   NOT NULL DEFAULT 1,
  `is_dismissible` TINYINT(1)  NOT NULL DEFAULT 1,
  `sort_order`    INT          NOT NULL DEFAULT 0,
  `start_at`      DATETIME     NULL,
  `end_at`        DATETIME     NULL,
  `max_impressions` INT        NOT NULL DEFAULT 0,
  `impressions`   INT          NOT NULL DEFAULT 0,
  `clicks`        INT          NOT NULL DEFAULT 0,
  `dismissals`    INT          NOT NULL DEFAULT 0,
  `created_at`    DATETIME     NULL,
  `updated_at`    DATETIME     NULL,
  `created_by`    VARCHAR(64)  NULL,
  KEY `idx_ads_place` (`placement`, `is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

'sfy_staff' => "CREATE TABLE IF NOT EXISTS `sfy_staff` (
  `id`              INT AUTO_INCREMENT PRIMARY KEY,
  `username`        VARCHAR(64)  NOT NULL,
  `display_name`    VARCHAR(96)  NOT NULL DEFAULT '',
  `password_hash`   VARCHAR(255) NOT NULL,
  `role`            VARCHAR(16)  NOT NULL DEFAULT 'staff',
  `is_active`       TINYINT(1)   NOT NULL DEFAULT 1,
  `failed_attempts` INT          NOT NULL DEFAULT 0,
  `last_failed_at`  DATETIME     NULL,
  `locked_until`    DATETIME     NULL,
  `last_login_at`   DATETIME     NULL,
  `last_login_ip`   VARCHAR(64)  NULL,
  `notes`           TEXT         NULL,
  `created_by`      INT          NOT NULL DEFAULT 0,
  `created_at`      DATETIME     NULL,
  `updated_at`      DATETIME     NULL,
  UNIQUE KEY `uniq_staff_user` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

'sfy_login_attempts' => "CREATE TABLE IF NOT EXISTS `sfy_login_attempts` (
  `id`         BIGINT AUTO_INCREMENT PRIMARY KEY,
  `username`   VARCHAR(64)  NULL,
  `ip`         VARCHAR(64)  NULL,
  `user_agent` VARCHAR(512) NULL,
  `success`    TINYINT(1)   NOT NULL DEFAULT 0,
  `reason`     VARCHAR(128) NULL,
  `created_at` DATETIME     NULL,
  KEY `idx_login_user` (`username`, `created_at`),
  KEY `idx_login_ip` (`ip`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

'sfy_audit_log' => "CREATE TABLE IF NOT EXISTS `sfy_audit_log` (
  `id`         BIGINT AUTO_INCREMENT PRIMARY KEY,
  `staff_id`   INT          NOT NULL DEFAULT 0,
  `username`   VARCHAR(64)  NULL,
  `action`     VARCHAR(64)  NULL,
  `target`     VARCHAR(191) NULL,
  `meta`       TEXT         NULL,
  `ip`         VARCHAR(64)  NULL,
  `created_at` DATETIME     NULL,
  KEY `idx_audit_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

'sfy_rate_limits' => "CREATE TABLE IF NOT EXISTS `sfy_rate_limits` (
  `bucket`       VARCHAR(64) NOT NULL,
  `rl_key`       VARCHAR(128) NOT NULL,
  `window_start` DATETIME NOT NULL,
  `hits`         INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`bucket`, `rl_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

/*
 * One row per time somebody *looked at a finished code*.
 *
 * The per-session `code_views` counter could only answer "how many times",
 * never "from where" — so a code reopened on someone else's phone left no
 * trace of which device or location asked for it. This table records the ask.
 */
'sfy_code_opens' => "CREATE TABLE IF NOT EXISTS `sfy_code_opens` (
  `id`           INT AUTO_INCREMENT PRIMARY KEY,
  `token`        VARCHAR(64)  NOT NULL,
  `session_id`   VARCHAR(64)  NULL,
  `device_id`    INT          NOT NULL DEFAULT 0,
  `device_name`  VARCHAR(191) NULL,
  `device_type`  VARCHAR(16)  NULL,
  `os`           VARCHAR(64)  NULL,
  `browser`      VARCHAR(64)  NULL,
  `ip`           VARCHAR(64)  NULL,
  `country`      VARCHAR(96)  NULL,
  `timezone`     VARCHAR(100) NULL,
  `own_device`   TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`   DATETIME     NULL,
  KEY `idx_co_token` (`token`),
  KEY `idx_co_session` (`session_id`),
  KEY `idx_co_device` (`device_id`),
  KEY `idx_co_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

/*
 * One row per *decided* human check (Cloudflare Turnstile).
 *
 * The gate is only worth having if its behaviour can be read back: how many
 * fresh runs actually solved it, how many were turned away, and how often it
 * had to let somebody through because Cloudflare could not be reached at all.
 * Plain page views are never written here — a row means a challenge was
 * submitted and a verdict was reached.
 */
'sfy_captcha_log' => "CREATE TABLE IF NOT EXISTS `sfy_captcha_log` (
  `id`         BIGINT AUTO_INCREMENT PRIMARY KEY,
  `context`    VARCHAR(16)  NULL,
  `outcome`    VARCHAR(24)  NOT NULL,
  `reason`     VARCHAR(32)  NULL,
  `codes`      VARCHAR(191) NULL,
  `session_id` VARCHAR(64)  NULL,
  `ip`         VARCHAR(64)  NULL,
  `user_agent` VARCHAR(512) NULL,
  `created_at` DATETIME     NULL,
  KEY `idx_cap_created` (`created_at`),
  KEY `idx_cap_context` (`context`, `created_at`),
  KEY `idx_cap_ip` (`ip`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

'sfy_migrations' => "CREATE TABLE IF NOT EXISTS `sfy_migrations` (
  `id`         VARCHAR(32)  NOT NULL,
  `title`      VARCHAR(191) NULL,
  `applied_at` DATETIME     NULL,
  `duration_ms` INT         NOT NULL DEFAULT 0,
  `status`     VARCHAR(16)  NOT NULL DEFAULT 'ok',
  `notes`      TEXT         NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

/* ── pricing plans (one row per plan) ─────────────────────────────── */
'sfy_pricing_plans' => "CREATE TABLE IF NOT EXISTS `sfy_pricing_plans` (
  `id`          VARCHAR(48)   NOT NULL,
  `period`      VARCHAR(20)   NOT NULL DEFAULT 'instant',
  `name`        VARCHAR(60)   NOT NULL,
  `days`        INT           NOT NULL DEFAULT 0,
  `price`       DECIMAL(10,2) NOT NULL DEFAULT 0,
  `savings`     DECIMAL(10,2) NULL,
  `note`        VARCHAR(180)  NULL,
  `featured`    TINYINT(1)    NOT NULL DEFAULT 0,
  `enabled`     TINYINT(1)    NOT NULL DEFAULT 1,
  `sort_order`  INT           NOT NULL DEFAULT 0,
  `updated_at`  DATETIME      NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

/* ── support / requests + threaded chat ───────────────────────────── */
'sfy_support_requests' => "CREATE TABLE IF NOT EXISTS `sfy_support_requests` (
  `id`              BIGINT AUTO_INCREMENT PRIMARY KEY,
  `code`            VARCHAR(32)  NOT NULL,
  `name`            VARCHAR(96)  NULL,
  `email`           VARCHAR(191) NOT NULL,
  `category`        VARCHAR(32)  NOT NULL DEFAULT 'other',
  `subject`         VARCHAR(191) NULL,
  `status`          VARCHAR(20)  NOT NULL DEFAULT 'open',
  `unread`          TINYINT(1)   NOT NULL DEFAULT 1,
  `ip`              VARCHAR(64)  NULL,
  `user_agent`      VARCHAR(512) NULL,
  `created_at`      DATETIME     NULL,
  `updated_at`      DATETIME     NULL,
  `last_message_at` DATETIME     NULL,
  UNIQUE KEY `uniq_support_code` (`code`),
  KEY `idx_support_status` (`status`, `updated_at`),
  KEY `idx_support_email` (`email`),
  KEY `idx_support_unread` (`unread`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

'sfy_support_messages' => "CREATE TABLE IF NOT EXISTS `sfy_support_messages` (
  `id`         BIGINT AUTO_INCREMENT PRIMARY KEY,
  `request_id` BIGINT       NOT NULL,
  `sender`     VARCHAR(10)  NOT NULL DEFAULT 'user',
  `body`       TEXT         NOT NULL,
  `ip`         VARCHAR(64)  NULL,
  `created_at` DATETIME     NULL,
  KEY `idx_support_msg_request` (`request_id`, `id`),
  KEY `idx_support_msg_ip` (`ip`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    ];
}

/* ── additive upgrades for pre-existing installs ───────────────────── */
/**
 * Result shape used by the migration runner:
 *   ['notes' => string[], 'failed' => string[]]
 * A non-empty 'failed' list downgrades the migration to `partial`, which the
 * installer retries on the next request — so a rejected ALTER repairs itself
 * instead of silently leaving the site half-upgraded.
 */
function sfy_schema_upgrade_columns(?PDO $db = null): array {
    $db = $db ?? sfy_db();
    $changed = [];
    $failed  = [];

    // Every single column is isolated: one failing ALTER must never abort the
    // rest of the upgrade (that would leave the site half-migrated).
    $add = function (string $table, string $column, string $def) use ($db, &$changed, &$failed) {
        try {
            if (sfy_add_column($table, $column, $def, $db)) $changed[] = "$table.$column";
        } catch (Throwable $e) {
            error_log("[SFY] column $table.$column failed: " . $e->getMessage());
            $failed[] = "$table.$column: " . $e->getMessage();
        }
    };

    /* lootlabs_accounts */
    $add('lootlabs_accounts', 'redirect_api',       "VARCHAR(8) NULL");
    $add('lootlabs_accounts', 'encrypt_status',     "VARCHAR(191) NULL");
    $add('lootlabs_accounts', 'encrypt_checked_at', "DATETIME NULL");
    $add('lootlabs_accounts', 'postback_format', "TEXT NULL");
    $add('lootlabs_accounts', 'postback_secret', "VARCHAR(255) NULL");
    $add('lootlabs_accounts', 'postback_url',    "TEXT NULL");
    $add('lootlabs_accounts', 'weight',          "INT NOT NULL DEFAULT 1");
    $add('lootlabs_accounts', 'daily_cap',       "INT NOT NULL DEFAULT 0");
    $add('lootlabs_accounts', 'used_today',      "INT NOT NULL DEFAULT 0");
    $add('lootlabs_accounts', 'used_date',       "DATE NULL");
    $add('lootlabs_accounts', 'last_used_at',    "DATETIME NULL");
    $add('lootlabs_accounts', 'timeout_seconds', "INT NOT NULL DEFAULT 8");
    $add('lootlabs_accounts', 'notes',           "TEXT NULL");
    $add('lootlabs_accounts', 'created_at',      "DATETIME NULL");
    $add('lootlabs_accounts', 'updated_at',      "DATETIME NULL");

    /* sfy_games */
    $add('sfy_games', 'game_name',      "VARCHAR(191) NOT NULL DEFAULT 'Unknown Game'");
    $add('sfy_games', 'script_version', "INT NOT NULL DEFAULT 1");
    $add('sfy_games', 'max_runs',       "INT NOT NULL DEFAULT 50");
    $add('sfy_games', 'notes',          "TEXT NULL");
    $add('sfy_games', 'updated_at',     "DATETIME NULL");

    /* sfy_tokens */
    $add('sfy_tokens', 'game_name',      "VARCHAR(191) NULL");
    $add('sfy_tokens', 'used_ip',        "VARCHAR(64) NULL");
    $add('sfy_tokens', 'used_device_id', "INT NOT NULL DEFAULT 0");
    $add('sfy_tokens', 'run_count',      "INT NOT NULL DEFAULT 0");
    $add('sfy_tokens', 'max_runs',       "INT NOT NULL DEFAULT 50");
    $add('sfy_tokens', 'max_devices',    "INT NOT NULL DEFAULT 1");
    $add('sfy_tokens', 'expires_at',     "DATETIME NULL");
    $add('sfy_tokens', 'notes',          "TEXT NULL");
    $add('sfy_tokens', 'created_by',     "VARCHAR(64) NULL");

    /* sfy_sessions */
    $add('sfy_sessions', 'fingerprint',        "VARCHAR(128) NULL");
    $add('sfy_sessions', 'device_id',          "INT NOT NULL DEFAULT 0");
    $add('sfy_sessions', 'lootlabs_click_id',  "VARCHAR(128) NULL");
    $add('sfy_sessions', 'postback_count',     "INT NOT NULL DEFAULT 0");
    $add('sfy_sessions', 'last_postback_at',   "DATETIME NULL");
    $add('sfy_sessions', 'step_started_at',    "DATETIME NULL");
    $add('sfy_sessions', 'risk_score',         "INT NOT NULL DEFAULT 0");
    $add('sfy_sessions', 'bypass_flags',       "INT NOT NULL DEFAULT 0");
    $add('sfy_sessions', 'code_views',         "INT NOT NULL DEFAULT 0");
    $add('sfy_sessions', 'first_seen_code_at', "DATETIME NULL");
    $add('sfy_sessions', 'device_name',        "VARCHAR(191) NULL");
    $add('sfy_sessions', 'device_fingerprint', "VARCHAR(128) NULL");
    $add('sfy_sessions', 'screen_resolution',  "VARCHAR(50) NULL");
    $add('sfy_sessions', 'timezone',           "VARCHAR(100) NULL");
    $add('sfy_sessions', 'language',           "VARCHAR(32) NULL");
    $add('sfy_sessions', 'country',            "VARCHAR(96) NULL");
    $add('sfy_sessions', 'completed_at',       "DATETIME NULL");
    $add('sfy_sessions', 'captcha_passed_at',  "DATETIME NULL");

    /* sfy_step_tokens (the return check needs clicked_at) */
    $add('sfy_step_tokens', 'clicked_at',    "DATETIME NULL");
    $add('sfy_step_tokens', 'returned_at',   "DATETIME NULL");
    $add('sfy_step_tokens', 'soft_verified', "TINYINT(1) NOT NULL DEFAULT 0");
    /* The per-run return ticket (migration 031). */
    $add('sfy_step_tokens', 'return_ticket',         "VARCHAR(64) NULL");
    $add('sfy_step_tokens', 'return_ticket_at',      "DATETIME NULL");
    $add('sfy_step_tokens', 'return_ticket_used_at', "DATETIME NULL");

    /* sfy_postback_log */
    $add('sfy_postback_log', 'nonce',      "VARCHAR(64) NULL");
    $add('sfy_postback_log', 'dwell',      "INT NULL");
    $add('sfy_postback_log', 'accepted',   "TINYINT(1) NOT NULL DEFAULT 0");
    $add('sfy_postback_log', 'reason',     "VARCHAR(64) NULL");
    $add('sfy_postback_log', 'user_agent', "VARCHAR(512) NULL");

    /* sfy_providers — the maintenance flag the chooser reads on every claim
       and every step. The definition-derived sweep below would find it too;
       naming it here keeps the hot column in the list an operator reads. */
    $add('sfy_providers', 'is_maintenance', "TINYINT(1) NOT NULL DEFAULT 0");

    /* Anything the definitions declare that the list above forgot (or never
       knew about) is repaired by reading the CREATE TABLE back out. Without
       this sweep, a column that only ever lived in a definition stayed
       missing forever: the diagnostic named it, the hand-written list had no
       entry for it, and the sentinel — a short hot-path list — never noticed.
       `sfy_postback_log.created_at` was exactly that, and every statement
       touching it threw "Unknown column", i.e. a server error on the page. */
    $sweep = sfy_schema_repair_columns($db);
    foreach ($sweep['notes']  as $n) $changed[] = $n;
    foreach ($sweep['failed'] as $f) $failed[]  = $f;

    return ['notes' => $changed, 'failed' => $failed];
}

function sfy_schema_upgrade_indexes(?PDO $db = null): array {
    $db = $db ?? sfy_db();
    $changed = [];
    $failed  = [];
    $add = function (string $t, string $i, string $c, bool $u = false) use ($db, &$changed, &$failed) {
        try {
            if (sfy_add_index($t, $i, $c, $u, $db)) $changed[] = "$t.$i";
        } catch (Throwable $e) {
            error_log("[SFY] index $t.$i failed: " . $e->getMessage());
            $failed[] = "$t.$i: " . $e->getMessage();
        }
    };
    $add('sfy_config',       'uniq_cfg_key',    '`config_key`', true);
    $add('sfy_tokens',       'uniq_token',      '`token`', true);
    $add('sfy_tokens',       'idx_tokens_used', '`is_used`');
    $add('sfy_tokens',       'idx_tokens_game', '`game_id`');
    $add('sfy_sessions',     'uniq_session',    '`session_id`', true);
    $add('sfy_sessions',     'idx_sessions_ip', '`user_ip`');
    $add('sfy_sessions',     'idx_sessions_token', '`token`');
    $add('sfy_sessions',     'idx_sessions_done', '`is_completed`');
    $add('sfy_sessions',     'idx_sessions_device', '`device_id`');
    $add('sfy_postback_log', 'idx_pb_session',  '`session_id`');
    $add('sfy_postback_log', 'idx_pb_created',  '`created_at`');
    return ['notes' => $changed, 'failed' => $failed];
}

/**
 * Column name → its ALTER-ready definition, parsed out of a CREATE TABLE.
 *
 * sfy_schema_expected_columns() answers "which columns should exist"; this
 * answers "and with what definition", which is what an additive repair needs.
 * Both read the same text, so what is checked and what is repaired can never
 * disagree — the shape of bug that kept a page 500-ing while the updater
 * happily reported "database already at version 028".
 */
function sfy_schema_defined_columns(string $definition): array {
    $cols = [];
    foreach (explode("\n", $definition) as $line) {
        $line = rtrim(trim($line), ',');
        if ($line === '' || $line[0] !== '`') continue;      // KEY / PRIMARY / UNIQUE / comments
        if (preg_match('/^`([a-z0-9_]+)`\s+(.+)$/i', $line, $m)) $cols[$m[1]] = trim($m[2]);
    }
    return $cols;
}

/**
 * Add back every column the definitions declare but the database is missing.
 *
 * `CREATE TABLE IF NOT EXISTS` cannot add a column to a table that already
 * exists, so a definition-only column needed an explicit entry in
 * sfy_schema_upgrade_columns() — and a missing entry was invisible: RUN
 * UPDATER said "up to date", REPAIR SCHEMA said "up to date", and the pages
 * that touched the column kept returning server errors.
 *
 * Deriving the repair from sfy_definitions() removes that blind spot: the
 * same text that produces the diagnostic produces the ALTER. Primary/auto
 * columns are skipped — they cannot be bolted onto a table that already has
 * one, and a table without them is rebuilt by the migration that owns it.
 *
 * @return array{notes: string[], failed: string[]}
 */
function sfy_schema_repair_columns(?PDO $db = null): array {
    $db     = $db ?? sfy_db();
    $notes  = [];
    $failed = [];
    foreach (sfy_definitions() as $table => $ddl) {
        foreach (sfy_schema_defined_columns($ddl) as $column => $definition) {
            if (preg_match('/AUTO_INCREMENT|PRIMARY KEY/i', $definition)) continue;
            try {
                // sfy_add_column() is a no-op when the table or column is
                // already there, so the sweep is safe to run on every repair.
                if (sfy_add_column($table, $column, $definition, $db)) $notes[] = "$table.$column";
            } catch (Throwable $e) {
                error_log("[SFY] repair column $table.$column: " . $e->getMessage());
                $failed[] = "$table.$column: " . $e->getMessage();
            }
        }
    }
    return ['notes' => $notes, 'failed' => $failed];
}

/** Seed sensible defaults the first time (never overwrites existing values). */
function sfy_schema_seed_config(?PDO $db = null): array {
    $db = $db ?? sfy_db();
    $seeded = [];
    $defaults = [
        'set_session_ttl_minutes'    => (string)sfy_cfg('security.session_ttl_minutes', 30),
        'set_default_tasks_required' => (string)sfy_cfg('security.default_tasks_required', 2),
        'set_default_account_chain'  => (string)sfy_cfg('security.default_account_chain', '1,2'),
        'set_min_task_seconds'       => (string)sfy_cfg('security.min_task_seconds', 4),
        'set_code_view_ttl_minutes'  => (string)sfy_cfg('security.code_view_ttl_minutes', 30),
        'set_max_code_views'         => (string)sfy_cfg('security.max_code_views', 4),
        'set_code_handoff'           => (string)sfy_cfg('security.code_handoff', 'any'),
        'set_token_reuse'            => (string)sfy_cfg('security.token_reuse', 'open'),
        'set_zerotap'                => sfy_cfg('security.zerotap', true) ? '1' : '0',
        'set_hub_pass'               => sfy_cfg('security.hub_pass', true) ? '1' : '0',
        'set_zerotap_handoff_seconds' => (string)sfy_cfg('security.zerotap_handoff_seconds', 5),
        'set_max_login_attempts'     => (string)sfy_cfg('security.max_login_attempts', 5),
        'set_require_postback'       => '1',
        'set_maintenance_mode'       => '0',
        'set_site_headline'          => 'Complete the tasks, unlock the code.',
        'set_site_subtext'           => 'Two verified steps. No shortcuts, no bypassing.',
        'set_support_discord'        => 'https://discord.com/channels/1437061764003921992/1442168765159702548',
        'set_premium_offer_title'    => 'Skip the tasks — 7 days for $9',
        'set_premium_offer_text'     => 'No tasks. No waiting. Instant access for 7 full days.',
        'set_pinned_label_continue'  => 'CONTINUE TASK {step}/{total}',
        'set_pinned_label_code'      => 'SHOW MY CODE',
        'set_pinned_label_guide'     => 'HOW TO GET TOKEN',
    ];
    foreach ($defaults as $k => $v) {
        $st = $db->prepare("SELECT 1 FROM sfy_config WHERE config_key=? LIMIT 1");
        $st->execute([$k]);
        if (!$st->fetchColumn()) {
            $db->prepare("INSERT INTO sfy_config (config_key, config_value, updated_at) VALUES (?,?,NOW())")->execute([$k, $v]);
            $seeded[] = $k;
        }
    }
    return $seeded;
}

/* ── migration registry ────────────────────────────────────────────── */
/**
 * Each migration: id, title, notes, plus either 'tables' (definition keys to
 * create) and/or 'run' (callable). Everything is idempotent.
 */
function sfy_migrations(): array {
    /* Kept in one place and sorted by id, so a migration added later cannot
       silently run out of order (the runner walks this array as given). */
    $m = [
        '001' => [
            'title'  => 'Core tables (config, tokens, sessions, postbacks)',
            'tables' => ['sfy_config', 'lootlabs_accounts', 'sfy_games', 'sfy_tokens',
                         'sfy_sessions', 'sfy_postback_log'],
        ],
        '002' => [
            'title'  => 'Upgrade legacy columns on existing tables',
            'run'    => fn(PDO $db) => sfy_schema_upgrade_columns($db),
        ],
        '003' => [
            'title'  => 'Indexes + unique keys',
            'run'    => fn(PDO $db) => sfy_schema_upgrade_indexes($db),
        ],
        '004' => [
            'title'  => 'Seed default settings',
            'run'    => fn(PDO $db) => sfy_schema_seed_config($db),
        ],
        '005' => [
            'title'  => 'Anti-bypass step nonces (sfy_step_tokens)',
            'tables' => ['sfy_step_tokens'],
        ],
        '006' => [
            'title'  => 'Device registry (sfy_devices)',
            'tables' => ['sfy_devices'],
        ],
        '007' => [
            'title'  => 'Advertisement manager (sfy_ads)',
            'tables' => ['sfy_ads'],
        ],
        '008' => [
            'title'  => 'Staff accounts, roles + login attempt log',
            'tables' => ['sfy_staff', 'sfy_login_attempts'],
        ],
        '009' => [
            'title'  => 'Audit trail + rate limiting buckets',
            'tables' => ['sfy_audit_log', 'sfy_rate_limits'],
        ],
        '010' => [
            'title'  => 'Adopt the legacy admin password as an owner account',
            'run'    => function (PDO $db) {
                $hash = (string)sfy_config_get('admin_password_hash', '');
                if ($hash === '') return ['no legacy password found'];
                $st = $db->prepare("SELECT 1 FROM sfy_staff WHERE username='admin' LIMIT 1");
                $st->execute();
                if ($st->fetchColumn()) return ['owner account already present'];
                $db->prepare("INSERT INTO sfy_staff (username, display_name, password_hash, role, is_active, created_at)
                              VALUES ('admin','Administrator',?,'owner',1,NOW())")->execute([$hash]);
                return ['admin owner account created from legacy password'];
            },
        ],
        '011' => [
            'title'  => 'Backfill first-seen completion timestamps',
            'run'    => function (PDO $db) {
                $n = $db->exec("UPDATE sfy_sessions SET completed_at = created_at
                                WHERE is_completed=1 AND completed_at IS NULL");
                return ["$n session(s) backfilled"];
            },
        ],
        '012' => [
            'title'  => 'Postback attribution column',
            'run'    => function (PDO $db) {
                $out    = [];
                $failed = [];
                sfy_try(function () use ($db, &$out, &$failed) {
                    if (sfy_add_column('sfy_postback_log', 'attribution', 'VARCHAR(24) NULL', $db)) {
                        $out[] = 'sfy_postback_log.attribution';
                    }
                    return true;
                }, null);
                return ['notes' => $out, 'failed' => $failed];
            },
        ],
        '013' => [
            'title'  => 'Ad scheduler + dismissible guards (idempotent)',
            'run'    => function (PDO $db) {
                $out = [];
                foreach ([['start_at','DATETIME NULL'], ['end_at','DATETIME NULL'],
                          ['max_impressions','INT NOT NULL DEFAULT 0'],
                          ['is_dismissible','TINYINT(1) NOT NULL DEFAULT 1'],
                          ['sort_order','INT NOT NULL DEFAULT 0'],
                          ['updated_at','DATETIME NULL'], ['created_by','VARCHAR(64) NULL']] as [$c, $d]) {
                    try { if (sfy_add_column('sfy_ads', $c, $d, $db)) $out[] = "sfy_ads.$c"; }
                    catch (Throwable $e) { error_log('[SFY] ads col ' . $c . ': ' . $e->getMessage()); }
                }
                return ['notes' => $out, 'failed' => []];
            },
        ],
        '014' => [
            'title'  => 'Homepage v2 — premium offer under the token box',
            'run'    => function (PDO $db) {
                $raw = (string)sfy_config_get('set_layout_home', '');
                if (trim($raw) === '') return ['fresh install — the new default layout applies'];
                $j = json_decode($raw, true);
                if (!is_array($j)) return ['stored layout unreadable — left untouched'];
                $rows = isset($j['sections']) && is_array($j['sections']) ? $j['sections'] : $j;
                if (!$rows) return ['stored layout empty — the new default applies'];
                $rows = sfy_layout_upgrade(sfy_layout_normalize($rows));
                sfy_config_set('set_layout_home', json_encode(['sections' => $rows],
                    JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
                sfy_config_all(true);
                sfy_layout(false, true);
                return ['premium block moved under the token box; counters hidden (' . count($rows) . ' sections)'];
            },
        ],
        '015' => [
            'title'  => 'Seed the tutorial + premium settings',
            'run'    => function (PDO $db) {
                $seeded  = [];
                $current = sfy_config_all(true);
                foreach ([
                    'set_tutorial_enabled' => '1',
                    'set_tutorial_fab'     => '1',
                    'set_premium_accent'   => '',
                ] as $k => $v) {
                    if (array_key_exists($k, $current)) continue;
                    sfy_config_set($k, $v);
                    $seeded[] = $k;
                }
                return ['notes' => $seeded];
            },
        ],
        '016' => [
            'title'  => 'Homepage v3 - hide the how-it-works and security panels',
            'run'    => function (PDO $db) {
                $raw = (string)sfy_config_get('set_layout_home', '');
                if (trim($raw) === '') return ['fresh install - the new default layout applies'];
                $j = json_decode($raw, true);
                if (!is_array($j)) return ['stored layout unreadable - left untouched'];
                $rows = isset($j['sections']) && is_array($j['sections']) ? $j['sections'] : $j;
                if (!$rows) return ['stored layout empty - the new default applies'];

                $rows = sfy_layout_upgrade(sfy_layout_normalize($rows));
                $off  = 0;
                foreach ($rows as $r) if (empty($r['enabled'])) $off++;
                sfy_config_set('set_layout_home', json_encode(['sections' => $rows],
                    JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
                sfy_config_all(true);
                sfy_layout(false, true);
                return ["$off section(s) now hidden; the guide card set to full width"];
            },
        ],
        '017' => [
            'title'  => 'Seed the premium offer copy (only where it is missing)',
            'run'    => function (PDO $db) {
                $current = sfy_config_all(true);
                $seeded  = [];
                foreach ([
                    'set_premium_offer_title'  => 'Skip every task — 7 days for $9',
                    'set_premium_offer_text'   => 'No tasks. No waiting. Your code in seconds.',
                    'set_premium_button_label' => 'GET PREMIUM — INSTANT ACCESS',
                    'set_premium_note'         => 'Instant activation · limited time offer',
                    'set_premium_bullets'      => "Skip every numbered task\nGet your code immediately\nPriority support\nWorks on any device",
                ] as $k => $v) {
                    // A blank stored value is as good as missing — that is what made
                    // the premium card render with no offer text at all.
                    if (trim((string)($current[$k] ?? '')) !== '') continue;
                    sfy_config_set($k, $v);
                    $seeded[] = $k;
                }
                return ['notes' => $seeded];
            },
        ],
        /*
         * Real LootLabs installs frequently cannot be reached by a
         * server-to-server postback (a free host whose security layer answers
         * the provider with a browser challenge, a postback URL that only
         * carries macros LootLabs does not know, …). That used to leave the
         * player on /done forever. These columns let the flow record that the
         * user really clicked into the task and really came back, so a
         * verified *return* can stand in for the postback until the real one
         * starts arriving again — and make it obvious in the log which is
         * which.
         */
        '018' => [
            'title'  => 'Task return check — click tracking + fallback verification switch',
            'run'    => function (PDO $db) {
                $out = [];
                $bad = [];
                foreach ([['clicked_at', 'DATETIME NULL'],
                          ['returned_at', 'DATETIME NULL'],
                          ['soft_verified', 'TINYINT(1) NOT NULL DEFAULT 0']] as [$c, $d]) {
                    try { if (sfy_add_column('sfy_step_tokens', $c, $d, $db)) $out[] = 'sfy_step_tokens.' . $c; }
                    catch (Throwable $e) {
                        // A rejected ALTER must mark this step 'partial' so the
                        // installer keeps retrying it instead of reporting success.
                        error_log('[SFY] step col ' . $c . ': ' . $e->getMessage());
                        $bad[] = 'sfy_step_tokens.' . $c . ': ' . $e->getMessage();
                    }
                }
                try { sfy_add_index('sfy_postback_log', 'idx_pb_reason', '`reason`', false, $db); }
                catch (Throwable $e) { /* index is optional */ }

                $current = sfy_config_all(true);
                $seeded  = [];
                foreach ([['set_postback_fallback', 'auto'], ['set_return_dwell_seconds', '45']] as [$k, $v]) {
                    if (array_key_exists($k, $current)) continue;
                    sfy_config_set($k, $v);
                    $seeded[] = $k;
                }
                return ['notes' => array_merge($out, $seeded), 'failed' => $bad];
            },
        ],
        /*
         * The LootLabs Redirect API (anti-bypass handoff) becomes part of the
         * control panel: mode, HTTP method and cache are settings, every
         * account can override them, and each account remembers the result of
         * its last API test so a dead key is visible instead of silent.
         */
        '019' => [
            'title'  => 'LootLabs Redirect API (anti-bypass) controls',
            'run'    => function (PDO $db) {
                $out = [];
                $bad = [];
                foreach ([['redirect_api', 'VARCHAR(8) NULL'],
                          ['encrypt_status', 'VARCHAR(191) NULL'],
                          ['encrypt_checked_at', 'DATETIME NULL']] as [$c, $d]) {
                    try { if (sfy_add_column('lootlabs_accounts', $c, $d, $db)) $out[] = 'lootlabs_accounts.' . $c; }
                    catch (Throwable $e) {
                        error_log('[SFY] account col ' . $c . ': ' . $e->getMessage());
                        $bad[] = 'lootlabs_accounts.' . $c . ': ' . $e->getMessage();
                    }
                }
                $current = sfy_config_all(true);
                $seeded  = [];
                foreach ([['set_redirect_api', 'auto'],
                          ['set_encrypt_method', 'post'],
                          ['set_redirect_cache_hours', '12']] as [$k, $v]) {
                    if (array_key_exists($k, $current)) continue;
                    sfy_config_set($k, $v);
                    $seeded[] = $k;
                }
                return ['notes' => array_merge($out, $seeded), 'failed' => $bad];
            },
        ],
        '022' => [
            'title'  => 'Reusable (multi-use) and hidden tokens',
            'run'    => function (PDO $db) {
                $out = [];
                $bad = [];
                foreach ([['multi_use', 'TINYINT(1) NOT NULL DEFAULT 0'],
                          ['is_hidden', 'TINYINT(1) NOT NULL DEFAULT 0']] as [$c, $d]) {
                    try { if (sfy_add_column('sfy_tokens', $c, $d, $db)) $out[] = 'sfy_tokens.' . $c; }
                    catch (Throwable $e) {
                        error_log('[SFY] token col ' . $c . ': ' . $e->getMessage());
                        $bad[] = 'sfy_tokens.' . $c . ': ' . $e->getMessage();
                    }
                }
                return ['notes' => $out, 'failed' => $bad];
            },
        ],
        /*
         * Zero-tap task handoff.
         *
         * `/done` already forwards a confirmed step straight to the next task,
         * and the flag it forwards with (`zt=1`) now makes that page open the
         * handoff itself instead of rendering another card to press. On by
         * default — it is the same flow the landing page has always described
         * — and switchable in Settings → Flow & anti-bypass.
         */
        '023' => [
            'title'  => 'Zero-tap flow — open the next task after a confirmed step',
            'run'    => function (PDO $db) {
                $current = sfy_config_all(true);
                $seeded  = [];
                foreach ([['set_zerotap', sfy_cfg('security.zerotap', true) ? '1' : '0']] as [$k, $v]) {
                    if (array_key_exists($k, $current)) continue;
                    sfy_config_set($k, $v);
                    $seeded[] = $k;
                }
                return ['notes' => $seeded, 'failed' => []];
            },
        ],
        /*
         * The hand-off card's countdown length, so the pause between "task n is
         * done" and the next task opening is tunable per site (2–15s, shipped
         * 5). Seeded only — an existing site that never touched it behaves
         * exactly as before, because the helper's fallback is the same 5s.
         */
        '024' => [
            'title'  => 'Zero-tap hand-off countdown length (seconds)',
            'run'    => function (PDO $db) {
                $current = sfy_config_all(true);
                $seeded  = [];
                foreach ([['set_zerotap_handoff_seconds',
                           (string)sfy_cfg('security.zerotap_handoff_seconds', 5)]] as [$k, $v]) {
                    if (array_key_exists($k, $current)) continue;
                    sfy_config_set($k, $v);
                    $seeded[] = $k;
                }
                return ['notes' => $seeded, 'failed' => []];
            },
        ],
        '021' => [
            'title'  => 'Browser identity on sessions (device change → restart at task 1)',
            'run'    => function (PDO $db) {
                $out = [];
                $bad = [];
                try {
                    if (sfy_add_column('sfy_sessions', 'flow_identity', 'VARCHAR(64) NULL', $db)) {
                        $out[] = 'sfy_sessions.flow_identity';
                    }
                } catch (Throwable $e) {
                    error_log('[SFY] flow_identity column: ' . $e->getMessage());
                    $bad[] = 'sfy_sessions.flow_identity: ' . $e->getMessage();
                }
                /*
                 * Sessions created before this migration have no identity, so
                 * they keep working: the check only acts when a session *has*
                 * one, and never locks anyone out on a missing value.
                 */
                return ['notes' => $out, 'failed' => $bad];
            },
        ],
        '020' => [
            'title'  => 'Code opens — who reopened a finished code, from where',
            'tables' => ['sfy_code_opens'],
            'run'    => function (PDO $db) {
                /* Backfill one row per already-completed session that carries a
                   view count, so the panel is not empty on an existing site. */
                $notes = ['sfy_code_opens'];
                $bad   = [];
                try {
                    $have = sfy_column_exists('sfy_sessions', 'code_views', $db);
                    if (!$have) return ['notes' => $notes, 'failed' => $bad];
                    $rows = $db->query("SELECT s.session_id, s.token, s.device_id, s.code_views, s.user_ip,
                                               s.country, s.completed_at, d.device_name, d.os, d.browser
                                        FROM sfy_sessions s LEFT JOIN sfy_devices d ON d.id = s.device_id
                                        WHERE s.is_completed=1 AND s.code_views > 0 LIMIT 500")->fetchAll();
                    if (!$rows) return ['notes' => $notes, 'failed' => $bad];

                    $seen = (int)$db->query("SELECT COUNT(*) AS n FROM sfy_code_opens")->fetch()['n'];
                    if ($seen > 0) return ['notes' => $notes, 'failed' => $bad];

                    $st = $db->prepare("INSERT INTO sfy_code_opens
                        (token, session_id, device_id, device_name, device_type, os, browser, ip, country,
                         timezone, own_device, created_at)
                        VALUES (?,?,?,?,?,?,?,?,?,'',1,?)");
                    $n = 0;
                    foreach ($rows as $r) {
                        // One row per recorded view, capped so a wild counter cannot
                        // flood the table during an upgrade.
                        $times = min((int)$r['code_views'], 50);
                        for ($i = 0; $i < $times; $i++) {
                            $st->execute([(string)$r['token'], (string)$r['session_id'], (int)$r['device_id'],
                                          (string)($r['device_name'] ?? ''), '', (string)($r['os'] ?? ''),
                                          (string)($r['browser'] ?? ''), (string)($r['user_ip'] ?? ''),
                                          (string)($r['country'] ?? ''), (string)($r['completed_at'] ?? '')]);
                            $n++;
                        }
                    }
                    if ($n > 0) $notes[] = 'backfilled ' . $n . ' historical open(s)';
                } catch (Throwable $e) {
                    error_log('[SFY] code_opens backfill: ' . $e->getMessage());
                    $bad[] = 'backfill: ' . $e->getMessage();
                }
                return ['notes' => $notes, 'failed' => $bad];
            },
        ],
        /*
         * The pinned mobile button's wording, one setting per state (a task is
         * running / the code is still open / nothing to recover). `{step}` and
         * `{total}` are substituted with the live numbers, so the site owner can
         * keep the numbers or drop them. Seeded with exactly the shipped
         * wording: an install that never touches the fields renders the same
         * markup it always did.
         */
        '025' => [
            'title'  => 'Pinned mobile button labels (continue / code / guide)',
            'run'    => function (PDO $db) {
                $current = sfy_config_all(true);
                $seeded  = [];
                foreach ([
                    'set_pinned_label_continue' => 'CONTINUE TASK {step}/{total}',
                    'set_pinned_label_code'     => 'SHOW MY CODE',
                    'set_pinned_label_guide'    => 'HOW TO GET THE CODE',
                ] as $k => $v) {
                    if (array_key_exists($k, $current)) continue;
                    sfy_config_set($k, $v);
                    $seeded[] = $k;
                }
                return ['notes' => $seeded, 'failed' => []];
            },
        ],
        /*
         * The pinned bar's "nothing to recover" wording moved from "HOW TO GET
         * THE CODE" to "HOW TO GET TOKEN". The bar is the *action* bar now —
         * inside the flow it mirrors the page's own continue button — so what is
         * left for it to say through the guide is how to get a token, not how to
         * read the code the flow already hands over.
         *
         * Only the untouched shipped default moves: a site that wrote its own
         * wording in Settings keeps it, while the phrase seeded by 025 (and a
         * missing row) both end up on the new one.
         */
        '026' => [
            'title'  => 'Pinned mobile button — guide wording is about getting a token',
            'run'    => function (PDO $db) {
                $all     = sfy_config_all(true);
                $current = (string)($all['set_pinned_label_guide'] ?? '');
                if ($current === 'HOW TO GET TOKEN') {
                    return ['notes' => ['set_pinned_label_guide already current'], 'failed' => []];
                }
                if ($current === '' || $current === 'HOW TO GET THE CODE') {
                    sfy_config_set('set_pinned_label_guide', 'HOW TO GET TOKEN');
                    return ['notes' => ['set_pinned_label_guide → HOW TO GET TOKEN'], 'failed' => []];
                }
                return ['notes' => ['custom guide wording kept: ' . $current], 'failed' => []];
            },
        ],
        /*
         * TASK PROVIDERS.
         *
         * Until now "the provider" was LootLabs, hard-coded in the flow. This
         * step turns that into a registry an administrator can extend from the
         * panel: a provider row (kind, task URL template, return hosts, budget),
         * an account pool per provider, and the session/step columns that
         * remember where a player chose to earn.
         *
         * LootLabs is seeded as provider #1 and every account that already
         * exists is assigned to it, so an existing install keeps working
         * untouched: one offerable provider means no question is asked and the
         * flow behaves exactly as it did before. Work.ink is seeded ready to
         * use (1 task per run) and simply waits for its first account.
         */
        '027' => [
            'title'  => 'Task providers — LootLabs + Work.ink, accounts per provider, per-provider task budget',
            'tables' => ['sfy_providers'],
            'run'    => function (PDO $db) {
                $notes = ['sfy_providers'];
                $bad   = [];

                foreach ([['lootlabs_accounts', 'provider_id', 'INT NOT NULL DEFAULT 0'],
                          ['sfy_sessions', 'provider_id', 'INT NOT NULL DEFAULT 0'],
                          ['sfy_step_tokens', 'provider_id', 'INT NOT NULL DEFAULT 0']] as [$t, $c, $def]) {
                    try {
                        if (sfy_add_column($t, $c, $def, $db)) $notes[] = "$t.$c";
                    } catch (Throwable $e) {
                        error_log("[SFY] $t.$c: " . $e->getMessage());
                        $bad[] = "$t.$c: " . $e->getMessage();
                    }
                }
                sfy_add_index('lootlabs_accounts', 'idx_acct_provider', '`provider_id`, `is_active`', false, $db);

                /* Seed the two shipped providers once each. */
                $seed = [
                    'lootlabs' => [
                        'name' => 'LootLabs', 'kind' => 'lootlabs', 'sort_order' => 1, 'tasks_allowed' => 2,
                        'description' => 'Fast tasks with instant verification.',
                        'return_hosts' => 'lootlabs.gg,lootlabs.com,loot-link.com',
                    ],
                    'workink' => [
                        'name' => 'Work.ink', 'kind' => 'workink', 'sort_order' => 2, 'tasks_allowed' => 1,
                        'description' => 'Quick Work.ink task — one click to finish.',
                        'return_hosts' => 'work.ink,workink.com',
                    ],
                ];
                $ids = [];
                foreach ($seed as $slug => $row) {
                    $st = $db->prepare('SELECT id FROM sfy_providers WHERE slug=? LIMIT 1');
                    $st->execute([$slug]);
                    $id = (int)($st->fetch()['id'] ?? 0);
                    if ($id > 0) { $ids[$slug] = $id; continue; }
                    $db->prepare('INSERT INTO sfy_providers
                        (slug, name, kind, description, is_active, sort_order, tasks_allowed, url_params,
                         pass_params, return_hosts, created_at, updated_at)
                        VALUES (?,?,?,?,1,?,?,?,1,?,NOW(),NOW())')
                       ->execute([$slug, $row['name'], $row['kind'], $row['description'], (int)$row['sort_order'],
                                  (int)$row['tasks_allowed'], '', $row['return_hosts']]);
                    $ids[$slug] = (int)$db->lastInsertId();
                    $notes[] = "seeded provider $slug";
                }

                /* Every existing account belongs to LootLabs until the owner
                   says otherwise — that is the pool the site has been rotating
                   all along. */
                if (!empty($ids['lootlabs'])) {
                    try {
                        $n = $db->exec('UPDATE lootlabs_accounts SET provider_id=' . (int)$ids['lootlabs']
                                     . ' WHERE provider_id=0 OR provider_id IS NULL');
                        if ((int)$n > 0) $notes[] = "assigned $n existing account(s) to LootLabs";
                    } catch (Throwable $e) {
                        error_log('[SFY] account assignment: ' . $e->getMessage());
                        $bad[] = 'account assignment: ' . $e->getMessage();
                    }
                }

                return ['notes' => $notes, 'failed' => $bad];
            },
        ],
        /*
         * HUMAN CHECK (TURNSTILE) BEFORE A RUN STARTS.
         *
         * The claim link was the only request in the flow that cost nothing
         * and produced a session row, so it was the only one worth scripting.
         * This step adds what the gate needs to be *enforced and readable*:
         *
         *   sfy_sessions.captcha_passed_at — the run solved the challenge, so
         *     the claim page never asks the same run twice;
         *   sfy_captcha_log — one row per decided challenge, which is how the
         *     panel can answer "was this thing doing anything?".
         *
         * No keys are seeded here on purpose: an install that enabled
         * Turnstile in config.php keeps working untouched (the panel shows its
         * values and overrides them only when the owner saves the form).
         */
        '028' => [
            'title'  => 'Human check (Turnstile) — per-run pass and challenge log',
            'tables' => ['sfy_captcha_log'],
            'run'    => function (PDO $db) {
                $notes = ['sfy_captcha_log'];
                $bad   = [];

                try {
                    if (sfy_add_column('sfy_sessions', 'captcha_passed_at', 'DATETIME NULL', $db)) {
                        $notes[] = 'sfy_sessions.captcha_passed_at';
                    }
                } catch (Throwable $e) {
                    error_log('[SFY] sfy_sessions.captcha_passed_at: ' . $e->getMessage());
                    $bad[] = 'sfy_sessions.captcha_passed_at: ' . $e->getMessage();
                }

                foreach ([['idx_cap_created', '`created_at`'],
                          ['idx_cap_context', '`context`, `created_at`'],
                          ['idx_cap_ip', '`ip`, `created_at`']] as [$idx, $cols]) {
                    try {
                        if (sfy_add_index('sfy_captcha_log', $idx, $cols, false, $db)) $notes[] = "sfy_captcha_log.$idx";
                    } catch (Throwable $e) {
                        error_log("[SFY] sfy_captcha_log.$idx: " . $e->getMessage());
                        $bad[] = "sfy_captcha_log.$idx: " . $e->getMessage();
                    }
                }

                return ['notes' => $notes, 'failed' => $bad];
            },
        ],
        /*
         * DEFINITION-DERIVED COLUMN REPAIR.
         *
         * Live installs proved the hole this closes: `sfy_postback_log` was
         * created before `created_at` existed, so the column was missing while
         * every migration reported "ok" — the updater announced schema 028 and
         * the diagnostic named the missing column, but nothing could create it
         * (CREATE TABLE IF NOT EXISTS never alters an existing table, and the
         * hand-written upgrade list had no entry for it). Every page that
         * touched it answered HTTP 500.
         *
         * This step exists so a stale install has an actual pending migration
         * to apply — the public auto-repair and the admin buttons both run
         * pending steps — and it re-derives the ALTER from the definitions, so
         * the same blind spot cannot come back.
         */
        '029' => [
            'title'  => 'Repair columns the definitions declare but the database is missing',
            'run'    => fn(PDO $db) => sfy_schema_repair_columns($db),
        ],
        /*
         * PARKING A NETWORK FOR MAINTENANCE.
         *
         * A task network breaks — its dashboard is down, its postbacks stop,
         * the owner is re-negotiating a link — and until now the only lever
         * was TOGGLE (is_active), which *hides* the provider completely: the
         * chooser silently loses an option and a player who had already picked
         * it is bounced to the other one with no explanation. That reads as a
         * bug, so the owner needs a state that says what is happening instead.
         *
         *   is_maintenance = 1  →  still listed on the chooser, greyed and
         *                          labelled UNDER MAINTENANCE, never offered
         *                          for a step, and never counted when the flow
         *                          decides whether there is really a choice to
         *                          make (so it cannot strand anybody on a
         *                          budget that only the parked network was
         *                          supposed to help cover).
         *
         * The pass-through hub needs no column: `set_hub_pass` (Admin →
         * Settings → Flow & anti-bypass) defaults to ON and is read from the
         * config table like every other flow switch.
         */
        '030' => [
            'title'  => 'Provider maintenance — a parked network is shown, greyed, and never offered',
            'tables' => ['sfy_providers'],
            'run'    => function (PDO $db) {
                $notes = ['sfy_providers'];
                $bad   = [];
                try {
                    if (sfy_add_column('sfy_providers', 'is_maintenance', 'TINYINT(1) NOT NULL DEFAULT 0', $db)) {
                        $notes[] = 'sfy_providers.is_maintenance';
                    }
                } catch (Throwable $e) {
                    error_log('[SFY] sfy_providers.is_maintenance: ' . $e->getMessage());
                    $bad[] = 'sfy_providers.is_maintenance: ' . $e->getMessage();
                }
                return ['notes' => $notes, 'failed' => $bad];
            },
        ],
        /*
         * THE PER-RUN RETURN TICKET — the LootLabs `&data=` destination stops
         * being a fixed, guessable landing page.
         *
         * The hole this closes: our landing page was the SAME `/done` for every
         * visitor and its address is public, so a bypass service only had to
         * navigate the player there. The only thing guarding it was the
         * browser's own headers — a `cross-site` document navigation with no
         * referrer was accepted as "the provider sent you here" — and any
         * server-side caller can set those, or strip the referrer on a
         * meta-refresh/`rel=noreferrer` redirect. So the landing counted, the
         * step confirmed and the code was handed over with no task done.
         *
         * There is exactly one thing only LootLabs can do: decrypt the
         * `&data=` blob. So the destination itself becomes something only that
         * decryption can reveal — `/done?rt=<ticket>` — and the ticket is
         * minted per run (per step), embedded *only* inside the encrypted blob,
         * never in the plain task URL, and is single-use.
         *
         * A step that carries a ticket may only be confirmed by a landing that
         * presents it; a bare `/done`, a replayed ticket, or a ticket from a
         * different run confirms nothing. Steps handed off without one (a plain
         * link, Work.ink, a custom provider) keep the ordinary gates, so this
         * change cannot strand a provider that has no `&data=` mechanism.
         *
         *   sfy_step_tokens.return_ticket         — the one-time ticket
         *   sfy_step_tokens.return_ticket_at      — when it was minted
         *   sfy_step_tokens.return_ticket_used_at — set when it confirmed a step
         */
        '031' => [
            'title'  => 'Per-run return ticket — the encrypted LootLabs destination is the only way back',
            'tables' => ['sfy_step_tokens'],
            'run'    => function (PDO $db) {
                $notes = ['sfy_step_tokens'];
                $bad   = [];
                foreach ([['return_ticket',         'VARCHAR(64) NULL'],
                          ['return_ticket_at',      'DATETIME NULL'],
                          ['return_ticket_used_at', 'DATETIME NULL']] as [$c, $d]) {
                    try {
                        if (sfy_add_column('sfy_step_tokens', $c, $d, $db)) $notes[] = 'sfy_step_tokens.' . $c;
                    } catch (Throwable $e) {
                        error_log('[SFY] sfy_step_tokens.' . $c . ': ' . $e->getMessage());
                        $bad[] = 'sfy_step_tokens.' . $c . ': ' . $e->getMessage();
                    }
                }
                try {
                    if (sfy_add_index('sfy_step_tokens', 'idx_step_ticket', '`return_ticket`', false, $db)) {
                        $notes[] = 'sfy_step_tokens.idx_step_ticket';
                    }
                } catch (Throwable $e) { /* the index is optional */ }

                $current = sfy_config_all(true);
                foreach ([['set_return_ticket_required', '1'],
                          ['set_postback_ip_enforce', '1'],
                          ['set_return_referrer_block', 'baconbypass.xyz,bypass.city,bypass.vip,rip.linkvertise.lol,bypass.link,bypass.tools,izen.lol']] as [$k, $v]) {
                    if (array_key_exists($k, $current)) continue;
                    sfy_config_set($k, $v);
                    $notes[] = $k;
                }

                return ['notes' => $notes, 'failed' => $bad];
            },
        ],
    ];

    ksort($m);
    return $m;
}

/* ── runner ────────────────────────────────────────────────────────── */
function sfy_migrations_ensure_table(?PDO $db = null): void {
    $db = $db ?? sfy_db();
    $db->exec(sfy_definitions()['sfy_migrations']);
}

function sfy_migrations_applied(?PDO $db = null): array {
    $db = $db ?? sfy_db();
    sfy_migrations_ensure_table($db);
    $out = [];
    foreach ($db->query("SELECT * FROM sfy_migrations")->fetchAll() as $r) $out[$r['id']] = $r;
    return $out;
}

/** Snapshot used by the admin Updater screen. */
function sfy_schema_status(?PDO $db = null): array {
    $db      = $db ?? sfy_db();
    $applied = sfy_migrations_applied($db);
    $all     = sfy_migrations();
    $pending = [];
    foreach ($all as $id => $m) {
        if (!isset($applied[$id]) || $applied[$id]['status'] !== 'ok') {
            $pending[$id] = $m;
        }
    }
    $tables = [];
    foreach ($db->query("SELECT TABLE_NAME, TABLE_ROWS FROM information_schema.TABLES
                         WHERE TABLE_SCHEMA = DATABASE()")->fetchAll() as $r) {
        $tables[$r['TABLE_NAME']] = (int)$r['TABLE_ROWS'];
    }
    return [
        'applied'  => $applied,
        'all'      => $all,
        'pending'  => $pending,
        'current'  => $applied ? max(array_keys($applied)) : '000',
        'latest'   => max(array_keys($all)),
        'tables'   => $tables,
        'version'  => (string)sfy_cfg('app.version'),
    ];
}

/**
 * Run pending migrations (or everything when $force = true).
 * @return array<int, array{id:string,title:string,status:string,notes:array}>
 */
function sfy_migrate(bool $force = false, ?PDO $db = null): array {
    $db      = $db ?? sfy_db();
    $applied = sfy_migrations_applied($db);
    $defs    = sfy_definitions();
    $log     = [];

    foreach (sfy_migrations() as $id => $m) {
        $done = isset($applied[$id]) && $applied[$id]['status'] === 'ok';
        if ($done && !$force) continue;

        $t0     = microtime(true);
        $notes  = [];
        $failed = [];
        try {
            foreach (($m['tables'] ?? []) as $t) {
                if (!isset($defs[$t])) continue;
                $existed = sfy_table_exists($t, $db);
                $db->exec($defs[$t]);
                $notes[] = ($existed ? 'verified' : 'created') . " table $t";
            }
            if (isset($m['run'])) {
                $res = ($m['run'])($db);
                if (is_array($res)) {
                    // Upgraders report {"notes":[],"failed":[]}; older steps
                    // return a flat list of note strings.
                    if (array_key_exists('notes', $res) || array_key_exists('failed', $res)) {
                        foreach (($res['notes'] ?? []) as $r)  $notes[]  = (string)$r;
                        foreach (($res['failed'] ?? []) as $r) $failed[] = (string)$r;
                    } else {
                        foreach ($res as $r) $notes[] = (string)$r;
                    }
                }
            }
            $ms = (int)round((microtime(true) - $t0) * 1000);

            if ($failed) {
                // Some statements inside this migration were rejected. Record it
                // as `partial` (not a lie, not a hard failure) so the installer
                // keeps retrying it and the admin Updater shows exactly what
                // could not be applied.
                $noteText = trim(implode('; ', array_merge($notes, array_map(fn($f) => "FAILED $f", $failed))));
                $db->prepare("INSERT INTO sfy_migrations (id,title,applied_at,duration_ms,status,notes)
                              VALUES (?,?,NOW(),?,'partial',?)
                              ON DUPLICATE KEY UPDATE applied_at=NOW(), duration_ms=VALUES(duration_ms),
                                                      status='partial', notes=VALUES(notes)")
                   ->execute([$id, $m['title'], $ms, $noteText]);
                sfy_schema_flag(false);
                $log[] = ['id' => $id, 'title' => $m['title'], 'status' => 'partial',
                          'notes' => array_merge($notes, array_map(fn($f) => "FAILED: $f", $failed))];
                continue;
            }

            $db->prepare("INSERT INTO sfy_migrations (id,title,applied_at,duration_ms,status,notes)
                          VALUES (?,?,NOW(),?,'ok',?)
                          ON DUPLICATE KEY UPDATE applied_at=NOW(), duration_ms=VALUES(duration_ms),
                                                  status='ok', notes=VALUES(notes)")
               ->execute([$id, $m['title'], $ms, implode('; ', $notes)]);
            $log[] = ['id' => $id, 'title' => $m['title'], 'status' => 'ok', 'notes' => $notes];
        } catch (Throwable $e) {
            $ms = (int)round((microtime(true) - $t0) * 1000);
            try {
                $db->prepare("INSERT INTO sfy_migrations (id,title,applied_at,duration_ms,status,notes)
                              VALUES (?,?,NOW(),?,'failed',?)
                              ON DUPLICATE KEY UPDATE applied_at=NOW(), status='failed', notes=VALUES(notes)")
                   ->execute([$id, $m['title'], $ms, $e->getMessage()]);
            } catch (Throwable $e2) { /* ignore */ }
            $log[] = ['id' => $id, 'title' => $m['title'], 'status' => 'failed', 'notes' => [$e->getMessage()]];
        }
    }

    sfy_schema_flush_cache();
    if (function_exists('sfy_config_all')) sfy_config_all(true);
    if ($log && !array_filter($log, fn($l) => $l['status'] !== 'ok')) sfy_schema_flag(true);
    return $log;
}

/* ── schema health flag ──────────────────────────────────────────────
   `set_schema_ok=1` means "the last verification found every table and
   every column this build needs". While it is set we skip the (14-odd)
   information_schema lookups on the public hot path; the moment anything
   reports a schema error the flag is cleared and the next request runs a
   full repair pass. */
function sfy_schema_flag(bool $ok): void {
    try { sfy_config_set('set_schema_ok', $ok ? '1' : '0'); } catch (Throwable $e) { /* DB down */ }
}

/** Columns the public verification flow cannot run without. */
function sfy_schema_sentinel(): array {
    return [
        ['sfy_config',       'config_key'],
        ['sfy_tokens',       'token'],
        ['sfy_tokens',       'is_used'],
        ['sfy_sessions',     'session_id'],
        ['sfy_sessions',     'is_completed'],
        ['sfy_sessions',     'expires_at'],
        ['sfy_sessions',     'fingerprint'],
        ['sfy_sessions',     'device_id'],
        ['sfy_sessions',     'step_started_at'],
        ['sfy_step_tokens',  'session_id'],
        ['sfy_step_tokens',  'clicked_at'],
        /* The return check trusts nothing without this: it is where /done
           records a provider landing the step may be confirmed from. */
        ['sfy_step_tokens',  'returned_at'],
        ['lootlabs_accounts','redirect_api'],
        ['sfy_devices',      'device_key'],
        ['sfy_postback_log', 'accepted'],
        /* Every postback/return path stamps and reads this column (the return
           check asks for MAX(created_at), the log insert writes it, the purge
           filters on it). While it was missing, those statements threw
           "Unknown column" instead of answering — a 500 on the claim page
           whose cause the diagnostic knew about but no repair could fix. */
        ['sfy_postback_log', 'created_at'],
        ['sfy_code_opens',   'token'],
        /* The human-check log: the panel reads it, and the gate writes to it. */
        ['sfy_captcha_log',  'outcome'],
        ['sfy_sessions',     'flow_identity'],
        /* Task providers (migration 027): the registry itself and the three
           columns that remember where a player chose to earn. */
        ['sfy_providers',    'slug'],
        /* Provider maintenance (migration 030): the chooser reads this column
           on every claim and every step, so a missing one is a 500 there. */
        ['sfy_providers',    'is_maintenance'],
        ['lootlabs_accounts','provider_id'],
        ['sfy_step_tokens',  'provider_id'],
        ['sfy_sessions',     'provider_id'],
    ];
}

/**
 * Fast, cached check: does this install have everything the flow needs?
 * Honours the `set_schema_ok` flag so a healthy site costs one config read.
 */
function sfy_schema_sentinel_ok(bool $force = false): bool {
    if (!$force && (string)sfy_config_get('set_schema_ok', '') === '1') return true;
    $ok = true;
    foreach (sfy_schema_sentinel() as [$table, $column]) {
        if (!sfy_table_exists($table) || !sfy_column_exists($table, $column)) { $ok = false; break; }
    }
    if ($ok) sfy_schema_flag(true);
    return $ok;
}

/** Run a repair pass but never more than once a minute for a stuck step. */
function sfy_install_if_empty(): void {
    static $ran = false;
    if ($ran) return;
    $ran = true;
    try {
        $applied = sfy_migrations_applied();
        $stuck   = null;

        foreach (sfy_migrations() as $id => $m) {
            $row = $applied[$id] ?? null;
            if ($row && ($row['status'] ?? '') === 'ok') continue;
            $stuck = $row ?: ['status' => 'missing', 'applied_at' => null];
            break;
        }

        if ($stuck) {
            // Throttle retries of a step that keeps failing so a broken ALTER
            // cannot slow every single page load.
            $at = (string)($stuck['applied_at'] ?? '');
            $ts = $at !== '' ? (int)strtotime($at) : 0;
            if ($ts > 0 && (time() - $ts) < 60) { sfy_schema_flag(false); return; }
            sfy_migrate();
            return;
        }

        // Migrations all look applied — verify the columns the flow needs and
        // repair the whole schema if any went missing.
        if (!sfy_schema_sentinel_ok()) {
            sfy_schema_flush_cache();
            sfy_migrate(true);
            sfy_schema_sentinel_ok(true);
        }
    } catch (Throwable $e) {
        error_log('[SFY] auto install: ' . $e->getMessage());
    }
}

/** Expected column names parsed straight out of a CREATE TABLE definition. */
function sfy_schema_expected_columns(string $definition): array {
    return array_keys(sfy_schema_defined_columns($definition));
}

/**
 * Compare every managed table against its definition.
 * @return array<string, array{missing_table:bool, missing:array, expected:int}>
 */
function sfy_schema_column_report(): array {
    return sfy_try(function (): array {
        $report = [];
        foreach (sfy_definitions() as $table => $ddl) {
            $expected = sfy_schema_expected_columns($ddl);
            if (!sfy_table_exists($table)) {
                $report[$table] = ['missing_table' => true, 'missing' => $expected, 'expected' => count($expected)];
                continue;
            }
            $missing = [];
            foreach ($expected as $col) if (!sfy_column_exists($table, $col)) $missing[] = $col;
            if ($missing) $report[$table] = ['missing_table' => false, 'missing' => $missing, 'expected' => count($expected)];
        }
        return $report;
    }, []);
}

/** Pending (never applied or previously failed) migration ids. */
function sfy_migrations_pending(): array {
    $out = [];
    try {
        $applied = sfy_migrations_applied();
        foreach (sfy_migrations() as $id => $m) {
            if (!isset($applied[$id]) || ($applied[$id]['status'] ?? '') !== 'ok') $out[$id] = $m;
        }
    } catch (Throwable $e) { /* ignore */ }
    return $out;
}
