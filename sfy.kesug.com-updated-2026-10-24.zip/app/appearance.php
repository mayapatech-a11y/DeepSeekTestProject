<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY ULTIMATE — APPEARANCE / THEME ENGINE
 *  Four curated looks plus per-install overrides (accent, radius, glow,
 *  effects, shell width, density). Everything lives in the database
 *  (sfy_config) so a design survives reloads, exports and migrations.
 *
 *  The whole UI is driven by CSS custom properties, so a theme is just a
 *  map of `--token => value` printed into a <style> block after the sheet.
 * ═══════════════════════════════════════════════════════════════════════
 */

/* ── palettes ──────────────────────────────────────────────────────── */
function sfy_design_presets(): array {
    return [

        'ink' => [
            'label'  => 'Deep Ink',
            'blurb'  => 'Calm slate-blue with a mint accent. Easiest on the eyes.',
            'scheme' => 'dark',
            'swatch' => ['#171e2e', '#38d9b0', '#7ba2f0'],
            'vars'   => [
                '--bg' => '#171e2e', '--bg-2' => '#121826',
                '--panel' => '#202a3f', '--panel-2' => '#27334c', '--panel-3' => '#33415f',
                '--input' => '#1b2334', '--line' => '#33405c', '--line-2' => '#46577a',
                '--neon' => '#38d9b0', '--neon-dim' => '#1f9e82', '--neon-soft' => '#9df0da',
                '--cyan' => '#4cc2e8', '--blue' => '#7ba2f0',
                '--violet' => '#a08cff', '--violet-dim' => '#6f5bd6',
                '--pink' => '#ef7fa8', '--lime' => '#9ed36a',
                '--gold' => '#e8b34a', '--gold-dim' => '#a07a1e', '--orange' => '#f09455',
                '--red' => '#ef6f7e', '--red-dim' => '#a83e4c', '--purple' => '#bb9af7',
                '--text' => '#eef2ff', '--text-dim' => '#c3cde6', '--text-mute' => '#939fc0',
            ],
        ],

        'aurora' => [
            'label'  => 'Aurora',
            'blurb'  => 'Indigo and violet. The most "gamer" of the four.',
            'scheme' => 'dark',
            'swatch' => ['#191a33', '#8f7bff', '#5ec8f5'],
            'vars'   => [
                '--bg' => '#191a33', '--bg-2' => '#14142a',
                '--panel' => '#23244a', '--panel-2' => '#2b2d59', '--panel-3' => '#393c74',
                '--input' => '#1e2040', '--line' => '#3a3d70', '--line-2' => '#515593',
                '--neon' => '#8f7bff', '--neon-dim' => '#6a54e0', '--neon-soft' => '#c9bcff',
                '--cyan' => '#5ec8f5', '--blue' => '#7ea2ff',
                '--violet' => '#c4a8ff', '--violet-dim' => '#8468e0',
                '--pink' => '#ff86c8', '--lime' => '#a8dd6a',
                '--gold' => '#f2c14e', '--gold-dim' => '#a8821c', '--orange' => '#ff9d5c',
                '--red' => '#ff7d92', '--red-dim' => '#b23e52', '--purple' => '#d4b3ff',
                '--text' => '#f2efff', '--text-dim' => '#cfc7f2', '--text-mute' => '#a09ac8',
            ],
        ],

        'ember' => [
            'label'  => 'Ember',
            'blurb'  => 'Warm charcoal with amber. Good contrast, low blue light.',
            'scheme' => 'dark',
            'swatch' => ['#1d1a18', '#f0a13c', '#e8798f'],
            'vars'   => [
                '--bg' => '#1d1a18', '--bg-2' => '#171412',
                '--panel' => '#262220', '--panel-2' => '#2f2a26', '--panel-3' => '#3d3630',
                '--input' => '#221e1b', '--line' => '#3d352e', '--line-2' => '#564a3f',
                '--neon' => '#f0a13c', '--neon-dim' => '#bd7720', '--neon-soft' => '#ffd79a',
                '--cyan' => '#63c7d6', '--blue' => '#86a8e0',
                '--violet' => '#b79cff', '--violet-dim' => '#7d63c9',
                '--pink' => '#e8798f', '--lime' => '#b8c95a',
                '--gold' => '#f5c451', '--gold-dim' => '#ad8620', '--orange' => '#ff8f4d',
                '--red' => '#e8686d', '--red-dim' => '#a63f44', '--purple' => '#c9a3e8',
                '--text' => '#faf5ef', '--text-dim' => '#ddd2c6', '--text-mute' => '#a89b8c',
            ],
        ],

        'midnight' => [
            'label'  => 'Midnight',
            'blurb'  => 'Deep navy with electric cyan. Classic dev-tool look.',
            'scheme' => 'dark',
            'swatch' => ['#0d1424', '#35d6ff', '#5b8cff'],
            'vars'   => [
                '--bg' => '#0d1424', '--bg-2' => '#080e1b',
                '--panel' => '#16203a', '--panel-2' => '#1c2846', '--panel-3' => '#26345a',
                '--input' => '#111a2e', '--line' => '#24304e', '--line-2' => '#35446b',
                '--neon' => '#35d6ff', '--neon-dim' => '#1a9dc4', '--neon-soft' => '#9fe9ff',
                '--cyan' => '#5fd0ff', '--blue' => '#5b8cff',
                '--violet' => '#8b7bff', '--violet-dim' => '#5a4bd6',
                '--pink' => '#ff7bb0', '--lime' => '#8fd95b',
                '--gold' => '#f5c451', '--gold-dim' => '#a8861e', '--orange' => '#ff9a52',
                '--red' => '#ff6f85', '--red-dim' => '#a83a4e', '--purple' => '#b9a2ff',
                '--text' => '#eaf2ff', '--text-dim' => '#b9c8e6', '--text-mute' => '#8595b8',
            ],
        ],

        'cyber' => [
            'label'  => 'Cyberpunk',
            'blurb'  => 'Near-black with hot magenta and cyan. Loudest of the set.',
            'scheme' => 'dark',
            'swatch' => ['#0b0a14', '#ff4fd8', '#4bf0ff'],
            'vars'   => [
                '--bg' => '#0b0a14', '--bg-2' => '#07060f',
                '--panel' => '#171331', '--panel-2' => '#1e1940', '--panel-3' => '#2a2356',
                '--input' => '#120f26', '--line' => '#2d2657', '--line-2' => '#423877',
                '--neon' => '#ff4fd8', '--neon-dim' => '#c0229f', '--neon-soft' => '#ffb3ef',
                '--cyan' => '#4bf0ff', '--blue' => '#6f7dff',
                '--violet' => '#a06bff', '--violet-dim' => '#6f3fd6',
                '--pink' => '#ff6fb5', '--lime' => '#a6ff4f',
                '--gold' => '#ffd24a', '--gold-dim' => '#b38f10', '--orange' => '#ff8f3f',
                '--red' => '#ff5470', '--red-dim' => '#b02340', '--purple' => '#c9a6ff',
                '--text' => '#f6efff', '--text-dim' => '#ccc0ea', '--text-mute' => '#9b8fc0',
            ],
        ],

        'toxic' => [
            'label'  => 'Toxic',
            'blurb'  => 'Black and acid lime. High energy, still readable.',
            'scheme' => 'dark',
            'swatch' => ['#0e130c', '#a9f227', '#45e6c8'],
            'vars'   => [
                '--bg' => '#0e130c', '--bg-2' => '#090d07',
                '--panel' => '#172214', '--panel-2' => '#1e2c19', '--panel-3' => '#293c22',
                '--input' => '#131c10', '--line' => '#2b3d22', '--line-2' => '#3f5a32',
                '--neon' => '#a9f227', '--neon-dim' => '#78b312', '--neon-soft' => '#d9ff9a',
                '--cyan' => '#45e6c8', '--blue' => '#63b4e0',
                '--violet' => '#a98cff', '--violet-dim' => '#7050cf',
                '--pink' => '#ff77a8', '--lime' => '#c6ff4f',
                '--gold' => '#f2d33f', '--gold-dim' => '#a89212', '--orange' => '#ffa03a',
                '--red' => '#ff5f6d', '--red-dim' => '#a8323f', '--purple' => '#c0a6ff',
                '--text' => '#f2fbe8', '--text-dim' => '#c6d6b8', '--text-mute' => '#93a385',
            ],
        ],

        'crimson' => [
            'label'  => 'Crimson',
            'blurb'  => 'Dark maroon with a red accent. Aggressive but clean.',
            'scheme' => 'dark',
            'swatch' => ['#170f13', '#ff4d6d', '#55d6e0'],
            'vars'   => [
                '--bg' => '#170f13', '--bg-2' => '#100a0d',
                '--panel' => '#241a20', '--panel-2' => '#2e2129', '--panel-3' => '#3d2c35',
                '--input' => '#1d1218', '--line' => '#3a2a32', '--line-2' => '#543c46',
                '--neon' => '#ff4d6d', '--neon-dim' => '#c22a49', '--neon-soft' => '#ffb0bf',
                '--cyan' => '#55d6e0', '--blue' => '#7f9bff',
                '--violet' => '#b98cff', '--violet-dim' => '#7d55d6',
                '--pink' => '#ff86b8', '--lime' => '#b6d94f',
                '--gold' => '#f7c948', '--gold-dim' => '#ac8a12', '--orange' => '#ff9048',
                '--red' => '#ff5a6a', '--red-dim' => '#a82a3a', '--purple' => '#cba6ff',
                '--text' => '#fdeef1', '--text-dim' => '#e0c6cc', '--text-mute' => '#ab8f96',
            ],
        ],

        'sunset' => [
            'label'  => 'Sunset',
            'blurb'  => 'Dusk purple with amber. Warm and easy at night.',
            'scheme' => 'dark',
            'swatch' => ['#1a1226', '#ff9a52', '#b48cff'],
            'vars'   => [
                '--bg' => '#1a1226', '--bg-2' => '#120c1c',
                '--panel' => '#261a38', '--panel-2' => '#2f2145', '--panel-3' => '#3f2d5a',
                '--input' => '#1f1630', '--line' => '#3c2c55', '--line-2' => '#57407a',
                '--neon' => '#ff9a52', '--neon-dim' => '#c96b1f', '--neon-soft' => '#ffcda0',
                '--cyan' => '#58d4e6', '--blue' => '#7b93ff',
                '--violet' => '#b48cff', '--violet-dim' => '#7a52d6',
                '--pink' => '#ff7fb0', '--lime' => '#c3d95a',
                '--gold' => '#ffcc4d', '--gold-dim' => '#b38a12', '--orange' => '#ff8a3d',
                '--red' => '#ff5f77', '--red-dim' => '#ab2a45', '--purple' => '#d0a6ff',
                '--text' => '#fff1e6', '--text-dim' => '#dcc8ba', '--text-mute' => '#a89486',
            ],
        ],

        'royal' => [
            'label'  => 'Royal',
            'blurb'  => 'Indigo and gold. Premium-store kind of look.',
            'scheme' => 'dark',
            'swatch' => ['#101433', '#f6c445', '#7e9dff'],
            'vars'   => [
                '--bg' => '#101433', '--bg-2' => '#0a0d24',
                '--panel' => '#191f4d', '--panel-2' => '#202863', '--panel-3' => '#2b3583',
                '--input' => '#141a44', '--line' => '#2b3577', '--line-2' => '#414ea0',
                '--neon' => '#f6c445', '--neon-dim' => '#bb8f14', '--neon-soft' => '#ffe6a1',
                '--cyan' => '#4fd6e6', '--blue' => '#7e9dff',
                '--violet' => '#a08cff', '--violet-dim' => '#6f52d6',
                '--pink' => '#ff86c8', '--lime' => '#a8d95a',
                '--gold' => '#ffd34d', '--gold-dim' => '#b88f12', '--orange' => '#ff9d4d',
                '--red' => '#ff6f80', '--red-dim' => '#aa3346', '--purple' => '#c9a6ff',
                '--text' => '#f4f6ff', '--text-dim' => '#c6cdf0', '--text-mute' => '#929ac8',
            ],
        ],

        'frost' => [
            'label'  => 'Frost',
            'blurb'  => 'Light theme — bright, clean, great in daylight.',
            'scheme' => 'light',
            'swatch' => ['#eef1f8', '#0e9f8c', '#3b6fd4'],
            'vars'   => [
                '--bg' => '#eef1f8', '--bg-2' => '#e3e8f4',
                '--panel' => '#ffffff', '--panel-2' => '#f6f8fd', '--panel-3' => '#eaeef8',
                '--input' => '#ffffff', '--line' => '#d2d9ea', '--line-2' => '#b9c3dd',
                '--neon' => '#0e9f8c', '--neon-dim' => '#0b7d6e', '--neon-soft' => '#0b6b5f',
                '--cyan' => '#0d8fb5', '--blue' => '#3b6fd4',
                '--violet' => '#6d4fd6', '--violet-dim' => '#5b40b8',
                '--pink' => '#d63384', '--lime' => '#5f8f16',
                '--gold' => '#a06a00', '--gold-dim' => '#8a5c00', '--orange' => '#c25e00',
                '--red' => '#c2354a', '--red-dim' => '#9c2738', '--purple' => '#7b3fd6',
                '--text' => '#1a2133', '--text-dim' => '#3d4762', '--text-mute' => '#5c6784',
            ],
        ],

        'paper' => [
            'label'  => 'Paper',
            'blurb'  => 'Warm cream light theme with a sepia-ink accent.',
            'scheme' => 'light',
            'swatch' => ['#f7f4ee', '#b26a12', '#2f62c9'],
            'vars'   => [
                '--bg' => '#f7f4ee', '--bg-2' => '#efeae1',
                '--panel' => '#ffffff', '--panel-2' => '#fbf8f3', '--panel-3' => '#f1ece2',
                '--input' => '#ffffff', '--line' => '#ded6c7', '--line-2' => '#c6bcaa',
                '--neon' => '#b26a12', '--neon-dim' => '#8d5209', '--neon-soft' => '#7a4606',
                '--cyan' => '#0d7f96', '--blue' => '#2f62c9',
                '--violet' => '#6b46c9', '--violet-dim' => '#57379f',
                '--pink' => '#c22a72', '--lime' => '#55801a',
                '--gold' => '#9a6a06', '--gold-dim' => '#7d5504', '--orange' => '#b85510',
                '--red' => '#b8293e', '--red-dim' => '#8f1f30', '--purple' => '#7a3fbf',
                '--text' => '#221c14', '--text-dim' => '#4a4238', '--text-mute' => '#6d6456',
            ],
        ],

        'mint' => [
            'label'  => 'Mint',
            'blurb'  => 'Fresh light theme in cool green — no glare.',
            'scheme' => 'light',
            'swatch' => ['#eef7f4', '#0b8f74', '#2f63c9'],
            'vars'   => [
                '--bg' => '#eef7f4', '--bg-2' => '#e2eeea',
                '--panel' => '#ffffff', '--panel-2' => '#f4fbf9', '--panel-3' => '#e6f2ee',
                '--input' => '#ffffff', '--line' => '#c8ded7', '--line-2' => '#a9c8be',
                '--neon' => '#0b8f74', '--neon-dim' => '#076b57', '--neon-soft' => '#065c4a',
                '--cyan' => '#0a7f97', '--blue' => '#2f63c9',
                '--violet' => '#6a46c9', '--violet-dim' => '#55379f',
                '--pink' => '#c22a72', '--lime' => '#4e8018',
                '--gold' => '#92680a', '--gold-dim' => '#755206', '--orange' => '#b35510',
                '--red' => '#b82a3c', '--red-dim' => '#8f1f2e', '--purple' => '#753fc0',
                '--text' => '#11231f', '--text-dim' => '#3a504a', '--text-mute' => '#5d726b',
            ],
        ],
    ];
}

/**
 * UI font stacks. Google families are loaded on demand from the <head>.
 * @return array<string,array{label:string,stack:string,google:?string}>
 */
function sfy_design_fonts(): array {
    return [
        'inter'    => ['label' => 'Inter (default)', 'stack' => "'Inter',system-ui,sans-serif", 'google' => null],
        'outfit'   => ['label' => 'Outfit — modern geometric', 'stack' => "'Outfit','Inter',system-ui,sans-serif", 'google' => 'Outfit:wght@400;500;600;700'],
        'rajdhani' => ['label' => 'Rajdhani — gamer condensed', 'stack' => "'Rajdhani','Inter',system-ui,sans-serif", 'google' => 'Rajdhani:wght@400;500;600;700'],
        'orbitron' => ['label' => 'Orbitron — sci-fi display', 'stack' => "'Orbitron','Inter',system-ui,sans-serif", 'google' => 'Orbitron:wght@400;500;700'],
        'system'   => ['label' => 'System UI (fastest)', 'stack' => 'system-ui,-apple-system,Segoe UI,Roboto,sans-serif', 'google' => null],
    ];
}

/** Which palette variables the accent picker is allowed to rewrite. */
function sfy_design_accent_targets(): array { return ['--neon', '--neon-dim', '--neon-soft']; }

function sfy_design_defaults(): array {
    return [
        'preset'     => 'ink',
        'accent'     => '',        // empty = use the preset's accent
        'radius'     => 10,
        'glow'       => 45,        // 0–100 intensity of every glow/divider
        'shell'      => 1120,      // content max width in px
        'font_scale' => 100,       // 90–115 %
        'density'    => 'cozy',    // cozy | compact
        'card_style' => 'solid',   // solid | glass | outline
        'bg_pattern' => 'grid',    // none | grid | dots | mesh | stripes
        'fx_grid'    => 1,         // animated background wash
        'fx_aurora'  => 1,         // let that wash drift
        'fx_scan'    => 0,         // CRT scanlines (off by default now)
        'fx_shine'   => 1,         // light sweep across primary buttons
        /* ── advanced shaping ─────────────────────────────────────── */
        'font_ui'    => 'inter',   // inter | outfit | rajdhani | orbitron | system
        'btn_style'  => 'solid',   // solid | gradient | outline
        'nav_style'  => 'pill',    // pill | underline | plain
        'motion'     => 'soft',    // off | soft | full
        'line_w'     => 1,         // 0–3 px borders
        'grain'      => 0,         // subtle noise overlay
    ];
}

/** Advanced combos the admin can apply with one click. */
function sfy_design_quick_styles(): array {
    return [
        'balanced' => ['label' => 'Balanced (default)', 'blurb' => 'Soft glow, Inter, pill nav, 1px lines.',
                       'set'   => ['radius' => 10, 'glow' => 45, 'density' => 'cozy', 'card_style' => 'solid',
                                   'font_ui' => 'inter', 'btn_style' => 'solid', 'nav_style' => 'pill',
                                   'motion' => 'soft', 'line_w' => 1, 'grain' => 0, 'bg_pattern' => 'grid']],
        'esports' => ['label' => 'Esports HUD', 'blurb' => 'Sharp corners, condensed type, bright glow, dotted grid.',
                       'set'   => ['radius' => 4, 'glow' => 85, 'density' => 'compact', 'card_style' => 'outline',
                                   'font_ui' => 'rajdhani', 'btn_style' => 'gradient', 'nav_style' => 'underline',
                                   'motion' => 'full', 'line_w' => 1, 'grain' => 1, 'bg_pattern' => 'dots']],
        'sci-fi'  => ['label' => 'Sci-Fi Console', 'blurb' => 'Orbitron headings, glass cards, heavy glow, scanline vibe.',
                       'set'   => ['radius' => 6, 'glow' => 70, 'density' => 'cozy', 'card_style' => 'glass',
                                   'font_ui' => 'orbitron', 'btn_style' => 'outline', 'nav_style' => 'pill',
                                   'motion' => 'soft', 'line_w' => 1, 'grain' => 1, 'bg_pattern' => 'mesh']],
        'minimal' => ['label' => 'Minimal / fast', 'blurb' => 'No glow, no effects, system font, flat cards.',
                       'set'   => ['radius' => 8, 'glow' => 0, 'density' => 'cozy', 'card_style' => 'outline',
                                   'font_ui' => 'system', 'btn_style' => 'solid', 'nav_style' => 'plain',
                                   'motion' => 'off', 'line_w' => 1, 'grain' => 0, 'bg_pattern' => 'none',
                                   'fx_grid' => 0, 'fx_aurora' => 0, 'fx_scan' => 0, 'fx_shine' => 0,
                                   'glow' => 0, 'bg_pattern' => 'none']],
        'arcade'  => ['label' => 'Arcade bright', 'blurb' => 'Chunky rounded panels, gradient buttons, full motion.',
                       'set'   => ['radius' => 16, 'glow' => 65, 'density' => 'cozy', 'card_style' => 'solid',
                                   'font_ui' => 'outfit', 'btn_style' => 'gradient', 'nav_style' => 'pill',
                                   'motion' => 'full', 'line_w' => 0, 'grain' => 0, 'bg_pattern' => 'stripes']],
    ];
}

/* ── read / write ──────────────────────────────────────────────────── */
/**
 * The single validator for appearance settings. Every path (reads from the
 * database and writes from the admin form) goes through here, so a typo or a
 * hand-edited row can never produce a broken stylesheet.
 */
function sfy_appearance_normalize(array $in): array {
    $out = sfy_design_defaults();

    foreach (array_keys($out) as $k) {
        if (!array_key_exists($k, $in)) continue;
        $v = $in[$k];
        if ($v === null || $v === '') continue;
        $out[$k] = in_array($k, ['radius','glow','shell','font_scale','line_w','grain'], true) ? (int)$v : (string)$v;
    }

    $presets = sfy_design_presets();
    $out['preset']     = isset($presets[$out['preset']]) ? (string)$out['preset'] : 'ink';
    $out['density']    = in_array($out['density'], ['cozy','compact'], true) ? (string)$out['density'] : 'cozy';
    $out['card_style'] = in_array($out['card_style'], ['solid','glass','outline'], true) ? (string)$out['card_style'] : 'solid';
    $out['bg_pattern'] = in_array($out['bg_pattern'], ['none','grid','dots','mesh','stripes'], true) ? (string)$out['bg_pattern'] : 'grid';
    $out['font_ui']    = isset(sfy_design_fonts()[$out['font_ui']]) ? (string)$out['font_ui'] : 'inter';
    $out['btn_style']  = in_array($out['btn_style'], ['solid','gradient','outline'], true) ? (string)$out['btn_style'] : 'solid';
    $out['nav_style']  = in_array($out['nav_style'], ['pill','underline','plain'], true) ? (string)$out['nav_style'] : 'pill';
    $out['motion']     = in_array($out['motion'], ['off','soft','full'], true) ? (string)$out['motion'] : 'soft';
    $out['line_w']     = max(0, min(3, (int)$out['line_w']));

    foreach (['fx_grid','fx_aurora','fx_scan','fx_shine','grain'] as $k) $out[$k] = !empty($out[$k]) ? 1 : 0;

    $out['accent']     = sfy_hex_clean((string)$out['accent']);
    $out['radius']     = max(0, min(24, (int)$out['radius']));
    $out['glow']       = max(0, min(100, (int)$out['glow']));
    $out['shell']      = max(880, min(1600, (int)$out['shell']));
    $out['font_scale'] = max(88, min(120, (int)$out['font_scale']));
    $out['vars']       = sfy_appearance_clean_vars($in['vars'] ?? []);

    return $out;
}

/** Palette overrides: known variables only, and only if they are a real hex. */
function sfy_appearance_clean_vars($vars): array {
    if (!is_array($vars)) return [];
    $presets = sfy_design_presets();
    $allowed = array_keys($presets['ink']['vars']);
    $out = [];
    foreach ($vars as $k => $v) {
        if (!is_string($k) || !in_array($k, $allowed, true)) continue;
        $hex = sfy_hex_clean((string)$v);
        if ($hex !== '') $out[$k] = $hex;
    }
    return $out;
}

function sfy_appearance(bool $refresh = false): array {
    static $cache = null;
    if ($cache !== null && !$refresh) return $cache;

    $raw = [];
    foreach (array_keys(sfy_design_defaults()) as $k) {
        $v = sfy_config_get('set_theme_' . $k, null);
        if ($v !== null) $raw[$k] = $v;
    }
    $vars = json_decode((string)sfy_config_get('set_theme_vars', ''), true);
    $raw['vars'] = is_array($vars) ? $vars : [];

    return $cache = sfy_appearance_normalize($raw);
}

function sfy_appearance_save(array $in): array {
    // A one-click style preset expands into its individual knobs first.
    $qs = (string)($in['quick_style'] ?? '');
    if ($qs !== '' && isset(sfy_design_quick_styles()[$qs])) {
        $in = array_merge($in, sfy_design_quick_styles()[$qs]['set']);
    }
    unset($in['quick_style']);

    $merged = array_merge(sfy_appearance(true), $in);

    // "Save this design": an explicit palette map freezes it, reset_vars
    // clears it, and anything else keeps whatever was already stored.
    if (array_key_exists('vars', $in))       $merged['vars'] = $in['vars'];
    elseif (!empty($in['reset_vars']))       $merged['vars'] = [];

    $out = sfy_appearance_normalize($merged);

    foreach ($out as $k => $v) {
        if ($k === 'vars') continue;
        sfy_config_set('set_theme_' . $k, (string)$v);
    }
    sfy_config_set('set_theme_vars', json_encode($out['vars'], JSON_UNESCAPED_SLASHES));
    sfy_config_all(true);
    sfy_appearance(true);

    return $out;
}

/* ── colour maths ──────────────────────────────────────────────────── */
function sfy_hex_clean(string $hex): string {
    $hex = trim($hex);
    if ($hex === '') return '';
    if ($hex[0] !== '#') $hex = '#' . $hex;
    if (!preg_match('/^#([0-9a-f]{3}|[0-9a-f]{6})$/i', $hex)) return '';
    if (strlen($hex) === 4) $hex = '#' . $hex[1] . $hex[1] . $hex[2] . $hex[2] . $hex[3] . $hex[3];
    return strtolower($hex);
}

function sfy_hex_rgb(string $hex): array {
    $hex = sfy_hex_clean($hex);
    if ($hex === '') return [0, 0, 0];
    return [hexdec(substr($hex, 1, 2)), hexdec(substr($hex, 3, 2)), hexdec(substr($hex, 5, 2))];
}

/** $pct > 0 lightens toward white, < 0 darkens toward black. */
function sfy_hex_shade(string $hex, int $pct): string {
    [$r, $g, $b] = sfy_hex_rgb($hex);
    $t = $pct > 0 ? 255 : 0;
    $k = min(100, abs($pct)) / 100;
    $r = (int)round($r + ($t - $r) * $k);
    $g = (int)round($g + ($t - $g) * $k);
    $b = (int)round($b + ($t - $b) * $k);
    return sprintf('#%02x%02x%02x', max(0, min(255, $r)), max(0, min(255, $g)), max(0, min(255, $b)));
}

function sfy_rgba(string $hex, float $alpha): string {
    [$r, $g, $b] = sfy_hex_rgb($hex);
    return 'rgba(' . $r . ',' . $g . ',' . $b . ',' . round(max(0, min(1, $alpha)), 3) . ')';
}

/* ── CSS builder ───────────────────────────────────────────────────── */
/**
 * The resolved colour map for an appearance array: preset → accent →
 * per-install saved overrides. Also what the Appearance editor's palette
 * grid is populated from, so "edit a colour" starts from what is on screen.
 */
function sfy_appearance_palette(?array $a = null): array {
    $a       = $a ?? sfy_appearance();
    $presets = sfy_design_presets();
    $p       = $presets[$a['preset']] ?? $presets['ink'];
    $scheme  = (string)$p['scheme'];
    $vars    = $p['vars'];

    // accent override → neon trio
    if (($a['accent'] ?? '') !== '') {
        $acc = (string)$a['accent'];
        $vars['--neon']      = $acc;
        $vars['--neon-dim']  = sfy_hex_shade($acc, $scheme === 'light' ? -22 : -26);
        $vars['--neon-soft'] = $scheme === 'light' ? sfy_hex_shade($acc, -30) : sfy_hex_shade($acc, 34);
    }

    // per-install saved overrides win over everything
    foreach (($a['vars'] ?? []) as $k => $v) $vars[$k] = $v;

    return $vars;
}

/** Friendly labels for the palette editor. */
function sfy_appearance_var_labels(): array {
    return [
        '--bg' => 'Page background', '--bg-2' => 'Deep background',
        '--panel' => 'Panel', '--panel-2' => 'Panel (top)', '--panel-3' => 'Panel (raised)',
        '--input' => 'Input field', '--line' => 'Border', '--line-2' => 'Border (strong)',
        '--neon' => 'Accent', '--neon-dim' => 'Accent (dim)', '--neon-soft' => 'Accent (links)',
        '--cyan' => 'Cyan', '--blue' => 'Blue', '--violet' => 'Violet', '--violet-dim' => 'Violet (dim)',
        '--pink' => 'Pink', '--lime' => 'Lime', '--gold' => 'Gold', '--gold-dim' => 'Gold (dim)',
        '--orange' => 'Orange', '--red' => 'Red', '--red-dim' => 'Red (dim)', '--purple' => 'Purple',
        '--text' => 'Text', '--text-dim' => 'Text (soft)', '--text-mute' => 'Text (muted)',
    ];
}

/**
 * The full appearance layer: palette + accents + glows + shape tokens.
 * Printed after assets/theme.css so it always wins.
 */
function sfy_appearance_css(?array $a = null): string {
    $a       = $a ?? sfy_appearance();
    $presets = sfy_design_presets();
    $p       = $presets[$a['preset']] ?? $presets['ink'];
    $scheme  = (string)$p['scheme'];
    $vars    = sfy_appearance_palette($a);

    $g = (int)$a['glow'] / 100;

    $out  = ':root{';
    foreach ($vars as $k => $v) $out .= $k . ':' . $v . ';';
    $out .= '--r:' . (int)$a['radius'] . 'px;';
    $out .= '--r-lg:' . ((int)$a['radius'] + 7) . 'px;';
    $out .= '--shell:' . (int)$a['shell'] . 'px;';
    $out .= '--fs:' . ((int)$a['font_scale'] / 100) . ';';
    $out .= '--line-w:' . max(0, (int)$a['line_w']) . 'px;';
    $fonts = sfy_design_fonts();
    $out .= '--ui:' . ($fonts[$a['font_ui']]['stack'] ?? $fonts['inter']['stack']) . ';';

    // glows derive from the palette so a re-accent re-glows for free
    $glowMap = ['--glow-neon' => '--neon', '--glow-violet' => '--violet', '--glow-pink' => '--pink',
                '--glow-gold' => '--gold', '--glow-red' => '--red', '--glow-cyan' => '--cyan'];
    $base = ['.46', '.40', '.34', '.36', '.36', '.40'];
    $i = 0;
    foreach ($glowMap as $gk => $ck) {
        $alpha = (float)$base[$i] * $g;
        $out .= $gk . ':' . sfy_rgba((string)$vars[$ck], $alpha) . ';';
        $i++;
    }
    $out .= '--shadow:' . ($scheme === 'light'
        ? '0 12px 30px rgba(24,40,90,' . round(0.10 + 0.08 * $g, 3) . ')'
        : '0 16px 40px rgba(5,9,26,' . round(0.30 + 0.24 * $g, 3) . ')') . ';';
    $out .= '--glow-alpha:' . round($g, 2) . ';';
    $out .= '}';

    /* effect switches */
    $off = [];
    if (!$a['fx_grid'])   $off[] = '.fx-grid{display:none !important}';
    if (!$a['fx_aurora']) $off[] = '.fx-grid{animation:none !important}';
    if (!$a['fx_scan'])   $off[] = '.fx-scan{display:none !important}';
    if (!$a['fx_shine'])  $off[] = '.btn-primary::after,.btn-gold::after{display:none !important}';
    if ($g <= 0.02)       $off[] = '*{text-shadow:none !important;box-shadow:none !important}'
                                 . '.brk::before,.brk::after{display:none !important}';

    /* background pattern swap */
    $patterns = [
        'none'    => '.fx-grid{background-image:none !important}',
        'grid'    => '',
        'dots'    => '.fx-grid{background-image:radial-gradient(currentColor 1.2px,transparent 1.3px) !important;'
                   . 'background-size:26px 26px !important;color:rgba(255,255,255,.10)}',
        'mesh'    => '.fx-grid{background-image:'
                   . 'radial-gradient(520px 340px at 22% 18%,var(--glow-cyan),transparent 62%),'
                   . 'radial-gradient(480px 320px at 78% 26%,var(--glow-violet),transparent 62%),'
                   . 'radial-gradient(520px 360px at 50% 96%,var(--glow-neon),transparent 62%) !important'
                   . ';background-size:100% 100% !important;animation:none !important}',
        'stripes' => '.fx-grid{background-image:repeating-linear-gradient(135deg,rgba(255,255,255,.05) 0 2px,transparent 2px 22px) !important;'
                   . 'background-size:auto !important;animation:none !important}',
    ];

    /* density + card treatments */
    $extra = '';
    if ($a['density'] === 'compact') {
        $extra .= '.card{padding:13px 15px}.grid{gap:10px}.kpi{padding:11px 13px}'
                . '.card-head{margin-bottom:10px}.sec-grid{gap:12px}';
    }
    if ($a['card_style'] === 'outline') {
        $extra .= '.card,.kpi,.login-box{background:transparent !important;border:1px solid var(--line-2) !important}'
                . '.card-head{border-bottom-color:var(--line)}';
    } elseif ($a['card_style'] === 'glass') {
        $light = $scheme === 'light';
        $extra .= '.card,.kpi,.login-box{background:linear-gradient(180deg,'
                . ($light ? 'rgba(255,255,255,.82)' : 'rgba(255,255,255,.07)') . ','
                . ($light ? 'rgba(255,255,255,.66)' : 'rgba(255,255,255,.03)') . ') !important;'
                . 'backdrop-filter:blur(14px) saturate(140%);-webkit-backdrop-filter:blur(14px) saturate(140%)}';
    }

    /* ── shaping: border weight, button + nav treatment, motion ─────── */
    $shape = '.card,.kpi,.msg,.term,.tbl,.tbl th,.tbl td,.ad-card,.ad-bar,.ad-side,.ad-modal,'
           . '.btn,.badge,input,select,textarea,.code-box,.token-pill,.login-box,.admin-nav,'
           . '.faq,.step,.tut-list>li{border-width:var(--line-w)}';

    if ($a['btn_style'] === 'outline') {
        $shape .= '.btn{background:transparent !important;color:var(--text) !important}'
                . '.btn-primary{color:var(--neon) !important;border-color:var(--neon) !important}'
                . '.btn-gold{color:var(--gold) !important;border-color:var(--gold) !important}'
                . '.btn-danger{color:var(--red) !important;border-color:var(--red) !important}'
                . '.btn-primary::after,.btn-gold::after{display:none !important}';
    } elseif ($a['btn_style'] === 'gradient') {
        $shape .= '.btn-primary{background:linear-gradient(135deg,var(--neon),var(--cyan) 55%,var(--violet)) !important}'
                . '.btn-gold{background:linear-gradient(135deg,var(--gold),var(--orange)) !important}'
                . '.btn-danger{background:linear-gradient(135deg,var(--red),var(--violet-dim)) !important}';
    }

    if ($a['nav_style'] === 'plain') {
        $shape .= '.admin-nav a{background:transparent !important;border:0 !important}'
                . '.admin-nav a.active{background:transparent !important;color:var(--neon) !important;font-weight:700}';
    } elseif ($a['nav_style'] === 'underline') {
        $shape .= '.admin-nav a{background:transparent !important;border:0 !important;border-radius:0 !important;'
                . 'border-bottom:2px solid transparent !important}'
                . '.admin-nav a.active{background:transparent !important;border-bottom-color:var(--neon) !important;'
                . 'color:var(--neon) !important}';
    }

    if ($a['motion'] === 'off') {
        $shape .= '.fx-grid{animation:none !important}.btn::after{display:none !important}'
                . '*,*::before,*::after{transition-duration:.01ms !important;animation-duration:.01ms !important}';
    } elseif ($a['motion'] === 'full') {
        $shape .= '.fx-grid{animation-duration:26s !important}'
                . '.card{transition:transform .18s ease,box-shadow .18s ease}'
                . '.card:hover{transform:translateY(-2px);box-shadow:0 20px 44px var(--glow-neon)}'
                . '.kpi:hover{transform:translateY(-3px)}';
    }

    $grain = (!empty($a['grain']))
        ? 'body::after{content:"";position:fixed;inset:0;pointer-events:none;z-index:9;opacity:.05;'
          . 'background-image:url("data:image/svg+xml,<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'120\' height=\'120\'>'
          . '<filter id=\'n\'><feTurbulence type=\'fractalNoise\' baseFrequency=\'0.9\' numOctaves=\'2\'/></filter>'
          . '<rect width=\'120\' height=\'120\' filter=\'url(%23n)\'/></svg>")}'
        : '';

    $css = $out . implode('', $off) . ($patterns[$a['bg_pattern']] ?? '') . $extra . $shape . $grain;

    /* light scheme needs a handful of targeted overrides */
    if ($scheme === 'light') {
        $css .= 'body{background:radial-gradient(1100px 640px at 8% -12%,var(--glow-neon),transparent 62%),'
              . 'radial-gradient(1000px 600px at 96% -4%,var(--glow-violet),transparent 60%),'
              . 'linear-gradient(180deg,#f5f7fd 0%,#eef1f8 46%,#e7ecf8 100%) !important;background-attachment:fixed}'
              . 'a:hover{color:#0a5c52}'
              . '.site-head{background:linear-gradient(90deg,rgba(255,255,255,.94),rgba(240,244,255,.94)) !important;'
              . 'border-bottom-color:var(--line-2) !important}'
              . '.site-head .brand span{color:var(--text)}'
              . '.admin-nav{background:rgba(255,255,255,.86) !important;border-bottom-color:var(--line) !important}'
              . '.admin-nav a{color:var(--text-dim)}'
              . '.admin-nav a.active{background:linear-gradient(180deg,var(--panel-2),var(--panel));color:var(--text)}'
              . '.head-right .mono,.mono,.dim,.mute,.hint,.label{color:var(--text-mute)}'
              . '.term{background:#12171f !important;border-color:#2a3446 !important;color:#d7e3ff !important}'
              . '.term .line,.term b,.term span{color:#d7e3ff}'
              . '.btn{background:linear-gradient(180deg,#ffffff,#eef2fb) !important;color:var(--text) !important;'
              . 'border-color:var(--line-2) !important}'
              . '.btn-primary{background:linear-gradient(180deg,var(--neon),var(--neon-dim)) !important;color:#062319 !important}'
              . '.btn-gold{background:linear-gradient(180deg,var(--gold),var(--gold-dim)) !important;color:#2a1c00 !important}'
              . '.btn-danger{background:linear-gradient(180deg,#e0576a,#b93a4d) !important;color:#fff !important}'
              . '.badge{background:#e8edf9 !important;color:var(--text-dim) !important;border-color:var(--line) !important}'
              . '.badge.g{background:#d9f5ec !important;color:#0a6b57 !important;border-color:#9fdcca !important}'
              . '.badge.y{background:#fdf0d3 !important;color:#8a6202 !important;border-color:#ecd9a4 !important}'
              . '.badge.r{background:#fde2e6 !important;color:#a32037 !important;border-color:#f0bec6 !important}'
              . 'table.tbl th{background:#f1f4fc !important;color:var(--text-dim) !important}'
              . 'table.tbl tr:hover td{background:#f6f8fe !important}'
              . 'input,select,textarea{background:var(--input) !important;color:var(--text) !important}'
              . '.token-pill{background:#f1f4fc !important;color:var(--text) !important}'
              . '.msg{color:var(--text)}'
              . '.role-pill{background:#e8edf9;color:var(--text-dim)}';
    }

    return $css;
}

/** Body classes the sheet uses for structural variants. */
function sfy_appearance_classes(?array $a = null): string {
    $a    = $a ?? sfy_appearance();
    $pres = sfy_design_presets()[$a['preset']] ?? null;
    $cls  = ['theme-' . $a['preset'], 'density-' . $a['density'], 'cards-' . $a['card_style'],
             'bg-' . $a['bg_pattern'], 'nav-' . $a['nav_style'], 'btn-' . $a['btn_style'],
             'motion-' . $a['motion'], 'font-' . $a['font_ui']];
    if (($pres['scheme'] ?? 'dark') === 'light') $cls[] = 'scheme-light';
    if (!$a['fx_grid'])   $cls[] = 'no-fx';
    if (!$a['fx_aurora']) $cls[] = 'no-drift';
    if ((int)$a['line_w'] === 0) $cls[] = 'no-lines';
    return implode(' ', $cls);
}

/** Everything an inline preview needs to re-render a *draft* look. */
function sfy_appearance_draft(): ?array {
    if (empty($_SESSION['sfy_appearance_draft']) || !is_array($_SESSION['sfy_appearance_draft'])) return null;
    $d = $_SESSION['sfy_appearance_draft'];
    $base = sfy_appearance();
    foreach (['preset','density','card_style','bg_pattern','accent','vars','font_ui','btn_style','nav_style','motion'] as $k) {
        if (array_key_exists($k, $d)) $base[$k] = $d[$k];
    }
    foreach (['radius','glow','shell','font_scale','fx_grid','fx_aurora','fx_scan','fx_shine','line_w','grain'] as $k) {
        if (array_key_exists($k, $d)) $base[$k] = (int)$d[$k];
    }
    // Drafts may arrive as a quick style; expand it exactly like a save would.
    if (isset($d['quick_style']) && isset(sfy_design_quick_styles()[(string)$d['quick_style']])) {
        foreach (sfy_design_quick_styles()[(string)$d['quick_style']]['set'] as $k => $v) $base[$k] = $v;
    }
    if (!isset(sfy_design_presets()[$base['preset']])) $base['preset'] = 'ink';
    return $base;
}

/* ── footer ────────────────────────────────────────────────────────── */
function sfy_footer_defaults(): array {
    return [
        'enabled'   => 1,
        'copyright' => '',                                  // empty → auto
        'tagline'   => (string)sfy_cfg('app.brand_line', 'secure gateway // lootlabs grade'),
        'show_admin'=> 0,                                   // visitor-facing site stays public
        'links'     => [
            ['label' => 'Home',     'url' => '',         'enabled' => 1, 'new_tab' => 0],
            ['label' => 'Tutorial', 'url' => 'tutorial', 'enabled' => 1, 'new_tab' => 0],
            ['label' => 'Admin',    'url' => 'admin/',   'enabled' => 1, 'new_tab' => 0],
            ['label' => 'Support',  'url' => 'support',  'enabled' => 1, 'new_tab' => 0],
        ],
    ];
}

function sfy_footer_config(bool $draft = false, bool $refresh = false): array {
    static $cache = null;
    if ($cache !== null && !$draft && !$refresh) return $cache;

    $def = sfy_footer_defaults();
    $out = $def;

    $raw = (string)sfy_config_get('set_footer_json', '');
    if ($raw !== '') {
        $j = json_decode($raw, true);
        if (is_array($j)) {
            $out['enabled']    = array_key_exists('enabled', $j) ? (int)$j['enabled'] : $def['enabled'];
            $out['show_admin'] = array_key_exists('show_admin', $j) ? (int)$j['show_admin'] : $def['show_admin'];
            $out['copyright']  = (string)($j['copyright'] ?? $def['copyright']);
            $out['tagline']    = (string)($j['tagline'] ?? $def['tagline']);
            if (isset($j['links']) && is_array($j['links'])) {
                $links = [];
                foreach ($j['links'] as $l) {
                    if (!is_array($l)) continue;
                    $links[] = [
                        'label'   => substr(trim((string)($l['label'] ?? '')), 0, 40),
                        'url'     => substr(trim((string)($l['url'] ?? '')), 0, 300),
                        'enabled' => !empty($l['enabled']) ? 1 : 0,
                        'new_tab' => !empty($l['new_tab']) ? 1 : 0,
                    ];
                }
                $out['links'] = $links;
            }
        }
    }

    if ($draft) {
        $d = $_SESSION['sfy_footer_draft'] ?? null;
        if (is_array($d)) {
            // Drafts replace wholesale — otherwise deleting a link in the
            // editor would not disappear from the live preview.
            foreach (['enabled','show_admin','copyright','tagline'] as $k) {
                if (array_key_exists($k, $d)) $out[$k] = $d[$k];
            }
            if (isset($d['links']) && is_array($d['links'])) {
                $links = [];
                foreach ($d['links'] as $l) {
                    if (!is_array($l)) continue;
                    $links[] = [
                        'label'   => substr(trim((string)($l['label'] ?? '')), 0, 40),
                        'url'     => substr(trim((string)($l['url'] ?? '')), 0, 300),
                        'enabled' => !empty($l['enabled']) ? 1 : 0,
                        'new_tab' => !empty($l['new_tab']) ? 1 : 0,
                    ];
                }
                $out['links'] = $links;
            }
        }
    }

    if (!$draft) $cache = $out;
    return $out;
}

function sfy_footer_save(array $in): array {
    $d = sfy_footer_defaults();

    $links = [];
    if (isset($in['links']) && is_array($in['links'])) {
        foreach ($in['links'] as $l) {
            if (!is_array($l)) continue;
            $label = substr(trim((string)($l['label'] ?? '')), 0, 40);
            $url   = substr(trim((string)($l['url'] ?? '')), 0, 300);
            if ($label === '' && $url === '') continue;
            $links[] = [
                'label'   => $label !== '' ? $label : 'Link',
                'url'     => $url,
                'enabled' => !empty($l['enabled']) ? 1 : 0,
                'new_tab' => !empty($l['new_tab']) ? 1 : 0,
            ];
        }
    }

    $out = [
        'enabled'    => !empty($in['enabled']) ? 1 : 0,
        'show_admin' => !empty($in['show_admin']) ? 1 : 0,
        'copyright'  => substr(trim((string)($in['copyright'] ?? '')), 0, 200),
        'tagline'    => substr(trim((string)($in['tagline'] ?? $d['tagline'])), 0, 120),
        'links'      => $links,
    ];

    sfy_config_set('set_footer_json', json_encode($out, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    sfy_config_all(true);
    sfy_footer_config(false, true);

    return $out;
}

/** Resolve a footer link URL: '@discord' means "the support link". */
function sfy_footer_link_url(string $url): string {
    if ($url === '@discord' || $url === '@support') {
        return (string)sfy_config_get('set_support_discord', '');
    }
    if ($url === '') return sfy_url('');
    if (preg_match('~^https?://~i', $url)) return $url;
    return sfy_url(ltrim($url, '/'));
}
