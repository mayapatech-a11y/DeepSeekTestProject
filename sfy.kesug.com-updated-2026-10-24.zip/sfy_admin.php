<?php
declare(strict_types=1);
/** Legacy admin entry point → the panel now lives at /admin/. */
require_once __DIR__ . '/app/core.php';
$q = $_GET;
$target = sfy_url('admin/') . ($q ? '?' . http_build_query($q) : '');
sfy_redirect($target);
