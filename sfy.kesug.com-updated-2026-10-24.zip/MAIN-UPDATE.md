# sfy.kesug.com — updated main project

Built from the staging code. Production DB and Turnstile are kept. The app_key
is the staging key, as requested.

## What is included

- All anti-bypass logic: postback key, ticket, landing bind, hard block,
  warning popup, IP cooldown, strict postback gate, relay pull with DoH.
- Latest admin settings/accounts views and actions.
- Latest updater-compatible code. No install.php (main has no staging installer).
- Production DB and Turnstile keys preserved from the old main config.
- app.domain is https://sfy.kesug.com.
- app_key is the staging key 467673..., so account #1's postback key is
  f9c3b9f586bfe5d5fe61f34b2ac3977ba45b3fab.
- The relay pull URL is the staging Worker, which you will keep after deleting
  sfytest.kesug.com staging.

## Critical warnings

1. app_key changed from the old main key to the staging key.
   - Existing admin sessions and old tickets are invalid; log in again.
   - Every account's postback key now derives from the staging app_key.
   - Account #1 is f9c3...; update the LootLabs postback URL to match if it
     still uses the old key.
2. The DB is unchanged (if0_42941977_sfy_codesys), same host/user/pass.
   Do not import the staging DB.
3. The LootLabs API key in the DB is unchanged. If by "staging API key" you
   meant the LootLabs account API key, update it in Admin -> Accounts; this code
   change does not touch DB account keys.
4. One consumer per Worker. Take sfytest.kesug.com offline before main starts
   pulling from the same Worker. Drain the KV first. Do not run both.
5. Delete the old root hook.php (and flow_test.php, review/) on the main host
   after uploading. The new receiver is api/hook.php.

## Upload

1. Backup the current main folder, DB and config.
2. Upload this zip to the main root (the folder with index.php), extract,
   overwrite.
3. If you do NOT want the app_key change: restore the old config/config.php
   immediately and update the LootLabs account URL using the key that old
   config generates.
4. Run Admin -> Updater once; confirm migrations.
5. In Admin -> Settings:
   - Show warning ON
   - Block flagged ON
   - Max flagged 2
   - IP cooldown 2h
   - Warning delay 10
   - Count connection OFF unless you want IP-level blocking
   - Require verified postback ON
6. LootLabs main account -> Postback URL:
   https://sfy-postback-relay.mayapatech.workers.dev/hook?token=a841fbc193a24bef9bc5f2af9b981af92a2601338d034763a064d481e2d34234&click_id={CLICK_ID}&ip={IP}&unique_id={UNIQUE_ID}&acct=1
   The app appends &key=f9c3...
7. Test a real task. Worker /hook 200, Worker /pull 200, site ok.
8. Then test bacon. It should wait and show the red warning, no code.

## Files not included

- old backups, DB dump, review folder, test scripts
- staging config/DB
- staging-only installer
