<?php
declare(strict_types=1);
/**
 * Document root.
 *
 * The hub is the front page: a visitor lands on the script library, and the
 * site's own landing page keeps its own address at /home (see the pretty
 * routes in .htaccess). This file only chooses between the two — it makes no
 * decision about either page.
 *
 * The fallback is not decoration. The hub is an optional folder, so if it is
 * not there the site must still answer on "/" with the page it always had;
 * a deleted folder cannot be allowed to take the front page with it.
 */

$hub = __DIR__ . '/hub/index.php';
if (is_file($hub)) {
    require $hub;
    return;
}

require __DIR__ . '/pages/home.php';
