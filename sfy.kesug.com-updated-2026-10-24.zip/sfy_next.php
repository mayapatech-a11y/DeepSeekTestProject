<?php
declare(strict_types=1);
/** Legacy path → /done (pages/next.php). */
require __DIR__ . '/pages/next.php';
