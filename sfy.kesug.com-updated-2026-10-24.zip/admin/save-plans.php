<?php
declare(strict_types=1);
/**
 * Dedicated plan-save endpoint.
 *
 * The Plans editor posts here instead of relying on admin/actions.php, so a
 * stale actions file can never silently swallow a plan change. Staff session,
 * capability and CSRF are still enforced.
 */
require_once dirname(__DIR__) . '/app/core.php';

if (!sfy_admin_current() || !sfy_admin_can('settings')) {
    http_response_code(403);
    exit('forbidden');
}
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST' || !sfy_csrf_check((string)($_POST['csrf'] ?? ''))) {
    $_SESSION['sfy_admin_flash'] = ['Security token expired — reload and try again.', 'err'];
    sfy_redirect(sfy_admin_url(['tab' => 'commerce', 'section' => 'plans']));
    exit;
}
$res = sfy_pricing_save_post($_POST);
sfy_audit('save_pricing', $res[0] ? 'saved' : 'failed');
$_SESSION['sfy_admin_flash'] = [(string)$res[1], $res[0] ? 'ok' : 'err'];
sfy_redirect(sfy_admin_url(['tab' => 'commerce', 'section' => 'plans']));
