<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  /admin — SFY ULTIMATE control panel
 *  Hardened login (lockout + attempt log), role-gated tabs, one-click
 *  database updater, device viewer, ads manager and staff management.
 * ═══════════════════════════════════════════════════════════════════════
 */
require_once dirname(__DIR__) . '/app/core.php';
require_once __DIR__ . '/actions.php';
require_once __DIR__ . '/layout.php';

sfy_install_if_empty();

/* ── logout ────────────────────────────────────────────────────────── */
if (sfy_param('logout') === '1') {
    sfy_admin_logout();
    sfy_redirect(sfy_admin_url(['bye' => 1]));
}

$loginErr  = '';
$loginInfo = '';

/* ── first-run setup ───────────────────────────────────────────────── */
$ownerCount = 0;
try { $ownerCount = (int)sfy_db()->query("SELECT COUNT(*) AS n FROM sfy_staff WHERE role='owner'")->fetch()['n']; }
catch (Throwable $e) { $ownerCount = 0; }
$legacyHash = (string)sfy_config_get('admin_password_hash', '');
$needsSetup = ($ownerCount === 0 && $legacyHash === '');

if (($_POST['action'] ?? '') === 'setup' && $needsSetup) {
    if (!sfy_csrf_check($_POST['csrf'] ?? '')) {
        $loginErr = 'Session expired — reload and try again.';
    } else {
        $u = strtolower(preg_replace('/[^a-z0-9_\.\-]/i', '', sfy_param('username', 'admin'))) ?: 'admin';
        $p = sfy_param('new_password');
        if (strlen($p) < 8)            $loginErr = 'Password must be at least 8 characters.';
        elseif ($p !== sfy_param('new_password2')) $loginErr = 'Passwords do not match.';
        else {
            sfy_install_if_empty();
            sfy_staff_create($u, $p, 'owner', sfy_param('display_name', 'Owner'));
            sfy_config_set('admin_password_hash', password_hash($p, PASSWORD_BCRYPT));
            sfy_login_log($u, true, 'setup');
            $loginInfo = "Owner account \"$u\" created. Please sign in.";
            $ownerCount = 1;
            $needsSetup = false;
        }
    }
}

/*
 * ── human check before a sign-in ────────────────────────────────────
 *
 * The login form is the other door a script can knock on, and unlike the
 * claim link it is worth knocking on repeatedly: a wrong password costs a
 * staff account nothing until the lockout fires. With this switched on
 * (Admin → Settings → BOT CHECK → "before a staff sign-in") the challenge is
 * verified *before* the password is even looked at, so a credential-stuffing
 * bot spends its budget on Cloudflare instead of on this install's lockout
 * counters — which also stops an attacker from locking the owner out by
 * burning their attempts.
 *
 * The pass is remembered for the browser session, so an owner who signs in
 * twice in one sitting is not asked twice. It is asked again from a fresh
 * browser, and it is deliberately *not* asked before the first-run owner
 * setup — an install with no owner must be reachable.
 */
$needCaptcha = sfy_captcha_needed('admin');

/* ── login ─────────────────────────────────────────────────────────── */
if (($_POST['action'] ?? '') === 'login' && $loginErr === '') {
    if (!sfy_csrf_check($_POST['csrf'] ?? '')) {
        $loginErr = 'Session expired — reload and try again.';
    } else {
        $res = null;
        if ($needCaptcha) {
            $cap = sfy_captcha_check('admin', '', sfy_param('cf-turnstile-response'), sfy_client_ip());
            if (empty($cap['ok'])) {
                $res = ['ok' => false, 'error' => (string)($cap['message'] ?? 'Human verification failed.')];
            }
        }
        if ($res === null) {
            $res = sfy_staff_login(sfy_param('username'), (string)($_POST['password'] ?? ''));
        }
        if (!empty($res['ok'])) {
            sfy_admin_boot_session($res['staff']);
            sfy_redirect(sfy_admin_url(['tab' => sfy_param('tab', 'overview')]));
        }
        $loginErr = (string)($res['error'] ?? 'Login failed.');
        $failures = sfy_login_failures(sfy_param('username'));
        $left     = max(0, (int)sfy_cfg('security.max_login_attempts', 5) - $failures['user']);
        $loginInfo = $left > 0
            ? "Lockout policy: $left attempt(s) left before a " . (int)sfy_cfg('security.lockout_minutes', 15) . '-minute block.'
            : 'Account blocked. Wait for the lockout window to pass or ask an owner to unlock you.';
    }
}

$me = sfy_admin_current();

/* ══════════════════════════════════════════════════════════════════
   LOGIN SCREEN
   ══════════════════════════════════════════════════════════════════ */
if (!$me) {
    $recentFail = 0;
    try {
        $st = sfy_db()->prepare("SELECT COUNT(*) AS n FROM sfy_login_attempts
                                 WHERE success=0 AND ip=? AND created_at > " . sfy_sql_now_offset('MINUTE'));
        $st->execute([sfy_client_ip(), -(int)sfy_cfg('security.login_window_minutes', 10)]);
        $recentFail = (int)($st->fetch()['n'] ?? 0);
    } catch (Throwable $e) { /* ignore */ }

    sfy_head(['title' => 'Admin login', 'page' => 'admin-login', 'noindex' => true, 'minimal' => true]);
    ?>
    <div class="login-wrap">
      <div class="fx-grid" aria-hidden="true"></div>
      <div class="login-box brk">
        <div class="card-head" style="border:0;padding:0;margin-bottom:8px">
          <h1>&gt;SFY_ADMIN</h1>
          <span class="spacer"></span>
          <span class="badge <?= $recentFail > 0 ? 'r' : 'g' ?>"><?= $recentFail ?> FAILED</span>
        </div>
        <p class="hint" style="margin-top:0">Verification backend control panel.</p>

        <?php if ($loginErr !== ''): ?><div class="msg err">✖ <?= sfy_esc($loginErr) ?></div><?php endif; ?>
        <?php if ($loginInfo !== ''): ?><div class="msg <?= $loginErr === '' ? 'info' : 'warn' ?>">◆ <?= sfy_esc($loginInfo) ?></div><?php endif; ?>

        <?php if ($needsSetup): ?>
          <div class="msg warn">◆ First run — create the owner account.</div>
          <form method="POST">
            <?= sfy_csrf_field() ?>
            <input type="hidden" name="action" value="setup">
            <div class="field"><label class="label">Owner username</label><input type="text" name="username" value="admin" required></div>
            <div class="field"><label class="label">Display name</label><input type="text" name="display_name" placeholder="Owner"></div>
            <div class="field"><label class="label">Password (min 8)</label><input type="password" name="new_password" minlength="8" required autofocus></div>
            <div class="field"><label class="label">Confirm password</label><input type="password" name="new_password2" minlength="8" required></div>
            <button class="btn btn-gold btn-lg">CREATE OWNER ACCOUNT</button>
          </form>
        <?php else: ?>
          <form method="POST">
            <?= sfy_csrf_field() ?>
            <input type="hidden" name="action" value="login">
            <div class="field"><label class="label">Username</label><input type="text" name="username" autocomplete="username" required autofocus></div>
            <div class="field"><label class="label">Password</label><input type="password" name="password" autocomplete="current-password" required></div>
            <?php if ($needCaptcha): ?>
              <div class="field"><label class="label">Human check</label><?= sfy_captcha_widget(['compact' => true]) ?></div>
            <?php endif; ?>
            <button class="btn btn-primary btn-lg">SIGN IN</button>
          </form>
          <div class="hint mt-2">
            Max <?= (int)sfy_cfg('security.max_login_attempts', 5) ?> attempts per
            <?= (int)sfy_cfg('security.login_window_minutes', 10) ?> min, then a
            <?= (int)sfy_cfg('security.lockout_minutes', 15) ?>-minute block. Every attempt is logged.
            <?php if ($needCaptcha): ?><br>This sign-in is protected by a human check.<?php endif; ?>
          </div>
        <?php endif; ?>

        <div class="hint center mt-2"><a href="<?= sfy_esc(sfy_url('')) ?>">← back to site</a></div>
      </div>
    </div>
    <?php
    sfy_foot(['page' => 'admin-login']);
    exit;
}

/* ══════════════════════════════════════════════════════════════════
   RUN ACTIONS + RENDER
   ══════════════════════════════════════════════════════════════════ */
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
[$msg, $msgType] = sfy_admin_handle_post();
if ($msg === '' && !empty($_SESSION['sfy_admin_flash'])) {
    [$msg, $msgType] = $_SESSION['sfy_admin_flash'];
    unset($_SESSION['sfy_admin_flash']);
    if (!in_array($msgType, ['ok', 'err', 'warn', 'info'], true)) $msgType = 'ok';
}
$updaterLog = $GLOBALS['SFY_UPDATER_LOG'] ?? null;

$tab = (string)($_GET['tab'] ?? 'overview');
/* Plans and Ads moved under Commerce. Old links keep working and land on the
   matching sub-tab instead of silently falling back to Overview. */
if ($tab === 'plans' || $tab === 'ads') {
    $_GET['section'] = $tab;
    $tab = 'commerce';
}
if (!isset(sfy_admin_tabs()[$tab]) || !sfy_admin_can(sfy_admin_tabs()[$tab]['cap'])) $tab = 'overview';

$db = sfy_db();

/* nav badge counts */
$counts = [];
try {
    $counts['tokens']   = (int)$db->query("SELECT COUNT(*) AS n FROM sfy_tokens WHERE is_used=0")->fetch()['n'];
    $counts['devices']  = (int)$db->query("SELECT COUNT(*) AS n FROM sfy_devices")->fetch()['n'];
    $counts['sessions'] = (int)$db->query("SELECT COUNT(*) AS n FROM sfy_sessions WHERE is_completed=0 AND expires_at>NOW()")->fetch()['n'];
    $counts['ads']      = (int)$db->query("SELECT COUNT(*) AS n FROM sfy_ads WHERE is_active=1")->fetch()['n'];
    if (sfy_table_exists('sfy_hub_orders')) {
        $counts['commerce'] = (int)$db->query("SELECT COUNT(*) AS n FROM sfy_hub_orders WHERE status='pending'")->fetch()['n'];
    }
    $counts['inbox'] = function_exists('sfy_support_unread_count') ? sfy_support_unread_count() : 0;
    $counts['staff']    = (int)$db->query("SELECT COUNT(*) AS n FROM sfy_staff WHERE is_active=1")->fetch()['n'];
    /* How many task providers can actually serve a step (active + funded). */
    $counts['providers'] = function_exists('sfy_provider_offerable') ? count(sfy_provider_offerable()) : null;
    if ($counts['providers'] === 0) $counts['providers'] = null;
} catch (Throwable $e) { /* ignore */ }

sfy_admin_head($me, $tab, $counts);

if ($msg !== '') {
    echo '<div class="msg ' . sfy_esc($msgType) . '">' . ($msgType === 'ok' ? '✔' : '✖') . ' ' . sfy_esc($msg) . '</div>';
}

$viewFile = __DIR__ . '/views/' . $tab . '.php';
if (is_file($viewFile)) {
    include $viewFile;
} else {
    include __DIR__ . '/views/overview.php';
}

sfy_admin_foot();
