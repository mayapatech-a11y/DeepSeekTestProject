<?php
/** @var PDO $db */
$statuses = ['pending' => 'Pending', 'contacted' => 'Contacted', 'paid' => 'Paid', 'delivered' => 'Delivered', 'cancelled' => 'Cancelled'];
$q      = trim((string)sfy_param('q'));
$status = trim((string)sfy_param('status'));
$page   = max(1, sfy_int('page', 1));
$per    = 15;
$ready  = sfy_table_exists('sfy_hub_orders');

$rows = []; $total = 0; $stats = ['pending' => 0, 'paid' => 0, 'delivered' => 0, 'value' => 0];
if ($ready) {
    $w = []; $p = [];
    if ($q !== '') {
        $w[] = '(reference LIKE ? OR buyer_name LIKE ? OR buyer_contact LIKE ? OR offer_title LIKE ?)';
        for ($i = 0; $i < 4; $i++) $p[] = "%$q%";
    }
    if (isset($statuses[$status])) { $w[] = 'status=?'; $p[] = $status; }
    $where = $w ? ' WHERE ' . implode(' AND ', $w) : '';
    $st = $db->prepare('SELECT COUNT(*) AS n FROM sfy_hub_orders' . $where);
    $st->execute($p);
    $total = (int)($st->fetch()['n'] ?? 0);
    $st = $db->prepare('SELECT * FROM sfy_hub_orders' . $where . ' ORDER BY created_at DESC LIMIT ' . $per . ' OFFSET ' . (($page - 1) * $per));
    $st->execute($p);
    $rows = $st->fetchAll();
    foreach ($db->query("SELECT status, COUNT(*) AS n, COALESCE(SUM(amount),0) AS v FROM sfy_hub_orders GROUP BY status")->fetchAll() as $r) {
        $stats[(string)$r['status']] = (int)$r['n'];
        if ((string)$r['status'] === 'delivered') $stats['value'] = (float)$r['v'];
    }
}
$base = ['tab' => 'commerce', 'section' => 'orders', 'q' => $q, 'status' => $status];
?>
<div class="grid grid-4 mb-2">
  <?= sfy_kpi('Pending', number_format((int)$stats['pending']), 'orange', 'waiting on you') ?>
  <?= sfy_kpi('Paid', number_format((int)$stats['paid']), 'gold', 'payment confirmed') ?>
  <?= sfy_kpi('Delivered', number_format((int)$stats['delivered']), 'g', number_format((float)$stats['value'], 2) . ' in sales') ?>
  <?= sfy_kpi('All orders', number_format($total), 'blue', 'matching filter') ?>
</div>

<?php if (!$ready): ?>
  <div class="card"><div class="msg warn">The hub order table is not installed. Open the Hub installer first.</div></div>
<?php else: ?>
<div class="card">
  <div class="card-head">
    <h2>&gt; ORDER_QUEUE</h2><span class="spacer"></span>
    <span class="badge <?= (int)$stats['pending'] ? 'r' : 'g' ?>"><?= (int)$stats['pending'] ?> PENDING</span>
  </div>
  <form method="GET" class="inline mb-2">
    <input type="hidden" name="tab" value="commerce">
    <input type="hidden" name="section" value="orders">
    <input class="grow" type="search" name="q" value="<?= sfy_esc($q) ?>" placeholder="Reference, buyer, contact or plan">
    <select name="status" style="max-width:170px">
      <option value="">Every status</option>
      <?php foreach ($statuses as $k => $lbl): ?><option value="<?= sfy_esc($k) ?>" <?= $status === $k ? 'selected' : '' ?>><?= sfy_esc($lbl) ?></option><?php endforeach; ?>
    </select>
    <button class="btn">FILTER</button>
    <a class="btn btn-ghost" href="<?= sfy_esc(sfy_admin_url(['tab' => 'commerce', 'section' => 'orders'])) ?>">RESET</a>
  </form>

  <?php if (!$rows): ?>
    <div class="empty">&gt; no orders matched.</div>
  <?php else: ?>
    <?php foreach ($rows as $o):
      $isEmail = (string)($o['contact_kind'] ?? '') === 'email';
      $ref = (string)$o['reference'];
      $name = (string)$o['buyer_name'];
      $plan = trim((string)($o['duration_label'] ?? '')) !== '' ? (string)$o['duration_label'] : (string)$o['offer_title'];
      $amount = number_format((float)$o['amount'], 2) . ' ' . (string)$o['currency'];
      $subject = 'SFY payment request — ' . $ref;
      $body = "Hello $name,\n\nThis is from SFY_Devs Team. We received your order $ref for $plan ($amount).\n\nWe ask for your supported payment method so we can complete the order. Please reply with:\n- Payment method (PayPal / Crypto wallet / Binance / other)\n- Payment account or wallet address\n- Preferred plan or duration\n- Transaction reference once paid\n\nWe will confirm the payment and deliver your access after it is verified.\n\nThank you,\nSFY_Devs Team";
      $mailto = $isEmail ? 'mailto:' . rawurlencode((string)$o['buyer_contact']) . '?subject=' . rawurlencode($subject) . '&body=' . rawurlencode($body) : '';
    ?>
      <div class="card" style="margin-bottom:10px">
        <div class="card-head" style="border:0">
          <span class="mono"><?= sfy_esc($ref) ?></span>
          <?= sfy_badge($statuses[(string)$o['status']] ?? (string)$o['status'], (string)$o['status'] === 'pending' ? 'y' : ((string)$o['status'] === 'delivered' ? 'g' : 'b')) ?>
          <span class="tiny mute"><?= sfy_esc($plan) ?> · <?= sfy_esc($amount) ?></span>
          <span class="spacer"></span><span class="tiny mute"><?= sfy_esc(sfy_ago((string)$o['created_at'])) ?></span>
        </div>
        <div class="grid grid-2" style="gap:12px">
          <div>
            <div class="label">Buyer</div>
            <div><?= sfy_esc($name) ?> · <span class="mono tiny"><?= sfy_esc((string)$o['buyer_contact']) ?></span></div>
            <div class="label mt-2">Pays with</div>
            <div><?= sfy_esc((string)($o['payment_method'] ?? '') !== '' ? (string)$o['payment_method'] : '—') ?></div>
            <div class="label mt-2">Plan</div>
            <div><?= sfy_esc($plan) ?> <span class="mono tiny"><?= sfy_esc((string)$o['offer_slug']) ?></span></div>
            <div class="label mt-2">IP</div>
            <div class="mono tiny"><?= sfy_esc((string)$o['ip']) ?></div>
            <?php if (trim((string)($o['message'] ?? '')) !== ''): ?>
              <div class="label mt-2">Buyer note</div>
              <div class="tiny"><?= sfy_esc((string)$o['message']) ?></div>
            <?php endif; ?>
            <details class="sfy-more">
              <summary>PAYMENT EMAIL TEMPLATE</summary>
              <textarea id="tpl-<?= (int)$o['id'] ?>" readonly rows="11" style="width:100%;margin-top:8px;font:11px/1.5 var(--mono)"><?= sfy_esc($body) ?></textarea>
              <div class="btn-row mt-2">
                <button type="button" class="btn btn-sm" onclick="var t=document.getElementById('tpl-<?= (int)$o['id'] ?>');t.select();document.execCommand('copy');">COPY TEMPLATE</button>
                <?php if ($isEmail): ?><a class="btn btn-sm btn-ghost" href="<?= sfy_esc($mailto) ?>">OPEN EMAIL</a><?php endif; ?>
              </div>
            </details>
          </div>
          <div>
            <form method="POST">
              <?= sfy_csrf_field() ?>
              <input type="hidden" name="action" value="commerce_order_status">
              <input type="hidden" name="id" value="<?= (int)$o['id'] ?>">
              <div class="field"><label class="label">Status</label>
                <select name="status"><?php foreach ($statuses as $k => $lbl): ?><option value="<?= sfy_esc($k) ?>" <?= (string)$o['status'] === $k ? 'selected' : '' ?>><?= sfy_esc($lbl) ?></option><?php endforeach; ?></select></div>
              <div class="field"><label class="label">Internal note</label>
                <textarea name="admin_note" rows="3"><?= sfy_esc((string)($o['admin_note'] ?? '')) ?></textarea></div>
              <button class="btn btn-primary btn-block">SAVE ORDER</button>
            </form>
            <form method="POST" data-confirm="Delete order <?= sfy_esc($ref) ?>?" style="margin-top:8px">
              <?= sfy_csrf_field() ?>
              <input type="hidden" name="action" value="commerce_order_delete">
              <input type="hidden" name="id" value="<?= (int)$o['id'] ?>">
              <button class="btn btn-sm btn-danger btn-block">DELETE ORDER</button>
            </form>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
    <?php $pages = max(1, (int)ceil($total / $per)); if ($pages > 1): ?>
      <div class="sfy-pager">
        <?php for ($i = max(1, $page - 2); $i <= min($pages, $page + 2); $i++): ?>
          <a class="btn btn-sm <?= $i === $page ? 'btn-primary' : '' ?>" href="<?= sfy_esc(sfy_admin_url($base + ['page' => $i])) ?>"><?= $i ?></a>
        <?php endfor; ?>
      </div>
    <?php endif; ?>
  <?php endif; ?>
</div>
<?php endif; ?>