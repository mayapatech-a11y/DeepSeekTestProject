<?php
/**
 * Admin → Appearance.
 * Four shipped designs, then per-install shape/effect controls and an
 * optional frozen palette ("save this design"). Everything is written to
 * sfy_config, so it survives reloads, exports and host moves.
 *
 * @var PDO $db
 */
$a        = sfy_appearance();
$presets  = sfy_design_presets();
$palette  = sfy_appearance_palette($a);
$labels   = sfy_appearance_var_labels();
$custom   = !empty($a['vars']);
?>

<?php sfy_admin_preview_panel('Pick a design below — the preview updates as you change things. Drafts live in your session until you save.'); ?>

<form method="POST" id="sfy-app-form">
  <?= sfy_csrf_field() ?>
  <input type="hidden" name="action" value="save_appearance">

  <div class="card mb-2">
    <div class="card-head">
      <h2>&gt; DESIGN_TEMPLATES</h2>
      <span class="spacer"></span>
      <span class="badge <?= $custom ? 'y' : 'g' ?>"><?= $custom ? 'CUSTOM PALETTE ACTIVE' : 'PRESET' ?></span>
    </div>

    <div class="theme-grid">
      <?php foreach ($presets as $key => $p): ?>
        <label class="theme-card <?= $a['preset'] === $key ? 'active' : '' ?>" data-preset-card>
          <input type="radio" name="preset" value="<?= sfy_esc($key) ?>" <?= $a['preset'] === $key ? 'checked' : '' ?>>
          <span class="sw">
            <?php foreach ($p['swatch'] as $c): ?><i style="background:<?= sfy_esc($c) ?>"></i><?php endforeach; ?>
          </span>
          <span>
            <span class="t"><?= sfy_esc($p['label']) ?></span>
            <div class="d"><?= sfy_esc($p['blurb']) ?></div>
            <div class="tiny mute" style="margin-top:5px">
              <?= sfy_esc($p['scheme'] === 'light' ? 'Light scheme' : 'Dark scheme') ?>
              · accent <b class="mono"><?= sfy_esc($p['vars']['--neon']) ?></b>
            </div>
          </span>
        </label>
      <?php endforeach; ?>
    </div>
  </div>

  <div class="card mb-2">
    <div class="card-head">
      <h2>&gt; QUICK_STYLES</h2>
      <span class="spacer"></span>
      <span class="hint" style="margin:0">One click sets font, shape, buttons, nav and motion together. You can still fine-tune below.</span>
    </div>
    <div class="theme-grid">
      <?php foreach (sfy_design_quick_styles() as $key => $q): ?>
        <button type="button" class="style-card" data-quick="<?= sfy_esc($key) ?>"
                data-set="<?= sfy_esc(json_encode($q['set'])) ?>">
          <span class="t"><?= sfy_esc($q['label']) ?></span>
          <div class="d"><?= sfy_esc($q['blurb']) ?></div>
        </button>
      <?php endforeach; ?>
    </div>
    <div class="hint" id="sfy-quick-note">Clicking a style only changes the form — press SAVE DESIGN to keep it.</div>
  </div>

  <div class="card mb-2">
    <div class="card-head"><h2>&gt; ADVANCED_LOOK</h2></div>
    <div class="grid grid-2">
      <div>
        <div class="field">
          <label class="label">UI font</label>
          <select name="font_ui">
            <?php foreach (sfy_design_fonts() as $k => $f): ?>
              <option value="<?= sfy_esc($k) ?>" <?= $a['font_ui'] === $k ? 'selected' : '' ?>><?= sfy_esc($f['label']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="field">
          <label class="label">Button style</label>
          <div class="chiprow">
            <?php foreach (['solid' => 'Solid', 'gradient' => 'Gradient', 'outline' => 'Outlined'] as $k => $lbl): ?>
              <label class="chip <?= $a['btn_style'] === $k ? 'on' : '' ?>">
                <input type="radio" name="btn_style" value="<?= $k ?>" <?= $a['btn_style'] === $k ? 'checked' : '' ?>><?= $lbl ?>
              </label>
            <?php endforeach; ?>
          </div>
        </div>
        <div class="field">
          <label class="label">Admin nav style</label>
          <div class="chiprow">
            <?php foreach (['pill' => 'Pills', 'underline' => 'Underline', 'plain' => 'Plain'] as $k => $lbl): ?>
              <label class="chip <?= $a['nav_style'] === $k ? 'on' : '' ?>">
                <input type="radio" name="nav_style" value="<?= $k ?>" <?= $a['nav_style'] === $k ? 'checked' : '' ?>><?= $lbl ?>
              </label>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
      <div>
        <div class="range-row">
          <div class="top"><b>Motion level</b><i class="mute"><?= sfy_esc($a['motion']) ?></i></div>
          <div class="chiprow">
            <?php foreach (['off' => 'Off (fastest)', 'soft' => 'Soft', 'full' => 'Full'] as $k => $lbl): ?>
              <label class="chip <?= $a['motion'] === $k ? 'on' : '' ?>">
                <input type="radio" name="motion" value="<?= $k ?>" <?= $a['motion'] === $k ? 'checked' : '' ?>><?= $lbl ?>
              </label>
            <?php endforeach; ?>
          </div>
        </div>
        <div class="range-row">
          <div class="top"><b>Border weight</b><i id="out-linew"><?= (int)$a['line_w'] ?>px</i></div>
          <input type="range" name="line_w" min="0" max="3" value="<?= (int)$a['line_w'] ?>" data-out="out-linew" data-suffix="px">
        </div>
        <label class="check"><input type="checkbox" name="grain" <?= $a['grain'] ? 'checked' : '' ?>> Subtle film grain overlay</label>
        <div class="hint">Border weight 0 gives a completely flat, borderless look. Motion “Off” also stops ambient animation for battery life.</div>
      </div>
    </div>
  </div>

  <div class="grid grid-2 mb-2">
    <div class="card" style="margin-bottom:0">
      <div class="card-head"><h2>&gt; SHAPE_AND_SPACING</h2></div>

      <div class="range-row">
        <div class="top"><b>Corner radius</b><i id="out-radius"><?= (int)$a['radius'] ?>px</i></div>
        <input type="range" name="radius" min="0" max="24" value="<?= (int)$a['radius'] ?>" data-out="out-radius" data-suffix="px">
      </div>
      <div class="range-row">
        <div class="top"><b>Glow / shadow intensity</b><i id="out-glow"><?= (int)$a['glow'] ?>%</i></div>
        <input type="range" name="glow" min="0" max="100" value="<?= (int)$a['glow'] ?>" data-out="out-glow" data-suffix="%">
      </div>
      <div class="range-row">
        <div class="top"><b>Content width</b><i id="out-shell"><?= (int)$a['shell'] ?>px</i></div>
        <input type="range" name="shell" min="880" max="1600" step="20" value="<?= (int)$a['shell'] ?>" data-out="out-shell" data-suffix="px">
      </div>
      <div class="range-row">
        <div class="top"><b>Text size</b><i id="out-font"><?= (int)$a['font_scale'] ?>%</i></div>
        <input type="range" name="font_scale" min="88" max="120" value="<?= (int)$a['font_scale'] ?>" data-out="out-font" data-suffix="%">
      </div>

      <div class="field">
        <label class="label">Accent colour (leave blank to use the template's)</label>
        <div class="inline">
          <input type="text" name="accent" id="sfy-accent" class="mono" value="<?= sfy_esc((string)$a['accent']) ?>"
                 placeholder="preset accent" maxlength="7" style="max-width:170px">
          <input type="color" id="sfy-accent-pick" value="<?= sfy_esc((string)$a['accent'] !== '' ? (string)$a['accent'] : $palette['--neon']) ?>">
          <button type="button" class="btn btn-sm btn-ghost" id="sfy-accent-clear">CLEAR</button>
        </div>
        <div class="swatches">
          <?php foreach (['#38d9b0','#4cc2e8','#7ba2f0','#a08cff','#ef7fa8','#e8b34a','#9ed36a','#bb9af7','#f09455','#5eead4'] as $c): ?>
            <button type="button" data-accent="<?= sfy_esc($c) ?>" style="background:<?= sfy_esc($c) ?>" title="<?= sfy_esc($c) ?>"></button>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

    <div class="card" style="margin-bottom:0">
      <div class="card-head"><h2>&gt; LAYOUT_AND_EFFECTS</h2></div>

      <div class="field">
        <label class="label">Density</label>
        <div class="chiprow">
          <?php foreach (['cozy' => 'Cozy', 'compact' => 'Compact'] as $k => $lbl): ?>
            <label class="chip <?= $a['density'] === $k ? 'on' : '' ?>">
              <input type="radio" name="density" value="<?= $k ?>" <?= $a['density'] === $k ? 'checked' : '' ?>><?= $lbl ?>
            </label>
          <?php endforeach; ?>
        </div>
      </div>

      <div class="field">
        <label class="label">Card style</label>
        <div class="chiprow">
          <?php foreach (['solid' => 'Solid', 'glass' => 'Glass', 'outline' => 'Outlined'] as $k => $lbl): ?>
            <label class="chip <?= $a['card_style'] === $k ? 'on' : '' ?>">
              <input type="radio" name="card_style" value="<?= $k ?>" <?= $a['card_style'] === $k ? 'checked' : '' ?>><?= $lbl ?>
            </label>
          <?php endforeach; ?>
        </div>
      </div>

      <div class="field">
        <label class="label">Background pattern</label>
        <div class="chiprow">
          <?php foreach (['none' => 'None', 'grid' => 'Grid', 'dots' => 'Dots', 'mesh' => 'Mesh', 'stripes' => 'Stripes'] as $k => $lbl): ?>
            <label class="chip <?= $a['bg_pattern'] === $k ? 'on' : '' ?>">
              <input type="radio" name="bg_pattern" value="<?= $k ?>" <?= $a['bg_pattern'] === $k ? 'checked' : '' ?>><?= $lbl ?>
            </label>
          <?php endforeach; ?>
        </div>
      </div>

      <div class="field">
        <label class="label">Background effects</label>
        <label class="check"><input type="checkbox" name="fx_grid" <?= $a['fx_grid'] ? 'checked' : '' ?>> Show the background wash</label>
        <label class="check"><input type="checkbox" name="fx_aurora" <?= $a['fx_aurora'] ? 'checked' : '' ?>> Let it drift slowly</label>
        <label class="check"><input type="checkbox" name="fx_shine" <?= $a['fx_shine'] ? 'checked' : '' ?>> Light sweep on primary buttons</label>
        <label class="check"><input type="checkbox" name="fx_scan" <?= $a['fx_scan'] ? 'checked' : '' ?>> CRT scanlines (retro)</label>
      </div>

      <div class="hint">Glow at 0% removes every shadow and halo — the calmest possible look.</div>
    </div>
  </div>

  <div class="card mb-2">
    <div class="card-head">
      <h2>&gt; CUSTOM_PALETTE</h2>
      <span class="spacer"></span>
      <span class="badge <?= $custom ? 'g' : 'gr' ?>"><?= $custom ? 'SAVED' : 'NOT SAVED' ?></span>
    </div>

    <label class="check" style="margin-top:0">
      <input type="checkbox" name="use_custom_palette" id="sfy-use-custom" <?= $custom ? 'checked' : '' ?>>
      Save and use a custom palette (tick this to freeze the design you see, then tune any colour)
    </label>

    <details class="acc mt-2" <?= $custom ? 'open' : '' ?>>
      <summary>Palette — <?= count($palette) ?> colours</summary>
      <div class="acc-body">
        <p class="hint" style="margin-top:12px">
          Values are pre-filled from <b><?= sfy_esc($presets[$a['preset']]['label']) ?></b>. While a custom palette is
          active the template's colours are ignored, so switching templates only changes shape defaults.
        </p>
        <div class="varbox" id="sfy-varbox">
          <?php foreach ($palette as $k => $v):
              $lbl = $labels[$k] ?? $k;
              $hex = sfy_hex_clean((string)$v); ?>
            <label>
              <span title="<?= sfy_esc($k) ?>"><?= sfy_esc($lbl) ?></span>
              <input type="text" class="mono" name="palette_text[<?= sfy_esc($k) ?>]" value="<?= sfy_esc($hex) ?>"
                     data-mirror="palette[<?= sfy_esc($k) ?>]" maxlength="7" <?= $custom ? '' : 'disabled' ?>>
              <input type="color" name="palette[<?= sfy_esc($k) ?>]" value="<?= sfy_esc($hex) ?>" <?= $custom ? '' : 'disabled' ?>>
            </label>
          <?php endforeach; ?>
        </div>
        <p class="hint">Anything that is not a plain <b>#rrggbb</b> value is ignored, so a typo can never break the site.</p>
      </div>
    </details>
  </div>

  <div class="btn-row">
    <button class="btn btn-primary">SAVE DESIGN</button>
  </div>
</form>

<form method="POST" class="mt-2"
      onsubmit="return confirm('Reset the whole design back to the shipped default (Deep Ink)?')">
  <?= sfy_csrf_field() ?>
  <input type="hidden" name="action" value="reset_appearance">
  <button class="btn btn-ghost btn-sm">RESET TO SHIPPED DEFAULT</button>
</form>

<script>
(function(){
  var form    = document.getElementById('sfy-app-form');
  var custom  = document.getElementById('sfy-use-custom');
  var varbox  = document.getElementById('sfy-varbox');

  function paletteOn(){
    var on = custom.checked;
    varbox.querySelectorAll('input').forEach(function(i){ i.disabled = !on; });
    document.querySelectorAll('#sfy-varbox label').forEach(function(l){ l.style.opacity = on ? '1' : '.55'; });
  }
  custom.addEventListener('change', function(){ paletteOn(); push(); });
  paletteOn();

  /* mirror text ↔ colour pickers */
  form.querySelectorAll('#sfy-varbox input[type=text]').forEach(function(t){
    var picker = form.querySelector('input[name="' + t.getAttribute('data-mirror') + '"]');
    if(!picker) return;
    t.addEventListener('input', function(){
      var v = t.value.trim();
      if(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(v)) picker.value = v.length === 4 ? '#' + v[1]+v[1]+v[2]+v[2]+v[3]+v[3] : v;
      push();
    });
  });

  /* slider readouts */
  form.querySelectorAll('input[type=range]').forEach(function(r){
    var out = document.getElementById(r.getAttribute('data-out'));
    r.addEventListener('input', function(){
      if(out) out.textContent = r.value + (r.getAttribute('data-suffix') || '');
      push();
    });
  });

  /* chip rows */
  form.querySelectorAll('.chip input[type=radio]').forEach(function(r){
    r.addEventListener('change', function(){
      var name = r.name;
      form.querySelectorAll('.chip input[name="' + name + '"]').forEach(function(x){
        x.closest('.chip').classList.toggle('on', x.checked);
      });
      push();
    });
  });

  /* preset cards + palette re-prefill */
  var PRESET_VARS = <?= json_encode(array_map(fn($p) => $p['vars'], $presets)) ?>;
  form.querySelectorAll('input[name="preset"]').forEach(function(r){
    r.addEventListener('change', function(){
      form.querySelectorAll('[data-preset-card]').forEach(function(c){
        c.classList.toggle('active', c.querySelector('input').checked);
      });
      var vars = PRESET_VARS[r.value] || {};
      Object.keys(vars).forEach(function(k){
        var t = form.querySelector('input[name="palette_text[' + k + ']"]');
        var p = form.querySelector('input[name="palette[' + k + ']"]');
        if(t) t.value = vars[k];
        if(p) p.value = vars[k];
      });
      push();
    });
  });

  /* accent helpers */
  var accent     = document.getElementById('sfy-accent');
  var accentPick = document.getElementById('sfy-accent-pick');
  accentPick.addEventListener('input', function(){ accent.value = accentPick.value; push(); });
  document.getElementById('sfy-accent-clear').addEventListener('click', function(){
    accent.value = ''; push();
  });
  document.querySelectorAll('[data-accent]').forEach(function(b){
    b.addEventListener('click', function(){
      accent.value = b.getAttribute('data-accent');
      accentPick.value = accent.value;
      push();
    });
  });
  accent.addEventListener('input', push);

  form.querySelectorAll('input[type=checkbox]').forEach(function(c){
    if(c !== custom) c.addEventListener('change', push);
  });
  form.querySelectorAll('input[type=text]:not([data-mirror])').forEach(function(t){
    t.addEventListener('input', push);
  });

  function collect(){
    var g = function(sel){ var e = form.querySelector(sel); return e ? e.value : ''; };
    var chk = function(n){ var e = form.querySelector('input[name="' + n + '"]'); return e && e.checked ? 1 : 0; };
    return {
      preset:     (form.querySelector('input[name=preset]:checked') || {}).value || 'ink',
      accent:     accent.value.trim(),
      radius:     +g('input[name=radius]'),
      glow:       +g('input[name=glow]'),
      shell:      +g('input[name=shell]'),
      font_scale: +g('input[name=font_scale]'),
      density:    (form.querySelector('input[name=density]:checked') || {}).value || 'cozy',
      card_style: (form.querySelector('input[name=card_style]:checked') || {}).value || 'solid',
      bg_pattern: (form.querySelector('input[name=bg_pattern]:checked') || {}).value || 'grid',
      font_ui:    g('select[name=font_ui]') || 'inter',
      btn_style:  (form.querySelector('input[name=btn_style]:checked') || {}).value || 'solid',
      nav_style:  (form.querySelector('input[name=nav_style]:checked') || {}).value || 'pill',
      motion:     (form.querySelector('input[name=motion]:checked') || {}).value || 'soft',
      line_w:     +g('input[name=line_w]'),
      grain:      chk('grain'),
      fx_grid:    chk('fx_grid'), fx_aurora: chk('fx_aurora'),
      fx_shine:   chk('fx_shine'), fx_scan:  chk('fx_scan'),
      vars:       document.getElementById('sfy-use-custom').checked ? currentPalette() : {}
    };
  }

  function currentPalette(){
    var out = {};
    if(!custom.checked) return out;
    form.querySelectorAll('#sfy-varbox input[type=text]').forEach(function(t){
      var v = t.value.trim();
      if(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(v)) out[t.getAttribute('data-mirror').replace(/^palette\[|\]$/g, '')] = v;
    });
    return out;
  }

  /* one-click style presets */
  document.querySelectorAll('[data-quick]').forEach(function(b){
    b.addEventListener('click', function(){
      var set;
      try { set = JSON.parse(b.getAttribute('data-set')); } catch(e) { return; }
      Object.keys(set).forEach(function(k){
        var radios = form.querySelectorAll('input[name="' + k + '"]');
        if (radios.length && radios[0].type === 'radio') {
          form.querySelectorAll('input[name="' + k + '"]').forEach(function(r){
            r.checked = (r.value === String(set[k]));
            var chip = r.closest('.chip'); if(chip) chip.classList.toggle('on', r.checked);
          });
          return;
        }
        var el = form.querySelector('[name="' + k + '"]');
        if (!el) return;
        if (el.type === 'checkbox') el.checked = !!+set[k] || set[k] === true;
        else el.value = set[k];
        if (el.type === 'range') {
          var out = document.getElementById(el.getAttribute('data-out'));
          if (out) out.textContent = el.value + (el.getAttribute('data-suffix') || '');
        }
      });
      var acc = form.querySelector('select[name=font_ui]');
      if (set.font_ui && acc) acc.value = set.font_ui;
      document.querySelectorAll('[data-quick]').forEach(function(x){ x.classList.toggle('active', x === b); });
      var note = document.getElementById('sfy-quick-note');
      if (note) note.textContent = '“' + b.querySelector('.t').textContent + '” applied to the form — press SAVE DESIGN to keep it.';
      push();
    });
  });

  document.querySelectorAll('select[name=font_ui]').forEach(function(sel){
    sel.addEventListener('change', push);
  });

  function push(){ window.sfyPreviewPush('appearance', collect()); }
})();
</script>
