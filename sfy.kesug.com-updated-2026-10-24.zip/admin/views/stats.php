<?php
/** @var PDO $db */
$days = sfy_int('days', 30);
if (!in_array($days, [7, 30, 90, 0], true)) $days = 30;
$funnel = sfy_funnel_stats();
$dev    = sfy_device_stats();
$ads    = sfy_ads_stats();

$countries = $db->query("SELECT COALESCE(NULLIF(country,''),'Unknown') AS label, COUNT(*) AS n
                         FROM sfy_devices GROUP BY label ORDER BY n DESC LIMIT 10")->fetchAll();
$browsers  = sfy_device_breakdown('browser', 10);
$devtypes  = sfy_device_breakdown('device_type', 6);
if ($days > 0) {
    $daily = $db->query("SELECT DATE(completed_at) AS day, COUNT(*) AS n
                        FROM sfy_sessions WHERE is_completed=1 AND completed_at IS NOT NULL
                          AND completed_at >= DATE_SUB(NOW(), INTERVAL " . (int)$days . " DAY)
                        GROUP BY DATE(completed_at) ORDER BY day DESC")->fetchAll();
} else {
    $daily = $db->query("SELECT DATE(completed_at) AS day, COUNT(*) AS n
                         FROM sfy_sessions WHERE is_completed=1 AND completed_at IS NOT NULL
                         GROUP BY DATE(completed_at) ORDER BY day DESC LIMIT 365")->fetchAll();
}
$topTokens = $db->query("SELECT t.token, t.code, t.tasks_required, COUNT(s.session_id) AS n
                         FROM sfy_tokens t LEFT JOIN sfy_sessions s
                           ON s.token=t.token AND s.is_completed=1
                         GROUP BY t.token ORDER BY n DESC, t.created_at DESC LIMIT 10")->fetchAll();
$recent = $db->query("SELECT s.*, d.device_name AS dev_name, d.os AS dev_os, d.browser AS dev_browser
                      FROM sfy_sessions s LEFT JOIN sfy_devices d ON d.id = s.device_id
                      WHERE s.is_completed=1 ORDER BY s.completed_at DESC LIMIT 40")->fetchAll();
$flags = $db->query("SELECT session_id, token, current_step, total_steps, bypass_flags, risk_score, user_ip,
                            device_name, created_at
                     FROM sfy_sessions WHERE bypass_flags > 0 ORDER BY risk_score DESC, created_at DESC LIMIT 20")->fetchAll();
$provPerf = $db->query("SELECT provider_id, COUNT(*) AS sessions,
                               SUM(is_completed=1) AS done, SUM(bypass_flags>0) AS flagged,
                               ROUND(AVG(risk_score),1) AS risk
                        FROM sfy_sessions WHERE provider_id>0
                        GROUP BY provider_id ORDER BY sessions DESC")->fetchAll();
$pbReasons = $db->query("SELECT COALESCE(NULLIF(reason,''),'unknown') AS reason,
                                COUNT(*) AS n, SUM(accepted=1) AS ok
                         FROM sfy_postback_log GROUP BY reason ORDER BY n DESC LIMIT 12")->fetchAll();
$pbTotal = 0; $pbOk = 0;
foreach ($pbReasons as $pr) { $pbTotal += (int)$pr['n']; $pbOk += (int)$pr['ok']; }

$maxDaily = 1;
foreach ($daily as $d) $maxDaily = max($maxDaily, (int)$d['n']);
$maxCountry = 1;
foreach ($countries as $c) $maxCountry = max($maxCountry, (int)$c['n']);
?>
<div class="grid grid-4 mb-2">
  <?= sfy_kpi('Sessions', number_format($funnel['total']), '', $funnel['open'] . ' in progress') ?>
  <?= sfy_kpi('Completed', number_format($funnel['completed']), '', $funnel['rate'] . '% conversion') ?>
  <?= sfy_kpi('Verified postbacks', number_format($funnel['postbacks']), 'blue', $funnel['postbacks_bad'] . ' rejected') ?>
  <?= sfy_kpi('Devices', number_format($dev['total']), 'gold', $dev['converters'] . ' converted') ?>
</div>

<div class="inline mb-2">
  <span class="tiny mute mono">PERIOD</span>
  <?php foreach ([7 => '7 DAYS', 30 => '30 DAYS', 90 => '90 DAYS', 0 => 'ALL TIME'] as $d => $lbl): ?>
    <a class="btn btn-sm <?= $days === $d ? 'btn-primary' : 'btn-ghost' ?>" href="<?= sfy_esc(sfy_admin_url(['tab' => 'stats', 'days' => $d])) ?>"><?= $lbl ?></a>
  <?php endforeach; ?>
  <span class="spacer"></span>
  <span class="tiny mute">Completion <b><?= $funnel['completed'] ?></b> / <?= $funnel['total'] ?> · rate <?= $funnel['rate'] ?>%</span>
</div>

<div class="grid grid-3 mb-2">
  <div class="card">
    <div class="card-head"><h2>&gt; TOP_COUNTRIES</h2></div>
    <div class="tbl-wrap"><table class="tbl" style="min-width:0">
      <thead><tr><th>Country</th><th>Devices</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($countries as $c): ?>
        <tr><td class="tiny"><?= sfy_esc((string)$c['label']) ?></td><td class="mono"><?= (int)$c['n'] ?></td>
            <td><?= sfy_mini_bar((int)$c['n'], $maxCountry) ?></td></tr>
      <?php endforeach; ?>
      <?php if (!$countries): ?><tr><td colspan="3" class="empty">no data</td></tr><?php endif; ?>
      </tbody>
    </table></div>
  </div>
  <div class="card">
    <div class="card-head"><h2>&gt; BROWSERS</h2></div>
    <div class="tbl-wrap"><table class="tbl" style="min-width:0">
      <thead><tr><th>Browser</th><th>Devices</th><th>Unlocks</th></tr></thead>
      <tbody>
      <?php foreach ($browsers as $b): ?>
        <tr><td class="tiny"><?= sfy_esc((string)$b['label']) ?></td><td class="mono"><?= (int)$b['n'] ?></td><td class="mono"><?= (int)$b['ok'] ?></td></tr>
      <?php endforeach; ?>
      <?php if (!$browsers): ?><tr><td colspan="3" class="empty">no data</td></tr><?php endif; ?>
      </tbody>
    </table></div>
  </div>
  <div class="card">
    <div class="card-head"><h2>&gt; PLATFORMS</h2></div>
    <div class="tbl-wrap"><table class="tbl" style="min-width:0">
      <thead><tr><th>Type</th><th>Devices</th><th>Unlocks</th></tr></thead>
      <tbody>
      <?php foreach ($devtypes as $t): ?>
        <tr><td class="tiny"><?= sfy_esc((string)$t['label']) ?></td><td class="mono"><?= (int)$t['n'] ?></td><td class="mono"><?= (int)$t['ok'] ?></td></tr>
      <?php endforeach; ?>
      <?php if (!$devtypes): ?><tr><td colspan="3" class="empty">no data</td></tr><?php endif; ?>
      </tbody>
    </table></div>
  </div>
</div>

<div class="grid grid-2 mb-2">
  <div class="card">
    <div class="card-head"><h2>&gt; PROVIDER_PERFORMANCE <span class="sfy-tip" data-tip="Sessions that chose each network, how many completed, and how many were flagged. A network with sessions but no completions is the first place to look.">?</span></h2></div>
    <div class="tbl-wrap"><table class="tbl" style="min-width:0">
      <thead><tr><th>Provider</th><th>Sessions</th><th>Done</th><th>Rate</th><th>Flagged</th><th>Avg risk</th></tr></thead>
      <tbody>
      <?php foreach ($provPerf as $pp): $pv = sfy_provider_find((int)$pp['provider_id']); $n = (int)$pp['sessions']; ?>
        <tr><td class="tiny"><?= $pv ? sfy_esc(sfy_provider_label($pv)) : '#' . (int)$pp['provider_id'] ?></td>
            <td class="mono"><?= $n ?></td><td class="mono"><?= (int)$pp['done'] ?></td>
            <td class="mono"><?= $n > 0 ? round((int)$pp['done'] / $n * 100, 1) : 0 ?>%</td>
            <td><?= (int)$pp['flagged'] ? sfy_badge((string)(int)$pp['flagged'], 'r') : '<span class="mute">—</span>' ?></td>
            <td class="mono"><?= sfy_esc((string)$pp['risk']) ?></td></tr>
      <?php endforeach; ?>
      <?php if (!$provPerf): ?><tr><td colspan="6" class="empty">no provider sessions yet</td></tr><?php endif; ?>
      </tbody>
    </table></div>
  </div>

  <div class="card">
    <div class="card-head"><h2>&gt; POSTBACK_HEALTH <span class="sfy-tip" data-tip="Why postbacks were accepted or rejected. A high bad_postback_key count means an account key/dashboard mismatch; a high already_completed count usually means a replay.">?</span></h2>
      <span class="spacer"></span><span class="badge <?= $pbTotal > 0 && $pbOk === $pbTotal ? 'g' : 'y' ?>"><?= $pbTotal > 0 ? round($pbOk / $pbTotal * 100, 1) : 0 ?>% OK</span></div>
    <div class="tbl-wrap"><table class="tbl" style="min-width:0">
      <thead><tr><th>Reason</th><th>Count</th><th>Accepted</th><th>Rate</th></tr></thead>
      <tbody>
      <?php foreach ($pbReasons as $pr): $n = (int)$pr['n']; $ok = (int)$pr['ok']; ?>
        <tr><td class="tiny mono"><?= sfy_esc((string)$pr['reason']) ?></td><td class="mono"><?= $n ?></td>
            <td class="mono"><?= $ok ?></td><td class="mono"><?= $n > 0 ? round($ok / $n * 100, 1) : 0 ?>%</td></tr>
      <?php endforeach; ?>
      <?php if (!$pbReasons): ?><tr><td colspan="4" class="empty">no postbacks yet</td></tr><?php endif; ?>
      </tbody>
    </table></div>
  </div>
</div>

<div class="grid grid-2 mb-2">
  <div class="card">
    <div class="card-head"><h2>&gt; DAILY_COMPLETIONS</h2></div>
    <div class="tbl-wrap"><table class="tbl" style="min-width:0">
      <thead><tr><th>Day</th><th>Completed</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($daily as $d): ?>
        <tr><td class="tiny"><?= sfy_esc((string)$d['day']) ?></td><td class="mono"><?= (int)$d['n'] ?></td>
            <td><?= sfy_mini_bar((int)$d['n'], $maxDaily) ?></td></tr>
      <?php endforeach; ?>
      <?php if (!$daily): ?><tr><td colspan="3" class="empty">no completions yet</td></tr><?php endif; ?>
      </tbody>
    </table></div>
  </div>

  <div class="card">
    <div class="card-head"><h2>&gt; ADS_PERFORMANCE</h2></div>
    <div class="tbl-wrap"><table class="tbl" style="min-width:0">
      <thead><tr><th>Placement</th><th>Ads</th><th>Impr.</th><th>Clicks</th><th>CTR</th></tr></thead>
      <tbody>
      <?php foreach (sfy_ads_by_placement() as $a): $imp = (int)$a['impressions']; $clk = (int)$a['clicks']; ?>
        <tr><td class="tiny"><?= sfy_esc((string)$a['placement']) ?></td><td class="mono"><?= (int)$a['n'] ?></td>
            <td class="mono"><?= number_format($imp) ?></td><td class="mono"><?= number_format($clk) ?></td>
            <td class="mono"><?= $imp > 0 ? round($clk / $imp * 100, 1) : 0 ?>%</td></tr>
      <?php endforeach; ?>
      <?php if (!$ads['total']): ?><tr><td colspan="5" class="empty">no ads configured</td></tr><?php endif; ?>
      </tbody>
    </table></div>
    <div class="hint">Total: <?= number_format($ads['impressions']) ?> impressions · <?= number_format($ads['clicks']) ?> clicks · <?= $ads['ctr'] ?>% CTR</div>
  </div>
</div>

<div class="card mb-2">
  <div class="card-head"><h2>&gt; TOP_TOKENS_BY_UNLOCKS</h2></div>
  <?php if (!$topTokens): ?>
    <div class="empty">no completions yet</div>
  <?php else: ?>
    <div class="tbl-wrap"><table class="tbl">
      <thead><tr><th>#</th><th>Token</th><th>Code</th><th>Tasks</th><th>Unlocks</th></tr></thead>
      <tbody>
      <?php foreach ($topTokens as $i => $t): ?>
        <tr><td class="mono"><?= $i + 1 ?></td>
            <td class="mono"><?= sfy_esc((string)$t['token']) ?></td>
            <td class="mono" style="color:var(--gold)"><?= sfy_esc((string)$t['code']) ?></td>
            <td class="mono"><?= (int)$t['tasks_required'] ?></td>
            <td><span class="badge <?= (int)$t['n'] > 0 ? 'g' : 'gr' ?>"><?= (int)$t['n'] ?></span></td></tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
  <?php endif; ?>
</div>

<?php
/* ── code opens: how each finished token has been used ───────────────
   Guarded, because the table arrives with migration 020 and an admin page
   must never 500 just because the upload is newer than the database. */
$coReady  = sfy_table_exists('sfy_code_opens');
$coRecent = $coTokens = [];
$coTotals = ['opens' => 0, 'devices' => 0, 'foreign' => 0, 'tokens' => 0];
if ($coReady) {
    $coTotals = array_merge($coTotals, (array)$db->query("SELECT COUNT(*) AS opens,
            COUNT(DISTINCT NULLIF(device_id,0)) AS devices,
            COALESCE(SUM(own_device=0),0) AS foreign,
            COUNT(DISTINCT token) AS tokens
        FROM sfy_code_opens")->fetch());
    $coRecent = $db->query("SELECT o.*, t.game_name FROM sfy_code_opens o
                            LEFT JOIN sfy_tokens t ON t.token = o.token
                            ORDER BY o.id DESC LIMIT 30")->fetchAll();
    $coTokens = $db->query("SELECT o.token, COUNT(*) AS opens,
                                   COUNT(DISTINCT NULLIF(o.device_id,0)) AS devices,
                                   COALESCE(SUM(o.own_device=0),0) AS foreign,
                                   MAX(o.created_at) AS last_at, t.code, t.game_name
                            FROM sfy_code_opens o LEFT JOIN sfy_tokens t ON t.token = o.token
                            GROUP BY o.token ORDER BY opens DESC, last_at DESC LIMIT 15")->fetchAll();
}
?>
<div class="card mb-2">
  <div class="card-head"><h2>&gt; CODE_OPENS</h2><span class="spacer"></span>
    <span class="badge <?= (int)$coTotals['foreign'] > 0 ? 'y' : 'g' ?>">
      <?= (int)$coTotals['foreign'] ?> FROM ANOTHER DEVICE</span></div>

  <?php if (!$coReady): ?>
    <div class="empty">The code-open log arrives with migration <b>020</b>. Open the
      <a href="<?= sfy_esc(sfy_admin_url(['tab' => 'updater'])) ?>">Updater</a> and run it.</div>
  <?php else: ?>
    <div class="grid grid-4 mb-2">
      <?= sfy_kpi('Code opens', number_format((int)$coTotals['opens']), '', 'every display of a finished code') ?>
      <?= sfy_kpi('Tokens', number_format((int)$coTotals['tokens']), 'gold', 'distinct tokens opened') ?>
      <?= sfy_kpi('Devices', number_format((int)$coTotals['devices']), 'blue', 'distinct devices asking') ?>
      <?= sfy_kpi('Reopened elsewhere', number_format((int)$coTotals['foreign']), 'purple',
                  'opened by a device that did not finish it') ?>
    </div>

    <?php if ($coTokens): ?>
      <div class="tbl-wrap"><table class="tbl">
        <thead><tr><th>Token</th><th>Code</th><th>Game</th><th>Opens</th><th>Devices</th>
                   <th>Elsewhere</th><th>Last opened</th></tr></thead>
        <tbody>
        <?php foreach ($coTokens as $t): ?>
          <tr>
            <td class="mono tiny"><?= sfy_esc((string)$t['token']) ?></td>
            <td class="mono" style="color:var(--gold)"><?= sfy_esc((string)($t['code'] ?? '')) ?></td>
            <td class="tiny"><?= sfy_esc(sfy_short((string)($t['game_name'] ?: '—'), 18)) ?></td>
            <td class="mono"><?= (int)$t['opens'] ?></td>
            <td class="mono"><?= (int)$t['devices'] ?></td>
            <td><span class="badge <?= (int)$t['foreign'] > 0 ? 'y' : 'gr' ?>"><?= (int)$t['foreign'] ?></span></td>
            <td class="tiny dim"><?= sfy_esc(sfy_ago((string)$t['last_at'])) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
    <?php else: ?>
      <div class="empty">No code has been opened yet. This fills in as soon as a player reads their code.</div>
    <?php endif; ?>

    <?php if ($coRecent): ?>
      <div class="tbl-wrap mt-2"><table class="tbl">
        <thead><tr><th>When</th><th>Token</th><th>Device</th><th>Location</th><th>Timezone</th>
                   <th>IP</th><th>Same device</th></tr></thead>
        <tbody>
        <?php foreach ($coRecent as $o): ?>
          <tr>
            <td class="tiny dim"><?= sfy_esc(sfy_ago((string)$o['created_at'])) ?></td>
            <td class="mono tiny" style="color:var(--gold)"><?= sfy_esc((string)$o['token']) ?></td>
            <td class="tiny"><?= sfy_esc(sfy_code_open_where($o)) ?></td>
            <td class="tiny"><?= sfy_esc((string)($o['country'] ?: '—')) ?></td>
            <td class="tiny"><?= sfy_esc((string)($o['timezone'] ?: '—')) ?></td>
            <td class="mono tiny"><?= sfy_esc((string)($o['ip'] ?: '—')) ?></td>
            <td><span class="badge <?= (int)$o['own_device'] === 1 ? 'g' : 'y' ?>">
              <?= (int)$o['own_device'] === 1 ? 'YES' : 'NO' ?></span></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
    <?php endif; ?>

    <div class="hint">A row is written every time a finished code is displayed. “Same device” compares the
      device that opened it with the one that completed the tasks, so a shared token shows up as
      <b>NO</b>. This is information only — nothing here blocks a player from their code.</div>
  <?php endif; ?>
</div>

<div class="card mb-2">
  <div class="card-head"><h2>&gt; BYPASS_FLAGS</h2><span class="spacer"></span>
    <span class="badge <?= $flags ? 'r' : 'g' ?>"><?= count($flags) ?> FLAGGED</span></div>
  <?php if (!$flags): ?>
    <div class="empty">no bypass attempts detected — the gate is holding.</div>
  <?php else: ?>
    <div class="tbl-wrap"><table class="tbl">
      <thead><tr><th>Session</th><th>Token</th><th>Flags</th><th>Risk</th><th>Device</th><th>IP</th><th>Created</th></tr></thead>
      <tbody>
      <?php foreach ($flags as $f): ?>
        <tr>
          <td class="mono tiny"><?= sfy_esc(sfy_short((string)$f['session_id'], 14)) ?></td>
          <td class="mono tiny"><?= sfy_esc((string)$f['token']) ?></td>
          <td><span class="badge r"><?= (int)$f['bypass_flags'] ?></span></td>
          <td class="mono"><?= (int)$f['risk_score'] ?></td>
          <td class="tiny"><?= sfy_esc(sfy_short((string)($f['device_name'] ?: '—'), 18)) ?></td>
          <td class="mono tiny"><?= sfy_esc((string)$f['user_ip']) ?></td>
          <td class="tiny dim"><?= sfy_esc(sfy_ago((string)$f['created_at'])) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
  <?php endif; ?>
</div>

<div class="card">
  <div class="card-head"><h2>&gt; RECENT_COMPLETIONS</h2></div>
  <?php if (!$recent): ?>
    <div class="empty">no completions yet</div>
  <?php else: ?>
    <div class="tbl-wrap"><table class="tbl">
      <thead><tr><th>When</th><th>Token</th><th>Device</th><th>Platform</th><th>Location</th>
                 <th>Screen</th><th>Timezone</th><th>IP</th></tr></thead>
      <tbody>
      <?php foreach ($recent as $r): ?>
        <tr>
          <td class="tiny dim"><?= sfy_esc(sfy_ago((string)$r['completed_at'])) ?></td>
          <td class="mono tiny" style="color:var(--gold)"><?= sfy_esc((string)$r['token']) ?></td>
          <td class="tiny"><?= sfy_esc(sfy_short((string)($r['dev_name'] ?: $r['device_name'] ?: '—'), 18)) ?></td>
          <td class="tiny"><?= sfy_esc((string)($r['dev_os'] ?? '')) ?> / <?= sfy_esc((string)($r['dev_browser'] ?? '')) ?></td>
          <td class="tiny"><?= sfy_esc((string)($r['country'] ?: '—')) ?></td>
          <td class="tiny"><?= sfy_esc((string)($r['screen_resolution'] ?: '—')) ?></td>
          <td class="tiny"><?= sfy_esc((string)($r['timezone'] ?: '—')) ?></td>
          <td class="mono tiny"><?= sfy_esc((string)$r['user_ip']) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
  <?php endif; ?>
</div>
