<?php
/** @var PDO $db */
$q      = sfy_param('q');
$fType  = sfy_param('type');
$sort   = sfy_param('sort', 'last_seen');
$pageNo = max(1, sfy_int('p', 1));
$per    = 50;

$stats  = sfy_device_stats();
$total  = sfy_devices_count($q, $fType);
$devices= sfy_devices_list($q, $sort, $per, ($pageNo - 1) * $per, $fType);

$view   = sfy_int('view');
$detail = $view > 0 ? sfy_device_find($view) : null;
$detailSessions = $detail ? sfy_device_sessions((int)$detail['id'], 20) : [];

$browsers = sfy_device_breakdown('browser', 6);
$oses     = sfy_device_breakdown('os', 6);
$countries= sfy_device_breakdown('country', 8);
$daily    = sfy_device_daily(10);
$clusters = sfy_device_ip_clusters(3, 8);
$maxDaily = 1;
foreach ($daily as $d) $maxDaily = max($maxDaily, (int)$d['devices']);
?>
<div class="grid grid-4 mb-2">
  <?= sfy_kpi('Devices tracked', number_format($stats['total']), '', $stats['today'] . ' seen today') ?>
  <?= sfy_kpi('Unlocked at least once', number_format($stats['converters']), '', $stats['repeat'] . ' repeat users') ?>
  <?= sfy_kpi('Total unlocks', number_format($stats['success_total']), 'gold', $stats['fail_total'] . ' failed attempts') ?>
  <?= sfy_kpi('Blocked', number_format($stats['blocked']), 'red', $stats['suspicious'] . ' suspicious') ?>
</div>

<div class="card">
  <div class="card-head">
    <h2>&gt; DEVICE_REGISTRY</h2>
    <span class="spacer"></span>
    <span class="badge gr"><?= number_format($total) ?> MATCHED</span>
    <?php sfy_admin_post_button('⛔ BLOCK SUSPICIOUS', ['action' => 'bulk_block_suspicious'], 'btn btn-sm btn-danger', 'Block every device flagged for bypass attempts?') ?>
  </div>

  <form method="GET" class="inline mb-2">
    <input type="hidden" name="tab" value="devices">
    <input class="grow" type="search" name="q" value="<?= sfy_esc($q) ?>" placeholder="search name / key / IP / country / token">
    <select name="type" style="max-width:150px">
      <option value="">All types</option>
      <?php foreach (['desktop', 'mobile', 'tablet', 'bot'] as $t): ?>
        <option value="<?= $t ?>" <?= $fType === $t ? 'selected' : '' ?>><?= ucfirst($t) ?></option>
      <?php endforeach; ?>
    </select>
    <select name="sort" style="max-width:180px">
      <?php foreach (['last_seen' => 'Recently seen', 'success' => 'Most unlocks', 'fail' => 'Most failures',
                      'sessions' => 'Most sessions', 'risk' => 'Highest risk', 'created' => 'Newest first',
                      'country' => 'Country', 'ip' => 'IP'] as $k => $lbl): ?>
        <option value="<?= $k ?>" <?= $sort === $k ? 'selected' : '' ?>><?= sfy_esc($lbl) ?></option>
      <?php endforeach; ?>
    </select>
    <button class="btn">FILTER</button>
    <a class="btn btn-ghost" href="<?= sfy_esc(sfy_admin_url(['tab' => 'devices'])) ?>">RESET</a>
  </form>

  <?php if (!$devices): ?>
    <div class="empty">&gt; no devices recorded yet — they appear the moment someone claims a token.</div>
  <?php else: ?>
    <div class="tbl-wrap">
      <table class="tbl">
        <thead>
          <tr><th>Device</th><th>Platform</th><th>Location</th><th>IP</th><th>Sessions</th>
              <th>Unlocks</th><th>Failed</th><th>Bypass</th><th>Last seen</th><th>State</th><th>Actions</th></tr>
        </thead>
        <tbody>
        <?php foreach ($devices as $d): ?>
          <tr>
            <td>
              <div class="mono"><?= sfy_esc(sfy_short((string)$d['device_name'], 26)) ?></div>
              <div class="tiny mute mono"><?= sfy_esc(sfy_short((string)$d['device_key'], 24)) ?></div>
            </td>
            <td class="tiny">
              <?= sfy_esc((string)$d['os']) ?><br>
              <span class="mute"><?= sfy_esc((string)$d['browser']) ?> <?= sfy_esc((string)$d['browser_version']) ?></span>
            </td>
            <td class="tiny"><?= sfy_esc((string)($d['country'] ?: '—')) ?></td>
            <td class="mono tiny"><?= sfy_esc((string)($d['ip'] ?: '—')) ?></td>
            <td class="mono"><?= (int)$d['session_count'] ?></td>
            <td><span class="badge <?= (int)$d['success_count'] > 0 ? 'g' : 'gr' ?>"><?= (int)$d['success_count'] ?></span></td>
            <td class="mono" style="color:<?= (int)$d['fail_count'] > 0 ? 'var(--orange)' : 'inherit' ?>"><?= (int)$d['fail_count'] ?></td>
            <td class="mono" style="color:<?= (int)$d['bypass_attempts'] > 0 ? 'var(--red)' : 'inherit' ?>"><?= (int)$d['bypass_attempts'] ?></td>
            <td class="tiny dim"><?= sfy_esc(sfy_ago((string)$d['last_seen'])) ?></td>
            <td>
              <?php if ((int)$d['is_blocked']): ?><?= sfy_badge('BLOCKED', 'r') ?>
              <?php elseif ((int)$d['is_trusted']): ?><?= sfy_badge('TRUSTED', 'b') ?>
              <?php else: ?><?= sfy_badge('NORMAL', 'gr') ?><?php endif; ?>
            </td>
            <td>
              <div class="actions">
                <a class="btn btn-sm" href="<?= sfy_esc(sfy_admin_url(['tab' => 'devices', 'view' => (int)$d['id']])) ?>">VIEW</a>
                <?php if ((int)$d['is_blocked']): ?>
                  <?php sfy_admin_post_button('UNBLOCK', ['action' => 'unblock_device', 'id' => (int)$d['id']]) ?>
                <?php else: ?>
                  <?php sfy_admin_post_button('BLOCK', ['action' => 'block_device', 'id' => (int)$d['id']], 'btn btn-sm btn-danger') ?>
                <?php endif; ?>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php
    $pages = (int)ceil($total / $per);
    if ($pages > 1):
      $qs = $_GET; ?>
      <div class="btn-row mt-2">
        <?php for ($i = 1; $i <= min($pages, 12); $i++): $qs['p'] = $i; $qs['tab'] = 'devices'; ?>
          <a class="btn btn-sm <?= $i === $pageNo ? 'btn-primary' : '' ?>" href="?<?= sfy_esc(http_build_query($qs)) ?>"><?= $i ?></a>
        <?php endfor; ?>
      </div>
    <?php endif; ?>
  <?php endif; ?>
</div>

<div class="grid grid-3 mb-2">
  <div class="card">
    <div class="card-head"><h2>&gt; BROWSERS</h2></div>
    <div class="tbl-wrap"><table class="tbl" style="min-width:0">
      <thead><tr><th>Browser</th><th>Devices</th><th>Unlocks</th></tr></thead>
      <tbody>
      <?php foreach ($browsers as $b): ?>
        <tr><td class="tiny"><?= sfy_esc((string)$b['label']) ?></td><td class="mono"><?= (int)$b['n'] ?></td><td class="mono"><?= (int)$b['ok'] ?></td></tr>
      <?php endforeach; ?>
      <?php if (!$browsers): ?><tr><td colspan="3" class="empty">no data</td></tr><?php endif; ?>
      </tbody>
    </table></div>
  </div>
  <div class="card">
    <div class="card-head"><h2>&gt; OPERATING_SYSTEMS</h2></div>
    <div class="tbl-wrap"><table class="tbl" style="min-width:0">
      <thead><tr><th>OS</th><th>Devices</th><th>Unlocks</th></tr></thead>
      <tbody>
      <?php foreach ($oses as $o): ?>
        <tr><td class="tiny"><?= sfy_esc((string)$o['label']) ?></td><td class="mono"><?= (int)$o['n'] ?></td><td class="mono"><?= (int)$o['ok'] ?></td></tr>
      <?php endforeach; ?>
      <?php if (!$oses): ?><tr><td colspan="3" class="empty">no data</td></tr><?php endif; ?>
      </tbody>
    </table></div>
  </div>
  <div class="card">
    <div class="card-head"><h2>&gt; LOCATIONS</h2></div>
    <div class="tbl-wrap"><table class="tbl" style="min-width:0">
      <thead><tr><th>Country</th><th>Devices</th><th>Unlocks</th></tr></thead>
      <tbody>
      <?php foreach ($countries as $c): ?>
        <tr><td class="tiny"><?= sfy_esc((string)$c['label']) ?></td><td class="mono"><?= (int)$c['n'] ?></td><td class="mono"><?= (int)$c['ok'] ?></td></tr>
      <?php endforeach; ?>
      <?php if (!$countries): ?><tr><td colspan="3" class="empty">no data</td></tr><?php endif; ?>
      </tbody>
    </table></div>
  </div>
</div>

<div class="grid grid-2 mb-2">
  <div class="card">
    <div class="card-head"><h2>&gt; NEW_DEVICES_PER_DAY</h2></div>
    <div class="tbl-wrap"><table class="tbl" style="min-width:0">
      <thead><tr><th>Day</th><th>Devices</th><th>Unlocks</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($daily as $d): ?>
        <tr><td class="tiny"><?= sfy_esc((string)$d['day']) ?></td><td class="mono"><?= (int)$d['devices'] ?></td>
            <td class="mono"><?= (int)$d['ok'] ?></td>
            <td><?= sfy_mini_bar((int)$d['devices'], $maxDaily) ?></td></tr>
      <?php endforeach; ?>
      <?php if (!$daily): ?><tr><td colspan="4" class="empty">no data</td></tr><?php endif; ?>
      </tbody>
    </table></div>
  </div>

  <div class="card">
    <div class="card-head"><h2>&gt; SHARED_IP_CLUSTERS</h2></div>
    <p class="hint mt-0">Several devices behind one IP — useful for spotting multi-account farms.</p>
    <div class="tbl-wrap"><table class="tbl" style="min-width:0">
      <thead><tr><th>IP</th><th>Devices</th><th>Unlocks</th><th>Failed</th><th>Last seen</th></tr></thead>
      <tbody>
      <?php foreach ($clusters as $c): ?>
        <tr><td class="mono tiny"><?= sfy_esc((string)$c['ip']) ?></td><td class="mono"><?= (int)$c['devices'] ?></td>
            <td class="mono"><?= (int)$c['ok'] ?></td><td class="mono"><?= (int)$c['fails'] ?></td>
            <td class="tiny dim"><?= sfy_esc(sfy_ago((string)$c['last_seen'])) ?></td></tr>
      <?php endforeach; ?>
      <?php if (!$clusters): ?><tr><td colspan="5" class="empty">no shared IPs</td></tr><?php endif; ?>
      </tbody>
    </table></div>
  </div>
</div>

<?php if ($detail): ?>
<div class="modal-bg show">
  <div class="modal" style="width:820px">
    <div class="modal-head">
      <h3>&gt; DEVICE #<?= (int)$detail['id'] ?></h3>
      <span class="spacer" style="margin-left:auto"></span>
      <?php if ((int)$detail['is_blocked']): ?><?= sfy_badge('BLOCKED', 'r') ?><?php else: ?><?= sfy_badge('ACTIVE', 'g') ?><?php endif; ?>
      <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_admin_url(['tab' => 'devices'])) ?>">✕</a>
    </div>
    <div class="modal-body">
      <div class="grid grid-4 mb-2">
        <?= sfy_kpi('Unlocks', (int)$detail['success_count'], '') ?>
        <?= sfy_kpi('Failed', (int)$detail['fail_count'], 'orange') ?>
        <?= sfy_kpi('Sessions', (int)$detail['session_count'], 'blue') ?>
        <?= sfy_kpi('Bypass flags', (int)$detail['bypass_attempts'], 'red') ?>
      </div>

      <div class="term" style="max-height:none;font-size:11.5px">
&gt; device name ... <?= sfy_esc((string)$detail['device_name']) ?>

&gt; fingerprint ... <?= sfy_esc((string)$detail['device_key']) ?>

&gt; platform ...... <?= sfy_esc((string)$detail['os']) ?> / <?= sfy_esc((string)$detail['browser']) ?> <?= sfy_esc((string)$detail['browser_version']) ?>

&gt; type .......... <?= sfy_esc((string)$detail['device_type']) ?>

&gt; screen ........ <?= sfy_esc((string)($detail['screen_resolution'] ?: 'n/a')) ?> · <?= sfy_esc((string)($detail['timezone'] ?: 'n/a')) ?> · <?= sfy_esc((string)($detail['language'] ?: 'n/a')) ?>

&gt; network ....... <?= sfy_esc((string)($detail['ip'] ?: 'n/a')) ?> (<?= sfy_esc((string)($detail['country'] ?: 'unknown')) ?>)

&gt; first seen .... <?= sfy_esc((string)$detail['first_seen']) ?> · last seen <?= sfy_esc((string)$detail['last_seen']) ?>

&gt; code views .... <?= (int)$detail['code_views'] ?> · tokens used <?= (int)$detail['tokens_used'] ?>

&gt; last token .... <?= sfy_esc((string)($detail['last_token'] ?: '—')) ?>

&gt; risk score .... <?= (int)$detail['risk_score'] ?>

&gt; user agent .... <?= sfy_esc(sfy_short((string)$detail['user_agent'], 120)) ?>
      </div>

      <div class="label mt-2">Sessions</div>
      <div class="tbl-wrap"><table class="tbl">
        <thead><tr><th>Session</th><th>Token</th><th>Step</th><th>State</th><th>Country</th><th>IP</th><th>Created</th></tr></thead>
        <tbody>
        <?php foreach ($detailSessions as $s): ?>
          <tr>
            <td class="mono tiny"><?= sfy_esc(sfy_short((string)$s['session_id'], 14)) ?></td>
            <td class="mono tiny"><?= sfy_esc((string)$s['token']) ?></td>
            <td class="mono tiny"><?= (int)$s['current_step'] ?>/<?= (int)$s['total_steps'] ?></td>
            <td><?= (int)$s['is_completed'] ? sfy_badge('DONE', 'g') : sfy_badge('OPEN', 'b') ?></td>
            <td class="tiny"><?= sfy_esc((string)($s['country'] ?: '—')) ?></td>
            <td class="mono tiny"><?= sfy_esc((string)$s['user_ip']) ?></td>
            <td class="tiny dim"><?= sfy_esc(sfy_ago((string)$s['created_at'])) ?></td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$detailSessions): ?><tr><td colspan="7" class="empty">no sessions on record</td></tr><?php endif; ?>
        </tbody>
      </table></div>

      <div class="label mt-2">Note</div>
      <form method="POST" class="inline">
        <?= sfy_csrf_field() ?>
        <input type="hidden" name="action" value="save_device_note">
        <input type="hidden" name="id" value="<?= (int)$detail['id'] ?>">
        <input class="grow" type="text" name="notes" value="<?= sfy_esc((string)($detail['notes'] ?? '')) ?>" placeholder="admin note about this device">
        <button class="btn">SAVE NOTE</button>
      </form>

      <div class="modal-actions" style="justify-content:flex-start">
        <?php if ((int)$detail['is_blocked']): ?>
          <?php sfy_admin_post_button('UNBLOCK DEVICE', ['action' => 'unblock_device', 'id' => (int)$detail['id']]) ?>
        <?php else: ?>
          <?php sfy_admin_post_button('BLOCK DEVICE', ['action' => 'block_device', 'id' => (int)$detail['id']], 'btn btn-danger') ?>
        <?php endif; ?>
        <?php sfy_admin_post_button((int)$detail['is_trusted'] ? 'REMOVE TRUST' : 'MARK TRUSTED', ['action' => 'trust_device', 'id' => (int)$detail['id']]) ?>
        <?php sfy_admin_post_button('RESET COUNTERS', ['action' => 'reset_device', 'id' => (int)$detail['id']], 'btn', 'Reset all counters for this device?') ?>
        <?php sfy_admin_post_button('DELETE DEVICE', ['action' => 'delete_device', 'id' => (int)$detail['id']], 'btn btn-danger', 'Delete this device record permanently?') ?>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>
