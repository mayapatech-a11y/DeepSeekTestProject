<?php
/** @var PDO $db */
$games = $db->query("SELECT * FROM sfy_games ORDER BY game_id")->fetchAll();
$edit  = sfy_param('edit');
$eg    = null;
if ($edit === 'new') {
    $eg = ['game_id' => '', 'game_name' => '', 'script_url' => '', 'is_active' => 1, 'max_runs' => 50,
           'script_version' => 1, 'notes' => ''];
} elseif ($edit !== '') {
    foreach ($games as $g) if ((string)$g['game_id'] === $edit) { $eg = $g; break; }
}

$tokenCounts = [];
foreach ($db->query("SELECT game_id, COUNT(*) AS n FROM sfy_tokens WHERE game_id IS NOT NULL GROUP BY game_id")->fetchAll() as $r) {
    $tokenCounts[(string)$r['game_id']] = (int)$r['n'];
}
$doneCounts = [];
foreach ($db->query("SELECT game_id, COUNT(*) AS n FROM sfy_sessions WHERE is_completed=1 AND game_id IS NOT NULL GROUP BY game_id")->fetchAll() as $r) {
    $doneCounts[(string)$r['game_id']] = (int)$r['n'];
}
?>
<div class="card">
  <div class="card-head">
    <h2>&gt; REGISTERED_GAMES</h2>
    <span class="spacer"></span>
    <span class="badge gr"><?= count($games) ?> GAMES</span>
    <a class="btn btn-sm btn-gold" href="<?= sfy_esc(sfy_admin_url(['tab' => 'games', 'edit' => 'new'])) ?>">+ ADD GAME</a>
  </div>

  <?php if (!$games): ?>
    <div class="empty">&gt; no games registered yet. Add the PlaceId and the raw script URL.</div>
  <?php else: ?>
    <div class="tbl-wrap">
      <table class="tbl">
        <thead><tr><th>Game ID</th><th>Name</th><th>Script URL</th><th>Version</th><th>Tokens</th>
                   <th>Unlocks</th><th>Max runs</th><th>State</th><th>Actions</th></tr></thead>
        <tbody>
        <?php foreach ($games as $g): $gid = (string)$g['game_id']; ?>
          <tr>
            <td class="mono"><?= sfy_esc($gid) ?></td>
            <td><?= sfy_esc((string)$g['game_name']) ?></td>
            <td class="mono tiny"><?= sfy_esc(sfy_short((string)$g['script_url'], 40)) ?></td>
            <td class="mono">v<?= (int)$g['script_version'] ?></td>
            <td class="mono"><?= $tokenCounts[$gid] ?? 0 ?></td>
            <td class="mono"><?= $doneCounts[$gid] ?? 0 ?></td>
            <td class="mono"><?= (int)($g['max_runs'] ?? 50) ?></td>
            <td><?= (int)$g['is_active'] ? sfy_badge('ACTIVE', 'g') : sfy_badge('OFF', 'r') ?></td>
            <td><div class="actions">
              <a class="btn btn-sm" href="<?= sfy_esc(sfy_admin_url(['tab' => 'games', 'edit' => $gid])) ?>">EDIT</a>
              <?php sfy_admin_post_button('TOGGLE', ['action' => 'toggle_game', 'game_id' => $gid]) ?>
            </div></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<div class="card">
  <div class="card-head"><h2>&gt; SCRIPT_DELIVERY</h2></div>
  <div class="term" style="max-height:none;font-size:11.5px">
&gt; the Roblox menu asks <?= sfy_esc(SFY_DOMAIN) ?>/g/get_script?game_id=PLACEID
&gt; point each game at a raw URL (gist.githubusercontent.com/.../raw/...)
&gt; bumping the version invalidates client caches automatically
  </div>
</div>

<?php if ($eg !== null): ?>
<div class="modal-bg show">
  <div class="modal" style="width:700px">
    <div class="modal-head">
      <h3><?= $eg['game_id'] ? '&gt; EDIT_GAME' : '&gt; ADD_GAME' ?></h3>
      <span class="spacer" style="margin-left:auto"></span>
      <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_admin_url(['tab' => 'games'])) ?>">✕</a>
    </div>
    <div class="modal-body">
      <form method="POST">
        <?= sfy_csrf_field() ?>
        <input type="hidden" name="action" value="save_game">
        <div class="grid grid-2">
          <div class="field"><label class="label">Game ID (PlaceId)</label>
            <input type="text" name="game_id" value="<?= sfy_esc((string)$eg['game_id']) ?>" <?= $eg['game_id'] ? 'readonly' : '' ?> required></div>
          <div class="field"><label class="label">Game name</label>
            <input type="text" name="game_name" value="<?= sfy_esc((string)$eg['game_name']) ?>"></div>
        </div>
        <div class="field"><label class="label">Script URL (raw)</label>
          <input type="text" name="script_url" value="<?= sfy_esc((string)$eg['script_url']) ?>"
                 placeholder="https://gist.githubusercontent.com/.../raw/script.lua" required></div>
        <div class="grid grid-2">
          <div class="field"><label class="label">Max runs</label>
            <input type="number" name="max_runs" value="<?= (int)($eg['max_runs'] ?: 50) ?>" min="1"></div>
          <div class="field" style="display:flex;align-items:flex-end">
            <label class="check"><input type="checkbox" name="is_active" <?= (int)$eg['is_active'] ? 'checked' : '' ?>> Active</label>
          </div>
        </div>
        <div class="field"><label class="label">Notes</label>
          <input type="text" name="notes" value="<?= sfy_esc((string)($eg['notes'] ?? '')) ?>"></div>
        <div class="modal-actions">
          <a class="btn btn-ghost" href="<?= sfy_esc(sfy_admin_url(['tab' => 'games'])) ?>">CANCEL</a>
          <button class="btn btn-primary">SAVE GAME</button>
        </div>
      </form>
      <?php if ($eg['game_id']): ?>
        <hr class="sep">
        <?php sfy_admin_form_start(['action' => 'delete_game', 'game_id' => (string)$eg['game_id']], 'Delete this game?'); ?>
        <button class="btn btn-danger">DELETE GAME</button></form>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php endif; ?>
