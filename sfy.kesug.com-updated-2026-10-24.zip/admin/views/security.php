<?php
/** @var PDO $db */
$attempts = sfy_login_attempts_recent(80);
$audit    = sfy_audit_recent(80);

$fail24   = (int)$db->query("SELECT COUNT(*) AS n FROM sfy_login_attempts WHERE success=0 AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)")->fetch()['n'];
$ok24     = (int)$db->query("SELECT COUNT(*) AS n FROM sfy_login_attempts WHERE success=1 AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)")->fetch()['n'];
$ipFail   = (int)$db->query("SELECT COUNT(DISTINCT ip) AS n FROM sfy_login_attempts WHERE success=0 AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)")->fetch()['n'];
$pbBad24  = (int)$db->query("SELECT COUNT(*) AS n FROM sfy_postback_log WHERE accepted=0 AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)")->fetch()['n'];
$flag24   = (int)$db->query("SELECT COUNT(*) AS n FROM sfy_sessions WHERE bypass_flags > 0 AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)")->fetch()['n'];
$blockedDevices = (int)$db->query("SELECT COUNT(*) AS n FROM sfy_devices WHERE is_blocked=1")->fetch()['n'];

$blocks = $db->query("SELECT username, COUNT(*) AS n, MAX(created_at) AS last_try, COUNT(DISTINCT ip) AS ips
                      FROM sfy_login_attempts WHERE success=0
                      GROUP BY username ORDER BY n DESC LIMIT 20")->fetchAll();

$staffLocked = $db->query("SELECT username, failed_attempts, last_failed_at, role FROM sfy_staff
                           WHERE failed_attempts > 0 ORDER BY failed_attempts DESC")->fetchAll();

/*
 * Human check (Cloudflare Turnstile) — the same accessors the gate uses, so
 * this panel can never claim the check is armed while it is not (or the other
 * way round). "Armed" means: switched on AND both keys present AND this host
 * able to reach Cloudflare — the three things a challenge actually needs.
 */
$capOn     = sfy_captcha_enabled();
$capReady  = sfy_captcha_ready();
$capWhere  = array_values(array_filter(sfy_captcha_contexts(), static fn(string $c): bool => sfy_captcha_at($c)));
$capProbs  = sfy_captcha_problems();
$capStats  = sfy_captcha_stats(24);
$capRuns   = sfy_captcha_gated_runs(24);
$capLog    = sfy_captcha_recent(40);
$capWhereTxt = $capWhere
    ? implode(' and ', array_map('sfy_captcha_context_label', $capWhere))
    : 'nowhere — no context is switched on';

$checks = [
    ['Postback signature required', !sfy_cfg('security.allow_unsigned_postback', false), 'security.allow_unsigned_postback = false'],
    ['Steps only advance on verified postback', (bool)sfy_return_check_state()['require_postback'], 'Settings → Flow & anti-bypass → Require a verified postback'],
    ['A return must come from the task provider', (bool)sfy_return_check_state()['require_provider'],
     'return_require_provider = true (a typed landing URL confirms nothing)'],
    ['Postbacks cannot be callable from a browser', !(bool)sfy_cfg('security.allow_browser_postback', false),
     'security.allow_browser_postback = false'],
    ['Device/browser locking', (bool)sfy_cfg('security.enforce_fingerprint', true), 'security.enforce_fingerprint = true'],
    ['Minimum task dwell time', sfy_setting_int('min_task_seconds', 4) > 0, 'min_task_seconds > 0'],
    ['Code view window limited', sfy_setting_int('code_view_ttl_minutes', 30) > 0, 'code_view_ttl_minutes > 0'],
    ['Code view cap enabled', sfy_setting_int('max_code_views', 4) > 0, 'max_code_views > 0'],
    ['Login lockout configured', (int)sfy_cfg('security.max_login_attempts', 5) > 0, 'max_login_attempts > 0'],
    ['Admin bound to browser', (bool)sfy_cfg('security.bind_admin_to_browser', true), 'bind_admin_to_browser = true'],
    ['Debug mode off', !SFY_DEBUG, 'app.debug = false'],
    ['Human check (bot gate) armed', $capReady,
     $capReady ? 'on: ' . $capWhereTxt
               : ($capOn ? 'on but NOT usable — ' . ($capProbs ? implode('; ', $capProbs) : 'see BOT CHECKS below')
                         : 'off — optional, set it up in Settings → BOT CHECK')],
];
?>
<div class="grid grid-4 mb-2">
  <?= sfy_kpi('Failed logins (24h)', number_format($fail24), 'red', $ipFail . ' distinct IPs') ?>
  <?= sfy_kpi('Successful logins (24h)', number_format($ok24), '') ?>
  <?= sfy_kpi('Rejected postbacks (24h)', number_format($pbBad24), 'orange') ?>
  <?= sfy_kpi('Flagged sessions (24h)', number_format($flag24), 'purple', $blockedDevices . ' devices blocked') ?>
</div>

<div class="card mb-2">
  <div class="card-head"><h2>&gt; SECURITY_POSTURE</h2></div>
  <div class="grid grid-2">
    <?php foreach ($checks as [$label, $ok, $hint]): ?>
      <div class="flex items-center gap" style="padding:6px 0;border-bottom:1px solid var(--line)">
        <span><?= $ok ? sfy_badge('OK', 'g') : sfy_badge('REVIEW', 'y') ?></span>
        <span class="small"><?= sfy_esc($label) ?></span>
        <span class="spacer grow"></span>
        <span class="tiny mute mono"><?= sfy_esc($hint) ?></span>
      </div>
    <?php endforeach; ?>
  </div>
  <div class="hint">Toggles live in <a href="<?= sfy_esc(sfy_admin_url(['tab' => 'settings'])) ?>">Settings</a>;
    the protocol-level ones (signature, dwell time, redirect API) live in <code>config/config.php</code>.</div>
</div>

<div class="grid grid-2 mb-2">
  <div class="card">
    <div class="card-head"><h2>&gt; BLOCKED_COUNTERS</h2></div>
    <p class="hint mt-0">Failed attempts since the last successful sign-in, per account.</p>
    <div class="tbl-wrap"><table class="tbl" style="min-width:0">
      <thead><tr><th>Username</th><th>Failed</th><th>IPs</th><th>Last try</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($blocks as $b): ?>
        <tr>
          <td class="mono"><?= sfy_esc((string)$b['username']) ?></td>
          <td><span class="badge <?= (int)$b['n'] >= (int)sfy_cfg('security.max_login_attempts', 5) ? 'r' : 'y' ?>"><?= (int)$b['n'] ?></span></td>
          <td class="mono"><?= (int)$b['ips'] ?></td>
          <td class="tiny dim"><?= sfy_esc(sfy_ago((string)$b['last_try'])) ?></td>
          <td><?php if (($s = sfy_staff_find((string)$b['username']))): ?>
            <?php sfy_admin_post_button('UNLOCK', ['action' => 'unlock_staff', 'id' => (int)$s['id']], 'btn btn-sm') ?>
          <?php else: ?><span class="mute tiny">n/a</span><?php endif; ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$blocks): ?><tr><td colspan="5" class="empty">no failed logins recorded</td></tr><?php endif; ?>
      </tbody>
    </table></div>
  </div>

  <div class="card">
    <div class="card-head"><h2>&gt; STAFF_LOCK_STATE</h2></div>
    <div class="tbl-wrap"><table class="tbl" style="min-width:0">
      <thead><tr><th>Username</th><th>Role</th><th>Failed</th><th>State</th><th></th></tr></thead>
      <tbody>
      <?php foreach (sfy_staff_all() as $s): $f = (int)$s['failed_attempts']; ?>
        <tr>
          <td class="mono"><?= sfy_esc((string)$s['username']) ?></td>
          <td class="tiny"><?= sfy_esc((string)$s['role']) ?></td>
          <td class="mono" style="color:<?= $f > 0 ? 'var(--red)' : 'inherit' ?>"><?= $f ?></td>
          <td><?= $f >= (int)sfy_cfg('security.max_login_attempts', 5) ? sfy_badge('LOCKED', 'r')
                : ((int)$s['is_active'] ? sfy_badge('ACTIVE', 'g') : sfy_badge('DISABLED', 'gr')) ?></td>
          <td><?php if ($f > 0) sfy_admin_post_button('RESET', ['action' => 'unlock_staff', 'id' => (int)$s['id']], 'btn btn-sm'); ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
  </div>
</div>

<div class="card mb-2">
  <div class="card-head">
    <h2>&gt; BOT_CHECKS</h2>
    <span class="spacer"></span>
    <?php if (!$capOn): ?><span class="badge gr">OFF</span>
    <?php elseif ($capReady): ?><span class="badge g">ARMED</span>
    <?php else: ?><span class="badge r">NOT USABLE</span><?php endif; ?>
    <?php sfy_admin_post_button('CLEAR LOG', ['action' => 'clear_captcha_log'], 'btn btn-sm btn-danger', 'Delete every human-check record?') ?>
  </div>

  <div class="grid grid-4 mb-2">
    <?= sfy_kpi('Challenges passed (24h)', number_format((int)$capStats['passed']), 'g', 'solved = a real run started') ?>
    <?= sfy_kpi('Challenges refused (24h)', number_format((int)$capStats['refused']), 'red',
                (int)$capStats['refused'] > 0 ? 'bad or missing token' : 'nothing turned away') ?>
    <?= sfy_kpi('Let through unchecked (24h)', number_format((int)$capStats['open']), 'y',
                (int)$capStats['open'] > 0 ? 'Cloudflare was unreachable' : 'always reachable') ?>
    <?= sfy_kpi('Gated runs (24h)', number_format($capRuns), 'blue', $capWhereTxt) ?>
  </div>

  <?php if (!$capOn): ?>
    <div class="msg warn">◆ The human check is <b>off</b>: the claim link can be opened by any script, which is what
      creates verification sessions for free. Turn it on in
      <a href="<?= sfy_esc(sfy_admin_url(['tab' => 'settings'])) ?>">Settings → BOT CHECK</a> — it needs a Cloudflare
      Turnstile site key and secret, and it only ever asks once per run.</div>
  <?php elseif ($capProbs): ?>
    <div class="msg err">✖ Switched on but <b>not enforced</b>: <?= sfy_esc(implode('; ', $capProbs)) ?>. Nobody is being
      blocked while this is true — the gate stands aside rather than locking players out of a page they cannot pass.
      Fix the keys or the host's outbound requests, then press TEST MY KEYS in
      <a href="<?= sfy_esc(sfy_admin_url(['tab' => 'settings'])) ?>">Settings</a>.</div>
  <?php elseif ((int)$capStats['open'] > 0): ?>
    <div class="msg warn">◆ <?= (int)$capStats['open'] ?> challenge(s) in the last 24h could not be checked because
      Cloudflare was unreachable, and the fail mode let those requests through. On <b>STAY OPEN</b> that is the safe
      direction; on <b>STRICT</b> they would have been refused instead (a staff sign-in is exempt either way — the check
      must not be able to lock you out of the panel that switches it off). See Settings → BOT CHECK.</div>
  <?php else: ?>
    <div class="msg info">◆ Armed for <?= sfy_esc($capWhereTxt) ?>. A pass is remembered per verification run, so the
      claim link, the pinned button and a reloaded tab never ask the same player twice.</div>
  <?php endif; ?>

  <div class="tbl-wrap"><table class="tbl">
    <thead><tr><th>When</th><th>Where</th><th>Verdict</th><th>Reason</th><th>Cloudflare codes</th><th>IP</th><th>Run</th></tr></thead>
    <tbody>
    <?php foreach ($capLog as $row): [$badge, $cls] = sfy_captcha_outcome_badge((string)$row['outcome']); ?>
      <tr>
        <td class="tiny dim"><?= sfy_esc(sfy_ago((string)$row['created_at'])) ?></td>
        <td class="tiny"><?= sfy_esc(sfy_short((string)$row['context'], 22)) ?></td>
        <td><?= sfy_badge($badge, $cls) ?></td>
        <td class="tiny"><?= sfy_esc((string)($row['reason'] ?: '—')) ?></td>
        <td class="tiny mute mono"><?= sfy_esc(sfy_short((string)($row['codes'] ?: '—'), 34)) ?></td>
        <td class="mono tiny"><?= sfy_esc((string)$row['ip']) ?></td>
        <td class="tiny mute mono"><?= sfy_esc(sfy_short((string)($row['session_id'] ?: '—'), 10)) ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$capLog): ?><tr><td colspan="7" class="empty">no challenge has been submitted yet</td></tr><?php endif; ?>
    </tbody>
  </table></div>
  <div class="hint">Only *decided* challenges are listed — a plain page view is never logged, so a row here means
    somebody submitted a challenge and Cloudflare answered. <b>REFUSED</b> shares are the interesting number while a
    bot run is going on; a steady stream of <b>BAD KEYS</b> or <b>UNREACHABLE</b> rows means the gate is standing aside
    and the site is unprotected, not that players are failing.</div>
</div>

<div class="card mb-2">
  <div class="card-head">
    <h2>&gt; LOGIN_ATTEMPTS</h2>
    <span class="spacer"></span>
    <?php sfy_admin_post_button('CLEAR LOG', ['action' => 'clear_login_attempts'], 'btn btn-sm btn-danger', 'Delete all login attempt records?') ?>
  </div>
  <div class="tbl-wrap"><table class="tbl">
    <thead><tr><th>When</th><th>Username</th><th>Result</th><th>Reason</th><th>IP</th><th>User agent</th></tr></thead>
    <tbody>
    <?php foreach ($attempts as $a): ?>
      <tr>
        <td class="tiny dim"><?= sfy_esc(sfy_ago((string)$a['created_at'])) ?></td>
        <td class="mono"><?= sfy_esc((string)$a['username']) ?></td>
        <td><?= (int)$a['success'] ? sfy_badge('SUCCESS', 'g') : sfy_badge('FAILED', 'r') ?></td>
        <td class="tiny"><?= sfy_esc((string)($a['reason'] ?: '—')) ?></td>
        <td class="mono tiny"><?= sfy_esc((string)$a['ip']) ?></td>
        <td class="tiny mute"><?= sfy_esc(sfy_short((string)$a['user_agent'], 46)) ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$attempts): ?><tr><td colspan="6" class="empty">no attempts recorded</td></tr><?php endif; ?>
    </tbody>
  </table></div>
</div>

<div class="card">
  <div class="card-head">
    <h2>&gt; AUDIT_TRAIL</h2>
    <span class="spacer"></span>
    <?php sfy_admin_post_button('CLEAR AUDIT', ['action' => 'clear_audit'], 'btn btn-sm btn-danger', 'Delete the entire audit trail?') ?>
  </div>
  <div class="tbl-wrap"><table class="tbl">
    <thead><tr><th>When</th><th>Staff</th><th>Action</th><th>Target</th><th>IP</th><th>Meta</th></tr></thead>
    <tbody>
    <?php foreach ($audit as $a): ?>
      <tr>
        <td class="tiny dim"><?= sfy_esc(sfy_ago((string)$a['created_at'])) ?></td>
        <td class="mono"><?= sfy_esc((string)$a['username']) ?></td>
        <td><span class="badge b"><?= sfy_esc((string)$a['action']) ?></span></td>
        <td class="tiny"><?= sfy_esc((string)($a['target'] ?: '—')) ?></td>
        <td class="mono tiny"><?= sfy_esc((string)$a['ip']) ?></td>
        <td class="tiny mute"><?= sfy_esc(sfy_short((string)($a['meta'] ?: ''), 60)) ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$audit): ?><tr><td colspan="6" class="empty">no audit entries yet</td></tr><?php endif; ?>
    </tbody>
  </table></div>
</div>
