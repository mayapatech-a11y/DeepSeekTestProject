<?php
/** @var PDO $db */
$funnel  = sfy_funnel_stats();
$dev     = sfy_device_stats();
$ads     = sfy_ads_stats();
$tkTotal = (int)$db->query("SELECT COUNT(*) AS n FROM sfy_tokens")->fetch()['n'];
$tkUsed  = (int)$db->query("SELECT COUNT(*) AS n FROM sfy_tokens WHERE is_used=1")->fetch()['n'];
$games   = (int)$db->query("SELECT COUNT(*) AS n FROM sfy_games")->fetch()['n'];
$accs    = (int)$db->query("SELECT COUNT(*) AS n FROM lootlabs_accounts")->fetch()['n'];
$accsOn  = (int)$db->query("SELECT COUNT(*) AS n FROM lootlabs_accounts WHERE is_active=1")->fetch()['n'];
$staffOn = (int)$db->query("SELECT COUNT(*) AS n FROM sfy_staff WHERE is_active=1")->fetch()['n'];
$blocked = (int)$db->query("SELECT COUNT(*) AS n FROM sfy_devices WHERE is_blocked=1")->fetch()['n'];
$schema  = sfy_schema_status();
$pending = count($schema['pending']);
$lastPb  = $db->query("SELECT * FROM sfy_postback_log ORDER BY id DESC LIMIT 6")->fetchAll();
?>
<div class="grid grid-4 mb-2">
  <?= sfy_kpi('Tokens', $tkTotal, '', $tkUsed . ' used') ?>
  <?= sfy_kpi('Devices', number_format($dev['total']), 'blue', $dev['today'] . ' active today') ?>
  <?= sfy_kpi('Codes unlocked', number_format($dev['success_total']), '', $dev['fail_total'] . ' failed attempts') ?>
  <?= sfy_kpi('Completion rate', $funnel['rate'] . '%', 'gold', $funnel['completed'] . '/' . $funnel['total'] . ' sessions') ?>
</div>

<div class="grid grid-2 mb-2">
  <div class="card">
    <div class="card-head"><h2>&gt; QUICK_ACTIONS</h2></div>
    <div class="btn-row">
      <a class="btn btn-gold" href="<?= sfy_esc(sfy_admin_url(['tab' => 'tokens', 'edit' => 'new'])) ?>">+ NEW TOKEN</a>
      <a class="btn" href="<?= sfy_esc(sfy_admin_url(['tab' => 'accounts', 'edit' => 'new'])) ?>">+ TASK ACCOUNT</a>
      <a class="btn" href="<?= sfy_esc(sfy_admin_url(['tab' => 'providers', 'edit' => 'new'])) ?>">+ TASK PROVIDER</a>
      <a class="btn" href="<?= sfy_esc(sfy_admin_url(['tab' => 'ads', 'edit' => 'new'])) ?>">+ AD</a>
      <a class="btn" href="<?= sfy_esc(sfy_admin_url(['tab' => 'devices'])) ?>">📱 DEVICES</a>
      <a class="btn" href="<?= sfy_esc(sfy_admin_url(['tab' => 'updater'])) ?>">
        ⬆ UPDATER<?= $pending ? ' (' . $pending . ')' : '' ?>
      </a>
    </div>
    <hr class="sep">
    <div class="term" style="max-height:none;font-size:11.5px">
&gt; anti-bypass ..... <?= sfy_return_check_state()['require_postback'] ? 'ENFORCED' : 'DISABLED' ?>

&gt; postback sig ... <?= sfy_cfg('security.allow_unsigned_postback', false) ? 'OPTIONAL (unsafe)' : 'REQUIRED' ?>

&gt; min dwell ...... <?= (int)sfy_setting_int('min_task_seconds', 4) ?>s
&gt; code window .... <?= (int)sfy_setting_int('code_view_ttl_minutes', 30) ?> min / <?= (int)sfy_setting_int('max_code_views', 4) ?> views
&gt; device lock .... <?= sfy_cfg('security.enforce_fingerprint', true) ? 'ON' : 'OFF' ?>
    </div>
  </div>

  <div class="card">
    <div class="card-head"><h2>&gt; SYSTEM_HEALTH</h2></div>
    <div class="tbl-wrap">
      <table class="tbl" style="min-width:0">
        <tbody>
          <tr><td class="dim">Database</td><td><?= sfy_badge('CONNECTED', 'g') ?></td></tr>
          <tr><td class="dim">Schema version</td><td class="mono"><?= sfy_esc($schema['current']) ?> / <?= sfy_esc($schema['latest']) ?>
            <?= $pending ? sfy_badge($pending . ' PENDING', 'y') : sfy_badge('UP TO DATE', 'g') ?></td></tr>
          <?php $provReady = function_exists('sfy_provider_offerable') ? count(sfy_provider_offerable()) : 0; ?>
          <tr><td class="dim">Task providers</td>
            <td><span class="mono"><?= $provReady ?></span> ready <?= sfy_badge($provReady > 1 ? 'PLAYER CHOOSES' : ($provReady === 1 ? 'AUTO' : 'NONE'), $provReady > 0 ? 'g' : 'r') ?></td></tr>
          <tr><td class="dim">Task accounts</td><td><?= $accsOn ?>/<?= $accs ?> <?= sfy_badge('ACTIVE', $accsOn ? 'g' : 'r') ?></td></tr>
          <tr><td class="dim">Registered games</td><td class="mono"><?= $games ?></td></tr>
          <tr><td class="dim">Active staff</td><td class="mono"><?= $staffOn ?></td></tr>
          <tr><td class="dim">Blocked devices</td><td class="mono"><?= $blocked ?></td></tr>
          <tr><td class="dim">Active ads</td><td class="mono"><?= $ads['active'] ?>/<?= $ads['total'] ?> · CTR <?= $ads['ctr'] ?>%</td></tr>
          <?php $ab = sfy_redirect_api_mode(); ?>
          <tr><td class="dim">Redirect API (anti-bypass)</td>
            <td><?= sfy_badge($ab === 'off' ? 'OFF' : strtoupper($ab), $ab === 'off' ? 'gr' : ($ab === 'on' ? 'g' : 'b')) ?>
              <span class="tiny mute"><?= sfy_esc(strtoupper(sfy_encrypt_method())) ?> · landing page <?= sfy_esc(sfy_short(sfy_redirect_destination(), 40)) ?></span></td></tr>
        </tbody>
      </table>
    </div>
  </div>
</div>

<div class="grid grid-2 mb-2">
  <div class="card">
    <div class="card-head"><h2>&gt; SESSION_FUNNEL</h2></div>
    <div class="tbl-wrap">
      <table class="tbl" style="min-width:0">
        <thead><tr><th>Stage</th><th>Count</th><th>Share</th></tr></thead>
        <tbody>
          <?php
          $rows = [
              ['Sessions opened', $funnel['total'], ''],
              ['Still in progress', $funnel['open'], 'blue'],
              ['Verified &amp; completed', $funnel['completed'], 'g'],
              ['Expired before finishing', $funnel['expired'], 'gr'],
              ['Flagged for bypass', $funnel['flagged'], 'r'],
          ];
          $max = max(1, $funnel['total']);
          foreach ($rows as [$label, $val, $tone]): ?>
            <tr>
              <td><?= $label ?></td>
              <td class="mono"><?= (int)$val ?></td>
              <td><?= sfy_mini_bar((int)$val, $max, $tone === 'g' ? '' : $tone) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="hint">Postbacks: <?= (int)$funnel['postbacks'] ?> verified / <?= (int)$funnel['postbacks_bad'] ?> rejected.</div>
  </div>

  <div class="card">
    <div class="card-head"><h2>&gt; RECENT_POSTBACKS</h2><span class="spacer"></span>
      <a class="btn btn-sm" href="<?= sfy_esc(sfy_admin_url(['tab' => 'security'])) ?>">VIEW LOG</a></div>
    <?php if (!$lastPb): ?>
      <div class="empty">No postbacks recorded yet.</div>
    <?php else: ?>
      <div class="tbl-wrap">
        <table class="tbl">
          <thead><tr><th>When</th><th>Step</th><th>Result</th><th>Reason</th><th>IP</th></tr></thead>
          <tbody>
          <?php foreach ($lastPb as $p): ?>
            <tr>
              <td class="tiny dim"><?= sfy_esc(sfy_ago((string)$p['created_at'])) ?></td>
              <td class="mono">#<?= (int)$p['step'] ?></td>
              <td><?= (int)$p['accepted'] ? sfy_badge('ACCEPTED', 'g') : sfy_badge('REJECTED', 'r') ?></td>
              <td class="tiny"><?= sfy_esc((string)($p['reason'] ?: '—')) ?></td>
              <td class="mono tiny"><?= sfy_esc((string)($p['ip'] ?? '—')) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<div class="card">
  <div class="card-head"><h2>&gt; TOP_DEVICES_BY_UNLOCKS</h2><span class="spacer"></span>
    <a class="btn btn-sm" href="<?= sfy_esc(sfy_admin_url(['tab' => 'devices'])) ?>">ALL DEVICES</a></div>
  <?php $top = sfy_device_leaderboard(8); ?>
  <?php if (!$top): ?>
    <div class="empty">No successful devices recorded yet.</div>
  <?php else: ?>
    <div class="tbl-wrap">
      <table class="tbl">
        <thead><tr><th>Device</th><th>OS / Browser</th><th>Location</th><th>Unlocks</th><th>Sessions</th><th>Last seen</th></tr></thead>
        <tbody>
        <?php foreach ($top as $d): ?>
          <tr>
            <td class="mono"><?= sfy_esc(sfy_short((string)$d['device_name'], 22)) ?></td>
            <td class="tiny"><?= sfy_esc((string)$d['os']) ?> · <?= sfy_esc((string)$d['browser']) ?></td>
            <td class="tiny"><?= sfy_esc((string)($d['country'] ?: '—')) ?></td>
            <td><span class="badge g"><?= (int)$d['success_count'] ?></span></td>
            <td class="mono"><?= (int)$d['session_count'] ?></td>
            <td class="tiny dim"><?= sfy_esc(sfy_ago((string)$d['last_seen'])) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>
