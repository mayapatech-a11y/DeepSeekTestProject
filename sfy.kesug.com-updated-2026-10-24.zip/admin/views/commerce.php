<?php
/** @var PDO $db */
$section = (string)sfy_param('section', 'plans');
if (!in_array($section, ['plans', 'ads', 'orders'], true)) $section = 'plans';
$pending = 0;
if (sfy_table_exists('sfy_hub_orders')) {
    $pending = (int)sfy_try(fn() => sfy_db()->query("SELECT COUNT(*) AS n FROM sfy_hub_orders WHERE status='pending'")->fetch()['n'], 0);
}
$base = ['tab' => 'commerce'];
?>
<div class="inline mb-2">
  <a class="btn btn-sm <?= $section === 'plans' ? 'btn-primary' : 'btn-ghost' ?>" href="<?= sfy_esc(sfy_admin_url($base + ['section' => 'plans'])) ?>">PLANS</a>
  <a class="btn btn-sm <?= $section === 'ads' ? 'btn-primary' : 'btn-ghost' ?>" href="<?= sfy_esc(sfy_admin_url($base + ['section' => 'ads'])) ?>">ADS</a>
  <a class="btn btn-sm <?= $section === 'orders' ? 'btn-primary' : 'btn-ghost' ?>" href="<?= sfy_esc(sfy_admin_url($base + ['section' => 'orders'])) ?>">ORDERS<?= $pending > 0 ? ' <span class="badge r">' . (int)$pending . '</span>' : '' ?></a>
</div>
<?php
if ($section === 'orders') {
    include __DIR__ . '/orders.php';
} elseif ($section === 'ads') {
    include __DIR__ . '/ads.php';
} else {
    include __DIR__ . '/plans.php';
}
?>