<?php
/** @var PDO $db */
$schema  = sfy_schema_status();
$pending = count($schema['pending']);
?>
<div class="card">
  <div class="card-head">
    <h2>&gt; SQL_CONSOLE</h2>
    <span class="spacer"></span>
    <span class="badge <?= $pending ? 'y' : 'g' ?>">SCHEMA <?= sfy_esc($schema['current']) ?><?= $pending ? ' · ' . $pending . ' PENDING' : '' ?></span>
  </div>

  <div class="grid grid-2">
    <div>
      <p class="small dim">
        Paste an exported SQL package (for example the TiDB token export) and run it in one go.
        Handy for installing a new release's <code>INSERT</code>/<code>UPDATE</code> payload.
      </p>
      <p class="small dim">
        <strong>Prefer the Updater tab</strong> for schema changes — it runs the maintained, idempotent
        migrations instead of raw SQL. This console is for data.
      </p>
      <div class="term" style="max-height:none;font-size:11.5px">
&gt; statement separator ... ";" on its own line or end of statement
&gt; blocked ............... DROP, TRUNCATE, GRANT, INTO OUTFILE, CREATE/DROP USER
&gt; every run is .......... recorded in the audit log
      </div>
    </div>
    <div>
      <form method="POST">
        <?= sfy_csrf_field() ?>
        <input type="hidden" name="action" value="import_sql">
        <label class="label">SQL to execute</label>
        <textarea name="sql" placeholder="-- paste exported SQL here&#10;INSERT INTO `sfy_tokens` (`token`,`code`,`tasks_required`) VALUES ('SFY-ABC','CODE1',2);" required></textarea>
        <div class="btn-row mt-2">
          <button class="btn btn-gold">▶ EXECUTE</button>
          <a class="btn btn-ghost" href="<?= sfy_esc(sfy_admin_url(['tab' => 'updater'])) ?>">OPEN UPDATER</a>
        </div>
      </form>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-head"><h2>&gt; CURRENT_TABLES</h2></div>
  <div class="tbl-wrap"><table class="tbl">
    <thead><tr><th>Table</th><th>Rows (est.)</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach ($schema['tables'] as $name => $rows): ?>
      <tr>
        <td class="mono"><?= sfy_esc((string)$name) ?></td>
        <td class="mono"><?= number_format((int)$rows) ?></td>
        <td class="tiny mute">
          <a href="<?= sfy_esc(sfy_admin_url(['tab' => 'sessions'])) ?>">sessions</a> ·
          <a href="<?= sfy_esc(sfy_admin_url(['tab' => 'devices'])) ?>">devices</a> ·
          <a href="<?= sfy_esc(sfy_admin_url(['tab' => 'tokens'])) ?>">tokens</a>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
</div>
