<?php
/**
 * Admin → Accounts: the task links a step is handed off to.
 *
 * Every account belongs to ONE task provider (Admin → Task providers) and its
 * provider's accounts rotate between steps — that is the same weighted
 * rotation LootLabs has always used, now applied per provider so two Work.ink
 * accounts take turns on Work.ink steps and never borrow a LootLabs link.
 *
 * @var PDO $db
 */
$allAccounts = $db->query("SELECT * FROM lootlabs_accounts ORDER BY id")->fetchAll();
$edit     = sfy_param('edit');

/* A provider filter (?provider=<id>) narrows the list; "none" shows the
   accounts that still need one and are therefore never used. */
$filterRaw = trim(sfy_param('provider'));
$filter    = $filterRaw === '' ? 0 : ($filterRaw === 'none' ? -1 : (int)$filterRaw);
$accounts  = $accountsAll = $allAccounts;
if ($filter !== 0) {
    $accounts = array_values(array_filter($allAccounts, function ($a) use ($filter) {
        $pid = (int)($a['provider_id'] ?? 0);
        return $filter === -1 ? $pid <= 0 : $pid === $filter;
    }));
}

$ea = null;
if ($edit === 'new') {
    $ea = ['id' => 0, 'name' => 'LootLabs', 'provider_id' => max(0, (int)sfy_param('provider')), 'api_key' => '',
           'postback_secret' => '', 'task_url' => '',
           'postback_url' => '', 'postback_format' => '', 'is_active' => 1, 'weight' => 1, 'daily_cap' => 0,
           'timeout_seconds' => 8, 'notes' => ''];
} elseif ($edit !== '') {
    foreach ($allAccounts as $a) if ((int)$a['id'] === (int)$edit) { $ea = $a; break; }
}

/* Providers are only read for their labels, so a missing table (an install
   whose updater has not run yet) simply renders the legacy panel. */
$providers   = function_exists('sfy_providers_all') ? sfy_providers_all() : [];
$provCounts  = function_exists('sfy_provider_account_counts') ? sfy_provider_account_counts() : [];
$hasProviderCol = function_exists('sfy_column_exists')
    ? (bool)sfy_try(fn() => sfy_column_exists('lootlabs_accounts', 'provider_id'), false) : false;

/*
 * A new link inherits the name of the network it is being added to. The row
 * button in Admin → Task providers opens this editor with `?provider=<id>`, and
 * a Work.ink row must not open a form pre-filled "LootLabs" — the owner would
 * have to notice and correct it before saving.
 */
if ($ea !== null && (int)$ea['id'] === 0 && (int)($ea['provider_id'] ?? 0) > 0) {
    foreach ($providers as $p) {
        if ((int)$p['id'] === (int)$ea['provider_id']) { $ea['name'] = (string)$p['name']; break; }
    }
}
$providerName = function (array $a) use ($providers): string {
    $pid = (int)($a['provider_id'] ?? 0);
    foreach ($providers as $p) if ((int)$p['id'] === $pid) return (string)$p['name'];
    return $pid > 0 ? 'provider #' . $pid : 'unassigned';
};

$activeCount = count(array_filter($accountsAll, fn($a) => (int)$a['is_active'] === 1));
$defaultChain = (string)sfy_setting('default_account_chain', '1,2');
?>
<?php
$abMode    = sfy_redirect_api_mode();
$abMethod  = strtoupper(sfy_encrypt_method());
$abKeys    = count(array_filter($accounts, fn($a) => trim((string)($a['api_key'] ?? '')) !== ''));
$abOk      = count(array_filter($accounts, fn($a) => str_starts_with(sfy_redirect_api_last_test($a)['status'], 'ok')));
$abMissing = sfy_redirect_api_requirements();
?>
<div class="grid grid-3 mb-2">
  <?= sfy_kpi('Accounts', count($accountsAll), '', $activeCount . ' active') ?>
  <?php
  $provActive = count(array_filter($providers, fn($p) => (int)$p['is_active'] === 1));
  $provReady  = function_exists('sfy_provider_offerable') ? count(sfy_provider_offerable()) : 0;
  ?>
  <?= sfy_kpi('Providers', count($providers), 'blue', $provActive . ' active · ' . $provReady . ' ready') ?>
  <?= sfy_kpi('Anti-bypass handoff', strtoupper($abMode),
              $abMode === 'off' ? 'orange' : '',
              $abMode === 'off' ? 'plain links only' : ($abMethod . ' · ' . $abKeys . ' key(s), ' . $abOk . ' tested OK')) ?>
</div>

<?php
/*
 * POSTBACK DOCTOR
 * "The task never registers" has exactly two causes and they look identical
 * from the player's side: the provider never called us, or it called us and
 * we rejected the call. This panel tells them apart.
 */
$pbHealth = sfy_postback_health(8);
$rcState  = sfy_return_check_state();
/* Use this install's real account id in the sample — a copied sample with a
   hard-coded acct= is exactly how dashboards end up pointing at a dead id. */
$pbFirstAcc = null;
foreach ($accounts as $a) if ((int)$a['is_active'] === 1) { $pbFirstAcc = $a; break; }
$pbFirst = $pbFirstAcc ? (int)$pbFirstAcc['id'] : 0;
$pbFirstProvider = ($pbFirstAcc && (int)($pbFirstAcc['provider_id'] ?? 0) > 0 && function_exists('sfy_provider_find'))
                 ? sfy_provider_find((int)$pbFirstAcc['provider_id']) : null;
/* Render the ACTIVE account's real postback URL, not a hard-coded
   /api/hook.php sample. A relay or any other custom postback URL must show up
   here, or the owner copies the direct site URL and LootLabs never reaches the
   relay. The per-account row below uses the same builder. */
$pbSample = $pbFirstAcc
    ? sfy_postback_url($pbFirstAcc, ['unique_id' => '{UNIQUE_ID}', 'nonce' => '{SUB_ID}', 'sig' => '{SIG}'], $pbFirstProvider)
    : sfy_url('api/hook.php') . '?click_id={CLICK_ID}&ip={IP}&unique_id={UNIQUE_ID}';
$pbIsCustom = $pbFirstAcc && trim((string)($pbFirstAcc['postback_url'] ?? '')) !== '';
$pbBadge  = $pbHealth['total'] === 0 ? ['NEVER RECEIVED', 'r']
          : ($pbHealth['accepted'] > 0 ? ['RECEIVING', 'g'] : ['REJECTING', 'y']);
?>
<div class="card mb-2">
  <div class="card-head">
    <h2>&gt; POSTBACK_DOCTOR</h2>
    <span class="spacer"></span>
    <?= sfy_badge($pbBadge[0], $pbBadge[1]) ?>
  </div>

  <div class="grid grid-4">
    <?= sfy_kpi('Received',   number_format($pbHealth['total']), '', 'all postback calls ever') ?>
    <?= sfy_kpi('Accepted',   number_format($pbHealth['accepted']), 'g', 'advanced a step') ?>
    <?= sfy_kpi('Rejected',   number_format($pbHealth['rejected']), $pbHealth['rejected'] > 0 ? 'red' : '', $pbHealth['rejected'] > 0 ? 'see the reasons below' : 'nothing refused') ?>
    <?= sfy_kpi('Last verified', $pbHealth['last_ok'] ? sfy_ago((string)$pbHealth['last_ok']) : 'never', 'gold', 'a real, non-fallback postback') ?>
  </div>

  <?php if ($pbHealth['total'] === 0): ?>
    <div class="msg err mt-2">
      ✖ <b>No postback has ever reached this install.</b> That is why tasks sit on CHECKING_YOUR_TASK.
      Work through this in order:
      <div class="hint" style="margin-top:6px">
        1. Try the reachability probe from your phone/another network:
        <a href="<?= sfy_esc(sfy_url('api/hook.php?ping=1')) ?>" target="_blank" rel="noopener"><?= sfy_esc(sfy_url('api/hook.php?ping=1')) ?></a>
        — it must show <code>{"status":"alive"}</code>, not the host's error or verify page.<br>
        2. In the LootLabs panel open <b>Advanced → Postback</b>, switch it on, and set the URL in the box below — one
        account at a time, and the <code>acct=</code> value must match the account id of the account you are editing.<br>
        3. Leave the macros alone. LootLabs replaces exactly <code>{CLICK_ID}</code>, <code>{IP}</code> and
        <code>{UNIQUE_ID}</code>; anything else arrives as literal text. <code>{CLICK_ID}</code> is what names the step —
        it is the <code>&amp;puid</code> this install puts on the task link.<br>
        4. Test one task yourself, then reload this page.
      </div>
    </div>
  <?php elseif ($pbHealth['accepted'] === 0): ?>
    <div class="msg warn mt-2">
      ◆ Postbacks <b>are</b> arriving but none was accepted — the parameters are the problem, not the network.
      Read the <code>reason</code> column below: <code>no_open_step</code> means the call carried neither our
      <code>unique_id</code> nor <code>sub_id</code>; <code>too_fast</code> means it fired before the dwell minimum;
      <code>account_mismatch</code> means the <code>acct=</code> value belongs to a different account.
    </div>
  <?php else: ?>
    <div class="msg info mt-2">◆ <?= (int)$pbHealth['accepted'] ?> postback(s) accepted;
      <?= (int)$pbHealth['soft'] ?> step(s) were confirmed by the return check instead.</div>
  <?php endif; ?>

  <?php if ($rcState['active']): ?>
    <div class="msg <?= $rcState['mode'] === 'on' ? 'warn' : 'info' ?> mt-2">
      ◆ <b>Return check is active (<?= sfy_esc(strtoupper($rcState['mode'])) ?>).</b>
      <?php if ($rcState['mode'] === 'auto'): ?>
      A step is confirmed when the player clicks into the task and comes back at least
      <b><?= (int)$rcState['dwell'] ?>s</b> later — it switches back to postback-only automatically as soon as one real
      postback is received (none in the last <?= (int)$rcState['stale_h'] ?>h).
      <?php else: ?>
      Every step may be confirmed by the player's verified return after <b><?= (int)$rcState['dwell'] ?>s</b>,
      whether or not postbacks work.
      <?php endif; ?>
      <?php if ($rcState['require_provider']): ?>
      A return only counts when the browser says the <b>provider</b> sent the player back (a cross-site navigation
      from your provider hosts), so typing or reopening the landing URL confirms nothing. Refused landings are logged
      as <code>return_rejected</code> with the host that was refused.
      <?php else: ?>
      <b>Provider check is OFF</b> — any visit to the landing page can confirm a step.
      <?php endif; ?>
      Change this in <a href="<?= sfy_esc(sfy_admin_url(['tab' => 'settings'])) ?>">Settings → Flow &amp; anti-bypass</a>.
    </div>
  <?php elseif ($rcState['mode'] === 'off'): ?>
    <div class="msg info mt-2">◆ Return check is <b>OFF</b> (strict postback-only). A step can never advance without a
      verified postback — only choose this once the doctor above reads RECEIVING.</div>
  <?php endif; ?>

  <div class="label mt-2">Postback URL to paste into LootLabs (panel → Advanced → Postback)<?= $pbFirst > 0 ? ' — active account #' . $pbFirst : '' ?></div>
  <div class="inline">
    <input class="grow mono" value="<?= sfy_esc($pbSample) ?>" readonly onclick="this.select()">
    <a class="btn btn-sm" href="<?= sfy_esc(sfy_url('api/hook.php?ping=1')) ?>" target="_blank" rel="noopener">TEST RECEIVER</a>
  </div>
  <?php if ($pbIsCustom): ?>
  <div class="msg warn mt-2">◆ This account has a <b>custom postback URL</b> (relay). The URL above is that custom
    URL with <code>&amp;key=…</code> appended — copy it, not the direct <code>/api/hook.php</code> sample.
    TEST RECEIVER below still checks the site's direct receiver; use <code>relay/smoke-test.ps1</code> for the relay.</div>
  <?php endif; ?>
  <div class="hint"><b>The URL now ends with <code>&amp;key=…</code>.</b> That key is the postback's own password:
    it never reaches a player's browser, and a call without it is refused as <code>bad_postback_key</code>. Paste the
    <b>whole</b> URL (key included) into the dashboard, and re-paste it whenever <code>app_key</code> changes. Keep the
    query names exactly as they are and let LootLabs fill the three macros it knows
    (<code>{CLICK_ID}</code>, <code>{IP}</code>, <code>{UNIQUE_ID}</code>). A placeholder LootLabs does not recognise is not
    removed — it arrives as the literal text and is logged as a junk parameter, so do not add a sub-id or signature macro.
    Alternate entry point if <code>/api</code> is filtered on your host: <code><?= sfy_esc(sfy_url('postback')) ?></code>.<br>
    <b>One dashboard, one postback URL.</b> LootLabs keeps a single postback per account, so with several accounts rotating a
    step most postbacks necessarily carry an <code>acct=</code> that does not match the account that served it — that is
    tolerated (logged as <code>session+acct</code>), and only matters when the nonce and session id are both missing.</div>

  <?php if ($pbHealth['recent']): ?>
    <div class="tbl-wrap mt-2">
      <table class="tbl">
        <thead><tr><th>When</th><th>Step</th><th>How matched</th><th>Result</th><th>Reason</th><th>Query</th></tr></thead>
        <tbody>
        <?php foreach ($pbHealth['recent'] as $r): ?>
          <tr>
            <td class="tiny dim"><?= sfy_esc(sfy_ago((string)($r['created_at'] ?? ''))) ?></td>
            <td class="mono"><?= (int)($r['step'] ?? 0) ?: '—' ?></td>
            <td class="mono tiny"><?= sfy_esc((string)($r['attribution'] ?? '') !== '' ? (string)$r['attribution'] : '—') ?></td>
            <td><?= (int)($r['accepted'] ?? 0) === 1
                    ? sfy_badge((int)($r['verified'] ?? 0) === 1 ? 'VERIFIED' : 'ACCEPTED', 'g')
                    : sfy_badge('REJECTED', 'r') ?></td>
            <td class="mono tiny"><?= sfy_esc((string)($r['reason'] ?? '')) ?></td>
            <td class="mono tiny"><?= sfy_esc(sfy_short((string)($r['raw_query'] ?? ''), 60)) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php
/**
 * REDIRECT API — ANTI-BYPASS HANDOFF
 *
 * The handoff we send the player into is one of their own LootLabs links plus
 * `&data=<encrypted return url>`. `data` is AES-256 encrypted with the account's
 * API key by LootLabs' encryptor, so only this server can decide where a
 * finished task lands — a copied link cannot be re-pointed somewhere else.
 */
$abSample = sfy_redirect_destination();
?>
<div class="card mb-2">
  <div class="card-head">
    <h2>&gt; REDIRECT_API_ANTI_BYPASS</h2>
    <span class="spacer"></span>
    <?= sfy_badge(strtoupper($abMode), $abMode === 'off' ? 'gr' : ($abMode === 'on' ? 'g' : 'b')) ?>
    <span class="badge gr"><?= sfy_esc($abMethod) ?></span>
  </div>

  <?php if ($abMissing): ?>
    <div class="msg err mt-2">
      ✖ <b>This upload is newer than the database.</b> Missing: <code><?= sfy_esc(implode(', ', $abMissing)) ?></code>.
      Until the updater finishes, per-account anti-bypass settings and test results cannot be stored on the account
      (the panel falls back to a config copy so the test result is still shown).
      <div class="btn-row" style="margin-top:8px">
        <a class="btn btn-sm btn-gold" href="<?= sfy_esc(sfy_admin_url(['tab' => 'updater'])) ?>">OPEN UPDATER</a>
      </div>
    </div>
  <?php endif; ?>

  <div class="grid grid-4">
    <?= sfy_kpi('Enabled accounts', $abKeys, '', 'have an API key') ?>
    <?= sfy_kpi('Tested OK', $abOk, $abOk > 0 ? 'g' : 'red', 'last anti-bypass test') ?>
    <?= sfy_kpi('Cache', sfy_redirect_cache_hours() > 0 ? sfy_redirect_cache_hours() . 'h' : 'off', 'blue',
                sfy_redirect_cache_hours() > 0 ? 'one API call serves all' : 'an API call per handoff') ?>
    <?= sfy_kpi('Landing page', sfy_short(preg_replace('#^https?://#', '', $abSample), 26), 'gold', 'the encrypted destination') ?>
  </div>

  <form method="POST" class="mt-2">
    <?= sfy_csrf_field() ?>
    <input type="hidden" name="action" value="save_config">
    <div class="grid grid-4">
      <div class="field"><label class="label">Mode</label>
        <select name="redirect_api">
          <option value="auto" <?= $abMode === 'auto' ? 'selected' : '' ?>>AUTO — use it when it answers (recommended)</option>
          <option value="on"   <?= $abMode === 'on'   ? 'selected' : '' ?>>ON — require it, block the step if it fails</option>
          <option value="off"  <?= $abMode === 'off'  ? 'selected' : '' ?>>OFF — plain links</option>
        </select></div>
      <div class="field"><label class="label">Request method</label>
        <select name="encrypt_method">
          <option value="post" <?= sfy_encrypt_method() === 'post' ? 'selected' : '' ?>>POST — JSON body (default)</option>
          <option value="get"  <?= sfy_encrypt_method() === 'get'  ? 'selected' : '' ?>>GET — query string</option>
        </select></div>
      <div class="field"><label class="label">Cache hours (0 = off)</label>
        <input type="number" name="redirect_cache_hours" min="0" max="168"
               value="<?= (int)sfy_redirect_cache_hours() ?>"></div>
      <div class="field"><label class="label">Encrypted landing page</label>
        <input type="text" name="return_url" class="mono"
               value="<?= sfy_esc(sfy_config_get('set_return_url', sfy_url('done'))) ?>">
          <div class="hint">Leave this on <?= sfy_esc(sfy_url('done')) ?> — the page that confirms the task and
            forwards the player straight to their next one. It is the same URL for every visitor, which is what the
            encryption cache needs; a destination carrying the session id works too, at one encryptor call per session.</div></div>
    </div>
    <div class="btn-row mt-2">
      <button class="btn btn-primary">SAVE ANTI-BYPASS SETTINGS</button>
    </div>
  </form>

  <div class="msg info mt-2">
    ◆ <b>How it works.</b> LootLabs' encryptor turns your landing page into an AES-256 blob:</n    <code>POST creators.lootlabs.gg/api/public/url_encryptor {destination_url, api_token} → message</code>.
    We append that as <code>&amp;data=</code> to the account's own task link, so the finished task is sent to
    <b><?= sfy_esc($abSample) ?></b> instead of whatever destination the link was created with. The blob only
    decrypts on links made with that account's key, which is the anti-bypass part — a leaked or copied task URL
    cannot be re-pointed at someone else's destination.
  </div>
  <div class="msg warn mt-2">
    ◆ <b>Point the link's own destination at a decoy.</b> Every handoff now sends the finished task to
    <code><?= sfy_esc($abSample) ?>?rt=&lt;one-time ticket&gt;</code>. The ticket is minted per run and travels
    <b>only inside the encrypted blob</b>, so a bypass service can neither read it, guess it nor replay it. The one
    thing it can still read is the destination you configured on the LootLabs link itself — so set that destination in
    the LootLabs dashboard to a page that is not your code flow (your home page is fine) and a scraped value leads
    nowhere. The encrypted <code>&amp;data=</code> always overrides it for real visitors.
  </div>
  <div class="hint">
    Get the key in the LootLabs creator panel (API / integrations) and paste it into the account's
    <b>API key</b> field below. Leave <code>{SESSION_ID}</code> out of the landing page and every visitor shares one
    encrypted value — that is what makes the cache safe and keeps you inside LootLabs' rate limits.
  </div>

  <div class="btn-row mt-2">
    <?php sfy_admin_post_button('⚡ TEST ANTI-BYPASS ON EVERY ACTIVE ACCOUNT', ['action' => 'test_redirect_api', 'id' => 0], 'btn btn-gold',
        'Sends one real encryptor request per active account and records the exact answer.'); ?>
    <?php sfy_admin_post_button('🎫 TEST RETURN TICKET', ['action' => 'test_return_ticket'], 'btn',
        'Checks that the per-run ticket is minted into the encrypted destination, accepted once, and refused on replay. Touches no live step.'); ?>
  </div>
</div>

<div class="card">
  <div class="card-head">
    <h2>&gt; LOOTLABS_ACCOUNTS</h2>
    <span class="spacer"></span>
    <a class="btn btn-sm btn-gold" href="<?= sfy_esc(sfy_admin_url(['tab' => 'accounts', 'edit' => 'new'])) ?>">+ ADD ACCOUNT</a>
  </div>

  <?php if ($providers): ?>
    <div class="inline mb-2">
      <span class="label" style="margin:0">Filter</span>
      <a class="btn btn-sm <?= $filter === 0 ? 'btn-primary' : '' ?>" href="<?= sfy_esc(sfy_admin_url(['tab' => 'accounts'])) ?>">ALL</a>
      <?php foreach ($providers as $p): ?>
        <a class="btn btn-sm <?= $filter === (int)$p['id'] ? 'btn-primary' : '' ?>"
           href="<?= sfy_esc(sfy_admin_url(['tab' => 'accounts', 'provider' => (int)$p['id']])) ?>">
          <?= sfy_esc(strtoupper((string)$p['name'])) ?> (<?= (int)($provCounts[(int)$p['id']] ?? 0) ?>)
        </a>
      <?php endforeach; ?>
      <a class="btn btn-sm <?= $filter === -1 ? 'btn-primary' : '' ?>"
         href="<?= sfy_esc(sfy_admin_url(['tab' => 'accounts', 'provider' => 'none'])) ?>">UNASSIGNED</a>
    </div>
  <?php endif; ?>

  <?php if (!$accounts): ?>
    <div class="msg warn">◆ <?= $allAccounts
      ? 'No account matches this filter.'
      : 'No accounts yet. Every task step needs at least one active account on the provider it runs on — until then the task page refuses to hand off (that is the "No active task provider" error).' ?></div>
  <?php else: ?>
    <div class="tbl-wrap">
      <table class="tbl">
        <thead><tr><th>#</th><th>Provider</th><th>Name</th><th>Task URL</th><th>Anti-bypass</th><th>Weight</th><th>Daily cap</th>
                   <th>Used today</th><th>Last used</th><th>State</th><th>Actions</th></tr></thead>
        <tbody>
        <?php foreach ($accounts as $a): $aProvider = (int)($a['provider_id'] ?? 0); ?>
          <tr>
            <td class="mono"><?= (int)$a['id'] ?></td>
            <td>
              <?php if ($hasProviderCol): ?>
                <?= $aProvider > 0 ? sfy_badge(strtoupper($providerName($a)), 'b') : sfy_badge('UNASSIGNED', 'r') ?>
                <div class="tiny mute"><?= $aProvider > 0 ? 'rotates with its provider' : 'not used by any step' ?></div>
              <?php else: ?>
                <span class="tiny mute">run the updater</span>
              <?php endif; ?>
            </td>
            <td>
              <div><?= sfy_esc((string)$a['name']) ?></div>
              <div class="tiny mute mono">key: <?= sfy_esc(sfy_short((string)$a['api_key'], 14)) ?></div>
            </td>
            <td class="mono tiny"><?= sfy_esc(sfy_short((string)$a['task_url'], 30)) ?></td>
            <?php [$abLabel, $abTone, $abHint] = sfy_redirect_api_status_label($a); ?>
            <td>
              <?= sfy_badge($abLabel, $abTone) ?>
              <div class="tiny mute"><?= sfy_esc((string)($a['encrypt_checked_at'] ?? '') !== '' ? sfy_ago((string)$a['encrypt_checked_at']) : 'inherit · ' . $abMode) ?></div>
              <?php if ($abTone === 'r' && $abHint !== ''): ?><div class="tiny" style="color:var(--red)"><?= sfy_esc($abHint) ?></div><?php endif; ?>
              <?php if (sfy_redirect_api_last_test($a)['from'] === 'config'): ?><div class="tiny mute">(config copy)</div><?php endif; ?>
            </td>
            <td class="mono"><?= (int)($a['weight'] ?? 1) ?></td>
            <td class="mono"><?= (int)($a['daily_cap'] ?? 0) ?: '∞' ?></td>
            <td class="mono"><?= (int)($a['used_today'] ?? 0) ?></td>
            <td class="tiny dim"><?= sfy_esc(sfy_ago((string)($a['last_used_at'] ?? ''))) ?></td>
            <td><?= (int)$a['is_active'] ? sfy_badge('ACTIVE', 'g') : sfy_badge('OFF', 'r') ?></td>
            <td>
              <div class="actions">
                <a class="btn btn-sm" href="<?= sfy_esc(sfy_admin_url(['tab' => 'accounts', 'edit' => (int)$a['id'], 'provider' => $filter > 0 ? $filter : null])) ?>">EDIT</a>
                <?php sfy_admin_post_button('TEST', ['action' => 'test_redirect_api', 'id' => (int)$a['id']], 'btn btn-sm btn-ghost',
                    'Send a real encryptor request with this account\'s key?'); ?>
                <?php sfy_admin_post_button('TOGGLE', ['action' => 'toggle_account', 'id' => (int)$a['id']]) ?>
              </div>
            </td>
          </tr>
          <tr>
            <td></td>
            <td colspan="10">
              <div class="tiny mute mb-1">POSTBACK URL — paste this into <?= sfy_esc($providerName($a)) ?> (macros are replaced per step):</div>
              <div class="inline">
                <input class="grow mono" readonly id="pb-<?= (int)$a['id'] ?>"
                       value="<?= sfy_esc(sfy_postback_url($a, ['unique_id' => '{UNIQUE_ID}', 'nonce' => '{SUB_ID}', 'sig' => '{SIG}'],
                                                          function_exists('sfy_provider_find') ? sfy_provider_find($aProvider) : null)) ?>">
                <button class="btn btn-sm" type="button"
                        onclick="var i=document.getElementById('pb-<?= (int)$a['id'] ?>');i.select();navigator.clipboard&&navigator.clipboard.writeText(i.value);">
                  COPY
                </button>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<div class="card">
  <div class="card-head"><h2>&gt; MACROS_SUPPORTED</h2></div>
  <div class="grid grid-2">
    <div class="term" style="max-height:none;font-size:11.5px">
{CLICK_ID}   → LootLabs click identifier
{IP}         → visitor IP reported by the provider
{USER_ID}    → our session id (also {UNIQUE_ID}, {SESSION_ID})
{SUB_ID}     → one-time step nonce (also {NONCE})
{SIG}        → per-step HMAC signature (also {SIGNATURE})
    </div>
    <div class="term" style="max-height:none;font-size:11.5px">
{ACCOUNT}    → this account id
{STEP}       → step number
{TOKEN}      → the user's token
{GAME_ID}    → place id
{DOMAIN}     → <?= sfy_esc(SFY_DOMAIN) ?>
    </div>
  </div>
  <div class="hint">Any macro the provider cannot fill stays literal — the server then falls back to matching the
    open step by IP inside the nonce window, so postbacks still verify.</div>
</div>

<?php if ($ea !== null): ?>
<div class="modal-bg show">
  <div class="modal" style="width:740px">
    <div class="modal-head">
      <h3><?= $ea['id'] ? '&gt; EDIT_ACCOUNT #' . (int)$ea['id'] : '&gt; ADD_ACCOUNT' ?></h3>
      <span class="spacer" style="margin-left:auto"></span>
      <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_admin_url(['tab' => 'accounts'])) ?>">✕</a>
    </div>
    <div class="modal-body">
      <form method="POST">
        <?= sfy_csrf_field() ?>
        <input type="hidden" name="action" value="save_account">
        <input type="hidden" name="id" value="<?= (int)$ea['id'] ?>">
        <div class="field"><label class="label">Task provider</label>
          <?php if ($providers): ?>
            <select name="provider_id">
              <option value="0" <?= (int)($ea['provider_id'] ?? 0) === 0 ? 'selected' : '' ?>>— unassigned (never used) —</option>
              <?php foreach ($providers as $p): ?>
                <option value="<?= (int)$p['id'] ?>" <?= (int)($ea['provider_id'] ?? 0) === (int)$p['id'] ? 'selected' : '' ?>>
                  <?= sfy_esc((string)$p['name']) ?> — <?= sfy_esc(sfy_provider_kind_label((string)$p['kind'])) ?>
                  <?= (int)$p['is_active'] ? '' : ' (inactive)' ?>
                </option>
              <?php endforeach; ?>
            </select>
            <div class="hint">This link rotates with the other accounts of the same provider. A provider with no active
              account is never offered to players. <a href="<?= sfy_esc(sfy_admin_url(['tab' => 'providers'])) ?>">Manage providers</a>.</div>
          <?php else: ?>
            <div class="msg warn">◆ No task-provider table yet — run <a href="<?= sfy_esc(sfy_admin_url(['tab' => 'updater'])) ?>">Admin → Updater</a>,
              then assign this account to LootLabs or Work.ink.</div>
          <?php endif; ?>
        </div>
        <div class="grid grid-2">
          <div class="field"><label class="label">Display name</label>
            <input type="text" name="name" value="<?= sfy_esc((string)$ea['name']) ?>" required></div>
          <div class="field"><label class="label">API key / token</label>
            <input type="text" name="api_key" value="<?= sfy_esc((string)$ea['api_key']) ?>" required></div>
          <div class="field"><label class="label">Postback secret (optional)</label>
            <input type="text" name="postback_secret" value="<?= sfy_esc((string)($ea['postback_secret'] ?? '')) ?>"></div>
          <div class="field"><label class="label">Weight (rotation)</label>
            <input type="number" name="weight" value="<?= (int)($ea['weight'] ?? 1) ?>" min="1" max="50"></div>
          <div class="field"><label class="label">Daily cap (0 = unlimited)</label>
            <input type="number" name="daily_cap" value="<?= (int)($ea['daily_cap'] ?? 0) ?>" min="0"></div>
          <?php $eaMode = strtolower(trim((string)($ea['redirect_api'] ?? ''))); ?>
          <div class="field"><label class="label">Anti-bypass handoff (this account)</label>
            <select name="redirect_api">
              <option value=""     <?= $eaMode === ''     ? 'selected' : '' ?>>INHERIT — follow the global mode</option>
              <option value="auto" <?= $eaMode === 'auto' ? 'selected' : '' ?>>AUTO — use the Redirect API, fall back to a plain link</option>
              <option value="on"   <?= $eaMode === 'on'   ? 'selected' : '' ?>>ON — require it (no API key = step blocked)</option>
              <option value="off"  <?= $eaMode === 'off'  ? 'selected' : '' ?>>OFF — plain links from this account</option>
            </select>
            <div class="hint">
              <?php if (trim((string)($ea['encrypt_status'] ?? '')) !== ''): ?>
                Last test: <b><?= sfy_esc((string)$ea['encrypt_status']) ?></b>
                <?= sfy_esc(sfy_ago((string)($ea['encrypt_checked_at'] ?? ''))) ?>.
              <?php else: ?>
                Not tested yet — use TEST in the accounts table.
              <?php endif; ?>
            </div></div>
          <div class="field"><label class="label">API timeout (s)</label>
            <input type="number" name="timeout_seconds" value="<?= (int)($ea['timeout_seconds'] ?? 8) ?>" min="3" max="30"></div>
        </div>
        <div class="field"><label class="label">Task URL (this account's own link)</label>
          <input type="text" name="task_url" value="<?= sfy_esc((string)$ea['task_url']) ?>" required
                 placeholder="https://loot-link.com/s?.... or https://work.ink/xxxx/sfy-script">
          <div class="hint">One link per account: the rotation picks between them, so you can paste as many as the network
            gave you.</div></div>
        <?php /* The placeholder is the built-in URL this account's own network would
                 get, so a LootLabs account does not show a macro LootLabs cannot replace. */
              $eaProvider = function_exists('sfy_provider_find') && (int)($ea['provider_id'] ?? 0) > 0
                          ? sfy_provider_find((int)$ea['provider_id']) : null; ?>
        <div class="field"><label class="label">Postback URL (leave blank to use the built-in default)</label>
          <input type="text" name="postback_url" value="<?= sfy_esc((string)($ea['postback_url'] ?? '')) ?>"
                 placeholder="<?= sfy_esc(sfy_postback_url(['id' => (int)$ea['id'], 'postback_url' => ''],
                                       ['unique_id' => '{UNIQUE_ID}', 'nonce' => '{SUB_ID}', 'sig' => '{SIG}'], $eaProvider)) ?>">
          <div class="hint">Leave it empty unless the network has its own format. A LootLabs account gets
            <code>{CLICK_ID}</code>, <code>{IP}</code> and <code>{UNIQUE_ID}</code> — the only macros LootLabs replaces.</div></div>
        <div class="field"><label class="label">Notes</label>
          <input type="text" name="notes" value="<?= sfy_esc((string)($ea['notes'] ?? '')) ?>"></div>
        <label class="check"><input type="checkbox" name="is_active" <?= (int)$ea['is_active'] ? 'checked' : '' ?>> Active (used for rotation)</label>
        <div class="modal-actions">
          <a class="btn btn-ghost" href="<?= sfy_esc(sfy_admin_url(['tab' => 'accounts'])) ?>">CANCEL</a>
          <button class="btn btn-primary">SAVE ACCOUNT</button>
        </div>
      </form>
      <?php if ($ea['id']): ?>
        <hr class="sep">
        <?php sfy_admin_form_start(['action' => 'delete_account', 'id' => (int)$ea['id']], 'Delete this account permanently?'); ?>
        <button class="btn btn-danger">DELETE ACCOUNT</button></form>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php endif; ?>
