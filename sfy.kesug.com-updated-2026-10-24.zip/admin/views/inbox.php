<?php
/** @var PDO $db */
sfy_support_ensure();
$imported = sfy_support_import_hub_messages();
$cats = sfy_support_categories();
$statuses = sfy_support_statuses();
$q = trim((string)sfy_param('q'));
$status = trim((string)sfy_param('status'));
$category = trim((string)sfy_param('category'));
$sort = trim((string)sfy_param('sort', 'new'));
if (!in_array($sort, ['new', 'old', 'unread', 'code'], true)) $sort = 'new';
$page = max(1, sfy_int('page', 1));
$per = 20;
$filter = ['q' => $q, 'status' => $status, 'category' => $category, 'sort' => $sort];
$total = sfy_support_count($filter);
$rows = sfy_support_list($filter, $page, $per);
$stats = sfy_support_stats();
$view = sfy_int('view');
$req = $view > 0 ? sfy_support_find_id($view) : null;
$msgs = $req ? sfy_support_messages((int)$req['id']) : [];
if ($req) {
    sfy_support_mark_read((int)$req['id']);
    $stats = sfy_support_stats();
}
$base = ['tab' => 'inbox', 'q' => $q, 'status' => $status, 'category' => $category, 'sort' => $sort];
?>
<div class="grid grid-4 mb-2">
  <?= sfy_kpi('Unread', number_format((int)$stats['unread']), 'orange', 'waiting for a reply') ?>
  <?= sfy_kpi('Open', number_format((int)($stats['open'] ?? 0)), 'blue', 'new / active') ?>
  <?= sfy_kpi('Resolved', number_format((int)($stats['resolved'] ?? 0)), 'g', 'closed successfully') ?>
  <?= sfy_kpi('All requests', number_format((int)$stats['total']), '', 'matching filter') ?>
</div>

<?php if ($imported > 0): ?><div class="msg info">Imported <?= (int)$imported ?> legacy Hub message(s) into this inbox.</div><?php endif; ?>

<?php if ($req): ?>
  <div class="card support-thread mb-2">
    <div class="card-head">
      <h2>&gt; <?= sfy_esc((string)$req['code']) ?></h2>
      <span class="spacer"></span>
      <?= sfy_badge(sfy_support_status_label((string)$req['status']), (string)$req['status'] === 'resolved' ? 'g' : ((string)$req['status'] === 'closed' ? 'gr' : 'y')) ?>
      <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_admin_url(['tab' => 'inbox'])) ?>">← QUEUE</a>
    </div>
    <div class="support-meta">
      <span><?= sfy_esc((string)($cats[(string)$req['category']] ?? 'Request')) ?></span>
      <span>·</span><span><?= sfy_esc((string)($req['subject'] ?: 'No subject')) ?></span>
      <span>·</span><span class="mono"><?= sfy_esc((string)$req['email']) ?></span>
      <span>·</span><span><?= sfy_esc(sfy_ago((string)$req['created_at'])) ?></span>
    </div>
    <div class="support-messages">
      <?php foreach ($msgs as $m): $admin = (string)$m['sender'] === 'admin'; ?>
        <div class="support-msg<?= $admin ? ' admin' : '' ?>">
          <div class="support-msg-head"><?= $admin ? 'SFY_Devs Team' : sfy_esc((string)$req['name']) ?> <span><?= sfy_esc(sfy_ago((string)$m['created_at'])) ?></span></div>
          <div class="support-msg-body"><?= nl2br(sfy_esc((string)$m['body'])) ?></div>
        </div>
      <?php endforeach; ?>
    </div>
    <div class="grid grid-2" style="gap:12px">
      <form method="POST" class="support-reply">
        <?= sfy_csrf_field() ?>
        <input type="hidden" name="action" value="support_admin_reply">
        <input type="hidden" name="id" value="<?= (int)$req['id'] ?>">
        <div class="field"><label class="label">Reply as SFY_Devs Team</label>
          <textarea name="message" rows="4" maxlength="3000" required></textarea></div>
        <button class="btn btn-primary">SEND REPLY</button>
      </form>
      <div>
        <form method="POST" class="mb-2">
          <?= sfy_csrf_field() ?>
          <input type="hidden" name="action" value="support_status">
          <input type="hidden" name="id" value="<?= (int)$req['id'] ?>">
          <div class="field"><label class="label">Status</label>
            <select name="status"><?php foreach ($statuses as $k => $lbl): ?><option value="<?= sfy_esc($k) ?>" <?= (string)$req['status'] === $k ? 'selected' : '' ?>><?= sfy_esc($lbl) ?></option><?php endforeach; ?></select></div>
          <button class="btn btn-gold">UPDATE STATUS</button>
        </form>
        <a class="btn btn-ghost btn-block" href="mailto:<?= sfy_esc((string)$req['email']) ?>?subject=<?= rawurlencode('Re: ' . (string)$req['code']) ?>">REPLY BY EMAIL</a>
        <form method="POST" data-confirm="Delete this request and all messages?" style="margin-top:8px">
          <?= sfy_csrf_field() ?>
          <input type="hidden" name="action" value="support_delete">
          <input type="hidden" name="id" value="<?= (int)$req['id'] ?>">
          <button class="btn btn-sm btn-danger btn-block">DELETE REQUEST</button>
        </form>
      </div>
    </div>
  </div>
<?php endif; ?>

<div class="card">
  <div class="card-head"><h2>&gt; INBOX</h2><span class="spacer"></span><span class="badge <?= (int)$stats['unread'] ? 'r' : 'g' ?>"><?= (int)$stats['unread'] ?> UNREAD</span></div>
  <form method="GET" class="inline mb-2">
    <input type="hidden" name="tab" value="inbox">
    <input class="grow" type="search" name="q" value="<?= sfy_esc($q) ?>" placeholder="Code, name, email or subject">
    <select name="status" style="max-width:150px">
      <option value="">Every status</option>
      <?php foreach ($statuses as $k => $lbl): ?><option value="<?= sfy_esc($k) ?>" <?= $status === $k ? 'selected' : '' ?>><?= sfy_esc($lbl) ?></option><?php endforeach; ?>
    </select>
    <select name="category" style="max-width:170px">
      <option value="">Every category</option>
      <?php foreach ($cats as $k => $lbl): ?><option value="<?= sfy_esc($k) ?>" <?= $category === $k ? 'selected' : '' ?>><?= sfy_esc($lbl) ?></option><?php endforeach; ?>
    </select>
    <select name="sort" style="max-width:150px">
      <?php foreach (['new' => 'Newest first', 'old' => 'Oldest first', 'unread' => 'Unread first', 'code' => 'Code A–Z'] as $k => $lbl): ?><option value="<?= sfy_esc($k) ?>" <?= $sort === $k ? 'selected' : '' ?>><?= sfy_esc($lbl) ?></option><?php endforeach; ?>
    </select>
    <button class="btn">FILTER</button>
    <a class="btn btn-ghost" href="<?= sfy_esc(sfy_admin_url(['tab' => 'inbox'])) ?>">RESET</a>
  </form>
  <?php if (!$rows): ?>
    <div class="empty">&gt; no requests matched.</div>
  <?php else: ?>
    <div class="tbl-wrap"><table class="tbl">
      <thead><tr><th>Code</th><th>From</th><th>Category</th><th>Subject</th><th>Status</th><th>Updated</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td class="mono"><?= sfy_esc((string)$r['code']) ?> <?= (int)$r['unread'] ? sfy_badge('NEW', 'r') : '' ?></td>
          <td><div><?= sfy_esc((string)$r['name']) ?></div><div class="tiny mute mono"><?= sfy_esc((string)$r['email']) ?></div></td>
          <td class="tiny"><?= sfy_esc((string)($cats[(string)$r['category']] ?? $r['category'])) ?></td>
          <td class="tiny"><?= sfy_esc((string)($r['subject'] ?: '—')) ?></td>
          <td><?= sfy_badge(sfy_support_status_label((string)$r['status']), (string)$r['status'] === 'resolved' ? 'g' : ((string)$r['status'] === 'closed' ? 'gr' : 'y')) ?></td>
          <td class="tiny dim"><?= sfy_esc(sfy_ago((string)$r['updated_at'])) ?></td>
          <td><a class="btn btn-sm" href="<?= sfy_esc(sfy_admin_url(['tab' => 'inbox', 'view' => (int)$r['id']])) ?>">OPEN</a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <?php $pages = max(1, (int)ceil($total / $per)); if ($pages > 1): ?>
      <div class="sfy-pager"><?php for ($i = 1; $i <= $pages; $i++): ?><a class="btn btn-sm <?= $i === $page ? 'btn-primary' : '' ?>" href="<?= sfy_esc(sfy_admin_url($base + ['page' => $i])) ?>"><?= $i ?></a><?php endfor; ?></div>
    <?php endif; ?>
  <?php endif; ?>
</div>
