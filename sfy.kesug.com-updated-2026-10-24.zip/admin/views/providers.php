<?php
declare(strict_types=1);
/**
 * Admin → Task providers.
 *
 * Where a player may earn their task: LootLabs, Work.ink, or anything else
 * the owner adds here. One row per provider holds
 *
 *   • how many tasks ONE verification may run on it (`tasks_allowed`),
 *   • the link/template the handoff is built from, with macros,
 *   • the hosts a landing back on /done is accepted from,
 *   • and the postback address to paste into the network's dashboard,
 *
 * while its accounts (Admin → Accounts) are the rotation pool — several
 * accounts on one provider rotate between steps exactly like LootLabs always
 * did, and providers never share an account.
 *
 * ── adding one: the type comes first ────────────────────────────────
 *
 * `+ ADD PROVIDER` no longer drops the owner into one generic form. It asks
 * *which network this is*, because LootLabs and Work.ink are set up in
 * different dashboards, need different keys and are confirmed by different
 * things. Only then is the editor rendered — with that type's own fields,
 * its own wording and its own walkthrough (see sfy_provider_types() in
 * app/providers.php). A type that a provider does not use simply has no
 * field on screen, and because the save writes only the fields the form
 * actually carried, switching type never blanks what the other side needs.
 *
 * @var PDO $db
 */
$providers = sfy_providers_all();
$edit      = sfy_param('edit');
$kindAsk   = trim(sfy_param('kind'));
$types     = sfy_provider_types();

$ep     = null;
$isNew  = false;
$epKind = '';

if ($edit === 'new') {
    $isNew = true;
    /* No type yet → the chooser below, not the editor. */
    if ($kindAsk !== '' && isset($types[sfy_provider_kind($kindAsk)])) {
        $ep     = sfy_provider_starter($kindAsk);
        $epKind = sfy_provider_kind($kindAsk);
    }
} elseif ($edit !== '') {
    foreach ($providers as $p) if ((int)$p['id'] === (int)$edit) { $ep = sfy_provider_normalize($p); break; }
    if ($ep !== null) {
        /* `&kind=` on an existing provider previews (and, on save, switches to)
           that type's field set while keeping every stored value. */
        $epKind = $kindAsk !== '' && isset($types[sfy_provider_kind($kindAsk)])
                ? sfy_provider_kind($kindAsk)
                : sfy_provider_kind((string)$ep['kind']);
    }
}

$epMeta   = $epKind !== '' ? sfy_provider_type_meta($epKind) : [];
$epFields = $epKind !== '' ? sfy_provider_type_fields($epKind) : [];
/* Short fields sit two to a row; anything with a long value gets its own. */
$epShort  = ['name', 'slug', 'tasks_allowed', 'sort_order', 'api_key', 'api_mode', 'description', 'notes'];

$offerable   = sfy_provider_offerable();
/* Parked for maintenance: still listed to players, never offered — see
   sfy_provider_maintenance(). The distinction matters for every count on this
   page, because a parked network cannot cover a budget or answer a step. */
$serving     = array_values(array_filter($offerable, fn($p) => !sfy_provider_maintenance($p)));
$parked      = array_values(array_filter($offerable, fn($p) => sfy_provider_maintenance($p)));
$counts      = sfy_provider_account_counts();
$served      = sfy_provider_served_counts();
$unassigned  = sfy_provider_unassigned_accounts();
$warnings    = sfy_provider_warnings();
$kinds       = sfy_provider_kinds();
$budgetTotal = 0;
$unlimited   = 0;
foreach ($serving as $p) {
    $allowed = sfy_provider_tasks_allowed($p);
    if ($allowed > 0) $budgetTotal += $allowed; else $unlimited++;
}
$hostCount = count(sfy_provider_return_hosts());
$tabUrl    = fn(array $q = []): string => sfy_admin_url(['tab' => 'providers'] + $q);

/**
 * One field of the editor, rendered the way its type describes it.
 * Labels and hints are ours (they carry <b>/<code>); values are escaped.
 */
$renderField = function (string $key, array $ep, string $kind): string {
    $d = sfy_provider_field($key, $kind);
    if (!$d) return '';

    $in  = (string)($d['input'] ?? 'text');
    $val = '';
    switch ($key) {
        case 'tasks_allowed': $val = (string)sfy_provider_tasks_allowed($ep); break;
        case 'sort_order':    $val = (string)(int)($ep['sort_order'] ?? 0); break;
        case 'api_mode':      $val = strtolower(trim((string)($ep['api_mode'] ?? ''))); break;
        case 'settings':      $val = sfy_provider_settings_text($ep); break;
        default:              $val = (string)($ep[$key] ?? '');
    }
    $label = (string)($d['label'] ?? $key);
    $hint  = (string)($d['hint'] ?? '');
    $out   = '<div class="field">';

    if ($in === 'check') {
        $on = match ($key) {
            'is_active'      => (int)$ep['is_active'] === 1,
            'is_maintenance' => sfy_provider_maintenance($ep),
            /* Only `pass_params` is left, and it stores a 0/1 too. */
            default          => sfy_provider_passes_params($ep),
        };
        $out .= '<label class="check"><input type="checkbox" name="' . sfy_esc($key) . '"'
              . ($on ? ' checked' : '') . '> ' . $label . '</label>';
    } elseif ($in === 'select') {
        $out .= '<label class="label">' . $label . '</label><select name="' . sfy_esc($key) . '">';
        foreach ((array)($d['options'] ?? []) as $ov => $ol) {
            $out .= '<option value="' . sfy_esc((string)$ov) . '"'
                  . ((string)$ov === $val ? ' selected' : '') . '>' . sfy_esc((string)$ol) . '</option>';
        }
        $out .= '</select>';
    } elseif ($in === 'textarea') {
        $out .= '<label class="label">' . $label . '</label>'
              . '<textarea name="' . sfy_esc($key) . '" rows="4" class="mono" placeholder="'
              . sfy_esc((string)($d['placeholder'] ?? '')) . '">' . sfy_esc($val) . '</textarea>';
    } else {
        $attr = ' type="' . sfy_esc($in) . '"';
        if ($in === 'number') {
            $attr .= ' min="' . (int)($d['min'] ?? 0) . '" max="' . (int)($d['max'] ?? 999) . '"';
        } elseif (!empty($d['attr'])) {
            $attr .= ' ' . (string)$d['attr'];
        }
        $out .= '<label class="label">' . $label . '</label>'
              . '<input' . $attr . ' name="' . sfy_esc($key) . '" value="' . sfy_esc($val) . '"'
              . (!empty($d['mono']) ? ' class="mono"' : '')
              . ' placeholder="' . sfy_esc((string)($d['placeholder'] ?? '')) . '">';
    }

    if ($hint !== '') $out .= '<div class="hint">' . $hint . '</div>';
    return $out . '</div>';
};
?>

<div class="grid grid-3 mb-2">
  <?= sfy_kpi('Providers', count($providers), '',
              count($serving) . ' ready to serve a step'
              . ($parked ? ' · ' . count($parked) . ' parked for maintenance' : '')) ?>
  <?= sfy_kpi('Tasks per run', $unlimited > 0 && $budgetTotal === 0 ? '∞' : (string)$budgetTotal, 'gold',
              $unlimited > 0 ? ($unlimited . ' provider(s) unlimited') : 'sum of every budget') ?>
  <?= sfy_kpi('Accepted return hosts', $hostCount, 'blue', 'a landing from these confirms a step') ?>
</div>

<?php foreach ($warnings as [$level, $text]): ?>
  <div class="msg <?= $level === 'r' ? 'err' : 'warn' ?>">
    <?= $level === 'r' ? '✖' : '◆' ?> <?= sfy_esc($text) ?>
  </div>
<?php endforeach; ?>

<div class="sfy-stat-grid">
  <div class="sfy-stat"><span>Providers</span><strong><?= count($providers) ?></strong><small><?= (int)count(array_filter($providers, fn($p) => (int)$p['is_active'] === 1)) ?> active</small></div>
  <div class="sfy-stat"><span>Serving</span><strong><?= count($serving) ?></strong><small>offerable now</small></div>
  <div class="sfy-stat"><span>Parked</span><strong><?= count($parked) ?></strong><small>maintenance</small></div>
  <div class="sfy-stat"><span>Accounts</span><strong><?= (int)array_sum($counts) ?></strong><small>in rotation</small></div>
  <div class="sfy-stat"><span>Tasks / run</span><strong><?= $unlimited > 0 ? '∞' : (int)$budgetTotal ?></strong><small>across serving</small></div>
  <div class="sfy-stat"><span>Checks</span><strong><?= count($warnings) ?></strong><small><?= count($warnings) ? 'needs attention' : 'all clear' ?></small></div>
</div>

<details class="card mb-2 sfy-collapse">
  <summary class="card-head">
    <h2>&gt; HOW_THE_CHOICE_WORKS</h2>
    <span class="spacer"></span>
    <?= sfy_badge(count($serving) > 1 ? 'PLAYER PICKS' : 'OPEN', count($serving) > 1 ? 'g' : 'gr') ?>
  </summary>
  <div class="term" style="max-height:none;font-size:11.5px">
<span class="line ok">1 network ready → no question: every step runs there.</span>
<span class="line ok">2+ networks ready → the player is asked WHERE to earn each run.</span>
<span class="line">the pick is remembered until that network's budget runs out</span>
<span class="line">rows of one kind (two LootLabs links) are ONE network: their links take turns</span>
<span class="line warn">a budget is only enforced while more than one network can really run</span>
<span class="line warn">a parked row is still listed, greyed, and never served a step</span>
<span class="line bad">a row with no active account contributes nothing to the network</span>
  </div>
  <div class="hint">
    <b>Several accounts on one provider rotate between steps</b>, exactly like the LootLabs pool always did — two Work.ink
    accounts take turns, and a LootLabs account is never used for a Work.ink step. Weight and daily cap are per account, in
    <a href="<?= sfy_esc(sfy_admin_url(['tab' => 'accounts'])) ?>">Admin → Accounts</a>.<br>
    <b>One network, several rows.</b> Rows of the same <i>kind</i> are <b>one network to the player</b>: two LootLabs rows
    collapse into a single <b>LootLabs</b> box, their links join one rotation (task 1 opens the first link, task 2 the
    second) and their budgets add up. Work.ink keeps its own box — that is a real choice. A <b>custom</b> row is its own
    network and is never merged, since its name, template and keys are its own. The rows themselves are untouched here:
    a provider with no active account is never offered a step.<br>
    <b>Budgets.</b> <code>Tasks per run</code> is how many tasks of ONE verification may happen on that provider: set it to
    <code>1</code> and the player is asked again for the next task, set it to <code>2</code> and a two-task token is done
    entirely there.    <code>0</code> means "as many as the token needs". Nothing is enforced while only one provider is ready,
    because there is nowhere else to send the player.<br>
    <b>PAUSE (maintenance).</b> A network that is broken or being re-negotiated is better <i>announced</i> than hidden:
    a paused provider keeps its box on the chooser, greyed and labelled <b>UNDER MAINTENANCE</b>, and no step is handed to
    it — including the steps of a player who had already picked it. It also stops counting towards the choice and towards
    the budgets above, so a paused network can never leave a player on a chooser with nothing pressable.
    <b>TOGGLE</b> is the other lever: it hides a provider completely, which is what you want for a network you have
    finished with rather than one you are fixing.
  </div>
</details>

<div class="card mb-2">
  <div class="card-head">
    <h2>&gt; TASK_PROVIDERS</h2>
    <span class="spacer"></span>
    <a class="btn btn-sm btn-gold" href="<?= sfy_esc($tabUrl(['edit' => 'new'])) ?>">+ ADD PROVIDER</a>
  </div>

  <?php if (!$providers): ?>
    <div class="msg warn">◆ No providers yet. Migration 027 seeds LootLabs and Work.ink — run
      <a href="<?= sfy_esc(sfy_admin_url(['tab' => 'updater'])) ?>">Admin → Updater</a>, then come back.</div>
  <?php else: ?>
    <div class="tbl-wrap">
      <table class="tbl">
        <thead><tr><th>#</th><th>Provider</th><th>Tasks / run</th><th>Accounts</th><th>Served</th><th>Return hosts</th>
                   <th>Order</th><th>State</th><th>Actions</th></tr></thead>
        <tbody>
        <?php foreach ($providers as $p): $p = sfy_provider_normalize($p); ?>
          <?php
          $pid     = (int)$p['id'];
          $pKind   = sfy_provider_kind((string)$p['kind']);
          $accs    = (int)($counts[$pid] ?? 0);
          $allowed = sfy_provider_tasks_allowed($p);
          ?>
          <tr>
            <td class="mono"><?= $pid ?></td>
            <td>
              <div><?= sfy_esc(sfy_provider_label($p)) ?>
                <?= sfy_badge(sfy_provider_kind_label((string)$p['kind']), 'b') ?>
                <?php if (function_exists('sfy_workink_status_label') && $pKind === 'workink'):
                      [$wkLabel, $wkTone] = sfy_workink_status_label($p); ?>
                  <?= sfy_badge('KEY ' . $wkLabel, $wkTone) ?>
                <?php endif; ?></div>
              <div class="tiny mute mono">slug: <?= sfy_esc((string)$p['slug']) ?></div>
              <?php if (trim((string)$p['description']) !== ''): ?>
                <div class="tiny mute"><?= sfy_esc((string)$p['description']) ?></div>
              <?php endif; ?>
            </td>
            <td class="mono"><?= $allowed > 0 ? (int)$allowed : '∞' ?></td>
            <td>
              <?= $accs > 0 ? sfy_badge($accs . ' ACTIVE', 'g') : sfy_badge('NONE', 'r') ?>
              <div class="tiny mute"><?= $accs > 0 ? 'rotates between steps' : 'never offered to players' ?></div>
              <?php
              /*
               * A provider and its links are two levels of one thing, so the row
               * is where a link is added: the button opens the link editor with
               * THIS provider already selected (name, network and rotation pool
               * all pre-filled). The Accounts tab holds the same editor plus the
               * per-link keys, postback boxes and the Postback Doctor, which is
               * more than a provider row can show without burying the list.
               */
              ?>
              <div class="actions mt-1">
                <a class="btn btn-sm <?= $accs > 0 ? 'btn-ghost' : 'btn-gold' ?>"
                   href="<?= sfy_esc(sfy_admin_url(['tab' => 'accounts', 'edit' => 'new', 'provider' => $pid])) ?>">+ ADD ACCOUNT</a>
                <?php if ($accs > 0): ?>
                  <a class="btn btn-sm btn-ghost"
                     href="<?= sfy_esc(sfy_admin_url(['tab' => 'accounts', 'provider' => $pid])) ?>">VIEW <?= $accs ?></a>
                <?php endif; ?>
              </div>
            </td>
            <td class="mono"><?= (int)($served[$pid] ?? 0) ?></td>
            <td class="mono tiny"><?= sfy_esc(trim((string)$p['return_hosts']) !== '' ? sfy_short((string)$p['return_hosts'], 30) : '—') ?></td>
            <td class="mono"><?= (int)$p['sort_order'] ?></td>
            <td>
              <?= (int)$p['is_active'] ? sfy_badge('ACTIVE', 'g') : sfy_badge('OFF', 'r') ?>
              <?php if (sfy_provider_maintenance($p)): ?>
                <?= sfy_badge('MAINTENANCE', 'y') ?>
              <?php endif; ?>
            </td>
            <td>
              <div class="actions">
                <a class="btn btn-sm" href="<?= sfy_esc($tabUrl(['edit' => $pid])) ?>">EDIT</a>
                <?php
                /*
                 * PAUSE, not TOGGLE. Taking a network down for an hour used to
                 * mean switching it inactive, which hides it from the chooser
                 * completely: a player who had already picked it was moved
                 * elsewhere with no explanation, which reads as a bug. PAUSE
                 * keeps it on the chooser, greyed and labelled, and stops every
                 * step being handed to it.
                 */
                $isParked = sfy_provider_maintenance($p);
                sfy_admin_post_button($isParked ? 'RESUME' : 'PAUSE',
                    ['action' => 'toggle_provider_maintenance', 'id' => $pid],
                    'btn btn-sm' . ($isParked ? ' btn-gold' : ''));
                ?>
                <?php sfy_admin_post_button('↑', ['action' => 'move_provider', 'id' => $pid, 'dir' => 'up'], 'btn btn-sm btn-ghost') ?>
                <?php sfy_admin_post_button('↓', ['action' => 'move_provider', 'id' => $pid, 'dir' => 'down'], 'btn btn-sm btn-ghost') ?>
                <?php sfy_admin_post_button('TOGGLE', ['action' => 'toggle_provider', 'id' => $pid]) ?>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>

  <?php if ($unassigned): ?>
    <div class="msg warn mt-2">
      ◆ <b><?= count($unassigned) ?> account(s) belong to no provider</b>, so they are never used for a step:
      <?= sfy_esc(implode(', ', array_map(fn($a) => '#' . (int)$a['id'] . ' ' . (string)$a['name'], array_slice($unassigned, 0, 6)))) ?>.
      Open <a href="<?= sfy_esc(sfy_admin_url(['tab' => 'accounts'])) ?>">Accounts</a> and pick a provider for each one.
    </div>
  <?php endif; ?>
</div>

<details class="card sfy-collapse">
  <summary class="card-head"><h2>&gt; MACROS_AND_TEMPLATES</h2><span class="spacer"></span><span class="tiny mute">OPEN</span></summary>
  <div class="grid grid-2">
    <div class="term" style="max-height:none;font-size:11.5px">
{SESSION_ID}  → our session id (also {USER_ID}, {UNIQUE_ID})
{SUB_ID}      → one-time step nonce (also {NONCE})
{SIG}         → per-step signature
{ACCOUNT_ID}  → the rotating account id
{STEP}        → step number
{TOKEN}       → the visitor's token
{GAME_ID}     → place id
{IP}          → visitor IP
{DESTINATION} → your post-task landing page
    </div>
    <div class="term" style="max-height:none;font-size:11.5px">
{PROVIDER}    → this provider's name
{PROVIDER_SLUG} → its slug
{DOMAIN}      → <?= sfy_esc(SFY_DOMAIN) ?>
{CLICK_ID}    → provider click id (postback template)
{setting:KEY} → a custom value you defined below
{__MACRO__}   → same as {MACRO}

      any macro with no value stays literal — the
      provider (or you) fills it in later.
    </div>
  </div>
  <div class="hint">
    <b>Task URL</b> is expanded for every handoff. Leave it empty and the <b>account's own link</b> is used instead — that
    is how LootLabs and Work.ink work, where each account is a different link. A custom network can put the macros straight
    into the template, e.g. <code class="mono">https://ads.example.com/start?u={SESSION_ID}&amp;t={SUB_ID}</code>.<br>
    <b>Extra query parameters</b> are appended after the link, so you can add a fixed network parameter
    (<code class="mono">zone=web&amp;type=ppl</code>) without touching the accounts.<br>
    <b>Custom values</b> (one <code class="mono">key = value</code> per line) are reachable in any template as
    <code class="mono">{setting:key}</code> — that is the no-code way to feed a network whatever parameters it wants.
  </div>
</details>

<?php if ($edit === 'new' && $ep === null): ?>
<div class="modal-bg show">
  <div class="modal" style="width:900px">
    <div class="modal-head">
      <h3>&gt; ADD_PROVIDER</h3>
      <span class="spacer" style="margin-left:auto"></span>
      <a class="btn btn-sm btn-ghost" href="<?= sfy_esc($tabUrl()) ?>">✕</a>
    </div>
    <div class="modal-body">
      <div class="msg info">◆ Every network is set up differently — pick the one you are adding and the next screen shows
        <b>only its fields</b> and its own dashboard instructions. Name, slug, tasks per run and notes are shared, so
        switching type later keeps them.</div>

      <div class="grid grid-3">
        <?php foreach ($types as $kind => $meta): ?>
          <div class="card" style="margin-bottom:0">
            <div class="card-head" style="border:0;padding:0">
              <h2>&gt; <?= sfy_esc(strtoupper((string)$meta['label'])) ?></h2>
              <span class="spacer"></span>
              <?= sfy_badge(!empty($meta['anti']) ? 'ANTI-BYPASS' : 'RETURN CHECK', !empty($meta['anti']) ? 'g' : 'b') ?>
            </div>
            <div class="ad-text"><?= (string)$meta['tagline'] ?></div>

            <div class="label mt-2">What you need</div>
            <div class="term" style="max-height:none;font-size:11.5px">
              <?php foreach ((array)$meta['needs'] as $need): ?>
<span class="line"><?= $need ?></span>
              <?php endforeach; ?>
            </div>

            <div class="label mt-2">A step is confirmed by</div>
            <div class="hint" style="margin-top:0"><?= (string)$meta['confirmed'] ?>.</div>

            <a class="btn btn-primary btn-block mt-2"
               href="<?= sfy_esc(sfy_admin_url(['tab' => 'providers', 'edit' => 'new', 'kind' => $kind])) ?>">
              ▶ ADD <?= sfy_esc(strtoupper((string)$meta['label'])) ?>
            </a>
          </div>
        <?php endforeach; ?>
      </div>

      <div class="hint mt-2">
        Already have one of these? Close this and press <b>EDIT</b> on its row — the editor asks the same questions and can
        switch a provider from one type to another without losing its name, budget or accounts.
      </div>

      <div class="modal-actions">
        <a class="btn btn-ghost" href="<?= sfy_esc($tabUrl()) ?>">CANCEL</a>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>

<?php if ($ep !== null): ?>
<div class="modal-bg show">
  <div class="modal" style="width:860px">
    <div class="modal-head">
      <h3><?= $isNew ? '&gt; ADD_PROVIDER' : '&gt; EDIT_PROVIDER #' . (int)$ep['id'] ?></h3>
      <?= sfy_badge(sfy_provider_kind_label($epKind), (string)($epMeta['tone'] ?? 'b')) ?>
      <span class="spacer" style="margin-left:auto"></span>
      <a class="btn btn-sm btn-ghost" href="<?= sfy_esc($tabUrl()) ?>">✕</a>
    </div>
    <div class="modal-body">

      <?php
      /* One heading per type, e.g. SET_UP_WORK_INK — the label with its runs of
         separators collapsed, so “Custom / other network” does not come out as
         CUSTOM__OTHER_NETWORK. */
      $epHeading = (string)preg_replace('/_+/', '_',
          strtoupper(str_replace([' ', '/', '.'], '_', (string)($epMeta['label'] ?? $epKind))));
      ?>
      <div class="card" style="margin-bottom:14px">
        <div class="card-head" style="border:0;padding:0">
          <h2>&gt; SET_UP_<?= sfy_esc(trim($epHeading, '_')) ?></h2>
          <span class="spacer"></span>
          <?= sfy_badge(sfy_provider_kind_label($epKind), (string)($epMeta['tone'] ?? 'b')) ?>
          <a class="btn btn-sm btn-ghost" href="<?= sfy_esc($tabUrl($isNew ? ['edit' => 'new'] : ['edit' => (int)$ep['id']])) ?>">
            ⇄ CHANGE TYPE
          </a>
        </div>
        <details class="sfy-more">
          <summary>SETUP STEPS</summary>
          <div class="term" style="max-height:none;font-size:11.5px;margin-top:8px">
            <?php foreach ((array)$epMeta['steps'] as $i => $line): ?>
<span class="line"><?= ($i + 1) . '. ' . $line ?></span>
            <?php endforeach; ?>
          </div>
          <div class="hint">
            A step on this provider is confirmed by <b><?= (string)$epMeta['confirmed'] ?></b>.
            <?php if (!empty($epMeta['docs'])): ?>
              Network documentation: <a href="<?= sfy_esc((string)$epMeta['docs']) ?>" target="_blank" rel="noopener">
                <?= sfy_esc((string)$epMeta['docs']) ?></a>.
            <?php endif; ?>
          </div>
        </details>

        <?php if ($epKind === 'workink'): ?>
          <div class="label mt-2">Destination to set on your Work.ink link</div>
          <div class="inline">
            <input class="grow mono" value="<?= sfy_esc(sfy_url('done')) ?>" readonly onclick="this.select()">
            <a class="btn btn-sm" href="<?= sfy_esc(sfy_url('api/hook.php?ping=1')) ?>" target="_blank"
               rel="noopener">TEST RECEIVER</a>
          </div>
          <div class="hint">Every finished Work.ink task has to land on this page — that landing, from one of the accepted
            return hosts below, is what confirms the step. Nothing else is required: Work.ink needs no Redirect API and no
            postback for the flow to work.</div>
        <?php endif; ?>

        <?php if ($epKind === 'lootlabs'): ?>
          <div class="label mt-2">Landing page LootLabs should send the player to</div>
          <div class="inline">
            <input class="grow mono" value="<?= sfy_esc(sfy_url('done')) ?>" readonly onclick="this.select()">
            <a class="btn btn-sm" href="<?= sfy_esc(sfy_url('api/hook.php?ping=1')) ?>" target="_blank"
               rel="noopener">TEST RECEIVER</a>
          </div>
          <div class="hint">Set the same destination in Admin → Accounts → Anti-bypass. With a working Redirect API key the
            handoff carries an encrypted <code>&amp;data=</code> for this URL, so a player cannot swap the landing for
            anything else.</div>
        <?php endif; ?>
      </div>

      <form method="POST">
        <?= sfy_csrf_field() ?>
        <input type="hidden" name="action" value="save_provider">
        <input type="hidden" name="id" value="<?= (int)$ep['id'] ?>">
        <input type="hidden" name="kind" value="<?= sfy_esc($epKind) ?>">

        <?php
        /* Short fields are paired two to a row; a wide field flushes the pair. */
        $pair = [];
        $flushPair = function () use (&$pair): void {
            if (!$pair) return;
            echo '<div class="grid grid-2">' . implode('', $pair) . '</div>';
            $pair = [];
        };
        foreach ($epFields as $key):
            $html = $renderField($key, $ep, $epKind);
            if ($html === '') continue;
            if (in_array($key, $epShort, true)) {
                $pair[] = $html;
                if (count($pair) === 2) $flushPair();
            } else {
                $flushPair();
                echo $html;
            }
        endforeach;
        $flushPair();
        ?>

        <?php if ($epKind === 'workink' && (int)$ep['id'] > 0 && function_exists('sfy_workink_status_label')): ?>
          <?php [$wkLabel, $wkTone, $wkHint] = sfy_workink_status_label($ep); ?>
          <hr class="sep">
          <div class="label">Work.ink key check</div>
          <div class="inline">
            <?= sfy_badge($wkLabel, $wkTone) ?>
            <span class="spacer grow"></span>
            <?php sfy_admin_post_button('⚡ TEST KEY', ['action' => 'test_provider', 'id' => (int)$ep['id']],
                  'btn btn-sm btn-gold') ?>
          </div>
          <div class="hint"><?= sfy_esc($wkHint) ?> The check asks Work.ink's token endpoint about a token this install
            invented, so the answer is about the key — never about a player. Save first if you just pasted a new one.</div>
        <?php endif; ?>

        <div class="modal-actions">
          <a class="btn btn-ghost" href="<?= sfy_esc($tabUrl()) ?>">CANCEL</a>
          <button class="btn btn-primary">SAVE PROVIDER</button>
        </div>
      </form>

      <?php if ((int)$ep['id'] > 0): ?>
        <?php $pAccounts = sfy_provider_accounts((int)$ep['id']); ?>
        <hr class="sep">
        <div class="label">Accounts on this provider (<?= count($pAccounts) ?> active)</div>
        <?php if ($pAccounts): ?>
          <div class="tbl-wrap">
            <table class="tbl">
              <thead><tr><th>#</th><th>Name</th><th>Task URL</th><th>Postback URL to paste</th></tr></thead>
              <tbody>
              <?php foreach ($pAccounts as $a): ?>
                <tr>
                  <td class="mono"><?= (int)$a['id'] ?></td>
                  <td><?= sfy_esc((string)$a['name']) ?></td>
                  <td class="mono tiny"><?= sfy_esc(sfy_short((string)$a['task_url'], 28)) ?></td>
                  <td class="mono tiny"><?= sfy_esc(sfy_short(sfy_postback_url($a, ['unique_id' => '{UNIQUE_ID}', 'nonce' => '{SUB_ID}', 'sig' => '{SIG}'], $ep), 60)) ?></td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php else: ?>
          <div class="msg warn">◆ No active account on this provider yet, so it is never offered. Every step needs a link
            to send the player to.</div>
        <?php endif; ?>
        <div class="btn-row mt-2">
          <a class="btn btn-sm btn-gold" href="<?= sfy_esc(sfy_admin_url(['tab' => 'accounts', 'edit' => 'new', 'provider' => (int)$ep['id']])) ?>">
            + ADD ACCOUNT TO <?= sfy_esc(strtoupper(sfy_provider_label($ep))) ?>
          </a>
          <a class="btn btn-sm" href="<?= sfy_esc(sfy_admin_url(['tab' => 'accounts', 'provider' => (int)$ep['id']])) ?>">
            VIEW ITS ACCOUNTS
          </a>
        </div>

        <hr class="sep">
        <?php sfy_admin_form_start(['action' => 'delete_provider', 'id' => (int)$ep['id']],
              'Delete this provider? Its accounts are kept and simply become unassigned.'); ?>
        <button class="btn btn-danger">DELETE PROVIDER</button></form>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php endif; ?>
