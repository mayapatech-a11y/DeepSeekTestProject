<?php
/** @var PDO $db */
$staff = sfy_staff_all();
$edit  = sfy_int('edit');
$es    = null;
if ($edit > 0) foreach ($staff as $s) if ((int)$s['id'] === $edit) { $es = $s; break; }
if (sfy_param('edit') === 'new') {
    $es = ['id' => 0, 'username' => '', 'display_name' => '', 'role' => 'staff', 'is_active' => 1, 'notes' => ''];
}

$roleDocs = [
    'owner'  => 'Full control: staff management, settings, updater, everything.',
    'admin'  => 'Everything except staff management — settings, updater, SQL, security.',
    'staff'  => 'Day-to-day: tokens, games, LootLabs accounts, sessions, devices, ads.',
    'viewer' => 'Read-only access to the dashboards and logs.',
];
?>
<div class="grid grid-4 mb-2">
  <?= sfy_kpi('Staff accounts', count($staff), '', count(array_filter($staff, fn($s) => (int)$s['is_active'] === 1)) . ' active') ?>
  <?= sfy_kpi('Owners', count(array_filter($staff, fn($s) => (string)$s['role'] === 'owner')), 'gold') ?>
  <?= sfy_kpi('Admins', count(array_filter($staff, fn($s) => (string)$s['role'] === 'admin')), 'blue') ?>
  <?= sfy_kpi('Locked', count(array_filter($staff, fn($s) => (int)$s['failed_attempts'] >= (int)sfy_cfg('security.max_login_attempts', 5))), 'red') ?>
</div>

<div class="card">
  <div class="card-head">
    <h2>&gt; STAFF_ACCOUNTS</h2>
    <span class="spacer"></span>
    <a class="btn btn-sm btn-gold" href="<?= sfy_esc(sfy_admin_url(['tab' => 'staff', 'edit' => 'new'])) ?>">+ ADD STAFF</a>
  </div>

  <div class="tbl-wrap">
    <table class="tbl">
      <thead><tr><th>User</th><th>Name</th><th>Role</th><th>State</th><th>Failed</th>
                 <th>Last login</th><th>Last IP</th><th>Created</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($staff as $s): $locked = (int)$s['failed_attempts'] >= (int)sfy_cfg('security.max_login_attempts', 5); ?>
        <tr>
          <td class="mono"><?= sfy_esc((string)$s['username']) ?>
            <?php if ((int)$s['id'] === (int)$me['id']): ?><span class="badge b">YOU</span><?php endif; ?></td>
          <td class="tiny"><?= sfy_esc((string)$s['display_name']) ?></td>
          <td><span class="role-pill <?= sfy_esc((string)$s['role']) ?>"><?= sfy_esc((string)$s['role']) ?></span></td>
          <td>
            <?php if (!(int)$s['is_active']) echo sfy_badge('DISABLED', 'gr');
                  elseif ($locked)          echo sfy_badge('LOCKED', 'r');
                  else                      echo sfy_badge('ACTIVE', 'g'); ?>
          </td>
          <td class="mono" style="color:<?= (int)$s['failed_attempts'] ? 'var(--red)' : 'inherit' ?>"><?= (int)$s['failed_attempts'] ?></td>
          <td class="tiny dim"><?= sfy_esc($s['last_login_at'] ? sfy_ago((string)$s['last_login_at']) : 'never') ?></td>
          <td class="mono tiny"><?= sfy_esc((string)($s['last_login_ip'] ?: '—')) ?></td>
          <td class="tiny dim"><?= sfy_esc($s['created_at'] ? sfy_ago((string)$s['created_at']) : '—') ?></td>
          <td><div class="actions">
            <a class="btn btn-sm" href="<?= sfy_esc(sfy_admin_url(['tab' => 'staff', 'edit' => (int)$s['id']])) ?>">EDIT</a>
            <?php if ((int)$s['failed_attempts'] > 0): ?>
              <?php sfy_admin_post_button('UNLOCK', ['action' => 'unlock_staff', 'id' => (int)$s['id']]) ?>
            <?php endif; ?>
            <?php if ((int)$s['id'] !== (int)$me['id']): ?>
              <?php sfy_admin_post_button((int)$s['is_active'] ? 'DISABLE' : 'ENABLE', ['action' => 'toggle_staff', 'id' => (int)$s['id']]) ?>
              <?php sfy_admin_post_button('DELETE', ['action' => 'delete_staff', 'id' => (int)$s['id']], 'btn btn-sm btn-danger', 'Delete this staff account?') ?>
            <?php endif; ?>
          </div></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$staff): ?>
        <tr><td colspan="9" class="empty">no staff accounts yet — the updater creates one from the legacy password.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="card">
  <div class="card-head"><h2>&gt; ROLES</h2></div>
  <div class="grid grid-4">
    <?php foreach ($roleDocs as $role => $doc): ?>
      <div class="kpi">
        <div class="lbl"><?= sfy_esc($role) ?></div>
        <div class="sub" style="font-size:12px;color:var(--text)"><?= sfy_esc($doc) ?></div>
      </div>
    <?php endforeach; ?>
  </div>
  <div class="hint">Staff actions are recorded in <a href="<?= sfy_esc(sfy_admin_url(['tab' => 'security'])) ?>">Security → Audit trail</a>.</div>
</div>

<?php if ($es): ?>
<div class="modal-bg show">
  <div class="modal">
    <div class="modal-head">
      <h3><?= (int)$es['id'] ? '&gt; EDIT_STAFF #' . (int)$es['id'] : '&gt; ADD_STAFF' ?></h3>
      <span class="spacer" style="margin-left:auto"></span>
      <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_admin_url(['tab' => 'staff'])) ?>">✕</a>
    </div>
    <div class="modal-body">
      <form method="POST">
        <?= sfy_csrf_field() ?>
        <input type="hidden" name="action" value="save_staff">
        <input type="hidden" name="id" value="<?= (int)$es['id'] ?>">
        <div class="grid grid-2">
          <div class="field"><label class="label">Username</label>
            <input type="text" name="username" value="<?= sfy_esc((string)$es['username']) ?>" <?= (int)$es['id'] ? 'readonly' : '' ?> required></div>
          <div class="field"><label class="label">Display name</label>
            <input type="text" name="display_name" value="<?= sfy_esc((string)$es['display_name']) ?>"></div>
          <div class="field"><label class="label">Role</label>
            <select name="role">
              <?php foreach (array_keys(sfy_roles()) as $r): ?>
                <option value="<?= sfy_esc($r) ?>" <?= (string)$es['role'] === $r ? 'selected' : '' ?>><?= sfy_esc($r) ?></option>
              <?php endforeach; ?>
            </select></div>
          <div class="field"><label class="label"><?= (int)$es['id'] ? 'New password (blank = keep)' : 'Password (min 8)' ?></label>
            <input type="password" name="password" <?= (int)$es['id'] ? '' : 'minlength="8" required' ?>></div>
        </div>
        <div class="field"><label class="label">Notes</label>
          <input type="text" name="notes" value="<?= sfy_esc((string)($es['notes'] ?? '')) ?>"></div>
        <label class="check"><input type="checkbox" name="is_active" <?= (int)$es['is_active'] ? 'checked' : '' ?>> Active</label>
        <div class="modal-actions">
          <a class="btn btn-ghost" href="<?= sfy_esc(sfy_admin_url(['tab' => 'staff'])) ?>">CANCEL</a>
          <button class="btn btn-primary">SAVE STAFF</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php endif; ?>
