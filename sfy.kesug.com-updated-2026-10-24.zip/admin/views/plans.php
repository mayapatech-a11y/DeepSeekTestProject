<?php
/** @var PDO $db */
$cfg    = sfy_pricing_config();
$plans  = $cfg['plans'];
$pays   = $cfg['payments'];
$nPlans = max(4, count($plans) + 1);
$nPays  = max(4, count($pays));
$enabled = sfy_pricing_enabled();
?>
<div class="card mb-2">
  <div class="card-head">
    <h2>&gt; PLANS_AND_PRICING</h2>
    <span class="spacer"></span>
    <?= $enabled ? sfy_badge('LIVE', 'g') : sfy_badge('OFF', 'gr') ?>
    <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_url('pricing')) ?>" target="_blank" rel="noopener">OPEN PRICING PAGE ↗</a>
  </div>
  <form method="POST" id="sfy-plans-form" action="<?= sfy_esc(sfy_url('admin/save-plans.php')) ?>">
    <?= sfy_csrf_field() ?>
    <input type="hidden" name="action" value="save_pricing">
    <input type="hidden" name="pricing_enabled" value="0">
    <div class="grid grid-2">
      <div class="field"><label class="label">Page title</label>
        <input type="text" name="pricing_title" maxlength="80" value="<?= sfy_esc((string)$cfg['title']) ?>"></div>
      <div class="field"><label class="label">Page introduction</label>
        <input type="text" name="pricing_intro" maxlength="200" value="<?= sfy_esc((string)$cfg['intro']) ?>"></div>
    </div>
    <label class="check"><input type="checkbox" name="pricing_enabled" value="1" <?= $enabled ? 'checked' : '' ?>>
      Pricing page enabled — the picker and premium buttons link here</label>

    <div class="label mt-2">Plans</div>
    <div class="tbl-wrap">
      <table class="tbl">
        <thead><tr><th>Show</th><th>Plan name</th><th>Period</th><th>Days</th><th>Price ($)</th><th>Save ($)</th><th>Note</th><th>Featured</th><th>Delete</th></tr></thead>
        <tbody>
        <?php for ($i = 0; $i < $nPlans; $i++): $p = $plans[$i] ?? ['id'=>'','name'=>'','days'=>0,'price'=>'','note'=>'','featured'=>0,'enabled'=>1]; ?>
          <tr>
            <td><label class="check"><input type="checkbox" name="plan_enabled[<?= $i ?>]" value="1" <?= !empty($p['enabled']) ? 'checked' : '' ?>></label></td>
            <td><input type="hidden" name="plan_id[<?= $i ?>]" value="<?= sfy_esc((string)($p['id'] ?? '')) ?>">
              <input type="text" name="plan_name[<?= $i ?>]" value="<?= sfy_esc((string)($p['name'] ?? '')) ?>" placeholder="7 Days"></td>
            <td><select name="plan_period[<?= $i ?>]">
              <?php foreach (sfy_pricing_periods() as $pk => $pl): ?>
                <option value="<?= sfy_esc($pk) ?>" <?= ($p['period'] ?? 'instant') === $pk ? 'selected' : '' ?>><?= sfy_esc($pl) ?></option>
              <?php endforeach; ?>
            </select></td>
            <td><input type="number" name="plan_days[<?= $i ?>]" min="0" max="3650" value="<?= (int)($p['days'] ?? 0) ?>"></td>
            <td><input type="number" name="plan_price[<?= $i ?>]" min="0" step="0.01" value="<?= sfy_esc((string)($p['price'] ?? '')) ?>"></td>
            <td><input type="number" name="plan_savings[<?= $i ?>]" min="0" step="0.01" value="<?= sfy_esc((string)($p['savings'] ?? '')) ?>"></td>
            <td><input type="text" name="plan_note[<?= $i ?>]" value="<?= sfy_esc((string)($p['note'] ?? '')) ?>" placeholder="Short line shown on the card"></td>
            <td><label class="check"><input type="checkbox" name="plan_featured[<?= $i ?>]" value="1" <?= !empty($p['featured']) ? 'checked' : '' ?>></label>
              </td>
            <td><label class="check"><input type="checkbox" name="plan_delete[<?= $i ?>]" value="1" title="Delete this plan when saving"></label></td>
          </tr>
        <?php endfor; ?>
        </tbody>
      </table>
    </div>
    <div class="hint">Leave a plan name blank to skip that row. Featured plans get the gold border and BEST VALUE flag.</div>

    <div class="label mt-2">Payment methods</div>
    <div class="tbl-wrap">
      <table class="tbl">
        <thead><tr><th>Label</th><th>Payment URL or wallet address</th><th>Note</th></tr></thead>
        <tbody>
        <?php for ($i = 0; $i < $nPays; $i++): $m = $pays[$i] ?? ['id'=>'','label'=>'','url'=>'','note'=>'']; ?>
          <tr>
            <td><input type="hidden" name="pay_id[<?= $i ?>]" value="<?= sfy_esc((string)($m['id'] ?? '')) ?>">
              <input type="text" name="pay_label[<?= $i ?>]" value="<?= sfy_esc((string)($m['label'] ?? '')) ?>" placeholder="PayPal"></td>
            <td><input type="text" name="pay_url[<?= $i ?>]" value="<?= sfy_esc((string)($m['url'] ?? '')) ?>" placeholder="https://..."></td>
            <td><input type="text" name="pay_note[<?= $i ?>]" value="<?= sfy_esc((string)($m['note'] ?? '')) ?>" placeholder="Short instruction"></td>
          </tr>
        <?php endfor; ?>
        </tbody>
      </table>
    </div>
    <div class="hint">Paste an https:// checkout link (PayPal, Binance, etc.) or a wallet address. Empty shows “setup coming soon”. These are payment instructions, not automatic checkout endpoints.</div>

    <div class="btn-row mt-2"><a class="btn btn-ghost" href="<?= sfy_esc(sfy_admin_url(['tab' => 'settings', 'section' => 'content'])) ?>">PREMIUM COPY</a></div>
    <div class="sfy-save-bar">
      <span>Changes are not live until saved.</span>
      <button class="btn btn-primary" type="submit">SAVE PLANS</button>
    </div>
  </form>
  <?php $pricingEndpoint = is_file(__DIR__ . '/../../admin/save-plans.php'); ?>
  <?php if (!$pricingEndpoint): ?>
    <div class="msg err">◆ The plan save endpoint <code>admin/save-plans.php</code> is missing from this upload. Changes cannot be saved until it is uploaded.</div>
  <?php endif; ?>
</div>