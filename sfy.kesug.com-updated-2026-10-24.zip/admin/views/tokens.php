<?php
/** @var PDO $db */
$q      = sfy_param('q');
$fGame  = sfy_param('game');
$fState = sfy_param('state');
$sort   = sfy_param('sort', 'new');
$pageNo = max(1, sfy_int('p', 1));
$per    = (int)sfy_int('per', 50);
if (!in_array($per, [25, 50, 100], true)) $per = 50;

$w = []; $p = [];
if ($q !== '')      { $w[] = "(token LIKE ? OR code LIKE ? OR notes LIKE ?)"; $p[] = "%$q%"; $p[] = "%$q%"; $p[] = "%$q%"; }
if ($fGame !== '')  { $w[] = "game_id=?"; $p[] = $fGame; }
if ($fState === 'used')   $w[] = "is_used=1";
if ($fState === 'unused') $w[] = "is_used=0";
$where = $w ? ' WHERE ' . implode(' AND ', $w) : '';

$st = $db->prepare("SELECT COUNT(*) AS n FROM sfy_tokens$where");
$st->execute($p);
$total = (int)($st->fetch()['n'] ?? 0);

$orders = [
    'new'   => 'created_at DESC, token ASC',
    'old'   => 'created_at ASC, token ASC',
    'token' => 'token ASC',
    'used'  => 'is_used DESC, used_at DESC',
    'tasks' => 'tasks_required DESC, created_at DESC',
    'game'  => 'game_id ASC, created_at DESC',
];
$order = $orders[$sort] ?? $orders['new'];
$st = $db->prepare("SELECT * FROM sfy_tokens$where ORDER BY $order LIMIT $per OFFSET " . (($pageNo - 1) * $per));
$st->execute($p);
$tokens = $st->fetchAll();

$usedAll   = (int)$db->query("SELECT COUNT(*) AS n FROM sfy_tokens WHERE is_used=1")->fetch()['n'];
$unusedAll = (int)$db->query("SELECT COUNT(*) AS n FROM sfy_tokens WHERE is_used=0")->fetch()['n'];

$games = $db->query("SELECT game_id, game_name FROM sfy_games ORDER BY game_id")->fetchAll();
$chainDefault = (string)sfy_setting('default_account_chain', '1,2');

/* The install-wide policy decides whether a USED row is actually dead. */
$reuseAll = sfy_token_reuse_mode() === 'open';

$edit = sfy_param('edit');
$et   = null;
if ($edit === 'new') {
    $et = ['token' => '', 'code' => '', 'game_id' => '', 'game_name' => '', 'tasks_required' => sfy_setting_int('default_tasks_required', 2),
           'account_chain' => $chainDefault, 'is_used' => 0, 'max_runs' => 50, 'max_devices' => 1,
           'multi_use' => 0, 'is_hidden' => 0, 'expires_at' => '', 'notes' => ''];
} elseif ($edit !== '') {
    $st = $db->prepare("SELECT * FROM sfy_tokens WHERE token=? LIMIT 1");
    $st->execute([$edit]);
    $et = $st->fetch() ?: null;
}
?>
<div class="grid grid-4 mb-2">
  <?= sfy_kpi('Tokens', number_format($total), '', 'matching filters') ?>
  <?= sfy_kpi('Used', number_format($usedAll), 'orange', 'marked used') ?>
  <?= sfy_kpi('Unused', number_format($unusedAll), 'green', 'ready to claim') ?>
  <?= sfy_kpi('Games', number_format(count($games)), 'blue', 'catalogued') ?>
</div>

<div class="card mb-2">
  <div class="card-head">
    <h2>&gt; BULK_UPDATE_TOKENS</h2>
    <span class="spacer"></span>
    <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_admin_url(['tab' => 'settings', 'section' => 'content'])) ?>">CHECKPOINT LABELS</a>
  </div>
  <form method="POST" data-confirm="Apply these values to the selected token scope?">
    <?= sfy_csrf_field() ?>
    <input type="hidden" name="action" value="bulk_update_tokens">
    <input type="hidden" name="q" value="<?= sfy_esc($q) ?>">
    <input type="hidden" name="game" value="<?= sfy_esc($fGame) ?>">
    <input type="hidden" name="state" value="<?= sfy_esc($fState) ?>">
    <div class="grid grid-4">
      <div class="field"><label class="label">Apply to</label>
        <select name="bulk_scope">
          <option value="all">All tokens</option>
          <option value="unused">Unused only</option>
          <option value="used">Used only</option>
          <option value="filtered">Current filter</option>
        </select></div>
      <div class="field"><label class="label">Account chain</label>
        <input type="text" name="bulk_account_chain" placeholder="blank = keep" maxlength="191"></div>
      <div class="field"><label class="label">Tasks required</label>
        <input type="number" name="bulk_tasks" min="1" max="20" placeholder="blank = keep"></div>
      <div class="field"><label class="label">Max runs</label>
        <input type="number" name="bulk_max_runs" min="1" max="10000" placeholder="blank = keep"></div>
      <div class="field"><label class="label">Max devices</label>
        <input type="number" name="bulk_max_devices" min="0" max="100" placeholder="blank = keep"></div>
      <div class="field" style="display:flex;align-items:flex-end">
        <button class="btn btn-primary btn-block">APPLY TO TOKENS</button></div>
    </div>
    <div class="hint">Only filled fields change. Account chain is the comma-separated account IDs. Existing sessions keep the task count they started with — start a new run for the new value.</div>
  </form>
</div>

<div class="card">
  <div class="card-head">
    <h2>&gt; TOKEN_MANAGEMENT</h2>
    <span class="spacer"></span>
    <span class="badge gr"><?= number_format($total) ?> TOTAL</span>
    <a class="btn btn-sm btn-gold" href="<?= sfy_esc(sfy_admin_url(['tab' => 'tokens', 'edit' => 'new'])) ?>">+ NEW TOKEN</a>
  </div>

  <?php if ($reuseAll): ?>
    <div class="msg warn" style="margin-bottom:12px">
      ◆ <b>Used-token policy: OPEN.</b> A token marked <b>USED</b> below still works — anyone holding the link runs
      the tasks again and gets their own code, so the badge is a record, not a dead link. Switch it to HANDOFF in
      <a href="<?= sfy_esc(sfy_admin_url(['tab' => 'settings'])) ?>">Settings</a> if a finished token should stop accepting
      new claims.
    </div>
  <?php else: ?>
    <div class="msg info">
      ◆ <b>Used-token policy: HANDOFF.</b> A token marked <b>USED</b> below no longer accepts a new claim: it only
      hands its code back inside the code window, then says it is finished. Tick <b>Reusable</b> on a token — or switch
      the policy to OPEN in <a href="<?= sfy_esc(sfy_admin_url(['tab' => 'settings'])) ?>">Settings</a> — to keep finished links working.
    </div>
  <?php endif; ?>

  <form method="GET" class="inline mb-2">
    <input type="hidden" name="tab" value="tokens">
    <input class="grow" type="search" name="q" value="<?= sfy_esc($q) ?>" placeholder="search token / code / notes">
    <select name="game" style="max-width:200px">
      <option value="">All games</option>
      <?php foreach ($games as $g): ?>
        <option value="<?= sfy_esc((string)$g['game_id']) ?>" <?= $fGame === (string)$g['game_id'] ? 'selected' : '' ?>>
          <?= sfy_esc((string)$g['game_id']) ?><?= $g['game_name'] ? ' — ' . sfy_esc(sfy_short((string)$g['game_name'], 18)) : '' ?>
        </option>
      <?php endforeach; ?>
    </select>
    <select name="state" style="max-width:150px">
      <option value="">Any status</option>
      <option value="unused" <?= $fState === 'unused' ? 'selected' : '' ?>>Unused</option>
      <option value="used" <?= $fState === 'used' ? 'selected' : '' ?>>Used</option>
    </select>
    <select name="sort" style="max-width:170px">
      <?php foreach (['new' => 'Newest first', 'old' => 'Oldest first', 'token' => 'Token A–Z', 'used' => 'Used first', 'tasks' => 'Most tasks', 'game' => 'Game A–Z'] as $k => $lbl): ?>
        <option value="<?= $k ?>" <?= $sort === $k ? 'selected' : '' ?>><?= sfy_esc($lbl) ?></option>
      <?php endforeach; ?>
    </select>
    <select name="per" style="max-width:100px" onchange="this.form.submit()">
      <?php foreach ([25, 50, 100] as $n): ?><option value="<?= $n ?>" <?= $per === $n ? 'selected' : '' ?>><?= $n ?>/page</option><?php endforeach; ?>
    </select>
    <button class="btn">FILTER</button>
    <a class="btn btn-ghost" href="<?= sfy_esc(sfy_admin_url(['tab' => 'tokens'])) ?>">RESET</a>
  </form>

  <?php if (!$tokens): ?>
    <div class="empty">&gt; no tokens matched. Generate some below or import SQL.</div>
  <?php else: ?>
    <div class="tbl-wrap">
      <table class="tbl">
        <thead>
          <tr><th>Token</th><th>Code</th><th>Game</th><th>Chain</th><th>Tasks</th><th>Runs</th>
              <th>Devices</th><th>Status</th><th>Created</th><th>Actions</th></tr>
        </thead>
        <tbody>
        <?php foreach ($tokens as $t): ?>
          <tr>
            <td class="mono"><?= sfy_esc((string)$t['token']) ?></td>
            <td class="mono" style="color:var(--gold)"><?= sfy_esc((string)$t['code']) ?></td>
            <td class="tiny"><?= sfy_esc((string)($t['game_id'] ?: '—')) ?></td>
            <td class="mono tiny"><?= sfy_esc((string)($t['account_chain'] ?: '—')) ?></td>
            <td class="mono"><?= (int)$t['tasks_required'] ?></td>
            <td class="mono tiny"><?= (int)$t['run_count'] ?>/<?= (int)$t['max_runs'] ?></td>
            <td class="mono tiny"><?= (int)($t['max_devices'] ?? 1) ?></td>
            <td>
              <?php
              /* A reusable token is never really "used up", so it must not look
                 like one — and a hidden token is marked so nobody wonders why
                 it is missing from the public counters. */
              $isMulti = (int)($t['multi_use'] ?? 0) === 1;
              ?>
              <?= $isMulti ? sfy_badge('REUSABLE', 'y')
                           : ((int)$t['is_used'] ? sfy_badge('USED', 'r') : sfy_badge('UNUSED', 'g')) ?>
              <?= (int)($t['is_hidden'] ?? 0) === 1 ? sfy_badge('HIDDEN', 'gr') : '' ?>
            </td>
            <td class="tiny dim"><?= sfy_esc(sfy_ago((string)$t['created_at'])) ?></td>
            <td>
              <div class="actions">
                <a class="btn btn-sm" href="<?= sfy_esc(sfy_admin_url(['tab' => 'tokens', 'edit' => (string)$t['token']])) ?>">EDIT</a>
                <?php if ((int)$t['is_used']): ?>
                  <?php sfy_admin_post_button('RESET', ['action' => 'reset_token', 'token' => (string)$t['token']]) ?>
                <?php else: ?>
                  <?php sfy_admin_post_button('MARK USED', ['action' => 'toggle_token', 'token' => (string)$t['token']]) ?>
                <?php endif; ?>
                <?php sfy_admin_post_button('DELETE', ['action' => 'delete_token', 'token' => (string)$t['token']], 'btn btn-sm btn-danger', 'Delete this token?') ?>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <?php
    $pages = max(1, (int)ceil($total / $per));
    $base = ['tab' => 'tokens', 'q' => $q, 'game' => $fGame, 'state' => $fState, 'sort' => $sort, 'per' => $per];
    if ($pages > 1): ?>
      <div class="sfy-pager">
        <span class="mute tiny mono"><?= number_format(($pageNo - 1) * $per + 1) ?>–<?= number_format(min($total, $pageNo * $per)) ?> of <?= number_format($total) ?></span>
        <span class="spacer"></span>
        <?php if ($pageNo > 1): ?><a class="btn btn-sm" href="<?= sfy_esc(sfy_admin_url($base + ['p' => 1])) ?>">«</a>
          <a class="btn btn-sm" href="<?= sfy_esc(sfy_admin_url($base + ['p' => $pageNo - 1])) ?>">‹</a><?php endif; ?>
        <?php for ($i = max(1, $pageNo - 2); $i <= min($pages, $pageNo + 2); $i++): ?>
          <a class="btn btn-sm <?= $i === $pageNo ? 'btn-primary' : '' ?>" href="<?= sfy_esc(sfy_admin_url($base + ['p' => $i])) ?>"><?= $i ?></a>
        <?php endfor; ?>
        <?php if ($pageNo < $pages): ?><a class="btn btn-sm" href="<?= sfy_esc(sfy_admin_url($base + ['p' => $pageNo + 1])) ?>">›</a>
          <a class="btn btn-sm" href="<?= sfy_esc(sfy_admin_url($base + ['p' => $pages])) ?>">»</a><?php endif; ?>
      </div>
    <?php endif; ?>
  <?php endif; ?>
</div>

<div class="card">
  <div class="card-head"><h2>&gt; BULK_GENERATOR</h2></div>
  <form method="POST" class="grid grid-4">
    <?= sfy_csrf_field() ?>
    <input type="hidden" name="action" value="bulk_tokens">
    <div class="field"><label class="label">How many</label><input type="number" name="count" value="10" min="1" max="500"></div>
    <div class="field"><label class="label">Prefix</label><input type="text" name="prefix" value="SFY"></div>
    <div class="field"><label class="label">Tasks required</label><input type="number" name="tasks_required" value="<?= sfy_setting_int('default_tasks_required', 2) ?>" min="1" max="20"></div>
    <div class="field"><label class="label">Account chain</label><input type="text" name="account_chain" value="<?= sfy_esc($chainDefault) ?>" placeholder="1,2"></div>
    <div class="field"><label class="label">Game ID</label><input type="text" name="game_id" placeholder="optional"></div>
    <div class="field"><label class="label">Game name</label><input type="text" name="game_name" placeholder="optional"></div>
    <div class="field"><label class="label">Expires at</label><input type="datetime-local" name="expires_at"></div>
    <div class="field" style="display:flex;align-items:flex-end">
      <button class="btn btn-primary btn-block">GENERATE TOKENS</button>
    </div>
  </form>
  <div class="hint">Each token gets a random 8-character code. Used tokens can be purged from the top-right of the table.</div>
</div>

<?php if ($et !== null): ?>
<div class="modal-bg show">
  <div class="modal">
    <div class="modal-head">
      <h3><?= $edit === 'new' ? '&gt; CREATE_TOKEN' : '&gt; EDIT_TOKEN' ?></h3>
      <span class="spacer" style="margin-left:auto"></span>
      <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_admin_url(['tab' => 'tokens'])) ?>">✕</a>
    </div>
    <div class="modal-body">
      <form method="POST">
        <?= sfy_csrf_field() ?>
        <input type="hidden" name="action" value="save_token">
        <div class="grid grid-2">
          <div class="field"><label class="label">Token <?= $edit === 'new' ? '(blank = auto)' : '' ?></label>
            <input type="text" name="token" value="<?= sfy_esc((string)$et['token']) ?>" <?= $edit === 'new' ? '' : 'readonly' ?>></div>
          <div class="field"><label class="label">Access code (blank = auto)</label>
            <input type="text" name="code" value="<?= sfy_esc((string)$et['code']) ?>"></div>
          <div class="field"><label class="label">Game ID</label>
            <input type="text" name="game_id" value="<?= sfy_esc((string)$et['game_id']) ?>"></div>
          <div class="field"><label class="label">Game name</label>
            <input type="text" name="game_name" value="<?= sfy_esc((string)($et['game_name'] ?? '')) ?>"></div>
          <div class="field"><label class="label">Tasks required</label>
            <input type="number" name="tasks_required" value="<?= (int)$et['tasks_required'] ?>" min="1" max="20">
            <div class="hint">This token's own step count. It overrides Default tasks. Existing sessions keep the count they started with — create a new run after changing this.</div></div>
          <div class="field"><label class="label">Account chain</label>
            <input type="text" name="account_chain" value="<?= sfy_esc((string)$et['account_chain']) ?>"></div>
          <div class="field"><label class="label">Max runs</label>
            <input type="number" name="max_runs" value="<?= (int)$et['max_runs'] ?>" min="1"></div>
          <div class="field"><label class="label">Max devices</label>
            <input type="number" name="max_devices" value="<?= (int)($et['max_devices'] ?? 1) ?>" min="0"></div>
          <div class="field"><label class="label">Expires at</label>
            <input type="datetime-local" name="expires_at" value="<?= sfy_esc($et['expires_at'] ? date('Y-m-d\TH:i', strtotime((string)$et['expires_at'])) : '') ?>"></div>
          <div class="field"><label class="label">Status</label>
            <select name="is_used">
              <option value="0" <?= !(int)$et['is_used'] ? 'selected' : '' ?>>Unused</option>
              <option value="1" <?= (int)$et['is_used'] ? 'selected' : '' ?>>Used</option>
            </select></div>
        </div>

        <?php /*
                 Two delivery rules, both off by default so nothing about the
                 existing behaviour changes until they are ticked.
               */ ?>
        <div class="grid grid-2">
          <div class="field"><label class="label">Reusable (multi-use)</label>
            <label class="check"><input type="checkbox" name="multi_use" value="1"
              <?= (int)($et['multi_use'] ?? 0) ? 'checked' : '' ?>>
              <span>Anyone with this link gets the code, again and again</span></label>
            <div class="hint">The token is never blocked as “already used”, and it never counts as being in use
              by somebody else — so many players can run it at the same time. Only needed when the used-token policy in
              <b>Settings</b> is HANDOFF; under the default OPEN policy every token already behaves this way.</div></div>
          <div class="field"><label class="label">Hidden</label>
            <label class="check"><input type="checkbox" name="is_hidden" value="1"
              <?= (int)($et['is_hidden'] ?? 0) ? 'checked' : '' ?>>
              <span>Keep it out of public counters and listings</span></label>
            <div class="hint">For private, staff or test tokens: the link still works, it is just not counted or
              shown to visitors.</div></div>
        </div>
        <div class="field"><label class="label">Notes</label>
          <input type="text" name="notes" value="<?= sfy_esc((string)($et['notes'] ?? '')) ?>"></div>
        <div class="modal-actions">
          <a class="btn btn-ghost" href="<?= sfy_esc(sfy_admin_url(['tab' => 'tokens'])) ?>">CANCEL</a>
          <button class="btn btn-primary">SAVE TOKEN</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php endif; ?>
