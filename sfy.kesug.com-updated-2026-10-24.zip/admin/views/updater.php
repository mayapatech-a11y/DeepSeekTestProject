<?php
/** @var PDO $db */
$status  = sfy_schema_status();
$pending = $status['pending'];
$applied = $status['applied'];
$log     = $updaterLog ?? null;

$expected = array_keys(sfy_definitions());
$missing  = [];
foreach ($expected as $t) if (!isset($status['tables'][$t])) $missing[] = $t;
$colProblems = sfy_schema_column_report();
$colCount    = 0;
foreach ($colProblems as $r) $colCount += count($r['missing']);

$phpOk   = version_compare(PHP_VERSION, '8.0.0', '>=');
$curlOk  = function_exists('curl_init');
$storeOk = is_dir(SFY_ROOT . '/storage') && is_writable(SFY_ROOT . '/storage');
?>
<div class="grid grid-4 mb-2">
  <?= sfy_kpi('Schema installed', $status['current'], '', 'latest ' . $status['latest']) ?>
  <?= sfy_kpi('Pending updates', count($pending), count($pending) ? 'orange' : '', count($pending) ? 'run the updater' : 'all applied') ?>
  <?= sfy_kpi('Tables', count($status['tables']), 'blue') ?>
  <?= sfy_kpi('App version', $status['version'], 'gold') ?>
</div>

<div class="card">
  <div class="card-head">
    <h2>&gt; DATABASE_UPDATER</h2>
    <span class="spacer"></span>
    <?php sfy_admin_post_button('⬆ RUN UPDATER', ['action' => 'run_updater'], 'btn btn-sm btn-primary', 'Apply every pending database update?') ?>
    <?php sfy_admin_post_button('⟳ REPAIR SCHEMA', ['action' => 'repair_schema'], 'btn btn-sm', 'Re-check and repair every migration (no data is dropped)?') ?>
    <?php sfy_admin_post_button('🧹 MAINTENANCE', ['action' => 'run_maintenance'], 'btn btn-sm') ?>
  </div>

  <div class="term" style="max-height:none;font-size:11.5px">
&gt; migrations are additive only — nothing here ever drops or truncates a table
&gt; apply the updater after every upload so new columns, tables and indexes exist
&gt; schema <?= sfy_esc($status['current']) ?> → <?= sfy_esc($status['latest']) ?><?= $pending ? ' (' . count($pending) . ' pending)' : ' (up to date)' ?>

&gt; missing tables: <?= $missing ? sfy_esc(implode(', ', $missing)) : 'none' ?>
  </div>

  <?php if ($log !== null): ?>
    <div class="label mt-2">Last run output</div>
    <div class="term" style="max-height:none;font-size:11.5px">
    <?php foreach ($log as $l): ?>
&gt; [<?= $l['status'] === 'ok' ? 'OK' : 'FAIL' ?>] <?= sfy_esc($l['id']) ?> <?= sfy_esc($l['title']) ?>

<?php foreach ($l['notes'] as $n): ?>      · <?= sfy_esc((string)$n) ?>

<?php endforeach; ?>
    <?php endforeach; ?>
<?php if (!$log): ?>&gt; nothing to do — database already at version <?= sfy_esc($status['current']) ?>

<?php endif; ?>
    </div>
  <?php endif; ?>
</div>

<div class="card mb-2">
  <div class="card-head">
    <h2>&gt; SCHEMA_DIAGNOSTIC</h2>
    <span class="spacer"></span>
    <span class="badge <?= $colCount === 0 ? 'g' : 'r' ?>"><?= $colCount === 0 ? 'EVERY COLUMN PRESENT' : $colCount . ' COLUMN(S) MISSING' ?></span>
  </div>
  <?php if ($colCount === 0): ?>
    <div class="msg ok">✔ All <?= count($expected) ?> managed tables and their columns are in place.</div>
  <?php else: ?>
    <div class="msg err">✖ Some tables are incomplete — this is what makes pages return a server error. Run the updater
      (or Repair schema) to add the missing pieces.</div>
    <div class="tbl-wrap"><table class="tbl">
      <thead><tr><th>Table</th><th>Problem</th><th>Missing columns</th></tr></thead>
      <tbody>
      <?php foreach ($colProblems as $table => $r): ?>
        <tr>
          <td class="mono"><?= sfy_esc((string)$table) ?></td>
          <td><?= $r['missing_table'] ? sfy_badge('TABLE MISSING', 'r') : sfy_badge('INCOMPLETE', 'y') ?></td>
          <td class="mono tiny"><?= sfy_esc(implode(', ', array_slice($r['missing'], 0, 14))) ?><?= count($r['missing']) > 14 ? ' …' : '' ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <div class="btn-row mt-2">
      <?php sfy_admin_post_button('⟳ FIX NOW (REPAIR SCHEMA)', ['action' => 'repair_schema'], 'btn btn-gold') ?>
    </div>
  <?php endif; ?>
</div>

<div class="grid grid-2 mb-2">
  <div class="card">
    <div class="card-head"><h2>&gt; <?= $pending ? 'PENDING_UPDATES' : 'ALL_UPDATES_APPLIED' ?></h2></div>
    <?php if (!$pending): ?>
      <div class="msg ok">✔ Database is fully up to date (version <?= sfy_esc($status['current']) ?>).</div>
    <?php else: ?>
      <div class="tbl-wrap"><table class="tbl" style="min-width:0">
        <thead><tr><th>ID</th><th>Update</th></tr></thead>
        <tbody>
        <?php foreach ($pending as $id => $m): ?>
          <tr>
            <td class="mono"><?= sfy_esc($id) ?></td>
            <td class="tiny"><?= sfy_esc((string)$m['title']) ?>
              <?php if (isset($applied[$id]) && $applied[$id]['status'] === 'failed'): ?>
                <br><span class="badge r">FAILED</span>
                <span class="mute"><?= sfy_esc(sfy_short((string)$applied[$id]['notes'], 90)) ?></span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
    <?php endif; ?>
  </div>

  <div class="card">
    <div class="card-head"><h2>&gt; ENVIRONMENT</h2></div>
    <div class="tbl-wrap"><table class="tbl" style="min-width:0">
      <tbody>
        <tr><td class="dim">PHP version</td><td class="mono"><?= sfy_esc(PHP_VERSION) ?> <?= sfy_badge($phpOk ? 'OK' : 'TOO OLD', $phpOk ? 'g' : 'r') ?></td></tr>
        <tr><td class="dim">cURL (LootLabs API)</td><td><?= sfy_badge($curlOk ? 'AVAILABLE' : 'MISSING', $curlOk ? 'g' : 'r') ?></td></tr>
        <tr><td class="dim">storage/ writable</td><td><?= sfy_badge($storeOk ? 'WRITABLE' : 'NOT WRITABLE', $storeOk ? 'g' : 'y') ?></td></tr>
        <tr><td class="dim">Debug mode</td><td><?= sfy_badge(SFY_DEBUG ? 'ON' : 'OFF', SFY_DEBUG ? 'y' : 'g') ?></td></tr>
        <tr><td class="dim">Timezone</td><td class="mono"><?= sfy_esc(date_default_timezone_get()) ?></td></tr>
        <tr><td class="dim">Server time</td><td class="mono"><?= date('Y-m-d H:i:s') ?></td></tr>
        <tr><td class="dim">MySQL</td><td class="mono"><?= sfy_esc((string)$db->getAttribute(PDO::ATTR_SERVER_VERSION)) ?></td></tr>
        <tr><td class="dim">DB name</td><td class="mono"><?= sfy_esc(SFY_DB_NAME) ?></td></tr>
      </tbody>
    </table></div>
    <?php if (SFY_DEBUG): ?>
      <div class="msg warn mt-2">◆ Debug mode is ON — set <code>app.debug</code> to false in config/config.php before going live.</div>
    <?php endif; ?>
  </div>
</div>

<div class="card mb-2">
  <div class="card-head"><h2>&gt; MIGRATION_HISTORY</h2></div>
  <div class="tbl-wrap"><table class="tbl">
    <thead><tr><th>ID</th><th>Update</th><th>Status</th><th>Applied</th><th>Duration</th><th>Notes</th></tr></thead>
    <tbody>
    <?php foreach (sfy_migrations() as $id => $m): $a = $applied[$id] ?? null; ?>
      <tr>
        <td class="mono"><?= sfy_esc($id) ?></td>
        <td class="tiny"><?= sfy_esc((string)$m['title']) ?></td>
        <td><?= $a ? sfy_badge(strtoupper((string)$a['status']), $a['status'] === 'ok' ? 'g' : 'r') : sfy_badge('PENDING', 'y') ?></td>
        <td class="tiny dim"><?= sfy_esc((string)($a['applied_at'] ?? '—')) ?></td>
        <td class="mono tiny"><?= $a ? (int)$a['duration_ms'] . 'ms' : '—' ?></td>
        <td class="tiny mute"><?= sfy_esc(sfy_short((string)($a['notes'] ?? ''), 110)) ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
</div>

<div class="card mb-2">
  <div class="card-head">
    <h2>&gt; ERROR_LOG</h2>
    <span class="spacer"></span>
    <?php $logSize = sfy_log_size(); ?>
    <span class="badge <?= $logSize > 0 ? 'y' : 'g' ?>"><?= number_format($logSize) ?> BYTES</span>
    <?php if ($logSize > 0): sfy_admin_post_button('CLEAR LOG', ['action' => 'clear_error_log'], 'btn btn-sm btn-danger', 'Delete the server error log?'); endif; ?>
  </div>
  <p class="hint mt-0">Anything PHP or the database complained about lands here — this is the first place to look when a page
    returns a server error. The file lives at <code>storage/php-errors.log</code> and is never web-readable.</p>
  <?php $logTail = sfy_log_tail(80); ?>
  <?php if ($logTail === ''): ?>
    <div class="msg ok">✔ No errors logged.</div>
  <?php else: ?>
    <pre class="term" style="max-height:340px;font-size:11px;white-space:pre-wrap;color:var(--text)"><?= sfy_esc($logTail) ?></pre>
  <?php endif; ?>
</div>

<div class="card">
  <div class="card-head"><h2>&gt; TABLES</h2></div>
  <div class="tbl-wrap"><table class="tbl">
    <thead><tr><th>Table</th><th>Est. rows</th><th>Expected by this version</th><th>Status</th></tr></thead>
    <tbody>
    <?php foreach ($status['tables'] as $name => $rows): ?>
      <tr>
        <td class="mono"><?= sfy_esc((string)$name) ?></td>
        <td class="mono"><?= number_format((int)$rows) ?></td>
        <td><?= in_array($name, $expected, true) ? 'yes' : '<span class="mute">legacy</span>' ?></td>
        <td><?= in_array($name, $expected, true) ? sfy_badge('MANAGED', 'g') : sfy_badge('UNTRACKED', 'gr') ?></td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>
