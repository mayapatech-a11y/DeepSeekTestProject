<?php
/** @var PDO $db */
$q      = sfy_param('q');
$fPlace = sfy_param('placement');
$ads    = sfy_ads_all($q, $fPlace);
$stats  = sfy_ads_stats();
$byP    = sfy_ads_by_placement();

$edit = sfy_param('edit');
$ea   = null;
if ($edit === 'new') {
    $ea = ['id' => 0, 'title' => '', 'body' => '', 'image_url' => '', 'target_url' => '', 'button_text' => 'Open',
           'placement' => 'banner', 'pages' => 'all', 'theme_color' => '#3BF5D0', 'is_active' => 1,
           'is_dismissible' => 1, 'sort_order' => 0, 'start_at' => '', 'end_at' => '', 'max_impressions' => 0];
} elseif ($edit !== '') {
    $ea = sfy_ad_find((int)$edit);
}
$eaPages = $ea ? array_filter(array_map('trim', explode(',', (string)$ea['pages']))) : ['all'];
?>
<div class="grid grid-4 mb-2">
  <?= sfy_kpi('Ads', $stats['total'], '', $stats['active'] . ' active') ?>
  <?= sfy_kpi('Impressions', number_format($stats['impressions']), 'blue') ?>
  <?= sfy_kpi('Clicks', number_format($stats['clicks']), 'gold', $stats['ctr'] . '% CTR') ?>
  <?= sfy_kpi('Dismissals', number_format($stats['dismissals']), 'orange') ?>
</div>

<div class="card">
  <div class="card-head">
    <h2>&gt; AD_PLACEMENTS</h2>
    <span class="spacer"></span>
    <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_admin_url(['tab' => 'plans'])) ?>">PLANS &amp; PRICING</a>
    <a class="btn btn-sm btn-gold" href="<?= sfy_esc(sfy_admin_url(['tab' => 'ads', 'edit' => 'new'])) ?>">+ NEW AD</a>
    <?php sfy_admin_post_button('RESET STATS', ['action' => 'reset_ad_stats', 'id' => 0], 'btn btn-sm btn-danger', 'Reset impression/click counters for every ad?') ?>
  </div>

  <div class="grid grid-4 mb-2">
    <?php foreach (sfy_ad_placements() as $key => $label): ?>
      <?php $row = null; foreach ($byP as $b) if ((string)$b['placement'] === $key) { $row = $b; break; } ?>
      <a class="kpi" style="text-decoration:none" href="<?= sfy_esc(sfy_admin_url(['tab' => 'ads', 'placement' => $key])) ?>">
        <div class="lbl"><?= sfy_esc($key) ?></div>
        <div class="val"><?= (int)($row['n'] ?? 0) ?></div>
        <div class="sub"><?= (int)($row['impressions'] ?? 0) ?> imp · <?= (int)($row['clicks'] ?? 0) ?> clicks</div>
      </a>
    <?php endforeach; ?>
  </div>

  <form method="GET" class="inline mb-2">
    <input type="hidden" name="tab" value="ads">
    <input class="grow" type="search" name="q" value="<?= sfy_esc($q) ?>" placeholder="search title / body / link">
    <select name="placement" style="max-width:220px">
      <option value="">All placements</option>
      <?php foreach (sfy_ad_placements() as $key => $label): ?>
        <option value="<?= sfy_esc($key) ?>" <?= $fPlace === $key ? 'selected' : '' ?>><?= sfy_esc($label) ?></option>
      <?php endforeach; ?>
    </select>
    <button class="btn">FILTER</button>
    <a class="btn btn-ghost" href="<?= sfy_esc(sfy_admin_url(['tab' => 'ads'])) ?>">RESET</a>
  </form>

  <?php if (!$ads): ?>
    <div class="empty">&gt; no ads yet. Ads show on the landing page, claim page, task page and code page.</div>
  <?php else: ?>
    <div class="tbl-wrap">
      <table class="tbl">
        <thead><tr><th>ID</th><th>Title</th><th>Placement</th><th>Pages</th><th>Window</th>
                   <th>Impr.</th><th>Clicks</th><th>CTR</th><th>Dismiss</th><th>State</th><th>Actions</th></tr></thead>
        <tbody>
        <?php foreach ($ads as $a):
          $imp = (int)$a['impressions']; $clk = (int)$a['clicks'];
          $ctr = $imp > 0 ? round($clk / $imp * 100, 1) : 0; ?>
          <tr>
            <td class="mono"><?= (int)$a['id'] ?></td>
            <td>
              <div><?= sfy_esc(sfy_short((string)$a['title'], 34)) ?></div>
              <div class="tiny mute"><?= sfy_esc(sfy_short((string)($a['body'] ?? ''), 42)) ?></div>
            </td>
            <td><span class="badge p"><?= sfy_esc((string)$a['placement']) ?></span></td>
            <td class="tiny"><?= sfy_esc((string)$a['pages']) ?></td>
            <td class="tiny dim">
              <?= sfy_esc($a['start_at'] ? date('m/d H:i', strtotime((string)$a['start_at'])) : '—') ?> →
              <?= sfy_esc($a['end_at'] ? date('m/d H:i', strtotime((string)$a['end_at'])) : '—') ?>
              <?php if ((int)$a['max_impressions'] > 0): ?><br>cap <?= (int)$a['max_impressions'] ?><?php endif; ?>
            </td>
            <td class="mono"><?= number_format($imp) ?></td>
            <td class="mono"><?= number_format($clk) ?></td>
            <td class="mono"><?= $ctr ?>%</td>
            <td class="mono"><?= number_format((int)$a['dismissals']) ?></td>
            <td><?= (int)$a['is_active'] ? sfy_badge('LIVE', 'g') : sfy_badge('PAUSED', 'gr') ?></td>
            <td><div class="actions">
              <a class="btn btn-sm" href="<?= sfy_esc(sfy_admin_url(['tab' => 'ads', 'edit' => (int)$a['id']])) ?>">EDIT</a>
              <?php sfy_admin_post_button((int)$a['is_active'] ? 'PAUSE' : 'ACTIVATE', ['action' => 'toggle_ad', 'id' => (int)$a['id']]) ?>
              <?php sfy_admin_post_button('DEL', ['action' => 'delete_ad', 'id' => (int)$a['id']], 'btn btn-sm btn-danger', 'Delete this ad?') ?>
            </div></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php if ($ea): ?>
<div class="modal-bg show">
  <div class="modal" style="width:820px">
    <div class="modal-head">
      <h3><?= $ea['id'] ? '&gt; EDIT_AD #' . (int)$ea['id'] : '&gt; NEW_AD' ?></h3>
      <span class="spacer" style="margin-left:auto"></span>
      <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_admin_url(['tab' => 'ads'])) ?>">✕</a>
    </div>
    <div class="modal-body">
      <form method="POST">
        <?= sfy_csrf_field() ?>
        <input type="hidden" name="action" value="save_ad">
        <input type="hidden" name="id" value="<?= (int)$ea['id'] ?>">

        <div class="grid grid-2">
          <div class="field"><label class="label">Title</label>
            <input type="text" name="title" value="<?= sfy_esc((string)$ea['title']) ?>" required></div>
          <div class="field"><label class="label">Button text</label>
            <input type="text" name="button_text" value="<?= sfy_esc((string)($ea['button_text'] ?? 'Open')) ?>"></div>
        </div>

        <div class="field"><label class="label">Body text</label>
          <textarea name="body" style="min-height:80px"><?= sfy_esc((string)($ea['body'] ?? '')) ?></textarea></div>

        <div class="grid grid-2">
          <div class="field"><label class="label">Image URL (optional)</label>
            <input type="text" name="image_url" value="<?= sfy_esc((string)($ea['image_url'] ?? '')) ?>"></div>
          <div class="field"><label class="label">Target URL</label>
            <input type="text" name="target_url" value="<?= sfy_esc((string)($ea['target_url'] ?? '')) ?>"></div>
        </div>

        <div class="grid grid-2">
          <div class="field"><label class="label">Placement</label>
            <select name="placement">
              <?php foreach (sfy_ad_placements() as $key => $label): ?>
                <option value="<?= sfy_esc($key) ?>" <?= (string)$ea['placement'] === $key ? 'selected' : '' ?>><?= sfy_esc($label) ?></option>
              <?php endforeach; ?>
            </select></div>
          <div class="field"><label class="label">Accent colour</label>
            <input type="text" name="theme_color" value="<?= sfy_esc((string)$ea['theme_color']) ?>" placeholder="#3BF5D0"></div>
        </div>

        <div class="field">
          <label class="label">Show on pages</label>
          <div class="btn-row">
            <?php foreach (sfy_ad_pages() as $key => $label): ?>
              <label class="check" style="margin-top:0">
                <input type="checkbox" name="pages[]" value="<?= sfy_esc($key) ?>" <?= in_array($key, $eaPages, true) ? 'checked' : '' ?>>
                <?= sfy_esc($label) ?>
              </label>
            <?php endforeach; ?>
          </div>
        </div>

        <div class="grid grid-4">
          <div class="field"><label class="label">Sort order</label>
            <input type="number" name="sort_order" value="<?= (int)$ea['sort_order'] ?>"></div>
          <div class="field"><label class="label">Max impressions (0 = ∞)</label>
            <input type="number" name="max_impressions" value="<?= (int)($ea['max_impressions'] ?? 0) ?>" min="0"></div>
          <div class="field"><label class="label">Start</label>
            <input type="datetime-local" name="start_at" value="<?= sfy_esc($ea['start_at'] ? date('Y-m-d\TH:i', strtotime((string)$ea['start_at'])) : '') ?>"></div>
          <div class="field"><label class="label">End</label>
            <input type="datetime-local" name="end_at" value="<?= sfy_esc($ea['end_at'] ? date('Y-m-d\TH:i', strtotime((string)$ea['end_at'])) : '') ?>"></div>
        </div>

        <label class="check"><input type="checkbox" name="is_active" <?= (int)$ea['is_active'] ? 'checked' : '' ?>> Active</label>
        <label class="check"><input type="checkbox" name="is_dismissible" <?= (int)$ea['is_dismissible'] ? 'checked' : '' ?>> Visitors may dismiss this ad</label>

        <div class="label mt-2">Preview <span class="mute">(rendered inline, even for overlays)</span></div>
        <div style="border:1px dashed var(--line-2);border-radius:var(--r);padding:16px;background:var(--bg-2)">
          <?= sfy_ad_render_preview($ea + ['pages' => implode(',', $eaPages)]) ?>
        </div>
        <div class="hint">
          On the live site this slot renders on:
          <b><?= sfy_esc(implode(', ', array_map(fn($k) => sfy_ad_pages()[$k] ?? $k, $eaPages ?: ['all']))) ?></b>.
          Use the <b>LIVE PREVIEW</b> panel at the top of this tab to see it in place.
        </div>

        <div class="modal-actions">
          <a class="btn btn-ghost" href="<?= sfy_esc(sfy_admin_url(['tab' => 'ads'])) ?>">CANCEL</a>
          <button class="btn btn-primary">SAVE AD</button>
        </div>
      </form>

      <?php if ($ea['id']): ?>
        <hr class="sep">
        <?php sfy_admin_form_start(['action' => 'reset_ad_stats', 'id' => (int)$ea['id']], 'Reset counters for this ad?'); ?>
        <button class="btn btn-danger">RESET COUNTERS</button></form>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php endif; ?>
