<?php
/**
 * Admin → Homepage.
 * Left of the pencil: nothing. The landing page is an ordered list of
 * sections stored as JSON, so the admin can add, remove, reorder, resize,
 * retitle, disable or re-point every block — plus the footer.
 *
 * @var PDO $db
 */
$sections = sfy_layout();
$types    = sfy_layout_types();
$widths   = sfy_layout_widths();
$slots    = sfy_layout_ad_slots();
$footer   = sfy_footer_config();

/** Tones a section can be tinted with. */
$tones = ['' => 'Default', 'neon' => 'Accent', 'gold' => 'Gold', 'blue' => 'Cyan',
          'violet' => 'Violet', 'red' => 'Red'];

/** A blank row for a given type — also used to build the JS templates. */
if (!function_exists('sfy_layout_blank')) {
    function sfy_layout_blank(string $type): array {
        return ['id' => '', 'type' => $type, 'enabled' => 1, 'width' => 'full', 'title' => '',
                'text' => '', 'html' => '', 'button_label' => '', 'button_url' => '',
                'ad' => 'banner', 'align' => 'left', 'tone' => ''];
    }
}

/** Which editor fields each type actually uses (mirrored in JS below). */
if (!function_exists('sfy_layout_field_map')) {
    function sfy_layout_field_map(): array {
        return [
            'hero'     => ['title', 'text'],
            'stats'    => [],
            'howto'    => ['title', 'text'],
            'features' => ['title', 'text'],
            'faq'      => ['title', 'text'],
            'premium'  => ['title', 'text', 'btn'],
            'tutorial' => ['title', 'text', 'btn'],
            'status'   => ['title', 'text'],
            'cta'      => ['title', 'text', 'btn'],
            'heading'  => ['title', 'text'],
            'custom'   => ['html'],
            'ad'       => ['ad'],
            'divider'  => ['title'],
        ];
    }
}

/** One editable section row (single source of truth for PHP and the JS clone). */
if (!function_exists('sfy_layout_row_html')) {
    function sfy_layout_row_html(array $s, array $types, array $widths, array $slots, array $tones): string {
        $meta    = $types[$s['type']] ?? ['label' => $s['type']];
        $fields  = sfy_layout_field_map()[$s['type']] ?? [];
        $has     = fn(string $f): bool => in_array($f, $fields, true);
        $esc     = 'sfy_esc';
        $off     = empty($s['enabled']) ? ' off' : '';
        $typeTag = '<span class="badge">' . $esc($meta['label']) . '</span>';

        $out  = '<div class="secrow' . $off . '" data-type="' . $esc($s['type']) . '" data-id="' . $esc((string)$s['id']) . '">';
        $out .= '<div class="hd">';
        $out .= '<span class="ord"><button type="button" class="btn btn-sm btn-ghost" data-move="-1" title="Move up">↑</button>'
              . '<button type="button" class="btn btn-sm btn-ghost" data-move="1" title="Move down">↓</button></span>';
        $out .= '<span class="nm">' . $esc($meta['label']) . '</span>' . $typeTag;
        $out .= '<span class="ord-handle">' . $esc((string)$s['id']) . '</span>';
        $out .= '<span class="spacer" style="margin-left:auto"></span>';
        $out .= '<label class="check" style="margin:0"><input type="checkbox" class="f-enabled"'
              . (!empty($s['enabled']) ? ' checked' : '') . '> visible</label>';
        $out .= '<span class="field" style="margin:0"><select class="f-width" title="Width">';
        foreach ($widths as $wk => $w) {
            $out .= '<option value="' . $esc($wk) . '"' . ($s['width'] === $wk ? ' selected' : '') . '>'
                  . $esc($w['label']) . ' (' . (int)$w['span'] . '/12)</option>';
        }
        $out .= '</select></span>';
        $out .= '<span class="field" style="margin:0"><select class="f-tone" title="Accent tone">';
        foreach ($tones as $tk => $tl) {
            $out .= '<option value="' . $esc($tk) . '"' . ($s['tone'] === $tk ? ' selected' : '') . '>'
                  . $esc($tl) . '</option>';
        }
        $out .= '</select></span>';
        $out .= '<button type="button" class="btn btn-sm btn-danger" data-del="1">REMOVE</button>';
        $out .= '</div>';

        $out .= '<div class="bd">';
        if ($has('title')) {
            $out .= '<div class="field" data-f="title"><label class="label">Title</label>'
                  . '<input type="text" class="f-title" value="' . $esc((string)$s['title']) . '" maxlength="120"'
                  . ' placeholder="' . $esc((string)($meta['label'] ?? '')) . '"></div>';
        } else {
            $out .= '<input type="hidden" class="f-title" value="' . $esc((string)$s['title']) . '">';
        }

        if ($has('text')) {
            $out .= '<div class="field" data-f="text"><label class="label">Text</label>'
                  . '<textarea class="f-text" rows="4" placeholder="' . $esc((string)($meta['hint'] ?? '')) . '">'
                  . $esc((string)$s['text']) . '</textarea>'
                  . '<div class="hint">' . $esc((string)($meta['hint'] ?? '')) . '</div></div>';
        } else {
            $out .= '<input type="hidden" class="f-text" value="' . $esc((string)$s['text']) . '">';
        }

        if ($has('html')) {
            $out .= '<div class="field" data-f="html"><label class="label">HTML</label>'
                  . '<textarea class="f-html mono" rows="5">' . $esc((string)$s['html']) . '</textarea>'
                  . '<div class="hint">Rendered as-is. Only paste markup you trust.</div></div>';
        } else {
            $out .= '<input type="hidden" class="f-html" value="' . $esc((string)$s['html']) . '">';
        }

        if ($has('btn')) {
            $out .= '<div class="grid grid-2">'
                  . '<div class="field" data-f="btn"><label class="label">Button label</label>'
                  . '<input type="text" class="f-btn-label" value="' . $esc((string)$s['button_label']) . '" maxlength="40"></div>'
                  . '<div class="field" data-f="btn"><label class="label">Button URL</label>'
                  . '<input type="text" class="f-btn-url mono" value="' . $esc((string)$s['button_url']) . '"></div>'
                  . '</div>';
        } else {
            $out .= '<input type="hidden" class="f-btn-label" value="' . $esc((string)$s['button_label']) . '">'
                  . '<input type="hidden" class="f-btn-url" value="' . $esc((string)$s['button_url']) . '">';
        }

        if ($has('ad')) {
            $out .= '<div class="field" data-f="ad"><label class="label">Ad placement</label>'
                  . '<select class="f-ad">';
            foreach ($slots as $sk => $sl) {
                $out .= '<option value="' . $esc($sk) . '"' . ($s['ad'] === $sk ? ' selected' : '') . '>'
                      . $esc($sl) . ' (' . $esc($sk) . ')</option>';
            }
            $out .= '</select><div class="hint">Ads are created in the Ads tab; this picks the slot on the page.</div></div>';
        } else {
            $out .= '<input type="hidden" class="f-ad" value="' . $esc((string)$s['ad']) . '">';
        }

        $out .= '<label class="check"><input type="radio" class="f-align" value="left"'
              . ($s['align'] === 'left' ? ' checked' : '') . '> left aligned</label>'
              . '<label class="check"><input type="radio" class="f-align" value="center"'
              . ($s['align'] === 'center' ? ' checked' : '') . '> centred</label>';

        $out .= '</div></div>';
        return $out;
    }
}

$fieldMap = sfy_layout_field_map();
?>

<?php sfy_admin_preview_panel('Drag nothing, click anything — reorder, resize, hide or delete sections and the preview follows. Save writes it to the database.'); ?>

<form method="POST" id="sfy-layout-form">
  <?= sfy_csrf_field() ?>
  <input type="hidden" name="action" value="save_layout">
  <input type="hidden" name="layout_json" id="sfy-layout-json" value="">

  <div class="card mb-2">
    <div class="card-head">
      <h2>&gt; HOMEPAGE_SECTIONS</h2>
      <span class="spacer"></span>
      <span class="badge g"><span id="sfy-sec-count"><?= count($sections) ?></span> SECTIONS</span>
    </div>
    <p class="hint" style="margin-top:0">
      Each section spans a width of a 12-column grid. On phones everything stacks to full width automatically.
    </p>

    <div id="sfy-sections">
      <?php foreach ($sections as $s) {
          echo sfy_layout_row_html($s, $types, $widths, $slots, $tones);
      } ?>
    </div>

    <div class="inline mt-2">
      <select id="sfy-add-type" style="max-width:280px">
        <?php foreach ($types as $tk => $tm): ?>
          <option value="<?= sfy_esc($tk) ?>"><?= sfy_esc($tm['label']) ?> — <?= sfy_esc($tm['hint']) ?></option>
        <?php endforeach; ?>
      </select>
      <button type="button" class="btn" id="sfy-add-sec">+ ADD SECTION</button>
      <span class="hint" style="margin:0">Changes preview live. Nothing is saved until you press SAVE LAYOUT.</span>
    </div>
  </div>

  <div class="btn-row mb-2">
    <button class="btn btn-primary">SAVE LAYOUT</button>
  </div>
</form>

<div id="sfy-templates" hidden>
  <?php foreach ($types as $tk => $tm): ?>
    <template data-type="<?= sfy_esc($tk) ?>"><?= sfy_layout_row_html(sfy_layout_blank($tk), $types, $widths, $slots, $tones) ?></template>
  <?php endforeach; ?>
</div>

<script>
(function(){
  var wrap   = document.getElementById('sfy-sections');
  var fieldMap = <?= json_encode($fieldMap) ?>;
  var newType  = document.getElementById('sfy-add-type');

  function rows(){
    return Array.prototype.map.call(wrap.querySelectorAll('.secrow'), function(r){
      var v = function(sel){ var e = r.querySelector(sel); return e ? e.value : ''; };
      var c = function(sel){ var e = r.querySelector(sel); return e && e.checked ? 1 : 0; };
      var al = r.querySelector('.f-align:checked');
      return {
        id: r.getAttribute('data-id') || '',
        type: r.getAttribute('data-type'),
        enabled: c('.f-enabled'),
        width: v('.f-width'),
        tone: v('.f-tone'),
        title: v('.f-title'),
        text: v('.f-text'),
        html: v('.f-html'),
        button_label: v('.f-btn-label'),
        button_url: v('.f-btn-url'),
        ad: v('.f-ad'),
        align: al ? al.value : 'left'
      };
    }).filter(function(x){ return !!x.type; });
  }

  function refreshFields(row){
    var type = row.getAttribute('data-type');
    var uses = fieldMap[type] || [];
    row.querySelectorAll('[data-f]').forEach(function(f){
      f.style.display = uses.indexOf(f.getAttribute('data-f')) >= 0 ? '' : 'none';
    });
  }

  function refreshCount(){
    document.getElementById('sfy-sec-count').textContent = wrap.querySelectorAll('.secrow').length;
  }

  function push(){ window.sfyPreviewPush('layout', { sections: rows() }); }

  function decorate(row){
    refreshFields(row);
    row.querySelectorAll('input,select,textarea').forEach(function(el){
      el.addEventListener('change', push);
      if(el.tagName === 'INPUT' && el.type === 'text') el.addEventListener('input', push);
      if(el.tagName === 'TEXTAREA') el.addEventListener('input', push);
    });
    row.querySelector('.f-enabled').addEventListener('change', function(){
      row.classList.toggle('off', !this.checked);
    });
    row.querySelectorAll('[data-move]').forEach(function(b){
      b.addEventListener('click', function(){
        var d = parseInt(b.getAttribute('data-move'), 10);
        var sib = d < 0 ? row.previousElementSibling : row.nextElementSibling;
        if(!sib) return;
        if(d < 0) wrap.insertBefore(row, sib); else wrap.insertBefore(sib, row);
        push();
      });
    });
    row.querySelector('[data-del]').addEventListener('click', function(){
      if(!confirm('Remove this section from the homepage?')) return;
      row.remove(); refreshCount(); push();
    });
  }

  wrap.querySelectorAll('.secrow').forEach(decorate);

  document.getElementById('sfy-add-sec').addEventListener('click', function(){
    var type = newType.value;
    var tpl  = document.querySelector('#sfy-templates template[data-type="' + type + '"]');
    if(!tpl) return;
    var node = tpl.content.firstElementChild.cloneNode(true);
    node.setAttribute('data-id', '');
    wrap.appendChild(node);
    decorate(node);
    refreshCount();
    push();
    node.scrollIntoView({behavior:'smooth', block:'center'});
  });

  document.getElementById('sfy-layout-form').addEventListener('submit', function(){
    document.getElementById('sfy-layout-json').value = JSON.stringify({ sections: rows() });
  });
})();
</script>

<?php
$footUrl  = $footer['links'][0]['url'] ?? '';
$hasAdmin = false;
foreach ($footer['links'] as $l) {
    if (stripos((string)$l['url'], 'admin') !== false) { $hasAdmin = true; break; }
}
?>

<form method="POST" id="sfy-footer-form">
  <?= sfy_csrf_field() ?>
  <input type="hidden" name="action" value="save_footer">
  <input type="hidden" name="footer_json" id="sfy-footer-json" value="">

  <div class="card mb-2">
    <div class="card-head">
      <h2>&gt; FOOTER</h2>
      <span class="spacer"></span>
      <span class="badge <?= $footer['enabled'] ? 'g' : 'y' ?>"><?= $footer['enabled'] ? 'VISIBLE' : 'HIDDEN' ?></span>
    </div>

    <label class="check" style="margin-top:0">
      <input type="checkbox" id="f-enabled" <?= $footer['enabled'] ? 'checked' : '' ?>>
      Show the footer under every public page
    </label>

    <label class="check">
      <input type="checkbox" id="f-admin" <?= !empty($footer['show_admin']) ? 'checked' : '' ?>>
      Show the <b>Admin</b> link in the footer (unticked = visitors never see it)
    </label>

    <div class="grid grid-2 mt-2">
      <div class="field">
        <label class="label">Copyright line</label>
        <input type="text" id="f-copy" value="<?= sfy_esc((string)$footer['copyright']) ?>"
               placeholder="© <?= date('Y') ?> <?= sfy_esc(SFY_APP_NAME) ?>">
        <div class="hint">Leave blank for the default. <b>{year}</b> and <b>{site}</b> are replaced automatically.</div>
      </div>
      <div class="field">
        <label class="label">Tagline (shown after //)</label>
        <input type="text" id="f-tag" value="<?= sfy_esc((string)$footer['tagline']) ?>" placeholder="secure gateway">
      </div>
    </div>

    <label class="label">Links</label>
    <p class="hint" style="margin-top:0">
      Untick a link to hide it, rename it, point it anywhere, or remove it entirely — including the Admin link.
      Use <b>@discord</b> as a URL to point at the Support link from Settings.
    </p>

    <div id="sfy-links">
      <?php foreach ($footer['links'] as $i => $l): ?>
        <div class="linkrow">
          <label class="fl"><input type="text" class="l-label" value="<?= sfy_esc((string)$l['label']) ?>"
                 maxlength="40" placeholder="Label"></label>
          <input type="text" class="l-url mono" value="<?= sfy_esc((string)$l['url']) ?>" placeholder="https:// or admin/ or @discord">
          <label class="fl"><input type="checkbox" class="l-on" <?= !empty($l['enabled']) ? 'checked' : '' ?>> show</label>
          <label class="fl"><input type="checkbox" class="l-tab" <?= !empty($l['new_tab']) ? 'checked' : '' ?>> new tab</label>
          <span class="ord"><button type="button" class="btn btn-sm btn-ghost" data-lmove="-1">↑</button>
            <button type="button" class="btn btn-sm btn-ghost" data-lmove="1">↓</button>
            <button type="button" class="btn btn-sm btn-danger" data-ldel="1">×</button></span>
        </div>
      <?php endforeach; ?>
    </div>

    <button type="button" class="btn btn-sm mt-2" id="sfy-add-link">+ ADD LINK</button>

    <?php if (!$hasAdmin): ?>
      <div class="msg warn mt-2" style="margin-bottom:0">◆ There is no Admin link in the footer right now.</div>
    <?php endif; ?>

    <div class="btn-row mt-2">
      <button class="btn btn-primary">SAVE FOOTER</button>
    </div>
  </div>
</form>

<div class="card mt-2">
  <div class="card-head"><h2>&gt; RECOMMENDED_LAYOUT</h2></div>
  <p class="hint" style="margin-top:0">
    The shipped order puts the <b>token box</b> first, the <b>premium offer</b> straight underneath it, then an
    ad banner, the how-it-works cards, the guide button and the security panel. The public counters ship hidden —
    tick <b>visible</b> on the “Live counters” section above to bring them back.
  </p>
  <form method="POST" onsubmit="return confirm('Replace your current homepage sections with the recommended layout?')">
    <?= sfy_csrf_field() ?>
    <input type="hidden" name="action" value="reset_layout">
    <button class="btn">LOAD RECOMMENDED LAYOUT</button>
  </form>
</div>

<script>
(function(){
  var wrap = document.getElementById('sfy-links');

  function links(){
    return Array.prototype.map.call(wrap.querySelectorAll('.linkrow'), function(r){
      var g = function(sel){ var e = r.querySelector(sel); return e ? e.value : ''; };
      var c = function(sel){ var e = r.querySelector(sel); return e && e.checked ? 1 : 0; };
      return { label: g('.l-label'), url: g('.l-url'), enabled: c('.l-on'), new_tab: c('.l-tab') };
    }).filter(function(x){ return x.label !== '' || x.url !== ''; });
  }

  function payload(){
    return {
      enabled: document.getElementById('f-enabled').checked ? 1 : 0,
      show_admin: document.getElementById('f-admin').checked ? 1 : 0,
      copyright: document.getElementById('f-copy').value,
      tagline: document.getElementById('f-tag').value,
      links: links()
    };
  }

  function push(){ window.sfyPreviewPush('footer', payload()); }

  function decorate(row){
    row.querySelectorAll('input').forEach(function(i){ i.addEventListener('change', push); });
    row.querySelectorAll('input[type=text]').forEach(function(i){ i.addEventListener('input', push); });
    row.querySelectorAll('[data-lmove]').forEach(function(b){
      b.addEventListener('click', function(){
        var d = parseInt(b.getAttribute('data-lmove'), 10);
        var sib = d < 0 ? row.previousElementSibling : row.nextElementSibling;
        if(!sib) return;
        if(d < 0) wrap.insertBefore(row, sib); else wrap.insertBefore(sib, row);
        push();
      });
    });
    row.querySelector('[data-ldel]').addEventListener('click', function(){ row.remove(); push(); });
  }
  wrap.querySelectorAll('.linkrow').forEach(decorate);

  ['f-enabled','f-admin','f-copy','f-tag'].forEach(function(id){
    var el = document.getElementById(id);
    el.addEventListener('change', push);
    if(el.type === 'text') el.addEventListener('input', push);
  });

  document.getElementById('sfy-add-link').addEventListener('click', function(){
    var row = document.createElement('div');
    row.className = 'linkrow';
    row.innerHTML = '<label class="fl"><input type="text" class="l-label" placeholder="Label" maxlength="40"></label>'
      + '<input type="text" class="l-url mono" placeholder="https:// or admin/ or @discord">'
      + '<label class="fl"><input type="checkbox" class="l-on" checked> show</label>'
      + '<label class="fl"><input type="checkbox" class="l-tab"> new tab</label>'
      + '<span class="ord"><button type="button" class="btn btn-sm btn-ghost" data-lmove="-1">↑</button>'
      + '<button type="button" class="btn btn-sm btn-ghost" data-lmove="1">↓</button>'
      + '<button type="button" class="btn btn-sm btn-danger" data-ldel="1">×</button></span>';
    wrap.appendChild(row);
    decorate(row);
    row.querySelector('.l-label').focus();
  });

  document.getElementById('sfy-footer-form').addEventListener('submit', function(){
    document.getElementById('sfy-footer-json').value = JSON.stringify(payload());
  });
})();
</script>
