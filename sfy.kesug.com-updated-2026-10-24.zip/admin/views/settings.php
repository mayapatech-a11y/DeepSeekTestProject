<?php
/** @var PDO $db */
$g = fn(string $k, string $d = '') => (string)sfy_config_get('set_' . $k, (string)sfy_setting($k, $d));

/*
 * The human check is read through the module's own accessors — never through
 * $g — because those are the values the gate actually acts on: a stored
 * override first, then `config/config.php`, then the shipped default. A panel
 * that read the same thing twice in two different ways is how an owner ends up
 * looking at "OFF" while the site is enforcing a challenge.
 */
$tsOn       = sfy_captcha_enabled();
$tsReady    = sfy_captcha_ready();
$tsProblems = sfy_captcha_problems();
$tsSiteKey  = sfy_captcha_site_key();
$tsSecret   = sfy_captcha_secret();
$tsTheme    = sfy_captcha_theme();
$tsFailOpen = sfy_captcha_fail_open();
$tsChecks   = sfy_captcha_stats(24);
$sfySections = [
    'general'  => 'GENERAL',
    'content'  => 'CONTENT',
    'flow'     => 'FLOW & ANTI-BYPASS',
    'security' => 'SECURITY & TOOLS',
];
$sfySection = (string)($_GET['section'] ?? 'general');
if (!isset($sfySections[$sfySection])) $sfySection = 'general';
?>
<style>
.sfy-settings-nav{display:flex;gap:6px;flex-wrap:wrap;padding:6px;margin:0 0 14px;background:var(--panel);border:1px solid var(--line);border-radius:12px}
.sfy-settings-nav a{flex:1 1 auto;text-align:center;padding:9px 12px;border-radius:8px;color:var(--text-mute);text-decoration:none;font-size:11px;font-weight:700;letter-spacing:.07em;border:1px solid transparent;white-space:nowrap}
.sfy-settings-nav a:hover{color:var(--text);background:var(--panel-2)}
.sfy-settings-nav a.active{color:#111;background:var(--neon);border-color:var(--neon)}
.sfy-section{display:none}
.sfy-section.active{display:block}
.sfy-tip{display:inline-flex;align-items:center;justify-content:center;width:17px;height:17px;margin-left:7px;border:1px solid var(--line-2);border-radius:50%;color:var(--text-mute);font-size:11px;font-style:normal;line-height:1;cursor:help;position:relative;vertical-align:middle;flex:0 0 auto}
.sfy-tip:hover,.sfy-tip:focus{color:var(--text);border-color:var(--neon);outline:none}
.sfy-tip::after{content:attr(data-tip);position:absolute;left:50%;bottom:calc(100% + 8px);transform:translateX(-50%);width:max-content;max-width:min(360px,80vw);padding:9px 11px;background:#0b0f14;border:1px solid var(--line-2);border-radius:8px;color:var(--text);font-size:12px;font-weight:400;line-height:1.45;letter-spacing:0;white-space:normal;text-align:left;opacity:0;visibility:hidden;pointer-events:none;z-index:80;box-shadow:0 10px 30px rgba(0,0,0,.5)}
.sfy-tip:hover::after,.sfy-tip:focus::after{opacity:1;visibility:visible}
.sfy-more{margin-top:8px;font-size:12px;line-height:1.55}
.sfy-more summary{cursor:pointer;color:var(--text-mute);font-size:11px;letter-spacing:.04em}
.sfy-more[open] summary{color:var(--text)}
@media(max-width:700px){.sfy-tip::after{left:0;transform:none;max-width:78vw}.sfy-settings-nav a{flex:1 1 45%}}
</style>
<nav class="sfy-settings-nav" aria-label="Settings sections">
<?php foreach ($sfySections as $sk => $sl): ?>
  <a href="<?= sfy_esc(sfy_admin_url(['tab' => 'settings', 'section' => $sk])) ?>" class="<?= $sfySection === $sk ? 'active' : '' ?>" <?= $sfySection === $sk ? 'aria-current="page"' : '' ?>><?= sfy_esc($sl) ?></a>
<?php endforeach; ?>
</nav>
<section id="sfy-sec-general" class="sfy-section<?= $sfySection === 'general' ? ' active' : '' ?>">
<div class="card mb-2">
  <div class="card-head"><h2>&gt; BOT_CHECK</h2><span class="spacer"></span>
    <?php if (!$tsOn): ?><span class="badge gr">OFF</span>
    <?php elseif ($tsReady): ?><span class="badge g">ARMED</span>
    <?php else: ?><span class="badge r">NOT USABLE</span><?php endif; ?>
    <span class="tiny mute mono"><?= (int)$tsChecks['passed'] ?> passed / <?= (int)$tsChecks['refused'] ?> refused (24h)</span>
  </div>
  <form method="POST">
    <?= sfy_csrf_field() ?>
    <input type="hidden" name="action" value="save_config">
    <input type="hidden" name="has_flags" value="1">
    <input type="hidden" name="flag_turnstile_enabled" value="1">
    <input type="hidden" name="flag_turnstile_at_claim" value="1">
    <input type="hidden" name="flag_turnstile_at_admin" value="1">

    <label class="check"><input type="checkbox" name="turnstile_enabled" <?= $tsOn ? 'checked' : '' ?>>
      Human check (Cloudflare Turnstile) enabled</label>
    <div class="hint">
      A challenge in front of the one request that costs nothing and leaves something behind: the claim link that
      creates a verification run. Everything after that is already signed, single-use and dwell-gated, so asking
      again later would only tax real players.
      <br><b>The check can never lock anybody out by accident:</b> it is only *demanded* while it can actually be
      checked — switch on, both keys filled in, and this host able to make an outbound HTTPS request. Half-configured,
      it blocks nobody and reports itself in <a href="<?= sfy_esc(sfy_admin_url(['tab' => 'security'])) ?>">Admin → Security</a>
      instead. Real code hand-offs (a finished token reopening its code) are never gated.
    </div>

    <div class="grid grid-2">
      <div class="field"><label class="label">Site key</label>
        <input type="text" name="turnstile_site_key" class="mono" value="<?= sfy_esc($tsSiteKey) ?>"
               placeholder="0x4AAAAAAA...">
        <div class="hint">Cloudflare dashboard → Turnstile → your widget → <b>Site Key</b>. Public: it is printed on the
          page and is safe to show.</div></div>
      <div class="field"><label class="label">Secret key</label>
        <input type="text" name="turnstile_secret" class="mono" value="<?= sfy_esc($tsSecret) ?>">
        <div class="hint">The same widget's <b>Secret Key</b>. Never printed on a page; it is only used server-side to
          ask Cloudflare about a solved challenge.</div></div>
      <div class="field"><label class="label">Widget theme</label>
        <select name="turnstile_theme">
          <?php foreach (['dark' => 'DARK — matches this panel and the dark flow pages',
                          'light' => 'LIGHT',
                          'auto' => 'AUTO — follow the visitor\'s system setting'] as $k => $label): ?>
            <option value="<?= $k ?>" <?= $tsTheme === $k ? 'selected' : '' ?>><?= sfy_esc($label) ?></option>
          <?php endforeach; ?>
        </select></div>
      <div class="field"><label class="label">If Cloudflare cannot be reached</label>
        <select name="turnstile_fail_mode">
          <option value="open" <?= $tsFailOpen ? 'selected' : '' ?>>STAY OPEN — let the player through and log it (recommended)</option>
          <option value="strict" <?= !$tsFailOpen ? 'selected' : '' ?>>STRICT — refuse anybody we could not check</option>
        </select>
        <div class="hint">Only about *our* provider being down — never about a challenge Cloudflare rejected. STAY OPEN
          means an outage at Cloudflare cannot take your whole flow offline; STRICT means a flood is not let through
          while the check is unavailable. Refusals Cloudflare itself makes (a bad token, an expired challenge) are always
          enforced, whatever this says.</div></div>
    </div>

    <label class="check"><input type="checkbox" name="turnstile_at_claim" <?= sfy_captcha_at('claim') ? 'checked' : '' ?>>
      Ask it before a verification starts (the claim link) — recommended</label>
    <label class="check"><input type="checkbox" name="turnstile_at_admin" <?= sfy_captcha_at('admin') ? 'checked' : '' ?>>
      Ask it before a staff sign-in</label>
    <div class="hint">The sign-in gate is checked <b>before</b> the password, so a credential-stuffing bot burns its
      attempts on Cloudflare instead of on your lockout counters — which also means it cannot lock you out by filling
      them up. One pass is remembered per browser session; a fresh browser solves it again.</div>

    <div class="btn-row mt-2"><button class="btn btn-primary">SAVE BOT CHECK</button></div>
  </form>

  <?php if ($tsProblems): ?>
    <div class="msg warn">◆ Turned on but not being enforced: <?= sfy_esc(implode('; ', $tsProblems)) ?>.
      Players are <b>not</b> blocked while this is true — fix it above, then press SAVE BOT CHECK.</div>
  <?php endif; ?>

  <div class="btn-row mt-2">
    <?php sfy_admin_post_button('TEST MY KEYS', ['action' => 'test_turnstile'], 'btn'); ?>
    <a class="btn btn-ghost" href="<?= sfy_esc(sfy_admin_url(['tab' => 'security'])) ?>">OPEN THE CHECK LOG</a>
  </div>
  <div class="hint">
    <b>TEST MY KEYS</b> asks Cloudflare to verify a throwaway token: that separates "the secret key is wrong" (nothing
    would ever pass, and with STAY OPEN the check would quietly stop enforcing anything) from "both keys are fine".
    Where to get them: <a href="https://dash.cloudflare.com/?to=/:account/turnstile" target="_blank" rel="noopener">Cloudflare
    dashboard → Turnstile</a> → add a widget for <code><?= sfy_esc(parse_url(sfy_url(''), PHP_URL_HOST) ?: 'this domain') ?></code>.
    A widget only works on the hostnames it was created for, so give it this exact domain (and <code>www</code> if you use
    both). The widget below this page is the real thing visitors see; a challenge is never shown twice for one run.
  </div>
</div>
</section>

<section id="sfy-sec-content" class="sfy-section<?= $sfySection === 'content' ? ' active' : '' ?>">
<div class="card mb-2">
  <div class="card-head"><h2>&gt; SITE_COPY</h2><span class="spacer"></span>
    <span class="badge gr">shown on the landing page</span></div>
  <form method="POST">
    <?= sfy_csrf_field() ?>
    <input type="hidden" name="action" value="save_config">
    <div class="grid grid-2">
      <div class="field"><label class="label">Headline</label>
        <input type="text" name="site_headline" value="<?= sfy_esc($g('site_headline', 'Complete the tasks, unlock the code.')) ?>"></div>
      <div class="field"><label class="label">Sub-text</label>
        <input type="text" name="site_subtext" value="<?= sfy_esc($g('site_subtext', 'Two verified steps. No shortcuts, no bypassing.')) ?>"></div>
      <div class="field"><label class="label">Support / Discord / shop URL</label>
        <input type="text" name="support_discord" value="<?= sfy_esc($g('support_discord')) ?>"
               placeholder="https://discord.gg/... or your shop link">
          <div class="hint">Support and every <code>@discord</code> footer link. The premium buttons go to the Pricing page instead.</div></div>
      <div class="field"><label class="label">Premium offer headline</label>
        <input type="text" name="premium_offer_title" value="<?= sfy_esc($g('premium_offer_title', 'Skip every task — 7 days for $9')) ?>"
               placeholder="Skip every task — 7 days for $9">
          <div class="hint">The big gold line on the landing page. Leave blank to use the default.</div></div>
      <div class="field"><label class="label">Premium sub-line</label>
        <input type="text" name="premium_offer_text" value="<?= sfy_esc($g('premium_offer_text', 'No tasks. No waiting. Your code in seconds.')) ?>"
               placeholder="No tasks. No waiting. Your code in seconds."></div>
      <div class="field"><label class="label">Premium button label</label>
        <input type="text" name="premium_button_label" value="<?= sfy_esc($g('premium_button_label', 'GET PREMIUM — INSTANT ACCESS')) ?>"
               placeholder="GET PREMIUM — INSTANT ACCESS"></div>
      <div class="field"><label class="label">Premium urgency line</label>
        <input type="text" name="premium_note" value="<?= sfy_esc($g('premium_note', 'Instant activation · limited time offer')) ?>"
               placeholder="Instant activation · limited time offer"></div>
      <div class="field"><label class="label">Premium perks — one per line</label>
        <textarea name="premium_bullets" rows="4"
                  placeholder="Skip every numbered task&#10;Get your code immediately"><?= sfy_esc($g('premium_bullets', "Skip every numbered task\nGet your code immediately\nPriority support\nWorks on any device")) ?></textarea>
          <div class="hint">Rendered as the ✓ list inside the premium card. Blank lines are ignored.</div></div>
      <div class="field"><label class="label">Checkpoint label — singular</label>
        <input type="text" name="checkpoint_label" value="<?= sfy_esc($g('checkpoint_label', 'checkpoint')) ?>" placeholder="checkpoint">
        <div class="hint">Used by the provider picker, e.g. “1 checkpoint”. Change it to “step”, “task”, “stage”, etc.</div></div>
      <div class="field"><label class="label">Checkpoint label — plural</label>
        <input type="text" name="checkpoint_label_plural" value="<?= sfy_esc($g('checkpoint_label_plural', 'checkpoints')) ?>" placeholder="checkpoints">
        <div class="hint">Used when the count is not 1, e.g. “3 checkpoints”.</div></div>
      <div class="field"><label class="label">Post-task return URL</label>
        <input type="text" name="return_url" value="<?= sfy_esc($g('return_url', sfy_url('done'))) ?>"
               placeholder="<?= sfy_esc(sfy_url('done')) ?>">
          <div class="hint">Where the LootLabs handoff sends users back. Default: <?= sfy_esc(sfy_url('done')) ?> —
            that page confirms the return and then forwards the player to their next task, so it is never a screen to sit
            on. Keep it free of session macros (<code>{SESSION_ID}</code>) unless you need per-player destinations: the
            encrypted handoff is cached per destination, so a fixed page costs one API call per account.</div></div>
    </div>
    <div class="btn-row mt-2"><button class="btn btn-primary">SAVE SITE COPY</button></div>
  </form>
</div>

<div class="card mb-2">
  <div class="card-head"><h2>&gt; GUIDE_AND_PREMIUM</h2><span class="spacer"></span>
    <span class="badge b">visitor-facing</span></div>
  <form method="POST">
    <?= sfy_csrf_field() ?>
    <input type="hidden" name="action" value="save_config">
    <input type="hidden" name="has_flags" value="1">
    <input type="hidden" name="flag_tutorial_enabled" value="1">
    <input type="hidden" name="flag_tutorial_fab" value="1">

    <label class="check" style="margin-top:0">
      <input type="checkbox" name="tutorial_enabled" <?= $g('tutorial_enabled', '1') === '1' ? 'checked' : '' ?>>
      Publish the tutorial page at <b><?= sfy_esc(sfy_url('tutorial')) ?></b> (also <code>/guide</code> and <code>/how-to</code>)</label>

    <label class="check">
      <input type="checkbox" name="tutorial_fab" <?= $g('tutorial_fab', '1') === '1' ? 'checked' : '' ?>>
      Show the action button pinned at the bottom on mobile</label>

    <div class="hint">
      On a phone the pinned button follows what the visitor is doing. Inside the flow it is the page's own action,
      linked *and worded the same*: on a task it reads <b>OPEN TASK &amp; RETURN</b> and carries that task's
      handoff link — the one the card's button uses, clock and all — so the bar is never a second, different answer
      to "what do I do next". Those labels come from the page, which is why the wording fields below only decide the
      states the bar works out by itself. Once the tasks are done
      and the code is still open it reads <b>📄 SHOW MY CODE</b>, with what is left of the view window and the
      display cap on the button itself. Only outside the flow — the home page, a visitor who has not started —
      does it fall back to the guide link, <b>HOW TO GET TOKEN</b>, which needs the guide page published above.
    </div>

    <div class="grid grid-3" style="margin-top:12px">
      <div class="field"><label class="label">Pinned button — while a task is running</label>
        <input type="text" name="pinned_label_continue" maxlength="48"
               value="<?= sfy_esc($g('pinned_label_continue', 'CONTINUE TASK {step}/{total}')) ?>"
               placeholder="CONTINUE TASK {step}/{total}">
        <div class="hint"><code>{step}</code> and <code>{total}</code> are replaced with the live numbers, wherever you
          put them (or leave them out).</div></div>
      <div class="field"><label class="label">Pinned button — code still open</label>
        <input type="text" name="pinned_label_code" maxlength="48"
               value="<?= sfy_esc($g('pinned_label_code', 'SHOW MY CODE')) ?>" placeholder="SHOW MY CODE">
        <div class="hint">The <b>3 LEFT · 24 MIN</b> note beside it is generated from the live window and display cap,
          not typed here.</div></div>
      <div class="field"><label class="label">Pinned button — outside the flow</label>
        <input type="text" name="pinned_label_guide" maxlength="48"
               value="<?= sfy_esc($g('pinned_label_guide', 'HOW TO GET TOKEN')) ?>" placeholder="HOW TO GET TOKEN">
        <div class="hint">A blank field always falls back to the shipped wording, and every label is collapsed to one
          line and cut at 48 characters so the bar cannot grow over the page.</div></div>
    </div>

    <div class="hint">
      The pinned button only appears on phones and never inside the admin panel. A sticky ad, if one is
      running, is pushed above it so they never overlap.
    </div>

    <div class="grid grid-2 mt-2">
      <div class="field"><label class="label">Premium block accent (optional)</label>
        <input type="text" name="premium_accent" class="mono" maxlength="7"
               value="<?= sfy_esc($g('premium_accent')) ?>" placeholder="follows the theme">
          <div class="hint">Leave blank to inherit the active design template's gold.</div></div>
      <div class="field"><label class="label">Guide link to paste anywhere</label>
        <input type="text" class="mono" value="<?= sfy_esc(sfy_url('tutorial')) ?>" readonly></div>
    </div>

    <div class="btn-row mt-2"><button class="btn btn-primary">SAVE GUIDE SETTINGS</button></div>
  </form>
</div>
</section>

<section id="sfy-sec-flow" class="sfy-section<?= $sfySection === 'flow' ? ' active' : '' ?>">
<div class="card mb-2">
  <div class="card-head"><h2>&gt; FLOW_AND_ANTI_BYPASS</h2></div>
  <form method="POST">
    <?= sfy_csrf_field() ?>
    <input type="hidden" name="action" value="save_config">
    <input type="hidden" name="has_flags" value="1">
    <input type="hidden" name="flag_require_postback" value="1">
    <input type="hidden" name="flag_zerotap" value="1">
    <input type="hidden" name="flag_hub_pass" value="1">
    <input type="hidden" name="flag_maintenance_mode" value="1">
    <input type="hidden" name="flag_show_bypass_warning" value="1">
    <input type="hidden" name="flag_bypass_block" value="1">
    <input type="hidden" name="flag_bypass_block_ip" value="1">
    <div class="grid grid-4">
      <div class="field"><label class="label">Session TTL (min)</label>
        <input type="number" name="session_ttl_minutes" value="<?= sfy_esc($g('session_ttl_minutes', '30')) ?>" min="5" max="180"></div>
      <div class="field"><label class="label">Default tasks</label>
        <input type="number" name="default_tasks_required" value="<?= sfy_esc($g('default_tasks_required', '2')) ?>" min="1" max="20">
        <div class="hint">Only used when a token has no per-token Tasks required. Every existing token keeps its own count, and every session keeps the count it was created with.</div></div>
      <div class="field"><label class="label">Default chain</label>
        <input type="text" name="default_account_chain" value="<?= sfy_esc($g('default_account_chain', '1,2')) ?>">
        <div class="hint">Comma-separated ACCOUNT IDs, not a task count. Use the account IDs shown in Admin → Accounts, e.g. 8,11,12. Leave blank to use every active account of the chosen provider.</div></div>
      <div class="field"><label class="label">Min task dwell (s)</label>
        <input type="number" name="min_task_seconds" value="<?= sfy_esc($g('min_task_seconds', '4')) ?>" min="0" max="120"></div>
      <div class="field"><label class="label">Code window (min)</label>
        <input type="number" name="code_view_ttl_minutes" value="<?= sfy_esc($g('code_view_ttl_minutes', '30')) ?>" min="0" max="1440"></div>
      <div class="field"><label class="label">Max code views</label>
        <input type="number" name="max_code_views" value="<?= sfy_esc($g('max_code_views', '4')) ?>" min="0" max="50"></div>
      <?php $ch = $g('code_handoff', 'any'); $ch = in_array($ch, ['any', 'device'], true) ? $ch : 'any'; ?>
      <div class="field"><label class="label">Finished token — who can reopen it</label>
        <select name="code_handoff">
          <option value="any"    <?= $ch === 'any'    ? 'selected' : '' ?>>ANY DEVICE — the code reopens for whoever holds the link (recommended)</option>
          <option value="device" <?= $ch === 'device' ? 'selected' : '' ?>>DEVICE LOCK — only the device that finished the tasks</option>
        </select></div>
      <?php $ru = $g('token_reuse', 'open'); $ru = in_array($ru, ['open', 'handoff'], true) ? $ru : 'open'; ?>
      <div class="field"><label class="label">Used token — claim it again?</label>
        <select name="token_reuse">
          <option value="open"    <?= $ru === 'open'    ? 'selected' : '' ?>>OPEN — a finished token is claimed again like a fresh one (recommended)</option>
          <option value="handoff" <?= $ru === 'handoff' ? 'selected' : '' ?>>HANDOFF — only hand the code back, never run the tasks again</option>
        </select>
        <div class="hint">Your token pool is what prevents duplicates, so gating here only dead-ends links that already
          worked. <b>OPEN</b> ignores the <code>USED</code> flag everywhere on the player side: the same link runs the tasks
          again for whoever holds it, and one player finishing never breaks it for the rest. <b>HANDOFF</b> is the old
          behaviour — a used token hands back its code inside the window above and otherwise says it is finished.
          A token marked <b>Reusable</b> in Tokens keeps working either way.</div></div>
      <div class="field"><label class="label">Max login attempts</label>
        <input type="number" name="max_login_attempts" value="<?= sfy_esc($g('max_login_attempts', '5')) ?>" min="1" max="20"></div>
      <?php $fb = $g('postback_fallback', 'auto'); $fb = in_array($fb, ['auto','on','off'], true) ? $fb : 'auto'; ?>
      <div class="field"><label class="label">Return check</label>
        <select name="postback_fallback">
          <option value="auto" <?= $fb === 'auto' ? 'selected' : '' ?>>AUTO — only while postbacks are missing (recommended)</option>
          <option value="on"   <?= $fb === 'on'   ? 'selected' : '' ?>>ON — always accept a verified return</option>
          <option value="off"  <?= $fb === 'off'  ? 'selected' : '' ?>>OFF — postback only (strictest)</option>
        </select>
        <div class="hint">A step can also be confirmed when the player verifiably clicks into the task and comes
          back after the dwell time below. AUTO keeps it as a safety net and returns to strict postback-only the moment a real
          postback is received again. See the <b>POSTBACK DOCTOR</b> in the LootLabs tab to check whether postbacks arrive.</div></div>
      <div class="field"><label class="label">Return dwell (s)</label>
        <input type="number" name="return_dwell_seconds" value="<?= sfy_esc($g('return_dwell_seconds', '45')) ?>" min="15" max="600">
        <div class="hint">How long the player must have been away on the task before the return counts.</div></div>
      <div class="field"><label class="label">Hand-off countdown (s)</label>
        <input type="number" name="zerotap_handoff_seconds" id="zerotap_handoff_seconds"
               value="<?= sfy_esc($g('zerotap_handoff_seconds', sfy_cfg('security.zerotap_handoff_seconds', 5))) ?>"
               min="2" max="15">
        <div class="hint">How long the <b>TASK n COMPLETE</b> card counts down before the next task opens itself
          (<b>2–15</b>s). It only sets the pause on a handoff that is already issued — the step still advances
          through the postback or the provider return, and a value outside the range is clamped. Used only while
          the zero-tap flow below is on.</div></div>
      <div class="field"><label class="label">Return must come from the provider</label>
        <input type="hidden" name="flag_return_require_provider" value="1">
        <label class="check"><input type="checkbox" name="return_require_provider" <?= $g('return_require_provider', sfy_cfg('security.return_require_provider', true) ? '1' : '0') === '1' ? 'checked' : '' ?>>
          Only the task page may send a player back (recommended)</label>
        <div class="hint">The landing only counts when the browser says the <b>task provider</b> sent the player there:
          a cross-site navigation from a host below. Typing the landing URL, bookmarking it or fetching it from the console
          reports <code>Sec-Fetch-Site: none</code> and confirms nothing. Switch this off only if your provider cannot be
          recognised at all — then any visit to the landing page can confirm a step.</div></div>
      <div class="field"><label class="label">Provider hosts</label>
        <input type="text" name="return_referrer_hosts" class="mono"
               value="<?= sfy_esc($g('return_referrer_hosts', sfy_cfg('security.return_referrer_hosts', 'lootlabs.gg,lootlabs.com,loot-link.com'))) ?>"
               placeholder="lootlabs.gg,lootlabs.com,loot-link.com">
        <div class="hint">Comma separated, matched by suffix (<code>links.lootlabs.gg</code> is covered by
          <code>lootlabs.gg</code>). Use <code>*</code> to accept any host that is not yours. Refusals are logged as
          <code>return_rejected</code> with the host that was refused — check the <b>POSTBACK DOCTOR</b> if players report
          that a finished task will not confirm.</div></div>
      <div class="field"><label class="label">Blocked referrer hosts</label>
        <input type="text" name="return_referrer_block" class="mono"
               value="<?= sfy_esc($g('return_referrer_block', sfy_cfg('security.return_referrer_block', ''))) ?>"
               placeholder="baconbypass.xyz,bypass.city,bypass.vip">
        <div class="hint">Link-skipping services named here are refused outright, whatever else the request says —
          logged as <code>blocked_referrer</code>. Comma separated, matched by suffix. This is the cheap layer; the
          <b>return ticket</b> below is the one that stops a service that strips its referrer.</div></div>
      <div class="field"><label class="label">Return ticket</label>
        <input type="hidden" name="flag_return_ticket_required" value="1">
        <label class="check"><input type="checkbox" name="return_ticket_required" <?= $g('return_ticket_required', sfy_cfg('security.return_ticket_required', true) ? '1' : '0') === '1' ? 'checked' : '' ?>>
          Require the per-run ticket the encrypted destination carries (recommended)</label>
        <div class="hint">The LootLabs <code>&amp;data=</code> handoff now points at
          <code>/done?rt=&lt;one-time ticket&gt;</code> instead of one fixed landing page. Only LootLabs can hand that
          ticket back — only it can decrypt the blob — and it is single-use, so a bare <code>/done</code>, a replayed URL
          or a copied link confirms nothing. Steps handed off without a ticket (a plain link, Work.ink, a custom
          provider) keep the ordinary gates, so no provider is stranded.</div></div>
      <div class="field"><label class="label">Postback IP binding</label>
        <input type="hidden" name="flag_postback_ip_enforce" value="1">
        <label class="check"><input type="checkbox" name="postback_ip_enforce" <?= $g('postback_ip_enforce', sfy_cfg('security.postback_ip_enforce', true) ? '1' : '0') === '1' ? 'checked' : '' ?>>
          Refuse a postback that came from a different network than the handoff (recommended)</label>
        <div class="hint">Compared on the /24 (IPv4) or /48 (IPv6), so a mobile handover keeps working while a
          different machine does not. The step nonce travels in the player's own task URL, so anyone holding that URL
          can echo it — but they cannot know the address the task was issued to. Refusals are logged as
          <code>ip_mismatch</code>.</div></div>
      <div class="field"><label class="label">Postback IP allow list (optional)</label>
        <input type="text" name="postback_ip_allowlist" class="mono"
               value="<?= sfy_esc($g('postback_ip_allowlist', '')) ?>" placeholder="203.0.113.7, 2001:db8::1">
        <div class="hint">Leave empty. A postback whose <code>{IP}</code> is on this list is accepted whatever the
          handoff address was — for a provider that reports its own egress address instead of the visitor's.</div></div>

      <div class="field"><label class="label">Postback nonce requirement (strict)</label>
        <input type="hidden" name="flag_postback_require_nonce" value="1">
        <label class="check"><input type="checkbox" name="postback_require_nonce" <?= $g('postback_require_nonce', sfy_cfg('security.postback_require_nonce', false) ? '1' : '0') === '1' ? 'checked' : '' ?>>
          Require the single-use step nonce on every postback</label>
        <div class="hint">When on, an unsigned postback must be attributed by the nonce (or session id) we handed
          the provider — the IP-only match, which a residential proxy can satisfy, is refused. Ships off; turn on
          only if the LootLabs dashboard's postback URL carries <code>{CLICK_ID}</code> (the value of the
          <code>&amp;puid</code> on the task link, which is where the nonce rides). A wrong setting here refuses
          every real postback — check the <b>POSTBACK DOCTOR</b> after turning it on.</div></div>

      <div class="field"><label class="label">Landing referrer requirement (strict)</label>
        <input type="hidden" name="flag_return_require_referrer" value="1">
        <label class="check"><input type="checkbox" name="return_require_referrer" <?= $g('return_require_referrer', sfy_cfg('security.return_require_referrer', false) ? '1' : '0') === '1' ? 'checked' : '' ?>>
          Refuse a landing that carries no referrer</label>
        <div class="hint">LootLabs sends <code>Referrer-Policy: no-referrer</code>, so its genuine landings arrive
          with an empty referrer. The <b>return ticket</b> (migration 031) already proves the landing came through
          LootLabs' decryption — this is belt-on-top-of-braces. Ships off; turn on if you would rather trust the
          ticket alone.</div></div>
    </div>
    <label class="check"><input type="checkbox" name="require_postback" <?= $g('require_postback', '1') === '1' ? 'checked' : '' ?>>
      Require a verified postback before a step can advance (recommended)</label>
    <div class="hint">While this is on, the <b>return check</b> below is switched off: a step can only advance through
      a postback that carries the account's <code>key</code>. That is what stops a bypass service which resolves the
      provider's destination — it can reuse the landing URL, but it cannot produce the postback.</div>
    <label class="check"><input type="checkbox" name="zerotap" <?= $g('zerotap', sfy_cfg('security.zerotap', true) ? '1' : '0') === '1' ? 'checked' : '' ?>>
      Zero-tap flow — after a confirmed step, open the next task automatically (recommended)</label>
    <div class="hint">
      When a step is confirmed the browser is forwarded straight into the next task instead of landing on a card that
      still asks for <b>OPEN TASK &amp; RETURN</b> — no extra press between steps. The handoff for the new step is issued
      and its click clock stamped on the server <b>before</b> the browser moves, and the step still only advances through
      the verified postback or the provider return, so the anti-bypass chain is exactly the one a tap produced. This is
      the mode you get when the pass-through above is switched off: it announces the hand-off on a short
      <b>TASK COMPLETE</b> card before moving. Switch both off to restore the press on every step — useful when you want
      the task page's ads and status card seen between tasks.
    </div>
    <label class="check"><input type="checkbox" name="hub_pass" <?= $g('hub_pass', sfy_cfg('security.hub_pass', true) ? '1' : '0') === '1' ? 'checked' : '' ?>>
      Pass-through hub — the page between two tasks is never shown, it hands the browser straight to the network (recommended)</label>
    <div class="hint">
      <code>/go/&lt;session&gt;</code> exists so the flow can mint the one-time nonce, log the hand-off and stamp the click
      clock — and all of that still happens on every step, exactly as before. What it no longer does is <b>show a page</b>:
      a player who presses <b>PROCEED TO GET CODE</b> on the claim link, or who the network sends back from a finished task,
      is handed directly to the task itself, with nothing to read and nothing to press in between. The page is still
      there for everything that is not a straight hand-off — a task that is already open (the Back button, a status
      refresh), a network that still has to be chosen, a spent budget, a reset — and it keeps its own card, its timer and
      its <b>RESET &amp; START OVER</b> whenever it is reached. Switch this off to bring back the intermediate page (and,
      with the zero-tap flow on, its <b>TASK COMPLETE</b> card).
    </div>
    <label class="check"><input type="checkbox" name="maintenance_mode" <?= $g('maintenance_mode', '0') === '1' ? 'checked' : '' ?>>
      Maintenance mode (public pages show a notice)</label>
    <div class="card mt-2" style="border-color:#5a2a33">
      <div class="card-head"><h2>&gt; BYPASS_RESPONSE</h2></div>
      <label class="check"><input type="checkbox" name="show_bypass_warning" <?= $g('show_bypass_warning', sfy_cfg('security.show_bypass_warning', defined('STAGING_COPY')) ? '1' : '0') === '1' ? 'checked' : '' ?>>
        Show the red warning modal when a run is flagged</label>
      <div class="hint">The first serious signal (bad postback key, IP mismatch, missing ticket, no hand-off
        cookie, named bypass referrer) shows the modal and records the attempt.</div>
      <label class="check"><input type="checkbox" name="bypass_block" <?= $g('bypass_block', sfy_cfg('security.bypass_block', sfy_cfg('security.show_bypass_warning', defined('STAGING_COPY'))) ? '1' : '0') === '1' ? 'checked' : '' ?>>
        Block a flagged run — no new task, no step advance, no code</label>
      <div class="hint">At the threshold below, <b>/go</b>, <b>/done</b> and <b>/out</b> answer
        <b>VERIFICATION_UNDER_REVIEW</b>. A verified provider postback clears the flags; the return check
        never does, and RESET &amp; START OVER keeps them. This is the hard anti-bypass for detected attempts.</div>
      <div class="grid grid-4">
        <div class="field"><label class="label">Max flagged attempts before block</label>
          <input type="number" name="bypass_block_after" min="1" max="10"
                 value="<?= sfy_esc($g('bypass_block_after', (string)sfy_cfg('security.bypass_block_after', 2))) ?>"></div>
        <div class="field"><label class="label">IP cooldown (hours)</label>
          <input type="number" name="bypass_ip_window_hours" min="1" max="168"
                 value="<?= sfy_esc($g('bypass_ip_window_hours', (string)sfy_cfg('security.bypass_ip_window_hours', 24))) ?>"></div>
        <div class="field"><label class="label">Popup delay (s)</label>
          <input type="number" name="bypass_warning_delay" min="1" max="60"
                 value="<?= sfy_esc($g('bypass_warning_delay', (string)sfy_cfg('security.bypass_warning_delay', 10))) ?>"></div>
      </div>
      <div class="hint">The strict-landing warning waits this long before showing, so a real postback that is
        still in flight can finish first. Lower it for a faster warning; too low will show the red popup to
        real players during a slow confirmation.</div>
      <label class="check"><input type="checkbox" name="bypass_block_ip" <?= $g('bypass_block_ip', sfy_cfg('security.bypass_block_ip', false) ? '1' : '0') === '1' ? 'checked' : '' ?>>
        Count this connection's attempts and enforce the IP cooldown</label>
      <div class="hint">When on, a connection with <b>N</b> flagged attempts in the last <b>H</b> hours gets
        <b>ACCESS_COOLDOWN</b> on <b>/go</b>, <b>/done</b> and <b>/out</b> until those rows age out — a rolling
        cooldown, not a permanent ban. A shared carrier, school or café address can catch innocent players; leave
        it off if that is a concern.</div>
      <div class="grid grid-4">
        <div class="field"><label class="label">Postback relay pull URL</label>
          <input type="text" name="relay_pull_url" value="<?= sfy_esc($g('relay_pull_url', (string)sfy_cfg('security.relay_pull_url', ''))) ?>"
                 placeholder="https://...workers.dev/pull?secret=..."></div>
        <div class="field"><label class="label">Relay timeout (s)</label>
          <input type="number" name="relay_timeout" min="2" max="15"
                 value="<?= sfy_esc($g('relay_timeout', (string)sfy_cfg('security.relay_timeout', 4))) ?>"></div>
      </div>
      <div class="hint">LootLabs cannot reach this host directly. A public relay receives the postback; this URL
        lets the site pull it outbound. See <code>RELAY-SETUP.md</code>. Leave empty to keep the relay off.</div>
    </div>
    <div class="btn-row mt-2"><button class="btn btn-primary">SAVE FLOW SETTINGS</button></div>
  </form>
  <form method="POST" class="card mt-2"
        onsubmit="return confirm('Reset every bypass flag, device counter and the rejected-row window? This cannot be undone.');">
    <?= sfy_csrf_field() ?>
    <input type="hidden" name="action" value="reset_bypass">
    <div class="card-head"><h2>&gt; BYPASS_COUNTERS</h2></div>
    <p class="dim small" style="margin:0 0 10px">Clear the session flags, device bypass counters and the
      rejected postback/landing rows that the block reads. Use it after a test, or to release a player who was
      flagged by mistake. The audit rows are deleted for the reset.</p>
    <button class="btn btn-danger">RESET BYPASS COUNTERS</button>
  </form>
  <div class="hint">
    The <b>LootLabs Redirect API</b> (anti-bypass handoff) has its own panel in
    <a href="<?= sfy_esc(sfy_admin_url(['tab' => 'accounts'])) ?>">Admin → Accounts</a>: global mode, per-provider and per-account override, POST/GET,
    cache window, the encrypted landing page and a one-click API test.
    Which providers a player may choose between, how many tasks each may serve, and the hosts a
    landing is accepted from are in <a href="<?= sfy_esc(sfy_admin_url(['tab' => 'providers'])) ?>">Admin → Task providers</a>.
    Signature enforcement (<code>trust_provider_attribution</code>) still lives in
    <code>config/config.php</code> so a compromised admin session cannot silently weaken the gate.
  </div>
</div>
</section>

<section id="sfy-sec-security" class="sfy-section<?= $sfySection === 'security' ? ' active' : '' ?>">
<div class="card mb-2">
  <div class="card-head"><h2>&gt; CHANGE_MY_PASSWORD</h2></div>
  <form method="POST">
    <?= sfy_csrf_field() ?>
    <input type="hidden" name="action" value="change_own_password">
    <div class="grid grid-3">
      <div class="field"><label class="label">Current password</label><input type="password" name="current_password" required></div>
      <div class="field"><label class="label">New password</label><input type="password" name="new_password" minlength="8" required></div>
      <div class="field"><label class="label">Confirm new password</label><input type="password" name="new_password2" minlength="8" required></div>
    </div>
    <div class="btn-row mt-2"><button class="btn btn-gold">CHANGE PASSWORD</button></div>
  </form>
</div>

<div class="card mb-2">
  <div class="card-head"><h2>&gt; ENDPOINTS_REFERENCE</h2></div>
  <div class="term" style="max-height:none;font-size:11.5px">
&gt; claim ......... <?= sfy_esc(sfy_url('claim/TOKEN')) ?>

&gt; task step ..... <?= sfy_esc(sfy_url('go/SESSION_ID')) ?>

&gt; final code .... <?= sfy_esc(sfy_url('out/SESSION_ID')) ?>

&gt; poller ........ <?= sfy_esc(sfy_url('done')) ?>

&gt; postback ...... <?= sfy_esc(sfy_url('api/hook.php')) ?>

&gt; postback ping . <?= sfy_esc(sfy_url('api/hook.php?ping=1')) ?>

&gt; device log .... <?= sfy_esc(sfy_url('api/device.php')) ?>

&gt; step status ... <?= sfy_esc(sfy_url('api/step.php')) ?>

&gt; tutorial ...... <?= sfy_esc(sfy_url('tutorial')) ?>

&gt; admin ......... <?= sfy_esc(sfy_url('admin/')) ?>
  </div>
</div>

<div class="card">
  <div class="card-head"><h2>&gt; HARDENING_CHECKLIST</h2></div>
  <ul style="margin:0;padding-left:20px;font-size:13px;color:var(--text-dim);line-height:1.9">
    <li>Upload <code>.htaccess</code> — <code>/app</code>, <code>/config</code> and <code>/storage</code> must return 403.</li>
    <li>Keep <code>app.debug</code> set to <code>false</code> in <code>config/config.php</code>.</li>
    <li>Rotate the postback secret if it was ever pasted in a public chat.</li>
    <li>Give shop staff the <code>staff</code> role, never <code>owner</code>.</li>
    <li>Run the updater after every upload so new schema ships with the code.</li>
  </ul>
</div>
</section>
<script>
(function(){
  function tip(text){
    var s=document.createElement('span');
    s.className='sfy-tip';
    s.textContent='?';
    s.tabIndex=0;
    s.setAttribute('role','note');
    s.setAttribute('aria-label',text);
    s.title=text;
    s.dataset.tip=text;
    return s;
  }
  document.querySelectorAll('.sfy-section .field').forEach(function(field){
    var hint=field.querySelector('.hint');
    var label=field.querySelector('.label');
    if(!hint || !label) return;
    var text=hint.textContent.replace(/\s+/g,' ').trim();
    if(!text) return;
    label.appendChild(tip(text));
    hint.remove();
  });
  document.querySelectorAll('.sfy-section .check').forEach(function(check){
    var hint=check.nextElementSibling;
    if(!hint || !hint.classList.contains('hint')) return;
    var text=hint.textContent.replace(/\s+/g,' ').trim();
    if(!text) return;
    check.appendChild(tip(text));
    hint.remove();
  });
  document.querySelectorAll('.sfy-section .hint').forEach(function(hint){
    if(hint.closest('details.sfy-more')) return;
    var d=document.createElement('details');
    d.className='sfy-more';
    var s=document.createElement('summary');
    s.textContent='Details';
    d.appendChild(s);
    hint.parentNode.insertBefore(d,hint);
    d.appendChild(hint);
  });
})();
</script>
