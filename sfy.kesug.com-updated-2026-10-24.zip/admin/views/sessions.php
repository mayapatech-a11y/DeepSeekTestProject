<?php
/** @var PDO $db */
$q        = sfy_param('q');
$state    = sfy_param('state');
$provider = max(0, sfy_int('provider', 0));
$sort     = sfy_param('sort', 'new');
$per      = (int)sfy_int('per', 50);
if (!in_array($per, [25, 50, 100], true)) $per = 50;
$pageNo   = max(1, sfy_int('p', 1));
$total    = sfy_sessions_count($q, $state, $provider);
$pages    = max(1, (int)ceil($total / $per));
if ($pageNo > $pages) $pageNo = $pages;
$sessions = sfy_sessions_list($q, $state, $per, ($pageNo - 1) * $per, $sort, $provider);
$providers = function_exists('sfy_providers_all') ? sfy_providers_all() : [];
$funnel   = sfy_funnel_stats();
$view     = sfy_param('view');
$detail   = $view !== '' ? sfy_session_detail($view) : [];
$base     = ['tab' => 'sessions', 'q' => $q, 'state' => $state, 'provider' => $provider ?: '', 'sort' => $sort, 'per' => $per];
?>
<div class="grid grid-4 mb-2">
  <?= sfy_kpi('Sessions', number_format($funnel['total']), '', $funnel['open'] . ' open now') ?>
  <?= sfy_kpi('Verified', number_format($funnel['completed']), '', $funnel['rate'] . '% completion') ?>
  <?= sfy_kpi('Expired', number_format($funnel['expired']), 'orange') ?>
  <?= sfy_kpi('Flagged', number_format($funnel['flagged']), 'red', 'bypass signals') ?>
</div>

<div class="card">
  <div class="card-head">
    <h2>&gt; SESSIONS <span class="mute tiny mono"><?= number_format($total) ?> matched</span></h2>
    <span class="spacer"></span>
    <?php sfy_admin_post_button('CLEAR EXPIRED', ['action' => 'clear_expired_sessions']) ?>
    <?php sfy_admin_post_button('CLEAR ALL', ['action' => 'clear_all_sessions'], 'btn btn-sm btn-danger', 'Delete ALL sessions and step nonces?') ?>
  </div>

  <form method="GET" class="inline mb-2">
    <input type="hidden" name="tab" value="sessions">
    <input type="hidden" name="p" value="1">
    <input class="grow" type="search" name="q" value="<?= sfy_esc($q) ?>" placeholder="search session / token / IP / device / country">
    <select name="state" style="max-width:155px">
      <option value="">Any state</option>
      <?php foreach (['open' => 'In progress', 'done' => 'Completed', 'expired' => 'Expired', 'flagged' => 'Flagged', 'highrisk' => 'High risk'] as $k => $lbl): ?>
        <option value="<?= $k ?>" <?= $state === $k ? 'selected' : '' ?>><?= sfy_esc($lbl) ?></option>
      <?php endforeach; ?>
    </select>
    <select name="provider" style="max-width:180px">
      <option value="">All providers</option>
      <?php foreach ($providers as $pv): ?>
        <option value="<?= (int)$pv['id'] ?>" <?= $provider === (int)$pv['id'] ? 'selected' : '' ?>><?= sfy_esc(sfy_provider_label($pv)) ?></option>
      <?php endforeach; ?>
    </select>
    <select name="sort" style="max-width:170px">
      <?php foreach (['new' => 'Newest first', 'old' => 'Oldest first', 'flags' => 'Most flags', 'risk' => 'Highest risk', 'expires' => 'Expiring first', 'steps' => 'Furthest step'] as $k => $lbl): ?>
        <option value="<?= $k ?>" <?= $sort === $k ? 'selected' : '' ?>><?= sfy_esc($lbl) ?></option>
      <?php endforeach; ?>
    </select>
    <select name="per" style="max-width:100px" onchange="this.form.submit()">
      <?php foreach ([25, 50, 100] as $n): ?><option value="<?= $n ?>" <?= $per === $n ? 'selected' : '' ?>><?= $n ?>/page</option><?php endforeach; ?>
    </select>
    <button class="btn">FILTER</button>
    <a class="btn btn-ghost" href="<?= sfy_esc(sfy_admin_url(['tab' => 'sessions'])) ?>">RESET</a>
  </form>

  <?php if (!$sessions): ?>
    <div class="empty">&gt; no sessions matched.</div>
  <?php else: ?>
    <div class="tbl-wrap">
      <table class="tbl">
        <thead><tr><th>Session</th><th>Token</th><th>Provider</th><th>Device</th><th>Step</th><th>State</th>
                   <th>Flags</th><th>PBs</th><th>Location</th><th>Created</th><th>Actions</th></tr></thead>
        <tbody>
        <?php foreach ($sessions as $s):
          $expired = (int)$s['is_completed'] === 0 && strtotime((string)$s['expires_at']) <= time();
          $prov = (int)($s['provider_id'] ?? 0) > 0 ? sfy_provider_find((int)$s['provider_id']) : null; ?>
          <tr>
            <td class="mono tiny"><?= sfy_esc(sfy_short((string)$s['session_id'], 14)) ?></td>
            <td class="mono tiny" style="color:var(--gold)"><?= sfy_esc((string)$s['token']) ?></td>
            <td class="tiny"><?= $prov ? sfy_esc(sfy_short(sfy_provider_label($prov), 16)) : '<span class="mute">—</span>' ?></td>
            <td class="tiny"><?= sfy_esc(sfy_short((string)($s['device_name'] ?? '—'), 16)) ?></td>
            <td class="mono"><?= (int)$s['current_step'] ?>/<?= (int)$s['total_steps'] ?></td>
            <td>
              <?php if ((int)$s['is_completed']) echo sfy_badge('DONE', 'g');
                    elseif ($expired)         echo sfy_badge('EXPIRED', 'gr');
                    else                      echo sfy_badge('OPEN', 'b'); ?>
            </td>
            <td><?= (int)($s['bypass_flags'] ?? 0) > 0 ? sfy_badge((string)(int)$s['bypass_flags'], 'r') : '<span class="mute">—</span>' ?></td>
            <td class="mono"><?= (int)($s['postback_count'] ?? 0) ?></td>
            <td class="tiny"><?= sfy_esc((string)($s['country'] ?: '—')) ?></td>
            <td class="tiny dim"><?= sfy_esc(sfy_ago((string)$s['created_at'])) ?></td>
            <td>
              <div class="actions">
                <a class="btn btn-sm" href="<?= sfy_esc(sfy_admin_url(['tab' => 'sessions', 'view' => (string)$s['session_id']])) ?>">VIEW</a>
                <?php if (!(int)$s['is_completed']): ?>
                  <?php sfy_admin_post_button('DONE', ['action' => 'complete_session', 'session_id' => (string)$s['session_id']], 'btn btn-sm btn-gold',
                        'Force-complete this session? The user will be able to read their code.') ?>
                <?php endif; ?>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div class="sfy-pager">
      <span class="mute tiny mono"><?= number_format(($pageNo - 1) * $per + 1) ?>–<?= number_format(min($total, $pageNo * $per)) ?> of <?= number_format($total) ?></span>
      <span class="spacer"></span>
      <?php if ($pageNo > 1): ?><a class="btn btn-sm" href="<?= sfy_esc(sfy_admin_url($base + ['p' => 1])) ?>">«</a>
        <a class="btn btn-sm" href="<?= sfy_esc(sfy_admin_url($base + ['p' => $pageNo - 1])) ?>">‹</a><?php endif; ?>
      <?php for ($i = max(1, $pageNo - 2); $i <= min($pages, $pageNo + 2); $i++): ?>
        <a class="btn btn-sm <?= $i === $pageNo ? 'btn-primary' : '' ?>" href="<?= sfy_esc(sfy_admin_url($base + ['p' => $i])) ?>"><?= $i ?></a>
      <?php endfor; ?>
      <?php if ($pageNo < $pages): ?><a class="btn btn-sm" href="<?= sfy_esc(sfy_admin_url($base + ['p' => $pageNo + 1])) ?>">›</a>
        <a class="btn btn-sm" href="<?= sfy_esc(sfy_admin_url($base + ['p' => $pages])) ?>">»</a><?php endif; ?>
    </div>
  <?php endif; ?>
</div>

<?php if ($detail): $s = $detail['session']; ?>
<div class="modal-bg show">
  <div class="modal" style="width:980px;max-width:96vw">
    <div class="modal-head">
      <h3>&gt; SESSION <?= sfy_esc(sfy_short((string)$s['session_id'], 20)) ?></h3>
      <?= (int)$s['is_completed'] ? sfy_badge('DONE', 'g') : sfy_badge('OPEN', 'b') ?>
      <?php if ((int)($s['bypass_flags'] ?? 0) > 0): ?><?= sfy_badge('FLAGGED', 'r') ?><?php endif; ?>
      <span class="spacer" style="margin-left:auto"></span>
      <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_admin_url(['tab' => 'sessions'])) ?>">✕</a>
    </div>
    <div class="modal-body">
      <div class="grid grid-4 mb-2">
        <div class="sfy-stat"><span>Progress</span><strong><?= (int)$s['current_step'] ?>/<?= (int)$s['total_steps'] ?></strong><small>step</small></div>
        <div class="sfy-stat"><span>Postbacks</span><strong><?= (int)($s['postback_count'] ?? 0) ?></strong><small>accepted + rejected</small></div>
        <div class="sfy-stat"><span>Flags</span><strong><?= (int)($s['bypass_flags'] ?? 0) ?></strong><small>risk <?= (int)($s['risk_score'] ?? 0) ?></small></div>
        <div class="sfy-stat"><span>Created</span><strong class="mono" style="font-size:13px"><?= sfy_esc(sfy_ago((string)$s['created_at'])) ?></strong><small><?= sfy_esc((string)$s['created_at']) ?></small></div>
      </div>

      <details class="sfy-more" open>
        <summary>EDIT SESSION</summary>
        <form method="POST" class="grid grid-4 mt-2">
          <?= sfy_csrf_field() ?>
          <input type="hidden" name="action" value="session_update">
          <input type="hidden" name="session_id" value="<?= sfy_esc((string)$s['session_id']) ?>">
          <div class="field"><label class="label">Current step</label><input type="number" name="edit_step" min="1" max="100" value="<?= (int)$s['current_step'] ?>"></div>
          <div class="field"><label class="label">Total steps</label><input type="number" name="edit_total" min="1" max="50" value="<?= (int)$s['total_steps'] ?>"></div>
          <div class="field"><label class="label">Bypass flags</label><input type="number" name="edit_flags" min="0" max="99" value="<?= (int)($s['bypass_flags'] ?? 0) ?>"></div>
          <div class="field"><label class="label">Risk score</label><input type="number" name="edit_risk" min="0" max="100" value="<?= (int)($s['risk_score'] ?? 0) ?>"></div>
          <div class="field"><label class="label">Provider</label>
            <select name="edit_provider">
              <option value="0">— none —</option>
              <?php foreach ($providers as $pv): ?>
                <option value="<?= (int)$pv['id'] ?>" <?= (int)($s['provider_id'] ?? 0) === (int)$pv['id'] ? 'selected' : '' ?>><?= sfy_esc(sfy_provider_label($pv)) ?></option>
              <?php endforeach; ?>
            </select></div>
          <div class="field"><label class="label">Expires at</label><input type="datetime-local" name="edit_expires" value="<?= sfy_esc($s['expires_at'] ? date('Y-m-d\TH:i', strtotime((string)$s['expires_at'])) : '') ?>"></div>
          <div class="field" style="display:flex;align-items:flex-end"><label class="check"><input type="checkbox" name="edit_completed" value="1" <?= (int)$s['is_completed'] ? 'checked' : '' ?>> Completed</label></div>
          <div class="field" style="display:flex;align-items:flex-end"><button class="btn btn-primary btn-block">SAVE CHANGES</button></div>
        </form>
      </details>

      <div class="term mt-2" style="max-height:none;font-size:11.5px">
&gt; token ......... <?= sfy_esc((string)$s['token']) ?>

&gt; expires ....... <?= sfy_esc((string)$s['expires_at']) ?> (<?= sfy_esc(sfy_ago((string)$s['expires_at'])) ?>)

&gt; last postback . <?= sfy_esc((string)($s['last_postback_at'] ?? 'never')) ?>

&gt; ip / agent .... <?= sfy_esc((string)$s['user_ip']) ?> · <?= sfy_esc(sfy_short((string)$s['user_agent'], 90)) ?>

&gt; device ........ <?= sfy_esc((string)($s['device_name'] ?: 'unknown')) ?> · <?= sfy_esc(sfy_short((string)($s['device_fingerprint'] ?: ''), 26)) ?>
      </div>

      <?php if (!empty($detail['device'])): ?>
        <div class="label mt-2">Bound device</div>
        <div class="tiny">
          #<?= (int)$detail['device']['id'] ?> · <?= sfy_esc((string)$detail['device']['device_name']) ?>
          · <?= sfy_esc((string)$detail['device']['os']) ?>/<?= sfy_esc((string)$detail['device']['browser']) ?>
          · <?= (int)$detail['device']['success_count'] ?> unlocks
          <a class="btn btn-sm" href="<?= sfy_esc(sfy_admin_url(['tab' => 'devices', 'view' => (int)$detail['device']['id']])) ?>">OPEN</a>
        </div>
      <?php endif; ?>

      <div class="label mt-2">Step nonces</div>
      <div class="tbl-wrap"><table class="tbl">
        <thead><tr><th>Step</th><th>Provider</th><th>Account</th><th>Nonce</th><th>Issued</th><th>Consumed</th><th>Issued IP</th></tr></thead>
        <tbody>
        <?php foreach ($detail['steps'] as $st): ?>
          <tr>
            <td class="mono">#<?= (int)$st['step'] ?></td>
            <?php $stProv = (int)($st['provider_id'] ?? 0) > 0 ? sfy_provider_find((int)$st['provider_id']) : null; ?>
            <td class="tiny"><?= (int)($st['provider_id'] ?? 0) > 0 ? sfy_esc(sfy_provider_label($stProv ?: [])) . ' <span class="mono mute">#' . (int)$st['provider_id'] . '</span>' : '<span class="mute">—</span>' ?></td>
            <td class="mono"><?= (int)$st['account_id'] ?></td>
            <td class="mono tiny"><?= sfy_esc(sfy_short((string)$st['nonce'], 18)) ?></td>
            <td class="tiny dim"><?= sfy_esc(sfy_ago((string)$st['issued_at'])) ?></td>
            <td><?= $st['consumed_at'] ? sfy_badge('USED', 'g') : sfy_badge('OPEN', 'y') ?></td>
            <td class="mono tiny"><?= sfy_esc((string)($st['issued_ip'] ?: '—')) ?></td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$detail['steps']): ?><tr><td colspan="7" class="empty">no handoffs issued</td></tr><?php endif; ?>
        </tbody>
      </table></div>

      <div class="label mt-2">Postback log</div>
      <div class="tbl-wrap"><table class="tbl">
        <thead><tr><th>When</th><th>Step</th><th>Result</th><th>Reason</th><th>Dwell</th><th>Click ID</th><th>IP</th></tr></thead>
        <tbody>
        <?php foreach ($detail['postbacks'] as $pb): ?>
          <tr>
            <td class="tiny dim"><?= sfy_esc(sfy_ago((string)$pb['created_at'])) ?></td>
            <td class="mono">#<?= (int)$pb['step'] ?></td>
            <td><?= (int)$pb['accepted'] ? sfy_badge('ACCEPTED', 'g') : sfy_badge('REJECTED', 'r') ?></td>
            <td class="tiny"><?= sfy_esc((string)($pb['reason'] ?: '—')) ?></td>
            <td class="mono tiny"><?= $pb['dwell'] !== null ? (int)$pb['dwell'] . 's' : '—' ?></td>
            <td class="mono tiny"><?= sfy_esc(sfy_short((string)($pb['click_id'] ?: '—'), 14)) ?></td>
            <td class="mono tiny"><?= sfy_esc((string)($pb['ip'] ?? '—')) ?></td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$detail['postbacks']): ?><tr><td colspan="7" class="empty">no postbacks</td></tr><?php endif; ?>
        </tbody>
      </table></div>

      <div class="modal-actions" style="justify-content:flex-start">
        <a class="btn" href="<?= sfy_esc(sfy_url('go/' . (string)$s['session_id'])) ?>" target="_blank" rel="noopener">OPEN AS USER</a>
        <?php sfy_admin_post_button('RESET SESSION', ['action' => 'reset_session', 'session_id' => (string)$s['session_id']], 'btn', 'Reset to step 1 and clear nonces?') ?>
        <?php sfy_admin_post_button('FORCE COMPLETE', ['action' => 'complete_session', 'session_id' => (string)$s['session_id']], 'btn btn-gold', 'Force-complete this session?') ?>
        <?php sfy_admin_post_button('DELETE', ['action' => 'delete_session', 'session_id' => (string)$s['session_id']], 'btn btn-danger', 'Delete this session?') ?>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>