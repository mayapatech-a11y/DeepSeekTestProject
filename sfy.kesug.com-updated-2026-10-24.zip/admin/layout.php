<?php
declare(strict_types=1);
/**
 * Admin chrome: sticky top bar with the signed-in staff member, a
 * capability-filtered tab strip and the shared neon terminal styling.
 */

function sfy_admin_tabs(): array {
    return [
        'overview' => ['label' => 'Overview',  'cap' => 'view',     'icon' => '⌂'],
        'tokens'   => ['label' => 'Tokens',    'cap' => 'tokens',   'icon' => '🗝'],
        'devices'  => ['label' => 'Devices',   'cap' => 'devices',  'icon' => '📱'],
        'sessions' => ['label' => 'Sessions',  'cap' => 'sessions', 'icon' => '🔗'],
        'providers'=> ['label' => 'Task providers', 'cap' => 'accounts', 'icon' => '🧭'],
        'accounts' => ['label' => 'Accounts',  'cap' => 'accounts', 'icon' => '🎯'],
        'games'    => ['label' => 'Games',     'cap' => 'games',    'icon' => '🎮'],
        'commerce' => ['label' => 'Commerce',  'cap' => 'settings', 'icon' => '🛒'],
        'inbox'    => ['label' => 'Inbox',     'cap' => 'settings', 'icon' => '✉'],
        'appearance'=> ['label' => 'Appearance','cap' => 'appearance','icon' => '🎨'],
        'homepage' => ['label' => 'Homepage',  'cap' => 'homepage', 'icon' => '🧩'],
        'stats'    => ['label' => 'Statistics','cap' => 'stats',    'icon' => '📊'],
        'updater'  => ['label' => 'Updater',   'cap' => 'updater',  'icon' => '⬆'],
        'import'   => ['label' => 'SQL',       'cap' => 'import',   'icon' => '📥'],
        'security' => ['label' => 'Security',  'cap' => 'security', 'icon' => '🛡'],
        'staff'    => ['label' => 'Staff',     'cap' => 'staff',    'icon' => '👥'],
        'settings' => ['label' => 'Settings',  'cap' => 'settings', 'icon' => '⚙'],
    ];
}

function sfy_admin_head(array $me, string $tab, array $counts = []): void {
    $pending = 0;
    try {
        $status  = sfy_schema_status();
        $pending = count($status['pending']);
    } catch (Throwable $e) { /* ignore */ }

    $tabs  = sfy_admin_tabs();
    $title = (string)($tabs[$tab]['label'] ?? 'Overview');
    $icon  = (string)($tabs[$tab]['icon'] ?? '⌂');

    sfy_head(['title' => 'Admin', 'page' => 'admin', 'noindex' => true, 'wide' => true,
              'minimal' => true, 'body_class' => 'admin-shell']);
    ?>
<style>
.sfy-tip{display:inline-flex;align-items:center;justify-content:center;width:17px;height:17px;margin-left:7px;border:1px solid var(--line-2);border-radius:50%;color:var(--text-mute);font-size:11px;font-style:normal;line-height:1;cursor:help;position:relative;vertical-align:middle;flex:0 0 auto}
.sfy-tip:hover,.sfy-tip:focus{color:var(--text);border-color:var(--neon);outline:none}
.sfy-tip::after{content:attr(data-tip);position:absolute;left:50%;bottom:calc(100% + 8px);transform:translateX(-50%);width:max-content;max-width:min(360px,80vw);padding:9px 11px;background:#0b0f14;border:1px solid var(--line-2);border-radius:8px;color:var(--text);font-size:12px;font-weight:400;line-height:1.45;letter-spacing:0;white-space:normal;text-align:left;opacity:0;visibility:hidden;pointer-events:none;z-index:80;box-shadow:0 10px 30px rgba(0,0,0,.5)}
.sfy-tip:hover::after,.sfy-tip:focus::after{opacity:1;visibility:visible}
.sfy-more{margin-top:8px;font-size:12px;line-height:1.55}
.sfy-more summary{cursor:pointer;color:var(--text-mute);font-size:11px;letter-spacing:.04em}
.sfy-more[open] summary{color:var(--text)}
.sfy-collapse{border:1px solid var(--line);border-radius:10px;background:var(--panel)}
.sfy-collapse>summary{list-style:none;cursor:pointer;display:flex;align-items:center;gap:8px;padding:12px 14px}
.sfy-collapse>summary::-webkit-details-marker{display:none}
.sfy-collapse>summary::after{content:'▾';margin-left:auto;color:var(--text-mute);font-size:12px;transition:transform .15s}
.sfy-collapse[open]>summary::after{transform:rotate(180deg)}
.sfy-collapse>summary h2{margin:0}
.sfy-stat-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px;margin:0 0 14px}
.sfy-stat{padding:11px 12px;border:1px solid var(--line);border-radius:10px;background:var(--panel)}
.sfy-stat span{display:block;font-size:10px;letter-spacing:.08em;color:var(--text-mute);text-transform:uppercase}
.sfy-stat strong{display:block;font-size:20px;line-height:1.2;margin-top:3px;color:var(--text)}
.sfy-stat small{display:block;font-size:10px;color:var(--text-mute);margin-top:2px}
.sfy-pager{display:flex;align-items:center;gap:5px;flex-wrap:wrap;margin-top:12px}
.sfy-save-bar{position:sticky;bottom:10px;z-index:40;display:flex;align-items:center;gap:12px;padding:10px 12px;margin-top:14px;border:1px solid var(--line-2);border-radius:10px;background:color-mix(in srgb,var(--panel) 92%,transparent);backdrop-filter:blur(8px);box-shadow:0 10px 30px rgba(0,0,0,.25)}
.sfy-save-bar span{font-size:11px;color:var(--text-mute)}
.sfy-save-bar .btn{margin-left:auto}
.sfy-pager .spacer{flex:1}
@media(max-width:700px){.sfy-tip::after{left:0;transform:none;max-width:78vw}}
</style>
<div class="admin-chrome">
<aside class="admin-side" id="sfy-admin-side" aria-label="Admin navigation">
  <div class="admin-side-head">
    <a class="brand" href="<?= sfy_esc(sfy_admin_url()) ?>">
      <span>&gt;SFY_ADMIN</span><span class="v">v<?= sfy_esc(SFY_VERSION) ?></span>
    </a>
    <button type="button" class="admin-side-x" id="sfy-admin-close" aria-label="Close menu">✕</button>
  </div>

  <nav class="admin-nav">
    <?php foreach ($tabs as $key => $t): ?>
      <?php if (!sfy_admin_can($t['cap'])) continue; ?>
      <a class="<?= $tab === $key ? 'active' : '' ?>" href="<?= sfy_esc(sfy_admin_url(['tab' => $key])) ?>"
         <?= $tab === $key ? 'aria-current="page"' : '' ?>>
        <span class="ic" aria-hidden="true"><?= $t['icon'] ?></span>
        <span class="lbl"><?= sfy_esc($t['label']) ?></span>
        <?php if (isset($counts[$key]) && $counts[$key] !== null): ?><span class="n"><?= (int)$counts[$key] ?></span><?php endif; ?>
        <?php if ($key === 'updater' && $pending): ?><span class="n"><?= $pending ?></span><?php endif; ?>
      </a>
    <?php endforeach; ?>
  </nav>

  <?php /* The hub module keeps its own screens in its own folder; these two
           entries are the only trace of it here, and they vanish if the
           module is not installed. */ ?>
  <?php if (function_exists('sfy_hub_live') && sfy_hub_live()): ?>
    <div class="admin-line" style="padding:2px">
      <span class="mono" style="color:var(--text-mute)">HUB</span>
      <span class="spacer" style="margin-left:auto"></span>
      <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_hub_admin_url()) ?>">⚙ Panel</a>
      <a class="btn btn-sm btn-ghost" href="<?= sfy_esc(sfy_hub_url()) ?>" target="_blank" rel="noopener">↗ Hub</a>
    </div>
  <?php endif; ?>

  <div class="admin-side-foot">
    <div class="admin-line">
      <span class="dot <?= $pending ? 'gold' : '' ?>"></span>
      <span class="mono"><?= $pending ? $pending . ' UPDATE(S)' : 'SCHEMA OK' ?></span>
      <span class="role-pill <?= sfy_esc((string)$me['role']) ?>"><?= sfy_esc((string)$me['role']) ?></span>
    </div>
    <div class="admin-line">
      <span class="who">@<?= sfy_esc((string)$me['username']) ?></span>
      <span class="mono" id="sfy-ttl" data-ttl="<?= (int)(($_SESSION['sfy_admin_time'] ?? time()) + SFY_ADMIN_TTL * 60) ?>"></span>
    </div>
    <a class="btn btn-sm btn-danger btn-block" href="<?= sfy_esc(sfy_admin_url(['logout' => 1])) ?>">LOGOUT</a>
  </div>
</aside>

<div class="admin-backdrop" id="sfy-admin-backdrop" aria-hidden="true"></div>

<div class="admin-main">
  <div class="admin-topbar">
    <button type="button" class="admin-burger" id="sfy-admin-burger" aria-controls="sfy-admin-side"
            aria-expanded="false" aria-label="Open menu">☰</button>
    <span class="admin-topbar-title"><?= $icon ?> <?= sfy_esc($title) ?></span>
    <span class="spacer"></span>
    <span class="admin-topbar-status"><span class="dot <?= $pending ? 'gold' : '' ?>"></span>
      <?= $pending ? $pending . ' UPDATE(S)' : 'ONLINE' ?></span>
    <a class="btn btn-sm btn-danger" href="<?= sfy_esc(sfy_admin_url(['logout' => 1])) ?>">LOGOUT</a>
  </div>
  <main class="admin-body">
<?php
}

function sfy_admin_foot(): void {
    ?>
  </main>
</div><!-- /.admin-main -->
</div><!-- /.admin-chrome -->
<script>
(function(){
  /*
   * The sidebar is a drawer on a phone: the same markup, translated out of the
   * viewport, opened by ☰ and closed by ✕, the backdrop or Escape. The page
   * scroll is locked while it is open (`body.admin-nav-open`), so a swipe on the
   * menu scrolls the menu instead of the page behind it.
   */
  var side   = document.getElementById('sfy-admin-side');
  var burger = document.getElementById('sfy-admin-burger');
  var closeB = document.getElementById('sfy-admin-close');
  var back   = document.getElementById('sfy-admin-backdrop');

  function setOpen(open){
    if(!side) return;
    side.classList.toggle('open', open);
    if(back) back.classList.toggle('open', open);
    document.body.classList.toggle('admin-nav-open', open);
    if(burger) burger.setAttribute('aria-expanded', open ? 'true' : 'false');
  }
  if(burger) burger.addEventListener('click', function(){ setOpen(!side.classList.contains('open')); });
  if(closeB) closeB.addEventListener('click', function(){ setOpen(false); });
  if(back)   back.addEventListener('click', function(){ setOpen(false); });
  document.addEventListener('keydown', function(e){ if(e.key === 'Escape') setOpen(false); });
  /* A tap on a tab should not leave the drawer covering the page it opened. */
  if(side) side.querySelectorAll('.admin-nav a').forEach(function(a){
    a.addEventListener('click', function(){
      if(window.matchMedia('(max-width:900px)').matches) setOpen(false);
    });
  });

  var el = document.getElementById('sfy-ttl');
  if(el){
    var tick = function(){
      var left = parseInt(el.getAttribute('data-ttl'),10) - Math.floor(Date.now()/1000);
      if(isNaN(left)) return;
      if(left < 0) left = 0;
      el.textContent = 'expires ' + Math.floor(left/60) + 'm';
    };
    tick(); setInterval(tick, 30000);
  }

  // confirm destructive submits
  document.querySelectorAll('form[data-confirm]').forEach(function(f){
    f.addEventListener('submit', function(ev){
      if(!confirm(f.getAttribute('data-confirm'))) ev.preventDefault();
    });
  });

  // Compact help: field hints become ? tooltips; long blocks become Details.
  function sfyTip(text){
    var s=document.createElement('span');
    s.className='sfy-tip'; s.textContent='?'; s.tabIndex=0;
    s.setAttribute('role','note'); s.setAttribute('aria-label',text);
    s.title=text; s.dataset.tip=text;
    return s;
  }
  document.querySelectorAll('.admin-body .field').forEach(function(field){
    var hint=field.querySelector('.hint'); var label=field.querySelector('.label');
    if(!hint || !label) return;
    var text=hint.textContent.replace(/\s+/g,' ').trim(); if(!text) return;
    label.appendChild(sfyTip(text)); hint.remove();
  });
  document.querySelectorAll('.admin-body .check').forEach(function(check){
    var hint=check.nextElementSibling;
    if(!hint || !hint.classList.contains('hint')) return;
    var text=hint.textContent.replace(/\s+/g,' ').trim(); if(!text) return;
    check.appendChild(sfyTip(text)); hint.remove();
  });
  document.querySelectorAll('.admin-body .hint').forEach(function(hint){
    if(hint.closest('details.sfy-more')) return;
    var d=document.createElement('details'); d.className='sfy-more';
    var s=document.createElement('summary'); s.textContent='Details';
    d.appendChild(s); hint.parentNode.insertBefore(d,hint); d.appendChild(hint);
  });
})();
</script>
<?php
    sfy_foot(['page' => 'admin']);
}

/**
 * Live-preview panel: an iframe of the real site rendered with the unsaved
 * draft in the current session, with desktop / tablet / mobile framing.
 * Any editor calls window.sfyPreviewPush(part, data) to refresh it.
 */
function sfy_admin_preview_panel(string $note = ''): void {
    $url = sfy_url('') . '?preview=1';
    ?>
<div class="card mb-2">
  <div class="card-head">
    <h2>&gt; LIVE_PREVIEW</h2>
    <span class="spacer"></span>
    <div class="seg" id="sfy-dev-seg">
      <button type="button" class="active" data-dev="desktop">🖥 Desktop</button>
      <button type="button" data-dev="tablet">▭ Tablet</button>
      <button type="button" data-dev="mobile">📱 Mobile</button>
    </div>
    <button type="button" class="btn btn-sm btn-ghost" id="sfy-prev-refresh">↻ REFRESH</button>
    <a class="btn btn-sm" href="<?= sfy_esc($url) ?>" target="_blank" rel="noopener">↗ OPEN IN TAB</a>
  </div>
  <p class="hint" style="margin:0 0 11px">
    <?= $note !== '' ? sfy_esc($note) : 'Drafts render here instantly. Nothing is written to the database until you press SAVE.' ?>
  </p>
  <div class="dev-stage is-desktop" id="sfy-dev-stage">
    <iframe class="dev-frame" id="sfy-preview" src="<?= sfy_esc($url) ?>" title="Live preview" loading="lazy"></iframe>
  </div>
</div>
<script>
(function(){
  var stage = document.getElementById('sfy-dev-stage');
  var frame = document.getElementById('sfy-preview');
  var base  = <?= json_encode($url) ?>;
  var csrf  = <?= json_encode(sfy_csrf_token()) ?>;
  var api   = <?= json_encode(sfy_url('api/preview')) ?>;
  var timer = null, pending = null;

  function reload(){ frame.src = base + '&t=' + Date.now(); }
  window.sfyPreviewReload = reload;

  window.sfyPreviewPush = function(part, data){
    pending = { part: part, data: data };
    clearTimeout(timer);
    timer = setTimeout(function(){
      try{
        fetch(api, {
          method:'POST', credentials:'same-origin',
          headers:{'Content-Type':'application/json'},
          body: JSON.stringify({ csrf: csrf, part: pending.part, data: pending.data })
        }).then(reload).catch(function(){});
      }catch(e){ reload(); }
    }, 450);
  };

  document.querySelectorAll('#sfy-dev-seg button').forEach(function(b){
    b.addEventListener('click', function(){
      document.querySelectorAll('#sfy-dev-seg button').forEach(function(x){ x.classList.remove('active'); });
      b.classList.add('active');
      stage.className = 'dev-stage is-' + b.getAttribute('data-dev');
    });
  });
  document.getElementById('sfy-prev-refresh').addEventListener('click', reload);
  setTimeout(reload, 600);
})();
</script>
<?php
}

/** Small helper: POST form with a confirm prompt. */
function sfy_admin_form_start(array $hidden = [], string $confirm = '', string $extraClass = ''): void {
    echo '<form method="POST" class="' . sfy_esc($extraClass) . '"'
       . ($confirm !== '' ? ' data-confirm="' . sfy_esc($confirm) . '"' : '') . '>';
    echo sfy_csrf_field();
    foreach ($hidden as $k => $v) {
        echo '<input type="hidden" name="' . sfy_esc((string)$k) . '" value="' . sfy_esc((string)$v) . '">';
    }
}

function sfy_admin_post_button(string $label, array $hidden, string $class = 'btn btn-sm', string $confirm = ''): void {
    sfy_admin_form_start($hidden, $confirm, 'inline');
    echo '<button class="' . sfy_esc($class) . '">' . sfy_esc($label) . '</button></form>';
}
