<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY ULTIMATE — ADMIN ACTIONS
 *  Every POST from the panel lands here. Each action is capability-gated,
 *  CSRF-checked and written to the audit trail.
 * ═══════════════════════════════════════════════════════════════════════
 */

function sfy_admin_handle_post(): array {
    $msg = '';
    $type = 'ok';

    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') return [$msg, $type];

    $action = (string)($_POST['action'] ?? '');
    if ($action === '') return [$msg, $type];

    if (!sfy_csrf_check($_POST['csrf'] ?? '')) {
        return ['CSRF token invalid — reload the page and try again.', 'err'];
    }

    /* Capability required per action. */
    $need = 'admin';
    foreach ([
        'save_account','delete_account','toggle_account','test_redirect_api','test_return_ticket',
        'test_provider'                                            => 'accounts',
        'save_provider','delete_provider','toggle_provider','move_provider',
        'commerce_order_status','commerce_order_delete'            => 'settings',
        'support_admin_reply','support_status','support_delete'     => 'settings',
        'toggle_provider_maintenance'                              => 'accounts',
        'save_game','delete_game','toggle_game'                   => 'games',
        'save_token','delete_token','reset_token','bulk_tokens',
        'bulk_update_tokens','purge_used_tokens','toggle_token'   => 'tokens',
        'clear_expired_sessions','clear_all_sessions','delete_session',
        'complete_session','reset_session','session_update'       => 'sessions',
        'block_device','unblock_device','trust_device','delete_device',
        'reset_device','bulk_block_suspicious','save_device_note' => 'devices',
        'save_ad','delete_ad','toggle_ad','reset_ad_stats'        => 'ads',
        'save_appearance','reset_appearance'                      => 'appearance',
        'save_layout','reset_layout','save_footer'                => 'homepage',
        'save_staff','delete_staff','toggle_staff','unlock_staff' => 'staff',
        'change_own_password'                                     => 'view',
        'clear_login_attempts','clear_audit','save_config','save_pricing','clear_error_log',
        'reset_bypass','test_turnstile','clear_captcha_log',
        'import_sql','run_updater','repair_schema','run_maintenance' => 'settings',
    ] as $act => $cap) {
        if ($action === $act) { $need = $cap; break; }
    }

    if (!sfy_admin_can($need)) {
        return ['Your role does not allow that action (' . $need . ').', 'err'];
    }

    try {
        $db  = sfy_db();
        $me  = sfy_admin_current() ?: [];
        $who = (string)($me['username'] ?? 'system');

        switch ($action) {

            /* ══ TASK PROVIDERS ══════════════════════════════════════
               Where a player may earn their task. Adding one here is enough:
               the kind decides how the handoff is built, the task URL is a
               template, and the return hosts widen the accepted provider
               landing for free. No code change anywhere else. */
            case 'save_provider': {
                if (!sfy_table_exists('sfy_providers')) {
                    return ['The task-provider tables are missing — run Admin → Updater first.', 'err'];
                }
                $id       = sfy_int('id');
                $kindRaw  = trim(sfy_param('kind'));
                /*
                 * The editor is reached *through* a type (Admin → Task providers
                 * → + ADD PROVIDER → LootLabs / Work.ink / Custom). A provider
                 * whose kind never arrived would be stored as `custom` and then
                 * be set up with the wrong fields, so a new one is refused
                 * instead of guessed at.
                 */
                if ($id <= 0 && $kindRaw === '') {
                    return ['Pick what kind of provider you are adding first — LootLabs, Work.ink and a custom '
                          . 'network each have their own fields and their own setup instructions.', 'err'];
                }
                $kind     = sfy_provider_kind($kindRaw);
                $starter  = sfy_provider_starter($kind);
                $existing = $id > 0 ? sfy_provider_normalize(sfy_provider_find($id) ?: []) : [];

                /*
                 * Every field is written only when the form carried it.
                 *
                 * That is what makes the per-type editors safe. The Work.ink form
                 * has no postback secret and no anti-bypass mode, the LootLabs and
                 * custom forms have them — so saving one type must not blank what
                 * the other types need. A field the form never asked about keeps
                 * the stored value (or, for a brand-new provider, the type's
                 * starter).
                 */
                $posted = static fn(string $k): bool => array_key_exists($k, $_POST);
                $text   = function (string $col, string $fallback = '') use ($posted, $existing, $starter): string {
                    if ($posted($col)) return trim((string)($_POST[$col] ?? ''));
                    return trim((string)($existing[$col] ?? ($starter[$col] ?? $fallback)));
                };
                $flag   = function (string $col) use ($posted, $existing, $starter): int {
                    if ($posted($col)) return isset($_POST[$col]) ? 1 : 0;
                    return (int)($existing[$col] ?? ($starter[$col] ?? 0));
                };

                $name     = substr($text('name'), 0, 191);
                if ($name === '') return ['A provider needs a name.', 'err'];

                $slug     = strtolower(preg_replace('/[^a-z0-9\-]+/i', '-', $text('slug')) ?? '');
                $slug     = trim((string)$slug, '-');
                if ($slug === '') $slug = trim(strtolower(preg_replace('/[^a-z0-9\-]+/i', '-', $name) ?? ''), '-');
                if ($slug === '') $slug = 'provider-' . substr((string)time(), -5);
                $slug     = substr($slug, 0, 48);
                $desc     = substr($text('description'), 0, 255);
                $active   = $flag('is_active');
                /* Parked for maintenance: shown to players, never offered. */
                $parked   = $flag('is_maintenance');
                $sort     = max(0, min(999, (int)$text('sort_order')));
                $budget   = max(0, min(50, (int)$text('tasks_allowed')));
                $taskUrl  = $text('task_url');
                $params   = $text('url_params');
                $passPar  = $flag('pass_params');
                $hosts    = substr($text('return_hosts'), 0, 255);
                $hookUrl  = $text('postback_url');
                $secret   = $text('postback_secret');
                $apiKey   = $text('api_key');
                $apiMode  = strtolower($text('api_mode'));
                if (!in_array($apiMode, ['auto', 'on', 'off'], true)) $apiMode = '';
                $notes    = $text('notes');
                /* "key = value" lines → JSON, so a template can use {setting:key}. */
                if ($posted('settings')) {
                    $settings = json_encode(sfy_provider_parse_settings(sfy_param('settings')), JSON_UNESCAPED_SLASHES);
                } else {
                    $settings = (string)($existing['settings'] ?? ($starter['settings'] ?? ''));
                }
                if (!is_string($settings)) $settings = '';

                /* Slugs are unique keys — make room rather than refusing to save. */
                $st = $db->prepare("SELECT id FROM sfy_providers WHERE slug=? AND id<>? LIMIT 1");
                $st->execute([$slug, $id]);
                if ($st->fetch()) $slug = substr($slug, 0, 40) . '-' . substr(sha1($slug . $id . microtime()), 0, 5);

                $args = [$slug, $name, $kind, $desc, $active, $parked, $sort, $budget, $taskUrl, $params, $passPar,
                         $hosts, $hookUrl, $secret, $apiKey, $apiMode, $settings, $notes];

                if ($id > 0) {
                    $args[] = $id;
                    $db->prepare("UPDATE sfy_providers SET slug=?,name=?,kind=?,description=?,is_active=?,is_maintenance=?,
                                    sort_order=?,tasks_allowed=?,task_url=?,url_params=?,pass_params=?,return_hosts=?,
                                    postback_url=?,postback_secret=?,api_key=?,api_mode=?,settings=?,notes=?,updated_at=NOW()
                                  WHERE id=?")
                       ->execute($args);
                    sfy_audit('save_provider', "provider#$id");
                    $_SESSION['sfy_admin_flash'] = ["Provider #$id updated — $name (" . sfy_provider_kind_label($kind) . ').', 'ok'];
                    sfy_redirect(sfy_admin_url(['tab' => 'providers']));
                } else {
                    $db->prepare("INSERT INTO sfy_providers (slug,name,kind,description,is_active,is_maintenance,sort_order,
                                    tasks_allowed,task_url,url_params,pass_params,return_hosts,postback_url,
                                    postback_secret,api_key,api_mode,settings,notes,created_at,updated_at)
                                  VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(),NOW())")
                       ->execute($args);
                    $newId = (int)$db->lastInsertId();
                    sfy_audit('add_provider', "provider#$newId");
                    $_SESSION['sfy_admin_flash'] = ["Provider #$newId added — $name (" . sfy_provider_kind_label($kind) . '). '
                         . 'Add at least one account to it, or players can never be sent there.', 'ok'];
                    sfy_redirect(sfy_admin_url(['tab' => 'providers']));
                }
                break;
            }
            case 'delete_provider': {
                $id = sfy_int('id');
                if ($id <= 0) return ['No provider selected.', 'err'];
                /* Accounts are kept, only unassigned: deleting a provider must
                   never quietly delete the task links that were pasted in. */
                try {
                    $db->prepare('UPDATE lootlabs_accounts SET provider_id=0 WHERE provider_id=?')->execute([$id]);
                } catch (Throwable $e) { error_log('[SFY] provider delete: ' . $e->getMessage()); }
                $db->prepare('DELETE FROM sfy_providers WHERE id=?')->execute([$id]);
                sfy_audit('delete_provider', "provider#$id");
                $msg = "Provider #$id deleted — its accounts are now unassigned.";
                break;
            }
            case 'toggle_provider': {
                $id = sfy_int('id');
                $db->prepare('UPDATE sfy_providers SET is_active=IF(is_active=1,0,1), updated_at=NOW() WHERE id=?')->execute([$id]);
                sfy_audit('toggle_provider', "provider#$id");
                $msg = "Provider #$id toggled.";
                break;
            }
            /*
             * Maintenance is a state of its own, not a second way to hide a
             * provider: a parked network keeps its place on the chooser (greyed,
             * "under maintenance") so players are told what is going on, and the
             * step plan simply never hands it a step. Nothing is duplicated
             * here — is_active stays the switch that hides a provider outright.
             */
            case 'toggle_provider_maintenance': {
                $id = sfy_int('id');
                $db->prepare('UPDATE sfy_providers SET is_maintenance=IF(is_maintenance=1,0,1), updated_at=NOW() WHERE id=?')->execute([$id]);
                $p   = sfy_provider_find($id);
                $on  = $p ? sfy_provider_maintenance($p) : false;
                sfy_audit('toggle_provider_maintenance', "provider#$id");
                $msg = $on
                     ? "Provider #$id is under maintenance — players still see it on the chooser, greyed, and every "
                       . 'step goes to the networks that are running.'
                     : "Provider #$id is serving steps again.";
                break;
            }
            case 'move_provider': {
                /* Reordering is a swap of sort_order with the neighbour, which
                   is also the order the chooser lists them in. */
                $id  = sfy_int('id');
                $dir = sfy_param('dir') === 'up' ? -1 : 1;
                $cur = sfy_provider_find($id);
                if (!$cur) return ["Provider #$id not found.", 'err'];
                if ($dir < 0) {
                    $st = $db->prepare('SELECT id FROM sfy_providers WHERE (sort_order<? OR (sort_order=? AND id<?))'
                                     . ' ORDER BY sort_order DESC, id DESC LIMIT 1');
                    $st->execute([(int)$cur['sort_order'], (int)$cur['sort_order'], $id]);
                } else {
                    $st = $db->prepare('SELECT id FROM sfy_providers WHERE (sort_order>? OR (sort_order=? AND id>?))'
                                     . ' ORDER BY sort_order ASC, id ASC LIMIT 1');
                    $st->execute([(int)$cur['sort_order'], (int)$cur['sort_order'], $id]);
                }
                $other = (int)($st->fetch()['id'] ?? 0);
                if ($other <= 0) {
                    $msg = 'That provider is already at the end of the list.';
                    break;
                }
                $os = sfy_provider_find($other);
                $db->prepare('UPDATE sfy_providers SET sort_order=? WHERE id=?')->execute([(int)($os['sort_order'] ?? 0), $id]);
                $db->prepare('UPDATE sfy_providers SET sort_order=? WHERE id=?')->execute([(int)$cur['sort_order'], $other]);
                sfy_audit('move_provider', "provider#$id");
                $msg = 'Provider order updated.';
                break;
            }

            /* ── task accounts (one pool per provider) ─────────────── */
            case 'save_account': {
                $id        = sfy_int('id');
                $providerId = sfy_int('provider_id');
                $name      = substr(sfy_param('name', 'LootLabs'), 0, 191);
                $apiKey    = sfy_param('api_key');
                $secret    = sfy_param('postback_secret');
                $taskUrl   = sfy_param('task_url');
                $hookUrl   = sfy_param('postback_url');
                $format    = sfy_param('postback_format');
                $active    = isset($_POST['is_active']) ? 1 : 0;
                $weight    = max(1, min(50, sfy_int('weight', 1)));
                $dailyCap  = max(0, sfy_int('daily_cap'));
                $timeout   = max(3, min(30, sfy_int('timeout_seconds', 8)));
                $notes     = sfy_param('notes');
                // '' = inherit the global Redirect API mode.
                $antiBypass = strtolower(sfy_param('redirect_api'));
                if (!in_array($antiBypass, ['auto', 'on', 'off'], true)) $antiBypass = '';

                if ($taskUrl === '') return ['Task URL is required.', 'err'];

                /* Which provider this link belongs to — its rotation pool. */
                $hasProvider = (bool)sfy_try(fn() => sfy_column_exists('lootlabs_accounts', 'provider_id'), false);
                if ($hasProvider && $providerId > 0 && !sfy_provider_find($providerId)) {
                    return ["Provider #$providerId does not exist.", 'err'];
                }

                if ($id > 0) {
                    $sql  = "UPDATE lootlabs_accounts SET name=?,api_key=?,postback_secret=?,task_url=?,
                                    postback_url=?,postback_format=?,is_active=?,weight=?,daily_cap=?,
                                    timeout_seconds=?,notes=?,redirect_api=?";
                    $args = [$name,$apiKey,$secret,$taskUrl,$hookUrl,$format,$active,$weight,$dailyCap,$timeout,$notes,$antiBypass];
                    if ($hasProvider) { $sql .= ',provider_id=?'; $args[] = $providerId; }
                    $sql .= ',updated_at=NOW() WHERE id=?';
                    $args[] = $id;
                    $db->prepare($sql)->execute($args);
                    sfy_audit('save_account', "account#$id");
                    $msg = "Account #$id updated.";
                } else {
                    $cols = ['name','api_key','postback_secret','task_url','postback_url','postback_format','is_active',
                             'weight','daily_cap','timeout_seconds','notes','redirect_api'];
                    $vals = [$name,$apiKey,$secret,$taskUrl,$hookUrl,$format,$active,$weight,$dailyCap,$timeout,$notes,$antiBypass];
                    if ($hasProvider) { $cols[] = 'provider_id'; $vals[] = $providerId; }
                    $marks = array_fill(0, count($cols), '?');
                    $db->prepare('INSERT INTO lootlabs_accounts (' . implode(',', $cols) . ',created_at,updated_at)'
                               . ' VALUES (' . implode(',', $marks) . ',NOW(),NOW())')->execute($vals);
                    $newId = (int)$db->lastInsertId();
                    sfy_audit('add_account', "account#$newId");
                    $mName = $providerId > 0 ? (string)(sfy_provider_find($providerId)['name'] ?? '') : '';
                    $msg = "Account #$newId added" . ($mName !== '' ? " to $mName" : '') . '.';
                    if ($hasProvider && $providerId <= 0) {
                        $msg .= ' It has no provider yet, so it will not be used — assign one in Task providers.';
                    }
                }
                $_SESSION['sfy_admin_flash'] = [$msg, 'ok'];
                sfy_redirect(sfy_admin_url(['tab' => 'accounts']));
                break;
            }
            /*
             * Anti-bypass self-test: encrypt the *real* return URL with this
             * account's key and store exactly what the API answered, so a dead
             * or wrong key shows up in the panel instead of silently turning
             * every handoff into a plain link.
             */
            case 'test_return_ticket': {
                $r     = sfy_return_ticket_selftest();
                $lines = [];
                foreach ($r['steps'] as $s) $lines[] = ($s[1] ? 'OK ' : 'NO ') . $s[0];
                $msg = ($r['ok'] ? 'Return ticket OK — ' : 'Return ticket problem — ')
                     . implode(' · ', $lines) . '.';
                sfy_audit('test_return_ticket', $r['ok'] ? 'ok' : 'failed');
                break;
            }
            case 'test_redirect_api': {
                $id = sfy_int('id');
                if ($id <= 0) {
                    // No account id: test every active account in one go.
                    $done = 0; $bad = 0;
                    foreach (sfy_accounts_active() as $a) {
                        $r = sfy_lootlabs_test((string)($a['api_key'] ?? ''));
                        sfy_account_store_encrypt_status((int)$a['id'], $r);
                        $done++; if (empty($r['ok'])) $bad++;
                        if ($done === 1) {
                            $msg = empty($r['ok'])
                                ? 'Anti-bypass test FAILED for ' . $a['name'] . ': ' . (string)$r['error']
                                : 'Anti-bypass OK for ' . $a['name'] . ' (HTTP ' . (int)$r['http'] . ', ' . (int)$r['ms'] . ' ms, type ' . (string)$r['type'] . ') — encrypted link works.';
                            $type = empty($r['ok']) ? 'err' : 'ok';
                        }
                    }
                    if ($done > 1) $msg .= " — $done account(s) tested, $bad failed.";
                    if ($done === 0) $msg = 'No active account to test.';
                    sfy_audit('test_redirect_api', 'all');
                    break;
                }

                $st = $db->prepare("SELECT * FROM lootlabs_accounts WHERE id=? LIMIT 1");
                $st->execute([$id]);
                $acc = $st->fetch();
                if (!$acc) return ["Account #$id not found.", 'err'];

                $r    = sfy_lootlabs_test((string)($acc['api_key'] ?? ''));
                $kept = sfy_account_store_encrypt_status($id, $r);
                sfy_audit('test_redirect_api', "account#$id");
                $unsaved = $kept ? '' : ' (the result is only kept in the config fallback — the account columns are missing,
                                     so run Admin → Updater to store it on the account)'; 
                if (empty($r['ok'])) {
                    $msg  = 'Anti-bypass FAILED: ' . (string)$r['error'] . $unsaved;
                    $type = 'err';
                } else {
                    $msg = 'Anti-bypass OK — LootLabs encrypted ' . $r['destination'] . ' in ' . (int)$r['ms']
                         . ' ms (HTTP ' . (int)$r['http'] . ', type ' . (string)$r['type'] . '). Handoffs from this account now carry &data=.'
                         . $unsaved;
                }
                break;
            }
            /*
             * Provider-level test — each kind is checked with the tool that kind
             * actually uses, so "it says OK" means something specific:
             *
             *   lootlabs — the provider's own Redirect API key, the one every
             *              account without a key inherits, encrypts the landing;
             *   workink  — Work.ink's token endpoint accepts the Key System key
             *              (the key never travels anywhere else);
             *   custom   — the template expands to a real URL instead of the
             *              "no task URL" dead end.
             *
             * Nothing here touches a session, a step or a player: the Work.ink
             * check asks about a token this install invents, and the LootLabs one
             * only encrypts the install's own landing page.
             */
            case 'test_provider': {
                $id = sfy_int('id');
                if ($id <= 0) return ['No provider selected.', 'err'];
                $pRow = sfy_provider_find($id);
                if (!$pRow) return ["Provider #$id not found.", 'err'];

                $pRow = sfy_provider_normalize($pRow);
                $kind = sfy_provider_kind((string)$pRow['kind']);
                sfy_audit('test_provider', "provider#$id $kind");

                if ($kind === 'workink') {
                    /* Guarded: a half-uploaded install (this module missing) must
                       answer with a sentence, not a 500. */
                    if (!function_exists('sfy_workink_key_check')) {
                        return ['The Work.ink module (app/workink.php) is not on this upload — re-upload it and retry.', 'err'];
                    }
                    $r = sfy_workink_key_check((string)$pRow['api_key']);
                    sfy_workink_record_test($id, $r);
                    if (empty($r['ok'])) {
                        return ['Work.ink key check: ' . (string)$r['error'], 'err'];
                    }
                    return ['Work.ink key OK — Work.ink accepted it (HTTP ' . (int)$r['http'] . ') on a token this install '
                          . 'invented, so nothing was verified for a player.', 'ok'];
                }

                if ($kind === 'lootlabs') {
                    $key = trim((string)$pRow['api_key']);
                    if ($key === '') {
                        return ['This LootLabs provider has no Redirect API key of its own. Paste one in the editor (accounts '
                              . 'without a key inherit it), or test the key on the account itself under Admin → Accounts.', 'err'];
                    }
                    $r = sfy_lootlabs_test($key);
                    if (empty($r['ok'])) return ['Anti-bypass FAILED: ' . (string)$r['error'], 'err'];
                    return ['Anti-bypass OK — LootLabs encrypted ' . (string)$r['destination'] . ' in ' . (int)$r['ms']
                          . ' ms (HTTP ' . (int)$r['http'] . '). Every account that inherits this key now sends handoffs '
                          . 'with &data=.', 'ok'];
                }

                $hand  = ['sid' => 'probe-session', 'nonce' => 'probe-nonce', 'signature' => 'probe-sig', 'step' => 1];
                $built = sfy_provider_build_handoff($pRow, ['id' => 0, 'task_url' => ''],
                                                    ['token' => 'probe-token', 'game_id' => '0'], $hand);
                if (empty($built['url'])) {
                    return ['This template produces no link: '
                          . (string)($built['error'] ?? 'the provider has no task URL and its accounts carry none'), 'err'];
                }
                return ['Template OK — one handoff expands to ' . (string)$built['url'], 'ok'];
            }
            case 'delete_account': {
                $id = sfy_int('id');
                $db->prepare("DELETE FROM lootlabs_accounts WHERE id=?")->execute([$id]);
                sfy_audit('delete_account', "account#$id");
                $msg = "Account #$id deleted.";
                break;
            }
            case 'toggle_account': {
                $id = sfy_int('id');
                $db->prepare("UPDATE lootlabs_accounts SET is_active=IF(is_active=1,0,1), updated_at=NOW() WHERE id=?")->execute([$id]);
                sfy_audit('toggle_account', "account#$id");
                $msg = "Account #$id toggled.";
                break;
            }

            /* ── games ─────────────────────────────────────────────── */
            case 'save_game': {
                $gid    = substr(sfy_param('game_id'), 0, 64);
                $gname  = substr(sfy_param('game_name', 'Unknown Game'), 0, 191);
                $url    = sfy_param('script_url');
                $maxr   = max(1, sfy_int('max_runs', 50));
                $active = isset($_POST['is_active']) ? 1 : 0;
                $notes  = sfy_param('notes');
                if ($gid === '' || $url === '') return ['Game ID and script URL are required.', 'err'];
                $db->prepare("INSERT INTO sfy_games (game_id,game_name,script_url,is_active,max_runs,notes,created_at,updated_at)
                              VALUES (?,?,?,?,?,?,NOW(),NOW())
                              ON DUPLICATE KEY UPDATE game_name=VALUES(game_name),script_url=VALUES(script_url),
                                                      is_active=VALUES(is_active),max_runs=VALUES(max_runs),
                                                      notes=VALUES(notes),script_version=script_version+1,updated_at=NOW()")
                   ->execute([$gid,$gname,$url,$active,$maxr,$notes]);
                sfy_audit('save_game', $gid);
                $msg = "Game $gid saved.";
                break;
            }
            case 'delete_game': {
                $gid = substr(sfy_param('game_id'), 0, 64);
                $db->prepare("DELETE FROM sfy_games WHERE game_id=?")->execute([$gid]);
                sfy_audit('delete_game', $gid);
                $msg = "Game $gid deleted.";
                break;
            }
            case 'toggle_game': {
                $gid = substr(sfy_param('game_id'), 0, 64);
                $db->prepare("UPDATE sfy_games SET is_active=IF(is_active=1,0,1), updated_at=NOW() WHERE game_id=?")->execute([$gid]);
                $msg = "Game $gid toggled.";
                break;
            }

            /* ── tokens ────────────────────────────────────────────── */
            case 'save_token': {
                $token   = substr(sfy_param('token'), 0, 64);
                $code    = substr(sfy_param('code'), 0, 64);
                $gid     = substr(sfy_param('game_id'), 0, 64);
                $gname   = substr(sfy_param('game_name'), 0, 191);
                $tasks   = max(1, min(20, sfy_int('tasks_required', 2)));
                $chain   = substr(sfy_param('account_chain'), 0, 191);
                $maxruns = max(1, sfy_int('max_runs', 50));
                $maxdev  = max(0, sfy_int('max_devices', 1));
                $expires = sfy_param('expires_at');
                $isUsed  = sfy_int('is_used');
                $notes   = sfy_param('notes');
                /* Unticked checkboxes are simply absent from the POST. */
                $multi   = sfy_int('multi_use') === 1 ? 1 : 0;
                $hidden  = sfy_int('is_hidden') === 1 ? 1 : 0;

                if ($token === '') {
                    $token = strtoupper('SFY-' . bin2hex(random_bytes(6)));
                }
                if ($code === '') $code = strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));

                /*
                 * The two delivery columns only exist once migration 022 has
                 * run, so they are written only when the database has them.
                 */
                $hasMulti  = sfy_column_exists('sfy_tokens', 'multi_use');
                $hasHidden = sfy_column_exists('sfy_tokens', 'is_hidden');
                $cols = ['token','code','game_id','game_name','tasks_required','account_chain',
                         'is_used','max_runs','max_devices','expires_at','notes','created_by'];
                $vals = [$token,$code,$gid ?: null,$gname ?: null,$tasks,$chain ?: null,$isUsed,$maxruns,$maxdev,
                         $expires !== '' ? date('Y-m-d H:i:s', strtotime($expires)) : null,$notes,$who];
                $upd  = ['code=VALUES(code)','game_id=VALUES(game_id)','game_name=VALUES(game_name)',
                         'tasks_required=VALUES(tasks_required)','account_chain=VALUES(account_chain)',
                         'is_used=VALUES(is_used)','max_runs=VALUES(max_runs)','max_devices=VALUES(max_devices)',
                         'expires_at=VALUES(expires_at)','notes=VALUES(notes)'];
                if ($hasMulti)  { $cols[] = 'multi_use'; $vals[] = $multi;  $upd[] = 'multi_use=VALUES(multi_use)'; }
                if ($hasHidden) { $cols[] = 'is_hidden'; $vals[] = $hidden; $upd[] = 'is_hidden=VALUES(is_hidden)'; }
                $marks = array_fill(0, count($cols), '?');

                $db->prepare('INSERT INTO sfy_tokens (' . implode(',', $cols) . ',created_at)'
                             . ' VALUES (' . implode(',', $marks) . ',NOW())'
                             . ' ON DUPLICATE KEY UPDATE ' . implode(',', $upd))
                   ->execute($vals);
                sfy_audit('save_token', $token);
                $_SESSION['sfy_admin_flash'] = ["Token $token saved.", 'ok'];
                sfy_redirect(sfy_admin_url(['tab' => 'tokens']));
                break;
            }
            case 'bulk_update_tokens': {
                $scope = (string)sfy_param('bulk_scope', 'all');
                $chain = trim((string)sfy_param('bulk_account_chain'));
                $tasks = (int)sfy_param('bulk_tasks', 0);
                $runs  = (int)sfy_param('bulk_max_runs', 0);
                $devRaw = trim((string)sfy_param('bulk_max_devices'));
                $devices = $devRaw === '' ? null : max(0, min(100, (int)$devRaw));

                $sets = []; $args = []; $where = []; $wp = [];
                if ($chain !== '') { $sets[] = 'account_chain=?'; $args[] = substr($chain, 0, 191); }
                if ($tasks > 0)   { $sets[] = 'tasks_required=?'; $args[] = max(1, min(20, $tasks)); }
                if ($runs > 0)    { $sets[] = 'max_runs=?'; $args[] = max(1, min(10000, $runs)); }
                if ($devices !== null) { $sets[] = 'max_devices=?'; $args[] = $devices; }
                if (!$sets) return ['Fill at least one field to update.', 'err'];

                if ($scope === 'unused') { $where[] = 'is_used=0'; }
                elseif ($scope === 'used') { $where[] = 'is_used=1'; }
                elseif ($scope === 'filtered') {
                    $q = trim((string)sfy_param('q'));
                    $game = trim((string)sfy_param('game'));
                    $state = trim((string)sfy_param('state'));
                    if ($q !== '') {
                        $where[] = '(token LIKE ? OR code LIKE ? OR notes LIKE ?)';
                        $wp[] = "%$q%"; $wp[] = "%$q%"; $wp[] = "%$q%";
                    }
                    if ($game !== '') { $where[] = 'game_id=?'; $wp[] = $game; }
                    if ($state === 'used') $where[] = 'is_used=1';
                    if ($state === 'unused') $where[] = 'is_used=0';
                }
                $sql = 'UPDATE sfy_tokens SET ' . implode(',', $sets)
                     . ($where ? ' WHERE ' . implode(' AND ', $where) : '');
                $st = $db->prepare($sql);
                $st->execute(array_merge($args, $wp));
                $n = $st->rowCount();
                sfy_audit('bulk_update_tokens', "$n tokens · $scope");
                $_SESSION['sfy_admin_flash'] = ["Updated $n token(s). Existing sessions keep their original step count.", 'ok'];
                sfy_redirect(sfy_admin_url(['tab' => 'tokens']));
                break;
            }
            case 'bulk_tokens': {
                $count = max(1, min(500, sfy_int('count', 10)));
                $tasks = max(1, min(20, sfy_int('tasks_required', 2)));
                $chain = substr(sfy_param('account_chain'), 0, 191);
                $gid   = substr(sfy_param('game_id'), 0, 64);
                $gname = substr(sfy_param('game_name'), 0, 191);
                $prefix= preg_replace('/[^A-Z0-9\-]/i', '', sfy_param('prefix', 'SFY')) ?: 'SFY';
                $expires = sfy_param('expires_at');
                $expiresSql = $expires !== '' ? date('Y-m-d H:i:s', strtotime($expires)) : null;

                $ins = $db->prepare("INSERT IGNORE INTO sfy_tokens
                        (token,code,game_id,game_name,tasks_required,account_chain,is_used,max_runs,max_devices,expires_at,created_by,created_at)
                        VALUES (?,?,?,?,?,?,0,50,1,?,?,NOW())");
                $made = 0;
                for ($i = 0; $i < $count; $i++) {
                    $t = strtoupper($prefix . '-' . strtoupper(bin2hex(random_bytes(3))) . '-' . strtoupper(bin2hex(random_bytes(2))));
                    $c = strtoupper(bin2hex(random_bytes(4)));
                    $ins->execute([$t, $c, $gid ?: null, $gname ?: null, $tasks, $chain ?: null, $expiresSql, $who]);
                    if ($ins->rowCount() > 0) $made++;
                }
                sfy_audit('bulk_tokens', "generated $made");
                $msg = "$made token(s) generated.";
                break;
            }
            case 'delete_token': {
                $token = substr(sfy_param('token'), 0, 64);
                $db->prepare("DELETE FROM sfy_tokens WHERE token=?")->execute([$token]);
                sfy_audit('delete_token', $token);
                $msg = 'Token deleted.';
                break;
            }
            case 'toggle_token': {
                $token = substr(sfy_param('token'), 0, 64);
                $db->prepare("UPDATE sfy_tokens SET is_used=IF(is_used=1,0,1) WHERE token=?")->execute([$token]);
                sfy_audit('toggle_token', $token);
                $msg = 'Token status toggled.';
                break;
            }
            case 'reset_token': {
                $token = substr(sfy_param('token'), 0, 64);
                $db->prepare("UPDATE sfy_tokens SET is_used=0, used_at=NULL, used_ip=NULL, used_device_id=0 WHERE token=?")->execute([$token]);
                $db->prepare("UPDATE sfy_sessions SET is_completed=0, current_step=1, completed_at=NULL,
                                expires_at=" . sfy_sql_now_offset('MINUTE') . " WHERE token=?")
                   ->execute([sfy_setting_int('session_ttl_minutes', 30), $token]);
                sfy_audit('reset_token', $token);
                $msg = "Token $token reset (sessions reopened).";
                break;
            }
            case 'purge_used_tokens': {
                $n = $db->exec("DELETE FROM sfy_tokens WHERE is_used=1 AND used_at < DATE_SUB(NOW(), INTERVAL 7 DAY)");
                sfy_audit('purge_used_tokens', (string)$n);
                $msg = "Purged $n used token(s) older than 7 days.";
                break;
            }

            /* ── sessions ──────────────────────────────────────────── */
            case 'clear_expired_sessions': {
                $n = $db->exec("DELETE FROM sfy_sessions WHERE is_completed=0 AND expires_at < NOW()");
                sfy_audit('clear_expired_sessions', (string)$n);
                $msg = "Cleared $n expired session(s).";
                break;
            }
            case 'clear_all_sessions': {
                $n = $db->exec("DELETE FROM sfy_sessions");
                $db->exec("DELETE FROM sfy_step_tokens");
                sfy_audit('clear_all_sessions', (string)$n);
                $msg = "Cleared $n session(s) and all step nonces.";
                break;
            }
            case 'delete_session': {
                $sid = substr(sfy_param('session_id'), 0, 64);
                $db->prepare("DELETE FROM sfy_sessions WHERE session_id=?")->execute([$sid]);
                $db->prepare("DELETE FROM sfy_step_tokens WHERE session_id=?")->execute([$sid]);
                sfy_audit('delete_session', $sid);
                $msg = 'Session deleted.';
                break;
            }
            case 'reset_session': {
                $sid = substr(sfy_param('session_id'), 0, 64);
                $db->prepare("UPDATE sfy_sessions SET current_step=1, is_completed=0, completed_at=NULL,
                                bypass_flags=0, risk_score=0, step_started_at=NOW(),
                                expires_at=" . sfy_sql_now_offset('MINUTE') . " WHERE session_id=?")
                   ->execute([sfy_setting_int('session_ttl_minutes', 30), $sid]);
                $db->prepare("DELETE FROM sfy_step_tokens WHERE session_id=?")->execute([$sid]);
                /* A run that starts over is a run that earns its human check
                   again — otherwise a reset would be a free pass. */
                sfy_captcha_reset($sid);
                sfy_audit('reset_session', $sid);
                $msg = 'Session reset to step 1.';
                break;
            }
            case 'session_update': {
                $sid = substr(sfy_param('session_id'), 0, 64);
                $st = $db->prepare("SELECT * FROM sfy_sessions WHERE session_id=?");
                $st->execute([$sid]);
                $s = $st->fetch();
                if (!$s) return ['Session not found.', 'err'];
                $step  = max(1, min(100, sfy_int('edit_step', (int)$s['current_step'])));
                $total = max(1, min(50, sfy_int('edit_total', (int)$s['total_steps'])));
                $flags = max(0, min(99, sfy_int('edit_flags', (int)($s['bypass_flags'] ?? 0))));
                $risk  = max(0, min(100, sfy_int('edit_risk', (int)($s['risk_score'] ?? 0))));
                $prov  = max(0, sfy_int('edit_provider', (int)($s['provider_id'] ?? 0)));
                $done  = sfy_param('edit_completed') === '1' ? 1 : 0;
                $expires = trim(sfy_param('edit_expires'));
                if ($expires !== '') {
                    $ts = strtotime($expires);
                    if ($ts === false) return ['Invalid expiry date.', 'err'];
                    $expires = date('Y-m-d H:i:s', $ts);
                } else {
                    $expires = (string)($s['expires_at'] ?? '');
                }
                $cur = $done ? $total + 1 : min($step, $total);
                $db->prepare("UPDATE sfy_sessions SET current_step=?, total_steps=?, bypass_flags=?, risk_score=?,
                                 provider_id=?, is_completed=?, completed_at=" . ($done ? 'NOW()' : 'NULL') . ",
                                 expires_at=? WHERE session_id=?")
                   ->execute([$cur, $total, $flags, $risk, $prov, $done, $expires ?: null, $sid]);
                sfy_audit('session_update', $sid);
                $_SESSION['sfy_admin_flash'] = ['Session updated.', 'ok'];
                sfy_redirect(sfy_admin_url(['tab' => 'sessions']));
                break;
            }
            case 'complete_session': {
                $sid = substr(sfy_param('session_id'), 0, 64);
                $st = $db->prepare("SELECT * FROM sfy_sessions WHERE session_id=?");
                $st->execute([$sid]);
                $s = $st->fetch();
                if (!$s) return ['Session not found.', 'err'];
                $db->prepare("UPDATE sfy_sessions SET current_step=total_steps+1, is_completed=1, completed_at=NOW() WHERE session_id=?")
                   ->execute([$sid]);
                $db->prepare("UPDATE sfy_tokens SET is_used=1, used_at=NOW() WHERE token=?")->execute([$s['token']]);
                $db->prepare("UPDATE sfy_step_tokens SET consumed_at=NOW() WHERE session_id=? AND consumed_at IS NULL")->execute([$sid]);
                sfy_audit('complete_session', $sid);
                $msg = 'Session force-completed (admin override).';
                break;
            }

            /* ── devices ───────────────────────────────────────────── */
            case 'block_device': case 'unblock_device': {
                $id = sfy_int('id');
                sfy_device_block($id, $action === 'block_device');
                sfy_audit($action, "device#$id");
                $msg = $action === 'block_device' ? "Device #$id blocked." : "Device #$id unblocked.";
                break;
            }
            case 'trust_device': {
                $id = sfy_int('id');
                $db->prepare("UPDATE sfy_devices SET is_trusted=IF(is_trusted=1,0,1), risk_score=0, updated_at=NOW() WHERE id=?")->execute([$id]);
                sfy_audit('trust_device', "device#$id");
                $msg = "Device #$id trust toggled.";
                break;
            }
            case 'reset_device': {
                $id = sfy_int('id');
                $db->prepare("UPDATE sfy_devices SET success_count=0, fail_count=0, session_count=0, code_views=0,
                                bypass_attempts=0, tokens_used=0, risk_score=0, updated_at=NOW() WHERE id=?")->execute([$id]);
                sfy_audit('reset_device', "device#$id");
                $msg = "Device #$id counters reset.";
                break;
            }
            case 'save_device_note': {
                $id = sfy_int('id');
                $db->prepare("UPDATE sfy_devices SET notes=?, updated_at=NOW() WHERE id=?")->execute([sfy_param('notes'), $id]);
                sfy_audit('save_device_note', "device#$id");
                $msg = 'Device note saved.';
                break;
            }
            case 'delete_device': {
                $id = sfy_int('id');
                sfy_device_delete($id);
                sfy_audit('delete_device', "device#$id");
                $msg = "Device #$id deleted.";
                break;
            }
            case 'bulk_block_suspicious': {
                $n = $db->exec("UPDATE sfy_devices SET is_blocked=1, updated_at=NOW()
                                WHERE is_blocked=0 AND (bypass_attempts > 0 OR risk_score >= 50)");
                sfy_audit('bulk_block_suspicious', (string)$n);
                $msg = "Blocked $n suspicious device(s).";
                break;
            }

            /* ── ads ───────────────────────────────────────────────── */
            case 'save_ad': {
                if (!sfy_table_exists('sfy_ads')) {
                    return ['The ads table is not installed yet — run Admin → Updater first.', 'err'];
                }
                $id     = sfy_int('id');
                $title  = substr(sfy_param('title'), 0, 191);
                if ($title === '') return ['Ad title is required.', 'err'];
                $pagesArr = array_filter((array)($_POST['pages'] ?? ['all']), fn($p) => isset(sfy_ad_pages()[(string)$p]));
                $place  = sfy_param('placement', 'banner');
                if (!isset(sfy_ad_placements()[$place])) $place = 'banner';

                /*
                 * Only write the columns this install actually has. A partly
                 * upgraded database used to fail the whole save with an SQL
                 * error instead of storing the ad.
                 */
                $vals = [
                    'title'          => $title,
                    'body'           => sfy_param('body'),
                    'image_url'      => sfy_param('image_url'),
                    'target_url'     => sfy_param('target_url'),
                    'button_text'    => substr(sfy_param('button_text', 'Open'), 0, 64),
                    'placement'      => $place,
                    'pages'          => $pagesArr ? implode(',', array_map('strval', $pagesArr)) : 'all',
                    'theme_color'    => preg_match('/^#[0-9a-fA-F]{3,8}$/', sfy_param('theme_color')) ? sfy_param('theme_color') : '#3BF5D0',
                    'is_active'      => isset($_POST['is_active']) ? 1 : 0,
                    'is_dismissible' => isset($_POST['is_dismissible']) ? 1 : 0,
                    'sort_order'     => sfy_int('sort_order'),
                    'start_at'       => sfy_param('start_at') !== '' ? date('Y-m-d H:i:s', strtotime(sfy_param('start_at'))) : null,
                    'end_at'         => sfy_param('end_at')   !== '' ? date('Y-m-d H:i:s', strtotime(sfy_param('end_at')))   : null,
                    'max_impressions'=> max(0, sfy_int('max_impressions')),
                ];

                $cols = []; $params = [];
                foreach ($vals as $col => $val) {
                    if (!sfy_ad_has($col)) continue;
                    $cols[]   = "`$col`";
                    $params[] = $val;
                }
                if (!$cols) return ['The ads table is missing every column this form writes — run Admin → Updater.', 'err'];

                if ($id > 0) {
                    $sets = implode(',', array_map(fn($c) => "$c=?", $cols));
                    if (sfy_ad_has('updated_at')) $sets .= ',`updated_at`=NOW()';
                    $params[] = $id;
                    $db->prepare("UPDATE sfy_ads SET $sets WHERE id=?")->execute($params);
                    sfy_audit('save_ad', "ad#$id");
                    $msg = "Ad #$id updated.";
                } else {
                    if (sfy_ad_has('created_at')) { $cols[] = '`created_at`'; }
                    if (sfy_ad_has('updated_at')) { $cols[] = '`updated_at`'; }
                    if (sfy_ad_has('created_by')) { $cols[] = '`created_by`'; $params[] = $who; }
                    $nows = [];
                    foreach ($cols as $c) $nows[] = ($c === '`created_at`' || $c === '`updated_at`') ? 'NOW()' : '?';
                    $db->prepare('INSERT INTO sfy_ads (' . implode(',', $cols) . ') VALUES (' . implode(',', $nows) . ')')
                       ->execute($params);
                    $newId = (int)$db->lastInsertId();
                    sfy_audit('add_ad', "ad#$newId");
                    $msg = "Ad #$newId created.";
                }
                break;
            }
            case 'delete_ad': {
                $id = sfy_int('id');
                $db->prepare("DELETE FROM sfy_ads WHERE id=?")->execute([$id]);
                sfy_audit('delete_ad', "ad#$id");
                $msg = "Ad #$id deleted.";
                break;
            }
            case 'toggle_ad': {
                $id = sfy_int('id');
                $db->prepare("UPDATE sfy_ads SET is_active=IF(is_active=1,0,1), updated_at=NOW() WHERE id=?")->execute([$id]);
                sfy_audit('toggle_ad', "ad#$id");
                $msg = "Ad #$id toggled.";
                break;
            }
            case 'reset_ad_stats': {
                $id = sfy_int('id');
                $sql = $id > 0 ? "UPDATE sfy_ads SET impressions=0, clicks=0, dismissals=0 WHERE id=" . $id
                               : "UPDATE sfy_ads SET impressions=0, clicks=0, dismissals=0";
                $db->exec($sql);
                sfy_audit('reset_ad_stats', $id > 0 ? "ad#$id" : 'all');
                $msg = 'Ad statistics reset.';
                break;
            }

            /* ── staff ─────────────────────────────────────────────── */
            case 'save_staff': {
                $id      = sfy_int('id');
                $user    = strtolower(preg_replace('/[^a-z0-9_\.\-]/i', '', sfy_param('username')));
                $display = substr(sfy_param('display_name'), 0, 96);
                $role    = sfy_param('role', 'staff');
                if (sfy_role_level($role) === 0) $role = 'staff';
                $pass    = sfy_param('password');
                $active  = isset($_POST['is_active']) ? 1 : 0;
                $notes   = sfy_param('notes');

                if ($id > 0) {
                    $fields = ['display_name=?','role=?','is_active=?','notes=?','updated_at=NOW()'];
                    $params = [$display,$role,$active,$notes];
                    if ($pass !== '') {
                        if (strlen($pass) < 8) return ['Password must be at least 8 characters.', 'err'];
                        $fields[] = 'password_hash=?';
                        $params[] = password_hash($pass, PASSWORD_BCRYPT);
                    }
                    $params[] = $id;
                    $db->prepare("UPDATE sfy_staff SET " . implode(',', $fields) . " WHERE id=?")->execute($params);
                    sfy_audit('save_staff', "staff#$id");
                    $msg = "Staff #$id updated.";
                } else {
                    if ($user === '') return ['Username is required.', 'err'];
                    if (strlen($pass) < 8) return ['Password must be at least 8 characters.', 'err'];
                    if (sfy_staff_find($user)) return ['That username already exists.', 'err'];
                    $newId = sfy_staff_create($user, $pass, $role, $display, (int)($me['id'] ?? 0));
                    $db->prepare("UPDATE sfy_staff SET is_active=?, notes=?, created_at=NOW() WHERE id=?")->execute([$active,$notes,$newId]);
                    sfy_audit('add_staff', "staff#$newId ($role)");
                    $msg = "Staff $user created with role $role.";
                }
                break;
            }
            case 'toggle_staff': {
                $id = sfy_int('id');
                if ($id === (int)($me['id'] ?? 0)) return ['You cannot disable your own account.', 'err'];
                $db->prepare("UPDATE sfy_staff SET is_active=IF(is_active=1,0,1), updated_at=NOW() WHERE id=?")->execute([$id]);
                sfy_audit('toggle_staff', "staff#$id");
                $msg = "Staff #$id toggled.";
                break;
            }
            case 'unlock_staff': {
                $id = sfy_int('id');
                $db->prepare("UPDATE sfy_staff SET failed_attempts=0, locked_until=NULL, updated_at=NOW() WHERE id=?")->execute([$id]);
                $st = $db->prepare("SELECT username FROM sfy_staff WHERE id=?");
                $st->execute([$id]);
                if ($u = $st->fetch()) {
                    $db->prepare("DELETE FROM sfy_login_attempts WHERE username=? AND success=0")->execute([$u['username']]);
                }
                sfy_audit('unlock_staff', "staff#$id");
                $msg = "Staff #$id unlocked and failed attempts cleared.";
                break;
            }
            case 'delete_staff': {
                $id = sfy_int('id');
                if ($id === (int)($me['id'] ?? 0)) return ['You cannot delete your own account.', 'err'];
                $st = $db->prepare("SELECT role FROM sfy_staff WHERE id=?");
                $st->execute([$id]);
                $role = (string)($st->fetch()['role'] ?? '');
                if ($role === 'owner') {
                    $owners = (int)$db->query("SELECT COUNT(*) AS n FROM sfy_staff WHERE role='owner' AND is_active=1")->fetch()['n'];
                    if ($owners <= 1) return ['You cannot delete the last active owner.', 'err'];
                }
                $db->prepare("DELETE FROM sfy_staff WHERE id=?")->execute([$id]);
                sfy_audit('delete_staff', "staff#$id");
                $msg = "Staff #$id deleted.";
                break;
            }
            case 'change_own_password': {
                $new = sfy_param('new_password');
                if (strlen($new) < 8) return ['Password must be at least 8 characters.', 'err'];
                if ($new !== sfy_param('new_password2')) return ['Passwords do not match.', 'err'];
                if (!password_verify(sfy_param('current_password'), (string)($me['password_hash'] ?? ''))) {
                    return ['Current password is incorrect.', 'err'];
                }
                $db->prepare("UPDATE sfy_staff SET password_hash=?, updated_at=NOW() WHERE id=?")
                   ->execute([password_hash($new, PASSWORD_BCRYPT), (int)($me['id'] ?? 0)]);
                sfy_config_set('admin_password_hash', password_hash($new, PASSWORD_BCRYPT));
                sfy_audit('change_password', 'self');
                $msg = 'Your password has been changed.';
                break;
            }

            /* ── security logs ─────────────────────────────────────── */
            case 'clear_login_attempts': {
                $n = $db->exec("DELETE FROM sfy_login_attempts");
                sfy_audit('clear_login_attempts', (string)$n);
                $msg = "Cleared $n login attempt record(s).";
                break;
            }
            case 'clear_audit': {
                $n = $db->exec("DELETE FROM sfy_audit_log");
                sfy_audit('clear_audit', (string)$n);
                $msg = "Cleared $n audit record(s).";
                break;
            }
            case 'clear_error_log': {
                $size = sfy_log_size();
                sfy_log_clear();
                sfy_audit('clear_error_log', $size . ' bytes');
                $msg = 'Error log cleared (' . number_format($size) . ' bytes).';
                break;
            }

            /* ── settings ──────────────────────────────────────────── */
            /* ══ BYPASS COUNTERS ═════════════════════════════════════
               The block reads three things: the session flags, the device
               counter and (only when the owner opts in) the last 24h of
               rejected rows. Clear all three in one action. Audit rows that
               are not rejections are left alone. */
            case 'reset_bypass': {
                $db->exec("UPDATE sfy_sessions SET bypass_flags=0, risk_score=0");
                $db->exec("UPDATE sfy_devices SET bypass_attempts=0, risk_score=0");
                $db->exec("DELETE FROM sfy_postback_log
                            WHERE reason IN ('return_rejected','bad_postback_key','ip_mismatch','unattributed_ip')");
                sfy_audit('reset_bypass', 'settings');
                $msg = 'Bypass flags, device counters and rejected-row window cleared.';
                break;
            }

            case 'support_admin_reply':
            case 'support_status':
            case 'support_delete': {
                $id = sfy_int('id');
                if ($id <= 0 || !sfy_support_find_id($id)) return ['Request not found.', 'err'];
                if ($action === 'support_delete') {
                    sfy_support_delete($id);
                    sfy_audit('support_delete', "request#$id");
                    $_SESSION['sfy_admin_flash'] = ['Request deleted.', 'ok'];
                    sfy_redirect(sfy_admin_url(['tab' => 'inbox']));
                }
                if ($action === 'support_status') {
                    $status = (string)sfy_param('status', 'open');
                    if (!sfy_support_update_status($id, $status)) return ['Unknown status.', 'err'];
                    sfy_audit('support_status', "request#$id $status");
                    $_SESSION['sfy_admin_flash'] = ['Request status updated.', 'ok'];
                    sfy_redirect(sfy_admin_url(['tab' => 'inbox', 'view' => $id]));
                }
                $res = sfy_support_reply($id, 'admin', (string)sfy_param('message'), sfy_client_ip());
                if (!$res['ok']) {
                    $_SESSION['sfy_admin_flash'] = [(string)$res['error'], 'err'];
                } else {
                    sfy_audit('support_admin_reply', "request#$id");
                    $_SESSION['sfy_admin_flash'] = ['Reply sent.', 'ok'];
                }
                sfy_redirect(sfy_admin_url(['tab' => 'inbox', 'view' => $id]));
                break;
            }
            case 'commerce_order_status':
            case 'commerce_order_delete': {
                if (!sfy_table_exists('sfy_hub_orders')) return ['The hub order table is not installed.', 'err'];
                $id = sfy_int('id');
                if ($id <= 0) return ['No order selected.', 'err'];
                if ($action === 'commerce_order_delete') {
                    $db->prepare('DELETE FROM sfy_hub_orders WHERE id=?')->execute([$id]);
                    sfy_audit('commerce_order_delete', "order#$id");
                    $_SESSION['sfy_admin_flash'] = ['Order deleted.', 'ok'];
                } else {
                    $status = (string)sfy_param('status', 'pending');
                    $allowed = ['pending','contacted','paid','delivered','cancelled'];
                    if (!in_array($status, $allowed, true)) return ['Unknown order status.', 'err'];
                    $note = substr((string)sfy_param('admin_note'), 0, 2000);
                    $db->prepare('UPDATE sfy_hub_orders SET status=?, admin_note=?, updated_at=NOW() WHERE id=?')
                       ->execute([$status, $note, $id]);
                    sfy_audit('commerce_order_status', "order#$id $status");
                    $_SESSION['sfy_admin_flash'] = ['Order updated.', 'ok'];
                }
                sfy_redirect(sfy_admin_url(['tab' => 'commerce', 'section' => 'orders']));
                break;
            }
            case 'save_pricing': {
                /* pricing_save_v3: delegated to the shared save function. */
                $res = sfy_pricing_save_post($_POST);
                if (empty($res[0])) return [(string)$res[1], 'err'];
                sfy_audit('save_pricing', 'saved');
                $_SESSION['sfy_admin_flash'] = [(string)$res[1], 'ok'];
                sfy_redirect(sfy_admin_url(['tab' => 'commerce', 'section' => 'plans']));
                break;
            }
            case 'save_config': {
                $keys = [
                    'session_ttl_minutes','default_tasks_required','default_account_chain','min_task_seconds',
                    'code_view_ttl_minutes','max_code_views','code_handoff','token_reuse','max_login_attempts','site_headline','site_subtext',
                    'support_discord','premium_offer_title','premium_offer_text','return_url',
                    'premium_accent','premium_button_label','premium_note','premium_bullets',
                    'checkpoint_label','checkpoint_label_plural',
                    'pinned_label_continue','pinned_label_code','pinned_label_guide',
                    'postback_fallback','return_dwell_seconds','return_referrer_hosts','zerotap_handoff_seconds',
                    'return_referrer_block','postback_ip_allowlist','bypass_block_after',
                    'bypass_ip_window_hours','bypass_warning_delay','relay_pull_url','relay_timeout',
                    'redirect_api','encrypt_method','redirect_cache_hours',
                    /* Human check — keys, appearance and what a broken service does. */
                    'turnstile_site_key','turnstile_secret','turnstile_theme','turnstile_fail_mode',
                ];
                foreach ($keys as $k) {
                    if (!array_key_exists($k, $_POST)) continue;
                    $v = trim((string)$_POST[$k]);
                    sfy_config_set('set_' . $k, $v);
                    sfy_config_set($k, $v);          // legacy key kept in sync
                }
                /*
                 * Flags are only re-written by the form that actually owns
                 * them. Before this, saving the SITE COPY card silently
                 * switched require_postback / maintenance_mode off, because a
                 * missing checkbox looks exactly like an unticked one.
                 */
                if (isset($_POST['has_flags'])) {
                    foreach (['require_postback','maintenance_mode','tutorial_enabled','tutorial_fab',
                              'return_require_provider','zerotap','hub_pass',
                              'return_ticket_required','postback_ip_enforce','postback_require_nonce','return_require_referrer',
                              'show_bypass_warning','bypass_block','bypass_block_ip',
                              'turnstile_enabled','turnstile_at_claim','turnstile_at_admin'] as $flag) {
                        if (array_key_exists($flag, $_POST)) {
                            sfy_config_set('set_' . $flag, '1');
                        } elseif (isset($_POST['flag_' . $flag])) {
                            sfy_config_set('set_' . $flag, '0');
                        }
                    }
                }
                if (array_key_exists('premium_accent', $_POST)) {
                    $acc = sfy_hex_clean((string)$_POST['premium_accent']);
                    sfy_config_set('set_premium_accent', $acc);
                }
                sfy_config_set('default_account_chain', trim((string)($_POST['default_account_chain'] ?? sfy_config_get('set_default_account_chain', '1,2'))));
                sfy_audit('save_config', 'settings');
                $msg = 'Settings saved.';
                break;
            }

            /* ── human check (Turnstile) ───────────────────────────── */
            case 'test_turnstile': {
                $t    = sfy_captcha_selftest();
                $msg  = 'Human check test: ' . (string)$t['text'];
                $type = !empty($t['ok']) ? 'ok' : 'err';
                sfy_audit('test_turnstile', (string)$t['why'] . ' ' . (string)$t['codes']);
                break;
            }
            case 'clear_captcha_log': {
                $n = sfy_captcha_clear_log();
                sfy_audit('clear_captcha_log', (string)$n);
                $msg = "Cleared $n human-check record(s).";
                break;
            }

            /* ── appearance ────────────────────────────────────────── */
            case 'save_appearance': {
                $in = [
                    'preset'     => sfy_param('preset', 'ink'),
                    'accent'     => sfy_param('accent'),
                    'radius'     => sfy_int('radius', 10),
                    'glow'       => sfy_int('glow', 45),
                    'shell'      => sfy_int('shell', 1120),
                    'font_scale' => sfy_int('font_scale', 100),
                    'density'    => sfy_param('density', 'cozy'),
                    'card_style' => sfy_param('card_style', 'solid'),
                    'bg_pattern' => sfy_param('bg_pattern', 'grid'),
                    'fx_grid'    => isset($_POST['fx_grid']) ? 1 : 0,
                    'fx_aurora'  => isset($_POST['fx_aurora']) ? 1 : 0,
                    'fx_scan'    => isset($_POST['fx_scan']) ? 1 : 0,
                    'fx_shine'   => isset($_POST['fx_shine']) ? 1 : 0,
                    /* advanced shaping */
                    'font_ui'    => sfy_param('font_ui', 'inter'),
                    'btn_style'  => sfy_param('btn_style', 'solid'),
                    'nav_style'  => sfy_param('nav_style', 'pill'),
                    'motion'     => sfy_param('motion', 'soft'),
                    'line_w'     => sfy_int('line_w', 1),
                    'grain'      => isset($_POST['grain']) ? 1 : 0,
                ];
                if (($qs = sfy_param('quick_style')) !== '') $in['quick_style'] = $qs;

                // Palette handling: either keep the preset clean, or persist a
                // frozen custom palette ("save this design").
                if (isset($_POST['use_custom_palette'])) {
                    $vars = [];
                    if (isset($_POST['palette']) && is_array($_POST['palette'])) {
                        foreach ($_POST['palette'] as $k => $v) {
                            $k = (string)$k;
                            if (!str_starts_with($k, '--') || strlen($k) > 24) continue;
                            $hex = sfy_hex_clean((string)$v);
                            if ($hex !== '') $vars[$k] = $hex;
                        }
                    }
                    $in['vars'] = $vars;
                } else {
                    $in['reset_vars'] = 1;
                }

                sfy_appearance_save($in);
                sfy_audit('save_appearance', (string)$in['preset'] . (isset($_POST['use_custom_palette']) ? ' +custom palette' : ''));
                $msg = 'Design saved. Every page (and the admin) now renders it.';
                break;
            }
            case 'reset_appearance': {
                sfy_appearance_save(array_merge(sfy_design_defaults(), ['reset_vars' => 1]));
                sfy_audit('reset_appearance', 'defaults');
                $msg = 'Appearance reset to the shipped default (Deep Ink).';
                break;
            }

            /* ── homepage layout + footer ──────────────────────────── */
            case 'save_layout': {
                $j    = json_decode((string)($_POST['layout_json'] ?? ''), true);
                $rows = is_array($j) ? ($j['sections'] ?? $j) : [];
                $rows = is_array($rows) ? $rows : [];
                if (!$rows) return ['The layout needs at least one section.', 'err'];
                $saved = sfy_layout_save($rows);
                sfy_audit('save_layout', count($saved) . ' section(s)');
                $msg = 'Homepage layout saved (' . count($saved) . ' section(s)).';
                break;
            }
            case 'reset_layout': {
                sfy_layout_reset();
                sfy_audit('reset_layout', 'default');
                $msg = 'Homepage layout restored to the default stack.';
                break;
            }
            case 'save_footer': {
                $j = json_decode((string)($_POST['footer_json'] ?? ''), true);
                if (!is_array($j)) return ['The footer payload was not valid JSON.', 'err'];
                $f = sfy_footer_save($j);
                sfy_audit('save_footer', count($f['links']) . ' link(s)');
                $msg = 'Footer saved (' . count($f['links']) . ' link slot(s)).';
                break;
            }

            /* ── updater ───────────────────────────────────────────── */
            case 'run_updater': {
                $log    = sfy_migrate(false);
                $applied = count(array_filter($log, fn($l) => $l['status'] === 'ok'));
                $failed  = count($log) - $applied;
                sfy_audit('run_updater', "$applied ok / $failed failed");
                $GLOBALS['SFY_UPDATER_LOG'] = $log;
                $msg = $log ? "$applied migration(s) applied" . ($failed ? ", $failed failed (see log below)" : '') . '.'
                            : 'Database is already up to date.';
                $type = $failed ? 'err' : 'ok';
                break;
            }
            case 'repair_schema': {
                $log = sfy_migrate(true);
                $GLOBALS['SFY_UPDATER_LOG'] = $log;
                sfy_audit('repair_schema', count($log) . ' steps');
                $msg = 'Full schema repair finished (' . count($log) . ' migration(s) re-checked).';
                break;
            }
            case 'import_sql': {
                $sql = trim((string)($_POST['sql'] ?? ''));
                if ($sql === '') return ['No SQL provided.', 'err'];
                foreach (['DROP ','TRUNCATE ','ALTER USER','GRANT ','CREATE USER','INTO OUTFILE'] as $bad) {
                    if (stripos($sql, $bad) !== false) return ["SQL contains a blocked statement ($bad).", 'err'];
                }
                $count = 0; $affected = 0; $errors = [];
                $db->exec("SET FOREIGN_KEY_CHECKS=0");
                foreach (array_filter(array_map('trim', explode(";\n", str_replace("\r", '', $sql)))) as $stmt) {
                    $stmt = trim($stmt);
                    if ($stmt === '' || str_starts_with($stmt, '--')) continue;
                    try { $affected += (int)$db->exec($stmt); $count++; }
                    catch (Throwable $e) { $errors[] = sfy_short($stmt, 40) . ': ' . $e->getMessage(); }
                }
                $db->exec("SET FOREIGN_KEY_CHECKS=1");
                sfy_audit('import_sql', "$count statement(s)");
                $msg = "Executed $count statement(s), $affected rows affected."
                     . ($errors ? ' Errors: ' . implode(' | ', array_slice($errors, 0, 3)) : '');
                if ($errors) $type = 'err';
                break;
            }
            case 'run_maintenance': {
                sfy_purge_stale();
                $db->exec("DELETE FROM sfy_sessions WHERE is_completed=0 AND expires_at < DATE_SUB(NOW(), INTERVAL 1 DAY)");
                $db->exec("DELETE FROM sfy_rate_limits WHERE window_start < DATE_SUB(NOW(), INTERVAL 1 HOUR)");
                sfy_audit('run_maintenance', 'manual');
                $msg = 'Maintenance finished: stale sessions, nonces, postback logs and rate limits pruned.';
                break;
            }

            default:
                return ['Unknown action.', 'err'];
        }
    } catch (Throwable $e) {
        error_log('[SFY admin] ' . $e->getMessage());
        return ['Error: ' . $e->getMessage(), 'err'];
    }

    return [$msg, $type];
}
