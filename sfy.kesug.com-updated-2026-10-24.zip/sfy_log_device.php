<?php
declare(strict_types=1);
/** Legacy path → /api/device (api/device.php). */
require __DIR__ . '/api/device.php';
