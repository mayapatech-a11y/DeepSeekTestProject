<?php
declare(strict_types=1);
/** Legacy path → /api/hook (api/hook.php). */
require __DIR__ . '/api/hook.php';
