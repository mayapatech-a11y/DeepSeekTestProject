<?php
declare(strict_types=1);
/**
 * TEMPORARY relay pull test — delete after use.
 * Open: https://sfytest.kesug.com/relay-test.php?key=<setup_key>
 *
 * It clears the 2s throttle lock, calls the configured relay pull URL from
 * THIS server, replays each event through /api/hook.php, and prints the result.
 * It can consume pending real postbacks, which is the point: it should turn
 * them into accepted rows.
 */
require __DIR__ . '/app/core.php';

$key = (string)($_GET['key'] ?? '');
if ($key === '' || !hash_equals((string)sfy_cfg('app.setup_key'), $key)) {
    http_response_code(403);
    header('Content-Type: text/plain; charset=utf-8');
    exit('forbidden');
}

@unlink(SFY_ROOT . '/storage/relay-pull.lock');

$url = trim(sfy_relay_opt('relay_pull_url', ''));
$out = [
    'relay_url_set' => $url !== '',
    'relay_url_len' => strlen($url),
    'relay_url_host' => $url !== '' ? (string)parse_url($url, PHP_URL_HOST) : '',
    'pull' => sfy_relay_pull(),
];

header('Content-Type: application/json; charset=utf-8');
echo json_encode($out, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
