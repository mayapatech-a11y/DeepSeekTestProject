<?php
declare(strict_types=1);
/**
 * Legacy include path — kept so any old script that does
 * `require 'sfy_core.php'` keeps working after the restructure.
 * The real bootstrap now lives in app/core.php.
 */
require_once __DIR__ . '/app/core.php';
