<?php
declare(strict_types=1);
/** Legacy path → /claim/<token> (pages/claim.php). */
require __DIR__ . '/pages/claim.php';
