<?php
declare(strict_types=1);
/**
 * ═══════════════════════════════════════════════════════════════════════
 *  SFY ULTIMATE — CENTRAL CONFIGURATION
 *  v6.0 — edit everything here, nothing else needs touching.
 * ═══════════════════════════════════════════════════════════════════════
 */

return [

    'app' => [
        'name'       => 'SFY ULTIMATE',
        'version'    => '9.0.1',
        'domain'     => 'https://sfy.kesug.com',
        'timezone'   => 'America/Los_Angeles',
        'debug'      => false,           // true = show PHP errors (dev only!)
        'app_key'    => '467673e5353743bad34c4dffca481a34',   // staging key — produces the live f9c3… postback key
        'setup_key'  => '454615c19ef0ade5b39cec14',
        'brand_line' => 'secure gateway // lootlabs grade',
    ],

    'db' => [
        'host' => 'sql209.infinityfree.com',
        'user' => 'if0_42941977',
        'pass' => 'wkM9F28pohF',
        'name' => 'if0_42941977_sfy_codesys',
        'port' => 3306,
    ],

    /*
     * The human check in front of the claim link.
     *
     * Armed here (a value saved in Admin → Settings → BOT CHECK overrides this
     * file, so the panel is still the switch): a fresh claim link asks for the
     * challenge once, and the run that opens from it is remembered as checked —
     * `/go`, `/done` and `/out` never ask again, and a finished token's code is
     * handed over without a check at all.
     *
     * Before trusting these keys, press TEST MY KEYS in that card. A challenge
     * that cannot be rendered is the one failure mode worth watching: an honest
     * visitor who can never produce a token is refused, so if the widget does
     * not appear on the live domain, switch the box OFF in the panel (the staff
     * sign-in is not gated by this file, so the panel stays reachable).
     */
    'turnstile' => [
        'enabled'  => true,
        'site_key' => '0x4AAAAAAB76t8brvM7b0a4c',
        'secret'   => '0x4AAAAAAB76t4cG_SB-rFyM1bElBJX03I0',
    ],

    'security' => [
        // ── postback / anti-bypass ─────────────────────────────────────
        'postback_secret'        => 'd556c9dcf155fe948400ec445e034cd5',
        'allow_unsigned_postback'=> false,   // refuse postbacks without a valid hash
        /*
         * LootLabs only returns the macros configured in its dashboard, so a
         * legitimate completion often arrives without our `sig`. When this is
         * true, a postback that carries the exact one-time step nonce (or the
         * session id we sent as unique_id) is accepted without a signature —
         * those values are only known to the provider. Set false to demand a
         * signature on every postback (stricter, but may stall real users).
         */
        'trust_provider_attribution' => true,
        /*
         * The postback URL's own password (P0-1).
         *
         * A postback is accepted only when it carries the per-account key that
         * sfy_postback_url() puts in the URL configured in the provider's
         * dashboard. The step nonce and the sig are printed in the player's
         * task URL, so neither of them can authenticate a call; this value is
         * never sent to a browser. Keep it true. Set it false for one release
         * only to diagnose a dashboard that still has the old URL.
         */
        'postback_key_required'  => true,
        'require_postback'       => true,    // steps only advance on a verified postback (enforced)
        'min_task_seconds'       => 10,      // user must dwell this long on the task
        /*
         * Return check — the safety net used when a postback never arrives
         * (mode and dwell are in Admin → Settings).
         *
         * `return_require_provider` makes a landing back on /done count only
         * when the browser says the *provider* sent the player there: a
         * cross-site document navigation from `return_referrer_hosts`. Typing
         * the landing URL, bookmarking it or fetching it from the console
         * reports `Sec-Fetch-Site: none` and confirms nothing. Turn it off only
         * if your provider cannot be recognised at all — with it off, any
         * visit to the landing page can confirm a step.
         *
         * `allow_browser_postback` is the same idea for the postback receiver:
         * the step nonce is visible in the player's own task URL, so a postback
         * URL pasted into the address bar must not verify anything. Leave it
         * false unless you really do run a redirect-based postback.
         */
        'return_require_provider' => true,
        'return_referrer_hosts'   => 'lootlabs.gg,lootlabs.com,loot-link.com',   // `*` = any host that is not ours
        /*
         * Hosts a landing is refused from, whatever else the request says.
         * Link-skipping services (Bacon Bypass and friends) name themselves in
         * the referrer when they do not strip it; this refuses them outright and
         * logs `blocked_referrer`. The ticket below is what stops the ones that
         * DO strip it — this is the cheap, honest second layer.
         */
        'return_referrer_block'   => 'baconbypass.xyz,bypass.city,bypass.vip,rip.linkvertise.lol,bypass.link,bypass.tools,izen.lol',
        /*
         * The per-run return ticket (migration 031) — the primary anti-bypass.
         *
         * The LootLabs `&data=` handoff points at `/done?rt=<one-time ticket>`
         * instead of one fixed landing page. Only LootLabs can hand that ticket
         * back (only it can decrypt the blob), and it is single-use, so a bare
         * `/done`, a replayed URL and a copied link all confirm nothing. Steps
         * handed off without a ticket keep the ordinary gates.
         *
         * `return_require_provider` above still applies underneath it: the
         * browser's own headers remain a second signal, never the only one.
         */
        'return_ticket_required'  => true,
        /*
         * P1-1 / P1-2 (2026-10-24). A landing that carries a return ticket is
         * confirmed only by the browser the handoff was issued to (an HttpOnly
         * per-step cookie) and from the network it was issued to (/24, /48).
         * This is what stops a server-side resolver that holds the landing URL.
         * Set false only as an emergency rollback for players who change
         * browser or network mid-task; the ticket and landing evidence remain.
         */
        'landing_bind'            => true,
        /*
         * Postback IP binding. `{IP}` in a LootLabs postback is the address that
         * did the task, so a genuine call lands on the network the handoff was
         * issued to. The step nonce travels in the player's own task URL, so
         * anyone holding that URL can echo it — but not the address it was
         * issued to, which is exactly what makes this the one signal a
         * server-side forgery cannot fake. Compared on the /24 (IPv4) / /48
         * (IPv6), so a mobile handover keeps working.
         *
         * Put an address in the allow list only if your provider reports its own
         * egress address instead of the visitor's.
         */
        'postback_ip_enforce'     => true,
        'postback_ip_allowlist'   => '',
        /*
         * Strict mode — refuse an unsigned postback unless it carries the
         * single-use step nonce (or the session id) we handed the provider.
         * With trust_provider_attribution on, an IP-only match is accepted as
         * the weakest level; a residential proxy can satisfy it, but it cannot
         * know the 128-bit nonce that travelled inside the task URL. Ships off
         * — turn on only after confirming the LootLabs dashboard's postback URL
         * carries {CLICK_ID} (the value of the &puid on the task link).
         */
        'postback_require_nonce'  => false,
        /*
         * Strict mode — refuse a cross-site landing that carries no referrer.
         * LootLabs sends `Referrer-Policy: no-referrer`, so its genuine
         * landings arrive with an empty referrer; the return ticket
         * (migration 031) already proves the landing came through their
         * decryption. Ships off. Turn on for strict behaviour.
         */
        'return_require_referrer' => false,        /*
         * Zero-tap flow (Admin → Settings → Flow & anti-bypass).
         *
         * After a step is confirmed, /done forwards the player with `zt=1`
         * and the task page hands them straight into the next task instead of
         * rendering a card that still asks for OPEN TASK & RETURN. The handoff
         * and its click clock are issued on the server *before* the redirect,
         * so the anti-bypass chain is exactly the one a tap would have used —
         * only the extra press is gone. The first task keeps its button.
         * Set false to make every step wait for a press.
         */
        'zerotap'                 => true,
        /*
         * Seconds the hand-off card counts down ("task n complete") before it
         * follows the next task's handoff. Long enough to read that the step
         * finished, short enough not to feel like a stall — the settings field
         * accepts the same 2–15 range, and the helper clamps to it either way.
         * Only used while the zero-tap flow above is on.
         */
        'zerotap_handoff_seconds' => 5,
        /*
         * The pass-through hub — the strongest form of "no extra press".
         *
         * `/go/<session>` mints the one-time step nonce, logs the hand-off and
         * stamps the click clock on the server, and with this on it then stops
         * there: the player is handed straight to the network instead of being
         * shown a page whose only content is a button asking them to confirm
         * what they already asked for. The page still exists and still does all
         * of its work — it simply has nothing to say on the way through.
         *
         * The three flow modes are a ladder, strongest first:
         *
         *   hub_pass ON                    → straight into the task
         *   hub_pass OFF + zerotap ON      → the TASK COMPLETE card, then the task
         *   hub_pass OFF + zerotap OFF     → the hand-off card and the task page
         *
         * Set false to make every step go through the intermediate page again.
         */
        'hub_pass'                => true,
        'allow_browser_postback'  => false,
        'max_step_nonce_age'     => 900,     // nonce expires after 15 min
        'max_postbacks_per_step' => 3,       // abuse threshold before flagging
        'enforce_fingerprint'    => true,    // bind a session to the browser that claimed it
        /*
         * Bypass response (staged 2026-10-24).
         *
         * A session flagged by a rejected postback, a ticket mismatch, a landing
         * with no hand-off cookie or a named link-skipping referrer gets a red
         * modal on /done, /go and /out.
         *
         * show_bypass_warning  — display the notice (staging on, production off).
         * bypass_block         — hard gate: once the session/device has
         *                        bypass_block_after serious attempts, /go, /done
         *                        and /out are refused and the code is withheld.
         *                        A verified provider postback clears the flags.
         * bypass_block_ip      — also count the last 24h of attempts from the IP.
         *                        Off: a shared carrier address must not lock a
         *                        whole household.
         * bypass_ban_after     — number used in the notice's "attempt N" copy.
         *
         * Both ship OFF here; the staging copy enables them by construction.
         */
        'show_bypass_warning'    => true,
        'bypass_block'           => true,
        'bypass_block_after'     => 2,
        'bypass_block_ip'        => false,
        'bypass_ip_window_hours' => 2,
        'bypass_warning_delay'   => 10,
        'bypass_ban_after'       => 3,

        /*
         * Postback relay (2026-10-24).
         *
         * InfinityFree challenges every external server GET, so LootLabs cannot
         * reach api/hook.php. A public relay (Cloudflare Worker) receives the
         * postback instead; the site pulls it outbound and replays it through
         * its own /api/hook.php. Set the full pull URL, including the secret:
         *   https://sfy-relay.example.workers.dev/pull?secret=...
         * Empty = relay disabled. See RELAY-SETUP.md.
         */
        'relay_pull_url'         => 'https://sfy-postback-relay.mayapatech.workers.dev/pull?secret=66528fe6f86040af9606244a670bccca09f91bc3e72849f091378ac7f89ed016',
        'relay_timeout'          => 10,

        // ── code release ───────────────────────────────────────────────
        'code_view_ttl_minutes'  => 30,      // code visible for N min after completion
        'max_code_views'         => 4,       // anti-sharing cap
        /*
         * Who may reopen a *finished* token's code?
         *   any    — any device that still holds the link, inside the window
         *            above (a fresh browser or their phone works).
         *   device — only the device that completed the tasks.
         * Whichever you pick, say so on the page: the copy follows this value.
         */
        'code_handoff'           => 'any',
        /*
         * Optional extra lock for /out/<session> (P1-4). When true the code is
         * only released to the browser that claimed the run (the sfy_sid
         * cookie). That closes a server-side fetch of the code link, but it
         * also stops the "open the code on a fresh phone" convenience of
         * code_handoff = any. Ships off; turn it on if you do not need that.
         */
        'code_bind_browser'      => false,
        /*
         * What happens when a token that is already marked USED is claimed?
         *   open    (default) — the used flag is ignored: the link works like a
         *            fresh one for everyone who holds it. The token pool (the
         *            separate code system) is what prevents duplicates, so
         *            gating here only dead-ends links that already worked.
         *   handoff — a used token only hands its code back inside the view
         *            window; a new claim is otherwise refused.
         * A token can also be marked "Reusable" individually, which reopens it
         * in HANDOFF mode too.
         */
        'token_reuse'            => 'open',

        // ── sessions ───────────────────────────────────────────────────
        'session_ttl_minutes'    => 30,
        'default_tasks_required' => 2,
        'default_account_chain'  => '1,2',

        // ── admin / staff hardening ────────────────────────────────────
        'admin_ttl_minutes'      => 90,
        'max_login_attempts'     => 5,
        'lockout_minutes'        => 15,
        'login_window_minutes'   => 10,
        'ip_login_attempts'      => 12,      // per IP, per window
        'bind_admin_to_browser'  => true,

        // ── generic rate limit ─────────────────────────────────────────
        'rate_limit_window'      => 60,
        'rate_limit_max'         => 40,
        /*
         * Client address source (P1-3).
         *
         * False = use REMOTE_ADDR only. True = honour Cloudflare / X-Real-IP /
         * X-Forwarded-For first. Those headers are trivially spoofed unless a
         * proxy in front of the site overwrites them, so this ships off. Turn
         * it on only when Cloudflare (or an equivalent) is in front.
         */
        'trust_proxy_headers'    => false,
    ],

    'lootlabs' => [
        'encrypt_url'     => 'https://creators.lootlabs.gg/api/public/url_encryptor',
        'redirect_api'    => true,           // use the redirect API (anti-bypass handoff)
        /*
         * False: when the encryptor is unreachable the handoff is refused with
         * a clear message instead of silently downgrading to a plain link with
         * no return ticket. A revenue gate must fail closed.
         */
        'fallback_plain'  => false,
        'timeout'         => 15,
    ],
];
