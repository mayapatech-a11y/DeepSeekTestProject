<?php
declare(strict_types=1);
/**
 * /api/device — device telemetry + session device binding.
 * Accepts JSON or form posts from the public pages. Never trusts the client
 * for security-relevant fields (UA and IP always come from the request).
 */
require_once dirname(__DIR__) . '/app/core.php';

sfy_install_if_empty();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sfy_json(['status' => 'error', 'reason' => 'method_not_allowed'], 405);
}
sfy_rate_limit_hit('device', sfy_client_ip());

$raw  = file_get_contents('php://input');
$data = json_decode((string)$raw, true);
if (!is_array($data)) $data = $_POST;
if (!$data) sfy_json(['status' => 'error', 'reason' => 'no_data'], 400);

$sid   = trim((string)($data['session_id'] ?? ''));
$event = trim((string)($data['event'] ?? 'heartbeat'));

$profile = sfy_device_profile($data);
$device  = sfy_device_upsert($profile, $event === 'claim');

if (!$device) sfy_json(['status' => 'error', 'reason' => 'device_rejected'], 500);

$sess = null;
if ($sid !== '' && preg_match('/^[a-f0-9]{16,64}$/i', $sid)) {
    $sess = sfy_load_session($sid);
}

if ($sess) {
    sfy_device_link_session($sid, (int)$device['id']);
    try {
        sfy_db()->prepare("UPDATE sfy_sessions SET
                device_name=COALESCE(NULLIF(?,''), device_name),
                device_fingerprint=COALESCE(NULLIF(?,''), device_fingerprint),
                screen_resolution=COALESCE(NULLIF(?,''), screen_resolution),
                timezone=COALESCE(NULLIF(?,''), timezone),
                language=COALESCE(NULLIF(?,''), language),
                country=COALESCE(NULLIF(?,''), country),
                user_agent=COALESCE(NULLIF(?,''), user_agent)
            WHERE session_id=?")
           ->execute([
               (string)$data['device_name'], (string)($data['device_fingerprint'] ?? ''),
               (string)($data['screen_resolution'] ?? ''), (string)($data['timezone'] ?? ''),
               (string)($data['language'] ?? ''), $profile['country'], sfy_user_agent(), $sid,
           ]);
    } catch (Throwable $e) { error_log('[SFY] device session update: ' . $e->getMessage()); }
}

if ($event === 'code_view' && $sess) {
    sfy_device_bump((int)$device['id'], 'code_views', 1);
}

sfy_json([
    'status'  => 'ok',
    'device'  => [
        'id'      => (int)$device['id'],
        'key'     => (string)$device['device_key'],
        'name'    => (string)$device['device_name'],
        'os'      => (string)$device['os'],
        'browser' => (string)$device['browser'],
        'country' => (string)$device['country'],
        'success' => (int)$device['success_count'],
    ],
    'success' => (int)$device['success_count'],
]);
