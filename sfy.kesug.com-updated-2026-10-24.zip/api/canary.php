<?php
declare(strict_types=1);
/**
 * Temporary canary — logs every request to storage/canary.log
 * so we can prove LootLabs is firing postbacks at all.
 * DELETE THIS FILE when done.
 */

$line = date('c')
      . ' | ' . ($_SERVER['REQUEST_METHOD'] ?? '?')
      . ' | ip=' . ($_SERVER['REMOTE_ADDR'] ?? '?')
      . ' | ua=' . substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 80)
      . ' | qs=' . substr((string)($_SERVER['QUERY_STRING'] ?? ''), 0, 500)
      . "\n";

@file_put_contents(__DIR__ . '/../storage/canary.log', $line, FILE_APPEND);

header('Content-Type: text/plain');
echo "ok\n";