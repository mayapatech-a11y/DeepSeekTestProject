<?php
declare(strict_types=1);
/**
 * /api/ad — impression / click / dismiss counter for the ad slots.
 * Always answers 204 so a beacon never blocks the page.
 */
require_once dirname(__DIR__) . '/app/core.php';

$id   = sfy_int('id');
$kind = sfy_param('a', 'imp');

if ($id > 0 && in_array($kind, ['imp', 'click', 'dis'], true)) {
    sfy_ad_track($id, $kind);
}

if (!headers_sent()) http_response_code(204);
exit;
