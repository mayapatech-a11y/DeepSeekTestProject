<?php
declare(strict_types=1);
/**
 * /api/hook — LootLabs postback receiver.
 *
 * Verification chain (any failure is logged and ignored):
 *   1. locate the open step handoff (nonce → session hint → same IP + window)
 *   2. session must be unfinished and live
 *   3. the step must match the session's current step
 *   4. dwell time on the task must exceed the configured minimum
 *   5. the per-step HMAC signature (or the account's own hash) must match
 *   → then, and only then, the nonce is consumed and the step advances.
 *
 * A call opened in a browser (a typed/pasted postback URL) is refused before
 * any of that: see sfy_postback_browser_navigation().
 */
require_once dirname(__DIR__) . '/app/core.php';

sfy_install_if_empty();

header('X-Robots-Tag: noindex');

/*
 * Reachability probe — `/api/hook.php?ping=1` (or `/postback?ping=1`).
 *
 * This answers the one question you cannot answer from inside a hosting
 * account: is the postback receiver actually reachable from the outside? If
 * the provider (or the admin's Postback Doctor) gets JSON back, the URL is
 * fine and the problem is the parameters; if it gets the host's own error or
 * challenge page, the URL never reached PHP at all.
 * Read-only: it touches no session, no nonce and no log row.
 */
if (sfy_param('ping') === '1' || sfy_param('health') === '1') {
    /* Doubles as a deploy check: this one URL says whether the upload landed
       and whether the schema updates behind it were applied. */
    $upgrade = sfy_try(function (): array {
        $pending = array_keys(sfy_migrations_pending());
        return [
            'pending_migrations' => count($pending),
            'latest_migration'   => $pending ? (string)end($pending) : 'none',
            'step_clicked_at'    => sfy_column_exists('sfy_step_tokens', 'clicked_at'),
            'step_returned_at'   => sfy_column_exists('sfy_step_tokens', 'returned_at'),
            'anti_bypass_columns'=> sfy_column_exists('lootlabs_accounts', 'redirect_api'),
            'return_check'       => sfy_return_check_state()['mode'],
            'return_provider_gate' => sfy_return_check_state()['require_provider'],
            'return_provider_hosts'=> implode(',', sfy_return_referrer_hosts()),
            'anti_bypass_mode'   => sfy_redirect_api_mode(),
            /* The per-run return ticket (migration 031) and the two gates that
               ride with it — a deploy check that answers "is the anti-bypass
               actually armed here?" in the same request. */
            'step_return_ticket' => sfy_column_exists('sfy_step_tokens', 'return_ticket'),
            'return_ticket_gate' => sfy_return_check_state()['require_ticket'],
            'postback_ip_binding'=> sfy_postback_ip_enforced(),
            'referrer_blocklist' => implode(',', sfy_return_referrer_blocklist()),
        ];
    }, ['pending_migrations' => -1]);

    $payload = [
        'status'   => 'alive',
        'service'  => 'sfy-postback',
        'version'  => SFY_VERSION,
        /* Which revision of the code is *actually* running here. Compare with
           `php -r 'require "app/core.php"; echo sfy_app_fingerprint();'` after
           an upload — a stale file keeps answering with the old error and no
           page can show that. */
        'build'    => sfy_app_fingerprint(),
        'time'     => date('c'),
        'schema'   => sfy_table_exists('sfy_step_tokens'),
        'upgrade'  => $upgrade,
        'hint'     => 'Receiver reachable. Next: open this same URL with ?click_id=test&unique_id=test&acct=1 '
                    . '(the parameter shape LootLabs sends) and check Admin → Accounts → POSTBACK DOCTOR '
                    . 'for the logged call.',
    ];

    /* Owner-only (see sfy_diag_report): with ?sfy_key=<app.app_key> this same
       URL also answers "what is actually breaking?" — log tail, live table
       DDL, sql_mode, and with &probe=1 a real session INSERT with cleanup. */
    $diag = sfy_diag_report(sfy_param('probe') === '1');
    if ($diag) {
        $payload['diagnostics'] = $diag;
        $payload['hint'] = 'Diagnostics attached (owner key accepted). session_insert.ok=false '
                         . 'names the exact statement that stops a run.';
    }

    sfy_json($payload);
}

/* P1-6 (2026-10-24): a cheap ceiling. All provider calls share the provider's
   egress, so keep it generous — this is a runaway-loop guard, not a gate. */
if (!sfy_rate_limit('postback', 240, 60)) {
    sfy_json(['status' => 'error', 'reason' => 'rate_limited'], 429);
}

/*
 * The postback URL must be called by the provider, not opened in a browser.
 * The step nonce is visible in the player's own task URL, so "paste the
 * postback URL into the address bar" was a working bypass of the whole gate.
 * A real callback (server-to-server, or a client-side XHR/pixel) is not a
 * document navigation and is unaffected — see sfy_postback_browser_navigation().
 */
if (sfy_postback_browser_navigation()) {
    sfy_try(function () {
        $db = sfy_db();
        $cols = ['unique_id','nonce','accepted','verified','reason','user_agent','raw_query','created_at'];
        $vals = [substr(sfy_param_any(['unique_id','session_id','sid','uid','user_id','custom','custom_id','s1','subid']), 0, 128),
                 substr(sfy_param_any(['sub_id','nonce','s2','subid_2']), 0, 64),
                 0, 0, 'browser_navigation', sfy_user_agent(),
                 substr((string)($_SERVER['QUERY_STRING'] ?? ''), 0, 2000)];
        $marks = [];
        foreach ($cols as $c) $marks[] = $c === 'created_at' ? 'NOW()' : '?';
        $db->prepare('INSERT INTO sfy_postback_log (' . implode(',', $cols) . ') VALUES (' . implode(',', $marks) . ')')
           ->execute($vals);
        return null;
    }, null);

    error_log('[SFY] postback refused: opened in a browser, not called by the provider');
    sfy_json(['status' => 'error', 'reason' => 'browser_navigation',
              'hint'   => 'postbacks must be called by the provider; this URL was opened in a browser'], 400);
}

$clickId  = sfy_param_any(['click_id', 'clickid', 'clickId', 'cid']);
$ip       = sfy_param_any(['ip', 'user_ip', 'ip_address'], sfy_client_ip());
$sidHint  = sfy_param_any(['unique_id', 'session_id', 'sid', 'uid', 'user_id', 'custom', 'custom_id', 's1', 'subid']);
/*
 * `click_id` is a nonce candidate on purpose. LootLabs documents exactly three
 * postback macros — `{CLICK_ID}`, `{IP}`, `{UNIQUE_ID}` — and the only value it
 * hands back that we control is the `&puid` we put on the task link, which is
 * documented to arrive as `click_id`. That is where the single-use step nonce
 * travels, so reading it here is what lets a real LootLabs postback name the
 * exact step. A network that echoes its own click id instead simply misses the
 * nonce lookup and falls through to the session hint, exactly as before.
 */
$nonce    = sfy_param_any(['sub_id', 'nonce', 's2', 'subid_2', 'click_id', 'clickid', 'clickId', 'cid']);
$acctHint = sfy_param_any(['acct', 'account', 'account_id']);
$sig      = sfy_param_any(['sig', 'signature']);
$hash     = sfy_param('hash');
/* P0-1 (2026-10-24): the per-account key from the postback URL. It is the only
   value in this request that never reaches a player's browser. */
$key      = sfy_param('key');

$rawQuery = substr((string)($_SERVER['QUERY_STRING'] ?? ''), 0, 2000);

/* Session hint may arrive as a token instead of an id. */
if ($sidHint !== '' && !preg_match('/^[a-f0-9]{16,64}$/i', $sidHint)) {
    try {
        $st = sfy_db()->prepare("SELECT session_id FROM sfy_sessions WHERE token=? ORDER BY created_at DESC LIMIT 1");
        $st->execute([$sidHint]);
        if ($r = $st->fetch()) $sidHint = (string)$r['session_id'];
    } catch (Throwable $e) { /* keep the raw hint */ }
}

$result = sfy_postback_verify((string)$sidHint, (string)$nonce, (string)$acctHint,
                              (string)$sig, (string)$ip, (string)$hash, (string)$key);

$sess = $result['session'];
$row  = $result['step_token'];
$acct = $result['account'];

/* ── always log the attempt ────────────────────────────────────────── */
try {
    $cols = ['session_id','account_id','step','click_id','ip','unique_id','nonce','dwell',
             'accepted','verified','reason','user_agent','raw_query','created_at'];
    $vals = [
        $sess['session_id'] ?? ($sidHint !== '' ? $sidHint : null),
        (int)($acct['id'] ?? ($row['account_id'] ?? 0)),
        (int)($row['step'] ?? 0),
        substr($clickId, 0, 128),
        substr($ip, 0, 64),
        substr($sidHint, 0, 128),
        substr((string)$nonce, 0, 64),
        isset($result['dwell']) ? (int)$result['dwell'] : null,
        $result['ok'] ? 1 : 0,
        in_array($result['level'], ['verified', 'ip_changed'], true) ? 1 : 0,
        substr((string)$result['reason'], 0, 64),
        sfy_user_agent(),
        $rawQuery,
    ];
    if (sfy_column_exists('sfy_postback_log', 'attribution')) {
        $cols[] = 'attribution';
        $vals[] = substr((string)($result['attribution'] ?? ''), 0, 24);
    }
    $marks = [];
    foreach ($cols as $c) $marks[] = $c === 'created_at' ? 'NOW()' : '?';
    sfy_db()->prepare('INSERT INTO sfy_postback_log (' . implode(',', $cols) . ')
                       VALUES (' . implode(',', $marks) . ')')->execute($vals);
} catch (Throwable $e) { error_log('[SFY hook] log: ' . $e->getMessage()); }

/* ── rejected ─────────────────────────────────────────────────────── */
if (!$result['ok']) {
    $level = (string)$result['level'];

    if ($sess && $level === 'bypass') {
        sfy_session_flag((string)$sess['session_id'], 'postback_' . $result['reason'], 30);
        if ((int)($sess['device_id'] ?? 0) > 0) sfy_device_bump((int)$sess['device_id'], 'fail_count', 1);
    } elseif ($sess && $level !== 'ignore' && (int)($sess['device_id'] ?? 0) > 0) {
        sfy_device_bump((int)$sess['device_id'], 'fail_count', 1);
    }

    $code = $level === 'ignore' ? 200 : ($level === 'bypass' ? 403 : 400);
    sfy_json([
        'status' => $level === 'ignore' ? 'ignored' : 'error',
        'reason' => $result['reason'],
        'level'  => $level,
    ], $code);
}

/* ── accepted ─────────────────────────────────────────────────────── */
$out = sfy_postback_consume($row, $sess, $acct ?: [], $clickId, $ip, (int)($result['dwell'] ?? 0));

if (empty($out['advanced'])) {
    /* The write did not land, so the nonce stayed open on purpose. Answer with
       a retryable status: a provider that re-delivers the postback will
       succeed, and nothing was recorded as a step completion. */
    sfy_json([
        'status' => 'error',
        'reason' => 'advance_failed',
        'level'  => 'accept',
        'retry'  => true,
    ], 503);
}

/*
 * A verified, key-authenticated provider postback is the proof the hard block
 * was waiting for: clear the flags so /out can release the code. The return
 * check never clears them.
 */
sfy_session_clear_flags((string)$sess['session_id']);

/*
 * Credit the finished flow to the device that claimed the session. Never
 * build a device from the postback request itself — that would be the
 * provider's server, not the player. (Shared with the return check so both
 * paths credit identically.)
 */
sfy_try(function () use ($sess, $out) { sfy_completion_credit($sess, (bool)$out['completed']); return null; }, null);

sfy_json([
    'status'       => 'ok',
    'verified'     => true,
    'session_id'   => $sess['session_id'],
    'step_done'    => (int)$row['step'],
    'new_step'     => $out['new_step'],
    'total_steps'  => $out['total'],
    'completed'    => $out['completed'],
    'redirect'     => $out['completed'] ? sfy_url('out/' . $sess['session_id']) : sfy_url('go/' . $sess['session_id']),
]);
