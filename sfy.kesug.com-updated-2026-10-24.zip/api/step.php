<?php
declare(strict_types=1);
/**
 * /api/step — the task page's helper endpoint.
 *   a=start  → marks the exact click moment so the dwell-time gate is accurate
 *   a=status → polled by the task/return pages to find out what the postback did.
 *              Callers pass cur=<the step they are showing>; a step the page
 *              already displays is never reported back as an advance (that
 *              mismatch is what made /go reload itself in a loop).
 *   a=reset  → throws the progress away and restarts the session at step 1
 * No action here can advance a step on its own. A step moves on a postback
 * (/api/hook) or on a return: /done records the provider landing, and a=status
 * only picks up the confirmation once the dwell has passed. This endpoint can
 * never *record* a return — its requests come from a page the player is already
 * on, which is exactly what a console fetch or a shared URL looks like.
 */
require_once dirname(__DIR__) . '/app/core.php';

sfy_install_if_empty();

$a   = sfy_param('a', 'status');
$sid = sfy_param('sid');
if ($sid === '') $sid = sfy_param('session_id');

if ($sid === '' || !preg_match('/^[a-f0-9]{16,64}$/i', $sid)) {
    sfy_json(['status' => 'error', 'reason' => 'bad_session'], 400);
}

$sess = sfy_load_session($sid);
if (!$sess) sfy_json(['status' => 'error', 'reason' => 'not_found'], 404);

/* ── mark the click ────────────────────────────────────────────────── */
if ($a === 'start') {
    $nonce = sfy_param('n', sfy_param('nonce'));
    $db    = sfy_db();

    if ($nonce !== '') {
        $st = $db->prepare("SELECT id FROM sfy_step_tokens WHERE session_id=? AND nonce=? AND consumed_at IS NULL LIMIT 1");
        $st->execute([$sid, $nonce]);
        if (!$st->fetch()) sfy_json(['status' => 'error', 'reason' => 'nonce_closed'], 409);
    } else {
        $st = $db->prepare("SELECT id FROM sfy_step_tokens WHERE session_id=? AND consumed_at IS NULL ORDER BY step DESC LIMIT 1");
        $st->execute([$sid]);
        if (!$st->fetch()) sfy_json(['status' => 'error', 'reason' => 'no_open_step'], 409);
    }

    /* The same clock the zero-tap handoff stamps server-side — one
       implementation, so a tapped step and an auto-opened one are measured
       identically by the return check. */
    sfy_step_begin($sid, $nonce);
    sfy_json(['status' => 'ok', 'started' => true,
              'min_dwell' => sfy_setting_int('min_task_seconds', 4),
              'return_dwell' => sfy_return_check_state()['dwell']]);
}

/* ── strict landing timed out: record the bypass attempt ───────────── */
if ($a === 'warn') {
    $rc = sfy_return_check_state();
    if (empty($rc['require_postback'])) {
        sfy_json(['status' => 'ignored', 'reason' => 'not_strict']);
    }
    if ((int)($sess['is_completed'] ?? 0) === 1 || sfy_session_is_expired($sess)) {
        sfy_json(['status' => 'ignored', 'reason' => 'closed']);
    }
    /* One flag per session; a refresh of the warning must not inflate it. */
    $flags = (int)($sess['bypass_flags'] ?? 0);
    if ($flags < 1) {
        sfy_session_flag($sid, 'bypass_strict_landing', 25);
        /* A rejected-row entry so the optional IP cooldown sees it too. */
        sfy_log_return_reject($sid, $sess, 'strict_landing', 'postback_required');
        $flags = 1;
    }
    sfy_json(['status' => 'ok', 'recorded' => true, 'flags' => $flags]);
}

/* ── restart a stuck flow from step 1 ──────────────────────────────── */
if ($a === 'reset') {
    $r = sfy_session_reset_flow($sid);
    if (empty($r['ok'])) {
        /* A finished session cannot be reset to step 1 — answer with where its
           code lives so the button is never a dead end. */
        sfy_json(['status' => 'error', 'reason' => (string)($r['reason'] ?? 'error'),
                  'redirect' => (string)($r['redirect'] ?? '')], 400);
    }
    sfy_json(['status' => 'reset', 'session_id' => $sid, 'redirect' => (string)$r['redirect']]);
}

/*
 * ── return check ────────────────────────────────────────────────────
 * The provider lands the player back on /done. The pages poll this endpoint
 * with ret=1 so a step whose click has since grown old enough can be picked up
 * without a postback — the fallback that keeps a postback-less install usable.
 * This endpoint never records the return itself: `returned_at` is written by
 * /done, and only when the request proves the provider sent the player there
 * (sfy_return_landing_evidence()). A poll can therefore only collect a
 * confirmation that was already earned. Off automatically the moment real
 * postbacks start arriving.
 */
$state = sfy_return_check_state();
$soft  = null;
if (sfy_param('ret') === '1') {
    /* Pull any postback the relay is holding, then replay it through the
       local receiver. The loopback is the server's own request, which the
       host does not challenge. */
    if (function_exists('sfy_relay_pull')) {
        sfy_relay_pull();
        $sess = sfy_load_session($sid) ?: $sess;
    }
    $soft = sfy_step_advance_soft($sid, 'return');
    if (!empty($soft['ok'])) {
        $sess = sfy_load_session($sid) ?: $sess;
    }
}

/* ── status poll ───────────────────────────────────────────────────── */
$step  = max(1, (int)($sess['current_step'] ?? 1));
$total = max(1, (int)($sess['total_steps'] ?? 1));

/* Which step is the page asking *about*? Without it a poll cannot tell "the step
   you are showing is done" from "you are behind" — and the first page to get
   that wrong reloads itself in a loop. See sfy_step_status_decision(). */
$cur = max(0, (int)sfy_param('cur', '0'));
$dec = sfy_step_status_decision($step, $total, (int)($sess['is_completed'] ?? 0) === 1, $cur, $sid);

if ($dec['status'] === 'completed') {
    sfy_json(['status' => 'completed', 'step' => $dec['step'], 'total_steps' => $dec['total'],
              'redirect' => $dec['redirect']]);
}

if ($dec['status'] === 'advanced') {
    sfy_json(['status' => 'advanced', 'step_done' => (int)($dec['step_done'] ?? $cur),
              'step' => $dec['step'], 'total_steps' => $dec['total'], 'redirect' => $dec['redirect']]);
}

/* Postbacks the provider sent that we refused — a refused *landing* is a
   different thing and has its own note below. */
$st = sfy_db()->prepare("SELECT COUNT(*) AS n FROM sfy_postback_log
                         WHERE session_id=? AND accepted=0 AND reason<>'return_rejected'
                           AND created_at > DATE_SUB(NOW(), INTERVAL 10 MINUTE)");
$st->execute([$sid]);
$rejects = (int)($st->fetch()['n'] ?? 0);

$ret = is_array($soft) && empty($soft['ok']) ? $soft : null;

sfy_json([
    'status'      => 'pending',
    'reason'      => $rejects > 0 ? 'postback_rejected' : 'awaiting_postback',
    'rejects'     => $rejects,
    'step'        => $dec['step'],
    'total_steps' => $dec['total'],
    'cur'         => $cur,
    'expires_at'  => (string)($sess['expires_at'] ?? ''),
    'return_check'=> $state['active'] ? 'on' : 'off',
    'return_note' => is_array($ret) ? (string)($ret['reason'] ?? '') : '',
    'wait'        => is_array($ret) ? (int)($ret['wait'] ?? 0) : 0,
]);
