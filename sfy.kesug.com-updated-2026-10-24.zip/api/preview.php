<?php
declare(strict_types=1);
/**
 * /api/preview — stores an *unsaved* draft of the appearance, homepage layout
 * or footer in the admin's session so the live-preview iframe can render it.
 * Nothing here touches the database; saving is a separate, CSRF-checked POST.
 */
require_once dirname(__DIR__) . '/app/core.php';

if (!headers_sent()) header('Cache-Control: no-store');

if (!sfy_admin_current()) {
    sfy_json(['status' => 'error', 'reason' => 'auth', 'detail' => 'Sign in to the admin panel first.'], 403);
}

$raw = (string)file_get_contents('php://input');
$in  = json_decode($raw, true);
if (!is_array($in)) {
    sfy_json(['status' => 'error', 'reason' => 'bad_json'], 400);
}

if (!sfy_csrf_check((string)($in['csrf'] ?? ''))) {
    sfy_json(['status' => 'error', 'reason' => 'csrf', 'detail' => 'Reload the admin page.'], 419);
}

$part = (string)($in['part'] ?? '');
$data = $in['data'] ?? null;

switch ($part) {
    case 'appearance':
        $_SESSION['sfy_appearance_draft'] = is_array($data) ? $data : null;
        break;
    case 'layout':
        $_SESSION['sfy_layout_draft'] = is_array($data) ? ($data['sections'] ?? []) : [];
        break;
    case 'footer':
        $_SESSION['sfy_footer_draft'] = is_array($data) ? $data : [];
        break;
    case 'clear':
        unset($_SESSION['sfy_appearance_draft'], $_SESSION['sfy_layout_draft'], $_SESSION['sfy_footer_draft']);
        break;
    default:
        sfy_json(['status' => 'error', 'reason' => 'unknown_part'], 400);
}

sfy_json(['status' => 'ok', 'part' => $part, 'at' => time()]);
